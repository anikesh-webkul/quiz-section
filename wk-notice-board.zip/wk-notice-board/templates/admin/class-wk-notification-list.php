<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Notification_List' ) ) {

	class Notification_List extends WP_List_Table {

		public function __construct() {
			global $status, $page;
			parent::__construct(array(
				'singular' => 'Notification',     //singular name of the listed records
				'plural'   => 'Notifications',   //plural name of the listed records
				'ajax'     => false,        //does this table support ajax?=
			));
			add_action( 'admin_head', array( &$this, 'adminHeader' ) );
		}

		public function adminHeader() {
			$curr_page = ( isset( $_GET['page'] ) ) ? wp_unslash( $_GET['page'] ) : false;
			if ( 'webkul-notifications' !== $curr_page ) {
				return;
			}
		}

		public function no_items() {
			esc_html_e( 'No Notification found, sorry!' );
		}

		public function column_default( $item, $column_name ) {
			switch ( $column_name ) {
				// case 'id':
				case 'title':
				case 'banner_text':
				case 'link':
				case 'status':
					return $item[ $column_name ];
				default:
					// return print_r( $item, true ); //Show the whole array for troubleshooting purposes
			}
		}

		public function get_sortable_columns() {
			$sortable_columns = array(
				'title' => array( 'title', false ),
				// 'id'    => array( 'id', false ),
			);
			return $sortable_columns;
		}
		public function column_status( $items ) {
			$items['status'] = ( 'enable' == $items['status'] ) ? 'Enabled' : 'Disabled';
			return $items['status'];
		}

		public function get_columns() {
			$columns = array(
				'cb'          => '<input type="checkbox" />',
				// 'id'          => 'id',
				'title'       => __( 'Notification Title' ),
				'banner_text' => _( 'Notification Text' ),
				'link'        => __( 'Notification Link' ),
				'status'      => __( 'Status' ),
			);
			return $columns;
		}

		public function usort_reorder( $a, $b ) {
			$orderby = ( ! empty( $_GET['orderby'] ) ) ? $_GET['orderby'] : 'id';
			$order   = ( ! empty( $_GET['order'] ) ) ? $_GET['order'] : 'desc';
			$result  = strcmp( strtolower( $a[ $orderby ] ), strtolower( $b[ $orderby ] ) );
			return ( 'DESC' === $order ) ? $result : -$result;
		}

		public function column_title( $item ) {
			if ( 'enable' === $item['status'] ) {
				$actions = array(
					'enable' => sprintf( '<a href="?page=%s&action=%s&id=%s">Disable</a>', wp_unslash( $_REQUEST['page'] ), 'disable', $item['id'] ),
				);
			} elseif ( 'disable' === $item['status'] ) {
				$actions = array(
					'disable' => sprintf( '<a href="?page=%s&action=%s&id=%s">Enable</a>', wp_unslash( $_REQUEST['page'] ), 'enable', $item['id'] ),
				);
			}
			$actions['edit'] = sprintf( '<a href="?page=add-notifications&id=%s">Edit</a>', $item['id'] );
			$actions         = array_reverse( $actions );
			return sprintf( '%1$s %2$s', _wk_remove_slashes( $item['title'] ), $this->row_actions( $actions ) );
		}
		public function column_banner_text( $item ) {
			return _wk_remove_slashes( $item['banner_text'] );

		}

		public function get_bulk_actions() {
			$actions = array(
				'enable'  => __( 'Enable' ),
				'disable' => __( 'Disable' ),
				'delete'  => __( 'Delete' ),
			);
			return $actions;
		}

		public function get_hidden_columns() {
			return array();
		}

		public function process_bulk_action() {
			global $wpdb;
			$table_name = $wpdb->prefix . 'banner_list';
			if ( isset( $_GET['id'] ) && ! empty( $_GET['id'] ) ) {
				$temp_id = ( is_array( $_GET['id'] ) ) ? wp_unslash( $_GET['id'] ) : explode( ' ', (int) $_GET['id'] );
				foreach ( $temp_id as $key => $value ) {

					if ( 'enable' === $this->current_action() ) {

						$wpdb->update( $table_name, array( 'status' => 'enable','auto_disable'=>'' ), array( 'id' => $value ), array( '%s' ), array( '%d' ) );

					} elseif ( 'disable' === $this->current_action() ) {
						$wpdb->update( $table_name, array( 'status' => 'disable', 'priority' => '10000' ), array( 'id' => $value ), array( '%s' ), array( '%d' ) );

					} elseif ( 'delete' === $this->current_action() ) {
						$wpdb->delete( $table_name, array( 'id' => $value ) );
					}
					wp_safe_redirect( '?page=webkul-notifications' );

				}
			}
		}

		public function column_cb( $item ) {
			return sprintf(
				'<input type="checkbox" name="id[]" value="%s" />',
				$item['id']
			);
		}

		private function notification_data() {
			global $wpdb;
			$table_name = $wpdb->prefix . 'banner_list';
			if ( isset( $_REQUEST['s'] ) && ! empty( $_REQUEST['s'] ) ) {
					$search     = wp_unslash( $_REQUEST['s'] );
					$search     = trim( $search );
					$table_data = $wpdb->get_results( "SELECT * FROM $table_name WHERE CONCAT_ws( title, banner_text ) LIKE '%$search%' ORDER BY id DESC", ARRAY_A );
			} else {
					$table_data = $wpdb->get_results( "SELECT * from $table_name ORDER BY id DESC", ARRAY_A );
			}
			return $table_data;
		}

		public function prepareItems() {
			global $wpdb;
			$columns  = $this->get_columns();
			$hidden   = $this->get_hidden_columns();
			$sortable = $this->get_sortable_columns();
			$this->process_bulk_action();
			$this->_column_headers = array( $columns, $hidden, $sortable );
			$temp_prepare_data     = $this->notification_data();
			usort( $temp_prepare_data, array( $this, 'usort_reorder' ) );
			$per_page     = $this->get_items_per_page( 'notification per page', 10 );
			$current_page = $this->get_pagenum();
			$total_items  = count( $temp_prepare_data );
			// only ncessary because we have sample temp_prepare_data
			$found_data = array_slice( $temp_prepare_data, ( ( $current_page - 1 ) * $per_page ), $per_page );
			$this->set_pagination_args(array(
				'total_items' => $total_items,                  //WE have to calculate the total number of items
				'per_page'    => $per_page,                 //WE have to determine how many items to show on a page
			));
			$this->items = $found_data;
		}

	}

	$notification_list = new Notification_List;
	echo '<div class="wrap"><h1 class="wp-heading-inline">Notifications</h1>';
	$notification_list->prepareItems();
	$path = admin_url(); ?>
	<a href= <?php echo esc_url( $path ) . 'admin.php?page=add-notifications'; ?> class="page-title-action">Add New</a>
	<form method="get">
	<input type="hidden" name="page" value="webkul-notifications">
	<?php
	$notification_list->search_box( 'search', 'search_id' );
	$notification_list->display();
	echo '</form></div>';

	
}
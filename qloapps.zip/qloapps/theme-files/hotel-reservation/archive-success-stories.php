<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();
?>

<section class="wk-header-wrapper wk-common-padding">
	<div class="container">
		<div class="row">
      <div class="col-md-1"></div>
      <div class="col-md-10">
				<div class="qlo-content-padd text-center">
					<h1>Share the story behind your success with QloApps.</h1>
					<p class="head-detail">Every success has a beautiful story behind it. Please let us know how QloApps was able to help you out in attaining what you desired. Your story will be our fuel and motivation to work even harder. Let us serve the hotel industry together.</p>
					<a href="<?php echo home_url('/register-success-story'); ?>" class="sugg-btn white btn-bgcolor btn-download-ext">Submit your site</a>
				</div>
			</div>
      <div class="col-md-1"></div>
		</div>
	</div>
</section>
<section class="wk-common-padding wk-clients-section border-shadow">
	<div class="container">
		<div class="row">
      <div class="col-md-12">
				<h1 class="text-center">Our Clients stories</h1>
				<?php

						$query_args = array(

							'post_type'=>'success-stories',
							'post_status'=>'publish',
							'order'=>'ASC',
							'posts_per_page' => -1

						);

						$the_query = new WP_Query( $query_args );

							if ( $the_query->have_posts() ) :

				        while($the_query->have_posts() ) :

									$the_query-> the_post();

									$customer_desig 	= get_post_meta( get_the_ID(), 'customer-designation', true);
									$customer_url 		= get_post_meta( get_the_ID(), 'partner-url', true);
									$customer_logo 		= get_post_meta( get_the_ID(), 'partner-logo', true);
									$customer_country = get_post_meta( get_the_ID(), 'partner-country', true);
									$customer_flag 		= get_post_meta( get_the_ID(), 'country-image', true);

									?>

									<a href="<?php echo get_the_permalink(); ?>" class="wk-clients">
										<div class="wk-client-content">

											<?php

											if( ! empty( $customer_logo ) ){
											?>

												<img src="<?php echo esc_url( $customer_logo ); ?>">

											<?php
											}
											?>

				            	<h4><?php echo get_the_title(); ?></h4>

											<?php

											if( ! empty( $customer_desig ) ){
												?>

												<p><?php echo esc_attr( $customer_desig );?></p>

												<?php
											}

											?>
										</div>
				            <div class="wk-client-link">
											<?php
											if( ! empty( $customer_country ) ){
											?>

												<p><?php echo esc_attr( $customer_country ); ?></p>

											<?php
											}

											if( ! empty( $customer_flag ) ){
											?>

												<img src="<?php echo esc_url( $customer_flag ); ?>">

											<?php
											}
											?>
				            </div>
				          </a>

									<?php
								endwhile;

								else:

							      echo '<div class="no-data text-center"><span class="label label-success">We are Writting And will be here soon..</span></div>';

							endif;
							?>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();?>

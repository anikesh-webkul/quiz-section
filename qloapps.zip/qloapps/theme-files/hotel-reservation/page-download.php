<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();

$ip = isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
$ip = explode(',',$ip);
$ip = $ip['0'];
$countryData = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));


$countryCode = ( ! empty( $countryData['geoplugin_countryCode'] ) ) ? $countryData['geoplugin_countryCode'] : '';
$countryCode = 'IN';

// Merchant key here as provided by PayUMoney
/* Live Key PlTOcn*/
/* Test Key  rjQUPktU */
$MERCHANT_KEY = "PlTOcn";


// End point - change to https://secure.payu.in for if LIVE mode
/* Test url https://test.payu.in
*/
/**/
$PAYU_BASE_URL = "https://secure.payu.in";
$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";

$action = $PAYU_BASE_URL . '/_payment';

?>
<section class="download-section wk-common-padding">
		<div class="container">
				<div class="row">
						<div class="col-md-6 col-sm-6">
								<div class="description">
										<h1>Download qloapps for free & start your hotel eCommerce...</h1>
										<ul>
												<li>Free to Use</li>
												<li>Launch your Personal Hotel Booking Site</li>
												<li>Upload Unlimited Rooms & Hotels</li>
												<li>On Desk Booking (Reception Booking)</li>
												<li>Multi language & Currency</li>
												<li>Status & Stats Management</li>
										</ul>
								</div>
						</div>
						<div class="col-md-1"></div>
						<div class="col-md-5 col-sm-6">
								<div class="download-form">
									<?php

									session_start();

									// if( true ) {

									if( isset( $_GET['success']) && ( $_GET['success'] != ''  ) ) {

										global $wp;

										if(isset($_SESSION['page_reload'])){

											$_SESSION['page_reload'] = $_SESSION['page_reload'];
										}
										else{
											$_SESSION['page_reload'] = "true";
										}

										$donater_country = ( 'IN' === $countryCode ) ? 'INR ' : '$';

										$page = home_url( $wp->request );

										$url_var = $_GET['success'];

										$url_var = explode('_',$url_var);

										$message = 'Qloapp is sponsored';

										if (isset($url_var[1]) && $url_var[1]) {
												$message .= ' by '.$url_var[1];
										}

										$message .= ' and amount is ' . $donater_country . $url_var[0];

										if (isset($url_var[2]) && $url_var[2]) {
												$message .= "\n" . 'Email : ' . $url_var[2];
										}

										if($_SESSION['page_reload']=="true"){

											// wp_mail( 'rohit053@webkul.com', 'QloApps Sponsored - USD '.$url_var[0] , $message );
											$recipients = array('rohit053@webkul.com','vinayrks@webkul.com');
											wp_mail( $recipients, 'QloApps Sponsored - ' . $donater_country . $url_var[0] , $message );
											$_SESSION['page_reload'] =  "false";
										 }
										 else{

											header("Location:$page");

										}

										?>
										<div style='height:231px;text-align:center;margin:0px auto;'>
											<div style='font-size:28px;font-weight:300;color: #333333;'>
												Thank You for Sponsoring us
											</div>
											<p style='font-style:normal;font-weight:400; font-size:16px; color: #444;padding: 5px 25px 10px;'>
												You have successfully sponsored us the amount of <?php echo ( 'IN' === $countryCode ) ? '&#x20b9;' . $url_var[0] : '$' . $url_var[0]; ?>, now you can proceed to download QloApps.
											</p>
											<form method="post" id="form-download" action="" >
												<input type="hidden" id="name" value="<?php echo( $url_var[1] )?>">
												<input type="hidden" id="email" value="<?php echo( urldecode($url_var[2]) )?>">
												<input name="download_file" id="download" type="submit" value="Download Qloapps v<?php echo get_option('latest_version_value'); ?>">
											</form>
										</div>

										<?php

								} else {
									unset($_SESSION['page_reload']);
									// var_dump($_SESSION['page_reload']);
									?>
									<form method="post" id="form-download"  name="payuForm">
										<h3>You're just one click away....</h3>
										<h5>Download qloapps & it's ready to launch a whole new hotel booking eCommerce site.</h5>
										<input type="text" id="firstname" name="firstname" placeholder="First Name" value="" />
										<input type="text" id="lastname" class="float-right" name="lastname" placeholder="Last Name" value="" />
										<input type="text" id="email" class="full-width" name="email" placeholder="Your Email" value="" />
										<input type="submit" name="download_file"  id="download" value="Download Qloapps v<?php echo( get_option( 'latest_version_value' ) ); ?>" />
										<p></p>
									</form>
									<?php
								}
								?>
								</div>
						</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="wk-sponsor-block ">
							<h2>Let's make Qloapps more better, Together...</h2>
							<h3>Sponsor us so you can be a part of making QloApps more better for its next release.</h3>
							<?php
							if( ! isset( $_GET['success']) ) {

							}
							?>
								<form method="post" id="form-sponsor" name="payuForm" class="wk-sponsor-form" action="<?php echo $action; ?>">
									<?php
									if( 'IN' === $countryCode ) {
										?>
										<input type="hidden" name="key" id="m_key" value="<?php echo $MERCHANT_KEY; ?>" />
										<input type="hidden" name="hash" id="hash" value=""/>
										<input type="hidden" name="txnid" id="txid" value="<?php echo $txnid; ?>" />
										<input type="hidden" name="surl" id="surl" value="<?php echo ( site_url( '/download/' ) ); ?>" />
										<input type="hidden" name="furl" id="furl" value="<?php echo ( site_url( '/download/' ) ); ?>" />
										<input type="hidden" name="productinfo" id="productinfo" value="QloApps" />
										<input type="hidden" name="service_provider" id="s_provide" value="payu_paisa" />
										<input type="hidden" id="qlocountryCode" value="<?php echo $countryCode; ?>">
										<?php
									} else {
										?>
										<input type="hidden" id="site_url" value="<?php echo ( site_url( '/download/' ) ); ?> ">
										<input type="hidden" id="qlocountryCode" value="<?php echo $countryCode; ?>">
										<?php
									}
									?>
									<div class="row">
										<div class="col-md-4">
											<span class="donate_amt_field">
												<span class="donate-side dnt-left"><?php echo ( 'IN' === $countryCode ) ? " &#x20b9;" : ' $' ?></span>
												<input type="text" id="donate_amt" class="donate-amt" name="amount">
												<span class="donate-side dnt-right">.00</span>
											</span>
											<input type="text" id="sponsor-name" name="firstname" class="input-field" value='' placeholder="Full Name">
											<input type="text" id="sponsor-email" name="email" class="input-field float-right" value='' placeholder="Email">
											<button type="submit" id="sponsor-submit-btn" class="white btn btn-bgcolor sponsor-submit">Sponsor us</button>
											<p></p>
										</div>
									</div>
								</form>
						</div>
					</div>
				</div>
				<div class="row">
						<div class="col-md-12 text-center">
								<p class="or-download-text">Other downloading resources</p>
						</div>
				</div>
				<div class="row">
						<div class="col-md-4 col-sm-4 text-center">
								<div class="download-option-tabs">
										<span class="img github-dwnld" title="Download/Clone Qloapps from Github"></span>
										<p>Download/Clone Qloapps from Github</p>
										<a href="https://github.com/webkul/hotelcommerce" target="_blank" rel="nofollow" class="get-it-now-btn white btn-bgcolor btn-download-ext">Go To Github<span class="glyphicon glyphicon-arrow-right"></span></a>
								</div>
						</div>
						<div class="col-md-4 col-sm-4 text-center">
								<div class="download-option-tabs">
										<span class="img docker-dwnld" title="Download the Dockerized Image of Qloapps"></span>
										<p>Download the Dockerized Image of Qloapps</p>
										<a href="https://hub.docker.com/r/webkul/qloapps_docker/" target="_blank" rel="nofollow" class="get-it-now-btn white btn-bgcolor btn-download-ext">Go To Docker<span class="glyphicon glyphicon-arrow-right"></span></a>
								</div>
						</div>
						<div class="col-md-4 col-sm-4 text-center">
								<div class="download-option-tabs">
										<span class="img vagrant-dwnld" title="Download the Vagrant Image of Qloapps"></span>
										<p>Download the Vagrant Image of Qloapps</p>
										<a href="https://github.com/webkul/Vagrant_qloapps" target="_blank" rel="nofollow" class="get-it-now-btn white btn-bgcolor btn-download-ext">Vagrant Image<span class="glyphicon glyphicon-arrow-right"></span></a>
								</div>
						</div>
				</div>
		</div>
</section>
<div class="popup-open">
	<div id="popup-outscreen">
		<div class="popup-wrapper pop-height1">

				<div class="closepopup" id="popupclose"></div>

				<div class="pop-img-sec">
					<svg id="Illustration" xmlns="http://www.w3.org/2000/svg" width="450" height="450" viewBox="0 0 450 450">

					<defs>
							<style>
								.cls-1, .cls-10, .cls-11, .cls-13, .cls-15, .cls-16, .cls-19, .cls-21, .cls-25, .cls-26, .cls-3, .cls-30, .cls-32, .cls-33, .cls-4, .cls-6, .cls-7, .cls-8, .cls-9 {
									fill-rule: evenodd;
								}

								.cls-1 {
									opacity: 0.03;
								}

								.cls-2 {
									opacity: 0.05;
								}

								.cls-3 {
									fill: #e7c072;
								}

								.cls-4 {
									fill: #ffe4b0;
								}

								.cls-5 {
									fill: #594f38;
								}

								.cls-6 {
									fill: #6d634c;
								}

								.cls-7 {
									fill: #e1e1e1;
								}

								.cls-8 {
									fill: #333;
								}

								.cls-9 {
									fill: #e2e9ee;
									opacity: 0.5;
								}

								.cls-10, .cls-29 {
									fill: #373023;
								}

								.cls-11, .cls-12 {
									fill: #433a28;
								}

								.cls-13 {
									fill: #534936;
								}

								.cls-14, .cls-16 {
									fill: #8a8271;
								}

								.cls-15 {
									fill: #9d978b;
								}

								.cls-17 {
									opacity: 0.12;
								}

								.cls-18 {
									fill: #ffeac2;
								}

								.cls-19 {
									fill: #fff2d9;
								}

								.cls-20 {
									fill: #77694d;
								}

								.cls-21 {
									fill: #d0b175;
								}

								.cls-22, .cls-33 {
									fill: #fff;
								}

								.cls-23, .cls-25 {
									fill: #615740;
								}

								.cls-24, .cls-26 {
									fill: #352e1e;
								}

								.cls-27 {
									fill: #c3a56a;
								}

								.cls-28 {
									fill: #f9dda6;
								}

								.cls-30 {
									fill: #e4c485;
								}

								.cls-31 {
									fill: #cbaa6a;
								}

								.cls-32 {
									fill: #e0e0e0;
								}

								.cls-34 {
									fill: #fff5e2;
								}
							</style>
						</defs>
						<path id="Back_Clouds" data-name="Back Clouds" class="cls-1" d="M373.252,203.928h-169.5a22.741,22.741,0,1,1,0-45.482h169.5A22.741,22.741,0,1,1,373.252,203.928ZM355.41,112.964H172.532a22.741,22.741,0,1,1,0,45.482H46.748a22.741,22.741,0,1,1,0-45.482h89.209a22.741,22.741,0,1,1,0-45.482H55.669a22.741,22.741,0,1,1,0-45.482H275.122a22.741,22.741,0,1,1,0,45.482H355.41A22.741,22.741,0,1,1,355.41,112.964ZM110.978,248.518h169.5a22.741,22.741,0,1,1,0,45.482h-169.5A22.741,22.741,0,1,1,110.978,248.518Z"/>
						<g id="Base_Shadows" data-name="Base Shadows">
							<ellipse class="cls-2" cx="202.5" cy="391" rx="136.5" ry="3"/>
							<ellipse id="Ellipse_720_copy" data-name="Ellipse 720 copy" class="cls-2" cx="322" cy="425.5" rx="49" ry="1.5"/>
							<ellipse id="Ellipse_720_copy_2" data-name="Ellipse 720 copy 2" class="cls-2" cx="401.5" cy="425.5" rx="18.5" ry="1.5"/>
						</g>
						<g id="Machine">
							<path id="Base" class="cls-3" d="M86,42H319a4,4,0,0,1,4,4V337H82V46A4,4,0,0,1,86,42ZM75,337H329a4,4,0,0,1,4,4v38a4,4,0,0,1-4,4H75a4,4,0,0,1-4-4V341A4,4,0,0,1,75,337Z"/>
							<path id="Shine" class="cls-4" d="M329,383H312a4,4,0,0,0,4-4V341a4,4,0,0,0-4-4h-2V42h9a4,4,0,0,1,4,4V337h6a4,4,0,0,1,4,4v38A4,4,0,0,1,329,383Z"/>
							<rect id="Dispensing_Area" data-name="Dispensing Area" class="cls-5" x="94" y="197" width="216" height="140" rx="4" ry="4"/>
							<path id="Dispensing_Area_copy" data-name="Dispensing Area copy" class="cls-6" d="M103,197V337H98a4,4,0,0,1-4-4V201a4,4,0,0,1,4-4h5Z"/>
							<g id="Boiled_Water_Right" data-name="Boiled Water Right">
								<path class="cls-7" d="M268,197h8l16,38-14,31a1,1,0,0,1-1,1l-3-1a1,1,0,0,1-1-1l11-30Z"/>
								<path class="cls-8" d="M281.979,237.137l9.119,4.1-11.077,23.623-8.119-3.1Z"/>
							</g>
							<g id="Steamer_Left" data-name="Steamer Left">
								<path class="cls-7" d="M137,197h-8l-16,38,14,31a1,1,0,0,0,1,1l3-1a1,1,0,0,0,1-1l-11-30Z"/>
								<path class="cls-8" d="M123.021,237.137l-9.119,4.1,11.077,23.623,8.119-3.1Z"/>
							</g>
							<g id="Coffee_Jar" data-name="Coffee Jar">
								<path id="Rectangle_8_copy" data-name="Rectangle 8 copy" class="cls-9" d="M235,337H170a4,4,0,0,1-4-4V299.965l0.011-.016L174,263h57l7.972,36.873L239,299.9V333A4,4,0,0,1,235,337Z"/>
								<path id="Rectangle_8_copy_3" data-name="Rectangle 8 copy 3" class="cls-10" d="M232,334H173a4,4,0,0,1-4-4V306h67v24A4,4,0,0,1,232,334Z"/>
								<path class="cls-11" d="M167,256h85v7H174Z"/>
								<rect class="cls-12" x="245" y="256" width="7" height="61"/>
								<rect id="Rectangle_8_copy_2" data-name="Rectangle 8 copy 2" class="cls-12" x="242" y="310" width="10" height="7"/>
							</g>
							<g id="Dispensor">
								<path id="Rectangle_3_copy_3" data-name="Rectangle 3 copy 3" class="cls-12" d="M155,197h92a0,0,0,0,1,0,0v11a2,2,0,0,1-2,2H157a2,2,0,0,1-2-2V197A0,0,0,0,1,155,197Z"/>
								<path id="Shine-2" data-name="Shine" class="cls-13" d="M245,210h-4a2,2,0,0,0,2-2V197h4v11A2,2,0,0,1,245,210Z"/>
								<path id="Rectangle_3_copy_2" data-name="Rectangle 3 copy 2" class="cls-14" d="M169,210h64a0,0,0,0,1,0,0v11a2,2,0,0,1-2,2H171a2,2,0,0,1-2-2V210A0,0,0,0,1,169,210Z"/>
								<path id="Rectangle_3_copy_4" data-name="Rectangle 3 copy 4" class="cls-15" d="M231,223h-4a2,2,0,0,0,2-2V210h4v11A2,2,0,0,1,231,223Z"/>
								<path id="Rectangle_4_copy" data-name="Rectangle 4 copy" class="cls-16" d="M195,221h14l-5,8h-4Z"/>
							</g>
							<rect id="Dispensing_Shadow" data-name="Dispensing Shadow" class="cls-17" x="202" y="197" width="108" height="140"/>
							<rect id="Body_Steel" data-name="Body Steel" class="cls-18" x="107" y="42" width="191" height="155"/>
							<path id="Body_Steel_copy" data-name="Body Steel copy" class="cls-19" d="M288,197V42h10V197H288Z"/>
							<rect id="Logo" class="cls-20" x="184" y="64" width="37" height="7"/>
							<g id="Manuals">
								<circle class="cls-20" cx="135" cy="109" r="8"/>
								<circle id="Ellipse_1_copy" data-name="Ellipse 1 copy" class="cls-20" cx="180" cy="109" r="8"/>
								<circle id="Ellipse_1_copy_2" data-name="Ellipse 1 copy 2" class="cls-20" cx="225" cy="109" r="8"/>
								<circle id="Ellipse_1_copy_3" data-name="Ellipse 1 copy 3" class="cls-20" cx="270" cy="109" r="8"/>
								<circle id="Ellipse_1_copy_4" data-name="Ellipse 1 copy 4" class="cls-20" cx="135" cy="145" r="8"/>
								<circle id="Ellipse_1_copy_4-2" data-name="Ellipse 1 copy 4" class="cls-20" cx="180" cy="145" r="8"/>
								<circle id="Ellipse_1_copy_4-3" data-name="Ellipse 1 copy 4" class="cls-20" cx="225" cy="145" r="8"/>
								<circle id="Ellipse_1_copy_4-4" data-name="Ellipse 1 copy 4" class="cls-20" cx="270" cy="145" r="8"/>
							</g>
						</g>
						<g id="Coffee_Cup_Used_" data-name="Coffee Cup (Used)">
							<path id="Body" class="cls-21" d="M330.785,358.987h38.439a1.785,1.785,0,0,1,1.788,1.782l-5.363,53.449A1.785,1.785,0,0,1,363.861,416H336.149a1.785,1.785,0,0,1-1.788-1.782L329,360.769A1.785,1.785,0,0,1,330.785,358.987Z"/>
							<circle id="Print" class="cls-22" cx="350" cy="388" r="12"/>
							<g id="Coffee_Beans" data-name="Coffee Beans">
								<g>
									<rect class="cls-23" x="344" y="384" width="6" height="9" rx="3" ry="3"/>
									<rect class="cls-24" x="346" y="384" width="1" height="9"/>
								</g>
								<g id="Group_1_copy" data-name="Group 1 copy">
									<path class="cls-25" d="M354.074,385.9a3.064,3.064,0,0,1,0,4.334l-1.858,1.858a3.065,3.065,0,1,1-4.336-4.334l1.858-1.858A3.067,3.067,0,0,1,354.074,385.9Z"/>
									<path class="cls-26" d="M354.374,385l0.637,0.636-6.368,6.353-0.637-.635Z"/>
								</g>
							</g>
							<rect id="Sipper_Shadow" data-name="Sipper Shadow" class="cls-27" x="327" y="360" width="46" height="3" rx="1" ry="1"/>
							<rect id="Sipper" class="cls-28" x="327" y="359" width="46" height="3" rx="1" ry="1"/>
							<path class="cls-10" d="M334,359h10s-2,3.132-2,5.476V367a3,3,0,0,1-6,0v-2.581C336,362.081,334,359,334,359Z"/>
							<rect class="cls-29" x="337" y="371" width="4" height="7" rx="2" ry="2"/>
						</g>
						<g id="Coffee_Cup" data-name="Coffee Cup">
							<path id="Body-2" data-name="Body" class="cls-30" d="M379,352h43a2,2,0,0,1,2,2l-6,60a2,2,0,0,1-2,2H385a2,2,0,0,1-2-2l-6-60A2,2,0,0,1,379,352Z"/>
							<circle id="Print-2" data-name="Print" class="cls-22" cx="400.5" cy="384.5" r="13.5"/>
							<g id="Coffee_Beans-2" data-name="Coffee Beans">
								<g>
									<rect class="cls-23" x="394" y="380" width="7" height="10" rx="3.5" ry="3.5"/>
									<rect class="cls-24" x="397" y="380" width="1" height="10"/>
								</g>
								<g id="Group_1_copy-2" data-name="Group 1 copy">
									<path class="cls-25" d="M405.987,382.013a3.452,3.452,0,0,1,0,4.882l-2.092,2.092a3.452,3.452,0,1,1-4.882-4.882l2.092-2.092A3.452,3.452,0,0,1,405.987,382.013Z"/>
									<path class="cls-26" d="M405.638,381.664l0.7,0.7-6.974,6.974-0.7-.7Z"/>
								</g>
							</g>
							<rect id="Sipper_Shadow-2" data-name="Sipper Shadow" class="cls-31" x="375" y="353" width="51" height="3" rx="1" ry="1"/>
							<rect id="Sipper-2" data-name="Sipper" class="cls-28" x="375" y="352" width="51" height="3" rx="1" ry="1"/>
							<path id="Steam" class="cls-32" d="M422.5,326h-4a2.5,2.5,0,0,0,0,5h-15a2.5,2.5,0,0,1,0,5h17a2.5,2.5,0,0,1,0,5h-8a2.5,2.5,0,0,1,0,5h-27a2.5,2.5,0,0,1,0-5h12a2.577,2.577,0,0,1-.5-0.05,2.5,2.5,0,0,0,0-4.9,2.577,2.577,0,0,1,.5-0.05h-21a2.5,2.5,0,0,1,0-5h21a2.5,2.5,0,0,0,0-5h-8a2.5,2.5,0,0,1,0-5h33A2.5,2.5,0,0,1,422.5,326Z"/>
						</g>
						<g id="Finished_Coffee" data-name="Finished Coffee">
							<path class="cls-21" d="M284,384l40,7c4.608,2.558,5.869,16.572,0,22l-40,7V384Z"/>
							<path id="Rectangle_15_copy" data-name="Rectangle 15 copy" class="cls-33" d="M312.959,399.987c-5.609.215-10.959-3.9-10.959-8.8a5.593,5.593,0,0,1,1.417-3.788l15.445,2.7a7.451,7.451,0,0,1,1.041,2.657C320.524,396.471,317.711,399.8,312.959,399.987Z"/>
							<ellipse id="Ellipse_2_copy" data-name="Ellipse 2 copy" class="cls-27" cx="285.5" cy="402" rx="15.5" ry="18"/>
							<ellipse class="cls-34" cx="285" cy="402" rx="14" ry="17"/>
							<path id="Ellipse_2_copy_3" data-name="Ellipse 2 copy 3" class="cls-33" d="M285,385c7.5,0.011-5.211,8.668-4,18,1.208,9.311,11.732,16,4,16s-14-7.611-14-17S277.268,384.989,285,385Z"/>
							<path id="Ellipse_2_copy_2" data-name="Ellipse 2 copy 2" class="cls-10" d="M296.089,412.348a13.545,13.545,0,0,1-9.894,6.579,2.817,2.817,0,0,1-2.169-2.128,2.728,2.728,0,0,1,2.5-3.067Z"/>
							<g id="Coffee_Beans-3" data-name="Coffee Beans">
								<g>
									<path class="cls-25" d="M309.441,388.132a5.726,5.726,0,0,1,3.339,2.525l0.837,1.973c0.532,1.252-.241,2.37-2.079,2.37-2.279,0-4.782-1.623-5.006-3.365l-0.333-2.591C306.045,387.854,307.639,387.544,309.441,388.132Z"/>
									<path class="cls-26" d="M308.389,387.789l1.052,0.343,2.1,6.868h-1.313Z"/>
								</g>
								<g id="Group_1_copy-3" data-name="Group 1 copy">
									<path class="cls-25" d="M315.23,390.767c0.982,0.772,1.56,1.8,1.285,2.4l-0.526,1.144c-0.426.926-2.1,0.952-3.726-.178-1.719-1.192-2.19-2.816-1.185-3.432l1.219-.747C312.924,389.571,314.214,389.969,315.23,390.767Z"/>
									<path class="cls-26" d="M315.163,390.379l0.51,0.4-2.656,3.3-0.849-.6Z"/>
								</g>
							</g>
						</g>
					</svg>

				</div>
				<div class="pop-detail-sec">
					<p class="pop-title">Buy us a Coffee :D</p>
					<p class="pop-desc">As we know <b>QloApps</b> is an <u>Open Source Project</u> to help hoteliers all around the World. We(QloApps) did set some targets & we have achieved those. Now we have some new targets to make QloApps more better but it can't be possible without some help of your Donation. Show us your Love & let's make QloApps more Advance & Gigantic.</p>
					<form style="font-size:0">
						<input type="hidden" id="site_url" value="<?php echo ( site_url( '/download/' ) ); ?> ">
						<span class="donate-side dnt-left dtn-pop-tag" style="width:auto">Sponser us</span>
						<span class="donate-side dnt-left dnt-pop-lft"> $</span>
						<input type="text" class="donate-amt pop-donate" id="donate-pop-amt" name="donate_amount"  >
						<span class="donate-side dnt-right">.00</span>

						<p><input class="donate-submit" id="donate-popup" type="submit" value="SUBMIT"><p>
					</form>

				</div>

		</div>
	</div>
</div>
<?php get_footer()?>

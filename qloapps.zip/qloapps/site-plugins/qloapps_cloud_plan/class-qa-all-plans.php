<?php
if( ! defined ( 'ABSPATH' ) ) {
  exit;
}

if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}
if ( ! class_exists( 'qa_all_plan' ) ) {
  class qa_all_plan extends WP_List_Table {
    public function __construct() {
      parent::__construct( [
        'singular' => __( 'qloapps', 'qa' ), //singular name of the listed records
        'plural'   => __( 'qloapps', 'qa' ), //plural name of the listed records
        'ajax'     => false //should this table support ajax?
        ] );
    }

    public function get_plans() {
        $result = ( get_option( 'qa_cloud_plans' ) ) ? maybe_unserialize( get_option( 'qa_cloud_plans' ) ) : array();
        foreach ($result as $key => $value) {
          $result[$key]['plan']    = implode( ', ', $value['plan'] );
          $result[$key]['package'] = implode( ', ', $value['package'] );
        }
        if ( isset( $_GET['s'] ) && ! empty( $_GET['s'] ) && $_GET['page'] == 'cloud_plans' ) {
          $search_result = array();
          $search = strtolower($_GET['s']);
          foreach ($result as $key => $value) {
            if( preg_match("/\b" . $search . "\b/i", strtolower( $value['plan'] ) ) || preg_match("/\b" . $search . "\b/i", strtolower( $value['package'] ) ) || preg_match("/\b" . $search . "\b/i", strtolower( $value['feature'] ) )  ) {
              $search_result[$key] =  $result[$key];
            }
          }
          return $search_result;
        } else {
          return $result;
        }

    }

    public function prepare_items() {
      $qa_cloud_data         = $this->get_plans();
      $columns               = $this->get_columns();
      $hidden                = array();
      $sortable              = $this->get_sortable_columns();
      $this->_column_headers = array( $columns, $hidden, $sortable );

      $this->process_bulk_action();

      function usort_reorder( $a, $b ) {
        $orderby = ( ! empty( $_GET['orderby'] ) ) ? $_GET['orderby'] : 'id';
        $order   = ( ! empty( $_GET['order'] ) ) ? $_GET['order'] : 'asc';
        $result  = strcmp( strtolower( $a[ $orderby ] ), strtolower( $b[ $orderby ] ) );
        return ( $order === 'desc' ) ? $result : -$result;
      }
      usort( $qa_cloud_data, 'usort_reorder' );

      $per_page     =  $this->get_items_per_page( 'qa_cloud_plans_per_page', 5 );
      $current_page = $this->get_pagenum();
      $total_items  = count($qa_cloud_data);

      $data_found   = array_slice( $qa_cloud_data, ( ( $current_page - 1 ) * $per_page ), $per_page );

      $this->items = $data_found;
      $this->set_pagination_args( array( 'total_items' => $total_items, 'per_page' => $per_page ) );
    }


    public function get_columns() {
      $columns = array(
        'cb'      => '<input type="checkbox">',
        'feature' => 'Feature',
        'plan'    => 'plan',
        'package' => 'Package',
        'status'  => 'Status'
    );
    return $columns;

    }

    //show plan table data
    public function column_default($item,$column_name){
        switch($column_name){
            case 'feature':
            case 'plan':
            case 'package':
            case 'status' :
            return $item[ $column_name ];

        }
    }

    function column_cb( $item ) {
			return sprintf( '<input type="checkbox" name="plan-id[]" value="%s" />', $item['id'] );
		}

    //set action to specific column
    public function column_feature($item) {
        $actions = array(
          'edit'   => sprintf('<a href="?page=add_cloud_plan&action=%s&plan-id=%s">Edit</a>','edit',$item['id']),
          'delete' => sprintf('<a href="?page=%s&action=%s&plan-id=%s">Delete</a>',$_REQUEST['page'],'delete',$item['id']),
        );

        return sprintf('%1$s %2$s', $item['feature'], $this->row_actions($actions) );
    }

    //set which column is sortable
    public function get_sortable_columns() {
      $sortable_columns = array(
        'feature' => array( 'feature', false ),
        'status'  => array( 'status', false ),
      );
      return $sortable_columns;
    }

    /*Perform Bulk Action*/
    public function get_bulk_actions(){
        $actions = array(
                        'delete'      => 'Delete',
                        'displayed'     => 'displayed',
                        'not-displayed' => 'not displayed'
                        );
        return $actions;
    }

    public function process_bulk_action() {
      if( isset($_GET['plan-id']) && ! empty($_GET['plan-id']) ) {
        $update_plan = ( get_option( 'qa_cloud_plans' ) ) ? maybe_unserialize( get_option( 'qa_cloud_plans' ) ) : array();
        if( is_array( $_GET['plan-id'] ) ) {
          foreach ($update_plan as $u_key => $u_value) {
            foreach ( $_GET['plan-id'] as $plan_id ) {
              if( $plan_id == $u_value['id'] ) {
                if( 'delete' == $this->current_action() ) {
                  unset($update_plan[$u_key]);
                } elseif ( 'displayed' == $this->current_action() ) {
                  $update_plan[$u_key]['status'] = 'displayed';
                } elseif ( 'not-displayed' == $this->current_action() ) {
                  $update_plan[$u_key]['status'] = 'not displayed';
                }
              }
            }
          }
        } else {
          foreach ($update_plan as $key => $value) {
            if( $value['id'] == $_GET['plan-id'] ) {
              if( 'delete' == $this->current_action() ) {
                unset($update_plan[$key]);
              } elseif ( 'displayed' == $this->current_action() ) {
                $update_plan[$key]['status'] = 'displayed';
              } elseif ( 'not-displayed' == $this->current_action() ) {
                $update_plan[$key]['status'] = 'not displayed';
              }
            }
          }
        }
        update_option( 'qa_cloud_plans', maybe_serialize( $update_plan ) );
        wp_redirect( admin_url() . 'admin.php?page=cloud_plans' );
      }
    }

  }

  $qa_plan = new qa_all_plan();
  ?> <div class="wrap">
          <h1 class="wp-heading-inline">Qlo Plans</h1>
          <a href="<?php echo admin_url(); ?>admin.php?page=add_cloud_plan" class="page-title-action">Add New</a>
  <?php
  $qa_plan->prepare_items();
  ?>

  <form method="get">
  <input type="hidden" name="page" value="<?php echo $_REQUEST['page']; ?>"/>
  <?php
  $qa_plan->search_box( 'search', 'search_plans' );
  $qa_plan->display();
  echo " </form> ";
  echo "</div>";
}
?>

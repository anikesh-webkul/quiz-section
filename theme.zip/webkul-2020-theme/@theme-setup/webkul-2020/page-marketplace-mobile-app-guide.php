<?php
get_header();
?>
	<section class="wk-mp-user-guide">
		<div class="container">
			<div class="row">
				<section class="wk-mp-userguide-header section-top section-padding">
					<div class="page-banner col-md-5">
						<img id="mpguide-img" src="<?php echo esc_url( get_template_directory_uri() . '/images/mp-mobile-app-guide.png' ); ?>">
					</div>
					<div class="page-tagline col-md-7">
						<h1>Marketplace Multi-Vendor Mobile App</h1>
						<ul>
							<li><p>Overview</p></li>
							<li><p>Why we need mobile app?</p></li>
							<li><p>Benefits of Marketplace Mobile App</p></li>
							<li><p>E-Commerce Mobile App vs Marketplace Mobile App</p></li>
							<li><p>How to start a marketplace mobile app?</p></li>
							<li><p>Why are Native Apps Superior than Hybrid Apps?</p></li>
							<li><p>SaaS Based App</p></li>
							<li><p>CMS Based App</p></li>
							<li><p>Scratched Based App</p></li>
							<li><p>Summary</p></li>
						</ul>
						<a id="mp-guide-btn" href="https://cdn.uvdesk.com/webkul/marketplace/mp-mobile-app.pdf" class="wk-button" download>DOWNLOAD</a>
					</div>
				</section>
			</div>

			<div class="row">
				<section class="wk-mp-platform section-padding">
					<div class="col-md-12">
						<div class="platform-plank more-height">
							<h1 id="mp-products">Products you may be interested in</h1>
							<div class="platform-card platform-magento">

								<div>
									<span class="wk-mp-platform-icon wk-mp-platform-icon-magento"></span>
									<h4>Magento&reg; Marketplace App</h4>
								</div>
								<p>Magento Multi-Vendor Mobile App will convert your website on Magento Marketplace to a native app. You will be getting app for both Android and iOS. This will allow your sellers to manage the store from an app. The customer to purchase via the app. The features of the app increase user engagement.</p>
								<a href="https://store.webkul.com/magento-multivendor-mobile-app.html" target="_blank" rel="noopener" class="wk-mp-btn">READ MORE</a>

							</div>

							<div class=" platform-card platform-magento">
								<div>
									<span class="wk-mp-platform-icon wk-mp-platform-icon-magento"></span>
									<h4>Magento&reg;2 Marketplace App</h4>
								</div>
								<p>Magento 2 Multi-Vendor Mobile App will make your Magento2 multi-vendor store accessible from anywhere and anytime. These native apps are created for both Android and iOS.The app provides multiple features to both seller and customer. The seller with the help of this app can manage the products and orders very easily.</p>
								<a href="https://store.webkul.com/magento2-marketplace-mobile-app.html" target="_blank" rel="noopener" class="wk-mp-btn">READ MORE</a>
							</div>

							 <div class=" platform-card platform-prestashop">
								<div>
									<span class="wk-mp-platform-icon wk-mp-platform-icon-prestashop"></span>
									<h4>Prestashop Marketplace App</h4>
								</div>
								<p>With PrestaShop Marketplace Mobile App , the store owner can now launch their website based store as a native app for both Android and iOS users. The sellers can now manage the complete store via an app and customer can even buy the showcased product with the app. This removes the struggle to look for a laptop/desktop for shopping purpose.</p>
								<a href="https://store.webkul.com/PrestaShop-Marketplace-Mobile-App.html" target="_blank" rel="noopener" class="wk-mp-btn">READ MORE</a>
							</div>

							<div class=" platform-card platform-opencart">
								<div>
									<span class="wk-mp-platform-icon wk-mp-platform-icon-opencart"></span>
									<h4>Opencart Marketplace App</h4>
								</div>
								<p>Opencart Multi Vendor Mobile App will make transform your website into an app that could be accessed by the user from anywhere and anytime. This will help in the increment of the sales on the store. The apps are enriched with both native apps as well as the marketplace. This combination makes the app highly usable.</p>
								<a href="https://store.webkul.com/Opencart-Marketplace-Mobile-App.html" target="_blank" rel="noopener" class="wk-mp-btn">READ MORE</a>
							</div>

							<div class=" platform-card platform-cs-cart">
								<div>
									<span class="wk-mp-platform-icon wk-mp-platform-icon-cs-cart"></span>
									<h4>CS-Cart Marketplace App</h4>
								</div>
								<p>CS-Cart Multi vendor Mobikul Mobile App is a completely native app that gives its user the advantage of device-based features. This splendid application will allow every size of business to flourish and expand into the mobile world. The seller will be able to see their Dashboard, Manage Orders and much more. The buyers can view product and place orders.</p>
								<a href="https://store.webkul.com/cs-cart-multivendor-mobile-app.html" target="_blank" rel="noopener" class="wk-mp-btn">READ MORE</a>
							</div>

							<div class=" platform-card platform-odoo">
								<div>
									<span class="wk-mp-platform-icon wk-mp-platform-icon-odoo"></span>
									<h4>Odoo Marketplace App</h4>
								</div>
								<p>Odoo Multi Vendor Mobile App will convert the marketplace store into an app for Android/iOS. Now you can easily manage your products from your Smartphones only. The app will give both the seller and buyer a convenient and attractive way to manage and access the store.</p>
								<a href="https://store.webkul.com/odoo-multivendor-mobile-app.html" target="_blank" rel="noopener" class="wk-mp-btn">READ MORE</a>
							</div>

						</div>
					</div>
				</section>
			</div>
		</div>

	</section>
<?php
get_footer();

<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WK_Jobs_Ogimage_Generator' ) ) {

	class WK_Jobs_Ogimage_Generator {
	
		private $canvas_width     = 1200;
		private $canvas_height    = 630;
		private $canvas_padding_x;
		private $canvas_padding_y;
		private $font_size;
		private $font_bold;
		private $font_regular;
		private $align;
		private $canvas;
		private $background;
		private $text_color;
		private $string;
		private $file;
	
	
		/*Constructor*/
		public function __construct( $text, $file_path = '' ) {
	
			$this->file     = $file_path; //This variable set on Top always;
			$this->set_wkog_configurations();
			$this->string   = $text;

			$watermark      = get_template_directory() . '/images/hiring-og/webkul-logo.jpg';
	
			$this->canvas   = imageCreate( $this->canvas_width, $this->canvas_height );
	
			$rgb_equivalent = $this->hex_to_rgb( $this->background );
			$color          = imagecolorallocate( $this->canvas, $rgb_equivalent['r'], $rgb_equivalent['g'], $rgb_equivalent['b'] );
	
			$this->text_color = imageColorallocate( $this->canvas, $this->text_color['r'], $this->text_color['g'], $this->text_color['b'] );
	
	
			$heading_color = imageColorallocate( $this->canvas, 255, 255, 255 );
	
			$this->bg_paint( $this->canvas, 0, 0, 1200, 530, '#0B1D5B' );
			$this->bg_paint( $this->canvas, 0, 530, 1200, 630, '#2552F5' );
			
			$this->wkog_paint_text( $this->canvas, $this->canvas_padding_x, 200, 70, 0, 30, $heading_color, $this->font_regular, "We&#8217;re hiring", $this->align );
	
			$this->wkog_paint_text( $this->canvas, $this->canvas_padding_x, $this->canvas_padding_y, $this->font_size, 0, 30, $this->text_color, $this->font_bold, $this->string, $this->align );

			// ====== Add Art Image ==============
			if( ! empty( $this->file ) ) {
				$this->wk_copy_image( $this->canvas, $this->file, 685 , 0, 0, 0 );
			}
			// ====== Add Art Image ==============
	
			
			// ====== Add WaterMark Webkul Logo Image ==============
			if( ! empty( $watermark ) ) {
				$this->wk_copy_image( $this->canvas, $watermark, $this->canvas_padding_x + 5 , 560, 0, 0 );
			}
			// ====== Add WaterMark Webkul Logo Image ==============

			header( 'Content-type:  image/png' );
			imagepng( $this->canvas );
			imagedestroy( $this->canvas );
		}
		/*Constructor*/

		private function wk_copy_image( $dest_img, $source_img, $x1, $y1, $x2, $y2 ) {
			
			if( ! file_exists( $source_img ) ) {
				return;
			}

			$file_ext = pathinfo( $source_img, PATHINFO_EXTENSION );

			switch( $file_ext ) {
				case 'png':
					$source_img = imagecreatefrompng( $source_img );
					break;
				case 'jpg':
					$source_img = imagecreatefromjpeg( $source_img );
					break;
				case 'jpeg':
					$source_img = imagecreatefromjpeg( $source_img );
					break;
				case 'gif':
					$source_img = imagecreatefromgif( $source_img );
					break;
				default:
					$source_img = false;
					break;

			}
			if( $source_img ) {

				$this->set_bgtransparent( $source_img );
				
				imagecopy( $dest_img, $source_img, $x1, $y1, $x2, $y2, imagesx( $source_img ), imagesy( $source_img ) );
			}
		}
	
		private function set_bgtransparent( $img ) {
	
			$color = imagecolorallocatealpha( $img, 0, 0, 0, 127 ); //127 means completely transparent.
			imagecolortransparent( $img, $color );
	
		}
	
	
		/*Helping Hands */
		private function set_wkog_configurations() {
	
			$this->canvas_padding_x = 60;
			
			$this->canvas_padding_y = -10;
			
			$this->font_size        = ! empty( $this->file ) ? 93 : 80;
	
			$this->align            = ! empty( $this->file ) ? 'Left' : 'Center';
	
			$this->font_regular     = get_template_directory() . '/assets/fonts/__regular/montserrat.ttf';
	
			$this->font_bold        = get_template_directory() . '/assets/fonts/__bold/montserrat.ttf';
			
			$this->background       = '#2552F5';
	
			$this->text_color       = $this->hex_to_rgb( '#4DD2FF' );
			
		}
	
	
		private function bg_paint( $ground, $x, $y, $x1, $y1, $color ) {
	
			if ( $x > $x1 || $y > $y1 ) {
				return false;
			}
	
			$col = $this->hex_to_rgb( $color );
	
			$color = imagecolorallocate( $ground, $col['r'], $col['g'], $col['b'] );
	
			imagefilledrectangle( $ground, $x, $y, $x1, $y1, $color );
	
			return true;
		}
	
	
		private function wkog_paint_text( &$canvas, $canvas_padding_x, $canvas_padding_y, $text_size, $text_angle, $txt_offset_y, $text_color, $font, $text, $align ) {
	
			$words        = explode( ' ', $text );
			$new_text     = '';
			$break_offset = 0;
			$line_breaks  = 0;
			$growing_text = '';

			$temp_width = ! empty( $this->file ) ? imagesx( $canvas ) / 1.5 - ( $canvas_padding_x * 2 ) : imagesx( $canvas ) - ( $canvas_padding_x * 2 );
	
			$canvas_size = array(
				'height' => imagesy( $canvas ) - ( $canvas_padding_y * 2 ),
				'width'  => $temp_width,
			);
	
			foreach ( $words as $word ) {
	
				if ( '' === $word ) {
					continue;
				}
	
				$test_string       = $growing_text . ' ' . $word;
				$growing_text_size = $this->wkog_get_text_size( $text_size, $text_angle, $font, $test_string );
	
				if ( $growing_text_size['width'] > $canvas_size['width'] ) {
					
					if ( 1 === count( $words ) ) {
	
						$char_count    = strlen( $test_string );
						$test_char_str = '';
						$counter       = 0;
	
						for ( $i = 0; $i < $char_count; $i++ ) {
	
							$counter++;
							$test_char_str      = $test_char_str . $test_string[ $i ];
							$test_char_str_size = $text_size * $counter;
							if ( $test_char_str_size > $canvas_size['width'] ) {
	
								$growing_text  = $growing_text . substr( $test_char_str, 0, $i ) . PHP_EOL;
								$test_char_str = '';
								$counter       = 0;
							} else {
								if ( $i === $char_count - 1 ) {
									$growing_text .= $test_char_str;
								}
							}
						}
					} else {
						$growing_text .= ( '' === $growing_text ? '' : PHP_EOL ) . $word;
					}
				} else {
					$growing_text .= ( '' === $growing_text ? '' : ' ') . $word;
				}
			}
	
			$textbox_size = $this->wkog_get_text_size( $text_size, $text_angle, $font, $growing_text );
			
			
			// reduce Text font size if it's width or height is greater than Canvas.
			while ( ( $textbox_size['height'] > $canvas_size['height'] / 2.5 ) || ( $textbox_size['width'] > $canvas_size['width'] - 80 ) ) {
	
				$text_size    = $text_size - 1;
				$textbox_size = $this->wkog_get_text_size( $text_size, $text_angle, $font, $growing_text );
			}

			switch ( strtoupper( $align ) ) {
				case 'RIGHT':
					$offset_x = $canvas_size['width'] - $textbox_size['width'];
					break;
				case 'CENTER':
					$offset_x = ( $canvas_size['width'] - $textbox_size['width'] ) / 2;
					break;
				default:
					$offset_x = 0; // LEFT
			}
	
			$offset_x += $canvas_padding_x;
			
			$offset_y = ( $canvas_size['height'] - $textbox_size['height'] ) / 2 + $text_size;
	
			imagettftext( $canvas, $text_size, $text_angle, $offset_x, $offset_y, $text_color, $font, $growing_text );
	
			return;
		}
	
	
		private function wkog_get_text_size( $size, $angle, $font, $text ) {
	
			$img_box = imagettfbbox( $size, $angle, $font, $text );
			return array(
				'height' => $img_box[1] - $img_box[5],
				'width'  => $img_box[4] - $img_box[0],
			);
		}
	
	
		public function hex_to_rgb( $hex ) {
	
			$hex      = str_replace( '#', '', $hex );
			$length   = strlen( $hex );
			$rgb['r'] = hexdec( 6 === $length ? substr( $hex, 0, 2 ) : ( 3 === $length ? str_repeat( substr( $hex, 0, 1 ), 2 ) : 0 ) );
			$rgb['g'] = hexdec( 6 === $length ? substr( $hex, 2, 2 ) : ( 3 === $length ? str_repeat( substr( $hex, 1, 1 ), 2 ) : 0 ) );
			$rgb['b'] = hexdec( 6 === $length ? substr( $hex, 4, 2 ) : ( 3 === $length ? str_repeat( substr( $hex, 2, 1 ), 2 ) : 0 ) );
	
			return $rgb;
		}
	
	}  //End OF CLass
}
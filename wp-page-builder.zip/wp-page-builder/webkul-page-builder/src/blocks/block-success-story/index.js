/**
 * Register Custom Success Story Block
 */

registerBlockType('wk-blocks/success-story', {
	title: 'Success Story',
	icon: 'id',
	category: 'webkul',
	keywords: [
		'Success Story',
	],
	parent: [['wk-blocks/layout-container'], ['wk-blocks/block-wrapper']],

	example: {},

	attributes: {
		content: {
			selector: 'p',
			type: 'array',
			source: 'children',
		},
		title: {
			type: 'array',
			source: 'children',
			selector: '.title',
		},
		label: {
			type: 'array',
			source: 'children',
			selector: '.label',
		},
		imgID: {
			type: 'number',
		},
		imgALT: {
			type: 'string',
			source: 'attribute',
			attribute: 'alt',
			selector: 'img',
		},
		imgURL: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
		},
		newWindow: {
			type: 'boolean',
		},
		link: {
			type: 'string',
		},
		linkWithBtn: {
			type: 'string'
		},
		linkWithBtnLabel: {
			type: 'string'
		}
	},
	edit: function (props) {
		var content = props.attributes.content,
			label = props.attributes.label,
			imgURL = props.attributes.imgURL,
			imgALT = props.attributes.imgALT,
			imgID = props.attributes.imgID,
			newWindow = props.attributes.newWindow,
			link = props.attributes.link;
			linkWithBtn = ( props.attributes.linkWithBtn ) ? props.attributes.linkWithBtn : false;
			linkWithBtnLabel = props.attributes.linkWithBtnLabel;

		var title = props.attributes.title;
		(!!props.attributes.title[0] && !!props.attributes.title[0].props) && (title = props.attributes.title[0].props.children);
	
		const onChangeTitle = (newTitle) => {
			props.setAttributes({ title: newTitle });
		}
		const onChangeContent = (newContent) => {
			props.setAttributes({ content: newContent });
		}
		const onRemoveImage = () => {
			props.setAttributes({
				imgURL: null,
				imgID: null,
				imgALT: null,
			});
		};
		return el(
			Fragment,
			{},

			/**Sidebar Setting */
			el(
				InspectorControls,
				{},
				el(
					PanelBody,
					{
						title: 'Story Link Setting',
						initial: true,
					},
					el(
						PanelRow,
						{},
						el(
							TextControl,
							{
								type: "string",
								label: 'Add Link',
								value: link,
								onChange: (newLink) => {
									props.setAttributes({ link: newLink });
								}
							}
						)
					),
					el(
						PanelRow,
						{},
						el(
							FormToggle,
							{
								checked: newWindow,
								onChange: event => props.setAttributes({ newWindow: event.target.checked })
							}
						),
						el(
							'span',
							{},
							'Open in new Tab',
						)
					),
					el(
						PanelRow,
						{},
						el(
							FormToggle,
							{
								checked: linkWithBtn,
								onChange: event => {
									return props.setAttributes({ linkWithBtn: event.target.checked })
								}
							}
						),
						el(
							'span',
							{},
							'Add a separate button',
						)
					)
				)
			),
			/** //Sidebar Setting */

			el(
				'div',
				{},

				el(
					'div',
					{
						className: 'wk-image-uploader',
					},
					el(
						MediaUpload,
						{
							type: "image",
							allowed: ALLOWED_MEDIA_TYPES,
							value: imgID,
							onSelect: img => props.setAttributes({
								imgID: img.id,
								imgURL: img.url,
								imgALT: img.alt ? img.alt : img.title
							}),
							render: ({ open }) => el(
								Fragment,
								null,
								el(
									Button,
									{
										className: imgURL ? 'wk-change-image' : 'wk-add-image',
										onClick: open
									},
									!imgURL ? wkUploadIcon : el("img",
										{
											src: imgURL,
											alt: imgALT
										}
									)
								),
								imgURL && el(
									Button,
									{
										className: "wk-remove-image",
										onClick: onRemoveImage
									},
									el(
										Dashicon,
										{
											icon: 'dismiss'
										}
									)
								)
							)
						}
					)
					/** //MediaUpload End */
                    
				),
				el(
					'div',
					{
					},
					el(
						RichText,
						{
							key: 'editable',
							tagName: 'h3',
							className: 'wk-success-story-title',
							onChange: onChangeTitle,
							value: title,
							placeholder: 'Story Title....'
						},
					),
					el(
						RichText,
						{
							key: 'editable',
							tagName: 'p',
							className: 'wk-success-story-label',
							onChange: (label) => {
								props.setAttributes({ label: label });
							},
							value: label,
							placeholder: 'Story label....'
						}
					),
					el(
						RichText,
						{
							key: 'editable',
							tagName: 'p',
							className: 'wk-success-story-description',
							onChange: onChangeContent,
							value: content,
							placeholder: 'Story Description....'
						}
					),
					(linkWithBtn) ? el(
						PlainText,
						{
							key: 'editable',
							tag: 'div',
							value: linkWithBtnLabel,
							placeholder: 'Button Label....',
							onChange: btnLabel => props.setAttributes({ linkWithBtnLabel: btnLabel })
						},
					) : '',
					el(
						Dashicon,
						{
							icon: 'admin-links'
						}
					)
				)
			)
		);
		/** //WP Fragment End */
	},

	save: function (props) {
		title = props.attributes.title;
		(!!props.attributes.title[0] && !!props.attributes.title[0].props) && (title = props.attributes.title[0].props.children);

		let imgBlock = (props.attributes.link) ? el(
			'a',
			{
				href: props.attributes.link,
				target: (props.attributes.newWindow) ? '_blank' : false,
				rel: (props.attributes.newWindow) ? 'noopener noreferrer' : false,
			},
			el(	'img', {
					src: props.attributes.imgURL,
					alt: props.attributes.imgALT,
				}
			)
		) : el(
			'img',
			{
				src:props.attributes.imgURL,
				alt:props.attributes.imgALT,
			}
		);

        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className:'story-block',
                },
                el(
                    'div',
                    {
                        className:'story-image',
                    },
                    imgBlock
                ),
                el(
                    'div',
                    {
                        className:'story-content',
					},
					(props.attributes.link) ?
					el(
						'div',
						{
							className:'title'
						},
						el(
							'a', {
								href: props.attributes.link,
								target: (props.attributes.newWindow) ? '_blank' : false,
								rel: (props.attributes.newWindow) ? 'noopener noreferrer' : false,
							},
							title,
						)
					) : el(
                        'div',
                        {
                            className:'title'
                        },
						title,
					),
					( props.attributes.label ) ? el(
                        RichText.Content,
                        {
                            tagName: 'div',
                            value: props.attributes.label,
                            className:'label'
                        },
                    )  : '',
                    el(
                        RichText.Content,
                        {
                            tagName: 'p',
                            value: props.attributes.content,
                            className:'about'
                        },
                    ),
                    ( props.attributes.link && props.attributes.linkWithBtn ) ? el(
                        'a',
                        {
                            href:props.attributes.link,
                            target:(props.attributes.newWindow) ? '_blank' : false,
                            rel:(props.attributes.newWindow) ? 'noopener noreferrer' : false,
                            className:'read-more'
                        },
                        props.attributes.linkWithBtnLabel,
                    ) : ''
                )

            )
        );
    }


} );
<?php
/**
 * The template for displaying content pages (not found)
 *
 * @package Mobikul
 * @subpackage Webkul
 * @since webkul theme
 */

?>

<div class="not-found margin-top">
	<div class="bullet-proof-error bullet-proof-h1-error text-center">
		<h1> We Are Writing </h1>
		<p class="page-not-found-text-p2">The content you are looking for is getting ready, Kindly stay in touch...</p>
	</div>
</div>

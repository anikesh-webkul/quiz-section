<?php 
/**
 * The template for displaying Page Not found 
 *
 * This is the template that displays Page Not found.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation	
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */  
get_header();
?>
<section class="outer-wrapper">
	<div class="container wk-inner-wrapper wk-common-padding">
		<div class="page-not-found">
			<div class="row">
				<div class="col-md-10 text-center">
					<img src="<?php echo get_template_directory_uri().'/images/404/404.png'?>" class="img-responsive img-not-found">
				</div>
				<div class="col-md-2"></div>
			</div>
			<div class="row">
				<div class="hidden-md col-sm-2"></div>
				<div class="col-md-12 col-sm-10">
					<h1 class="text-center">PAGE NOT FOUND</h1> 
					<p class="text-center">The page you are looking for doesn't exist. Go to <a href="<?php echo site_url(); ?>" title="Qloapps">Home Page</a></p>
				</div>
			</div>
		</div>
	</div>		
</section>	
<?php get_footer();	?>
	
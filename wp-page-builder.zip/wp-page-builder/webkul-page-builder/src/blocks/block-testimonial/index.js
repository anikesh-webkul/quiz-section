/**
 * Register Custom Block Jumbotron
 */

registerBlockType( 'wk-blocks/testimonial', {
    title : 'Testimonial',
    icon : 'align-center',
    category: 'webkul',
    keywords: [
        'Testimonail',
    ],
    // parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    example: {},

    attributes: {
        content: {
            selector: 'p',
            type:'array',
            source: 'children',
        },
        title: {
            type:'array',
            source: 'children',
            selector: 'h5',
        },
        company: {
            type:'array',
            selector:'span',
            source:'children'
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgURL: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
        },
    },
    edit : function( props ) {
        var content = props.attributes.content,
        title = props.attributes.title,
        imgURL = props.attributes.imgURL,
        imgALT = props.attributes.imgALT,
        imgID = props.attributes.imgID,
        company = props.attributes.company;

        const onChangeTitle = ( newTitle ) => {
            props.setAttributes( { title: newTitle } );
        }
        const onChangeContent = ( newContent ) => {
            props.setAttributes( { content: newContent } );
        }
        const onRemoveImage = () => {
			props.setAttributes( {
				imgURL: null,
                imgID: null,
                imgALT:null,
			} );
        };
        return el(
            Fragment,
            {},

            el(
                'div',
                {
                    className:'wk-testimonial-wrap text-center',
                },

                el(
                    'div',
                    {
                        className:'wk-image-uploader',
                    },
                    el(
                        RichText,
                        {
                            key: 'editable',
                            tagName: 'p',
                            value: content,
                            onChange: onChangeContent,
                            placeholder:'Testimonial Description....'
                        },
                    ),
                    el(
                        MediaUpload,
                        {
                            type: "image",
                            allowed: ALLOWED_MEDIA_TYPES,
                            value: imgID,
                            onSelect: img => props.setAttributes({
                                imgID: img.id,
                                imgURL: img.url,
                                imgALT:img.alt ? img.alt : img.title 
                            }),
                            render: ({ open }) => el(
                                Fragment,
                                null,
                                el(
                                    Button,
                                    {
                                        className: imgURL ? 'wk-change-image' : 'wk-add-image',
                                        onClick: open,
                                        style:{ maxWidth: '120px', paddingTop: '15%' },
                                    },
                                    ! imgURL ? wkUploadIcon : el( "img",
                                        {
                                            src: imgURL,
                                            alt: imgALT
                                        }
                                    )
                                ),
                                imgURL && el(
                                    Button,
                                    {
                                        className: "wk-remove-image",
                                        onClick: onRemoveImage
                                    },
                                    el(
                                        Dashicon,
                                        {
                                            icon: 'dismiss'
                                        }
                                    )
                                )
                            )
                        }
                    ),
                   
                ),
                /** //MediaUpload End */

                el(
                    RichText,
                    {
                        key: 'editable',
                        tagName: 'h5',
                        value: title,
                        onChange: onChangeTitle,
                        placeholder:'Testimonial Client Name.....'
                    },
                ),
                el(
                    RichText,
                    {
                        key: 'editable',
                        tagName: 'span',
                        value: company,
                        onChange: (company) => { props.setAttributes({company:company}) },
                        placeholder:'Testimonial Client Company'
                    },
                ),

            )
        );
        /** //WP Fragment End */
    },

    save:function(props) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className: ( props.attributes.className ) ? 'wk-testimonial-wrap ' + props.attributes.className : 'wk-testimonial-wrap'
                },
                el(
                    RichText.Content,
                    {
                        tagName: 'p',
                        className:'content',
                        value: props.attributes.content,
                    },
                ),
                ( props.attributes.imgURL ) &&
                el(
                    'img',
                    {
                        className:'img',
                        alt:props.attributes.imgALT,
                        src:props.attributes.imgURL,
                    },
                ),
                el(
                    RichText.Content,
                    {
                        tagName:'h5',
                        className:'tilte',
                        value:props.attributes.title,
                    }
                ),
                el(
                    RichText.Content,
                    {
                        tagName:'span',
                        className:'company',
                        value:props.attributes.company,
                    }
                )
            ),
        );
    }


} );
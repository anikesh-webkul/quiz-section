<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();

$page_id     = get_the_id();
$has_header  = get_post_meta( $page_id, 'wk_page_has_header', true );
$has_infobox = get_post_meta( $page_id, 'wk_infobox_visible', true );
$all_infra   = get_option( 'wktheme-page-infrastructure' );
$all_infra   = ( '' === $all_infra ) ? array() : $all_infra;
$path        = wp_upload_dir()['baseurl'];
?>

<?php
if ( '1' === $has_header ) {

	$layout        = get_post_meta( $page_id, 'wk_page_layout_view', true );
	$grid_class    = ( 'wide' === $layout ) ? 'wkgrid-wide' : 'wkgrid-squeezy';
	$has_bg_col    = ( 'wide' === $layout ) ? 'section-padding-bk has-bgcol' : 'section-padding-bk';
	$tagline       = get_post_meta( $page_id, 'wk_banner_tagline', true );
	$feat_img      = get_the_post_thumbnail_url( $page_id, 'full' );
	$opt_btn_attrs = maybe_unserialize( get_post_meta( $page_id, 'wk_opt_btn_attr', true ) );
	?>

	<section class="wk-page-header <?php echo esc_attr( $has_bg_col ); ?> has-bg-gradient container-margin-down-40 dir-rtl">
		<div class="<?php echo esc_attr( $grid_class ); ?>">
			<div class="page-banner">
				<img src="<?php echo esc_url( $feat_img ); ?>" />
			</div>
			<div class="page-tagline">
				<h1><?php echo $tagline; ?></h1>
				<?php
				if ( isset( $opt_btn_attrs['enable'] ) && '1' === $opt_btn_attrs['enable'] && ! empty( $opt_btn_attrs['link'] ) && ! empty( $opt_btn_attrs['label'] ) ) {

					$_link   = ( ! empty( $opt_btn_attrs['link'] ) ) ? $opt_btn_attrs['link'] : '';
					$_label  = ( ! empty( $opt_btn_attrs['label'] ) ) ? $opt_btn_attrs['label'] : '';
					$_rel    = ( ! empty( $opt_btn_attrs['rel'] ) ) ? ' rel=' . $opt_btn_attrs['rel'] : '';
					$_target = ( ! empty( $opt_btn_attrs['target'] ) ) ? ' target=_blank' : '';
					$_color  = ( ! empty( $opt_btn_attrs['color'] ) && 'prime' === $opt_btn_attrs['color'] ) ? 'wk-button' : 'wk-button ' . $opt_btn_attrs['color'];

					echo '<a class="' . esc_attr( $_color ) . '" href="' . esc_url( $_link ) . '"' . esc_attr( $_target . $_rel ) . '>' . esc_attr( $_label ) . '</a>';
				}
				?>
			</div>
			<?php echo ( 'wide' === $layout ) ? '' : ''; ?>
		</div>
	</section>
	<?php
}
add_action( 'wk_brand_kit_template', function( $data ) {
	$path        = get_template_directory_uri() . '/images/brand-kit/';
	$heading     = isset( $data['heading'] ) ? $data['heading'] : '';
	$description = isset( $data['desc'] ) ? $data['desc'] : '';
	$img_array   = isset( $data['img_array'] ) ? $data['img_array'] : array();
	$class       = isset( $odd ) ? 'wrap-small' : '';
	$btn         = '';
	?>
	<section class="section-padding wk-brand-kit-wrapper">
		<div class="wkgrid-wide">
			<div class="wk-brand-kit-data">
				<h2><?php echo esc_attr( $heading ); ?></h2>
				<p class="text-light"><?php echo esc_attr( $description ); ?></p>
			</div>
			<div class="wk-brand-kit-img-wrap">
				<?php
				$count = count( $img_array );
				$odd   = ( $count % 2 ) == 0 ? false : true;
				$val   = $count - 3;
				$small = '';
				foreach ( $img_array as $key => $value ) {

					$desc      = isset( $value['desc'] ) ? '<div class="desc">' . $value['desc'] . '</div>' : '';
					$img       = '';
					$only_text = '';
					if ( isset( $value['path'] ) ) {
						$img = '<img src=" ' . esc_url( $path . $value['path'] ) . '"/>';
					} else {
						$only_text = 'only-text';
					}
					if ( $odd && $val <= $key ) {
						$small = ' wrap-small';
					}
					?>
					<div class="img-wrap <?php echo esc_attr( $only_text . $small ); ?>">
						<?php echo $img . $desc;?>
					</div>
					<?php
				}
				$small = '';
				?>
			</div>
		</div>
	</section>
	<?php
}
);
$img_array = array(
	array(
		'path' => 'ap-1.png',
	),
	array(
		'path' => 'ap-2.png',
	),
	array(
		'desc' => '<p class="text-light">Logo symbol used only on square space.</p>',
	),
	array(
		'path' => 'square.png',
	),
	array(
		'path' => 'breating.png',
	),
);

$data      = array(
	'heading'   => 'Aspect Ratio',
	'desc'      => 'Our text and symbol have estimated ratio and breathing space.',
	'img_array' => $img_array,
);
do_action( 'wk_brand_kit_template', $data );

$img_array = array(
	array(
		'path' => 'webkul-logo-white.png',
		'desc' => '<p> Color Logo</p><p class="text-light">Use blue (#2149f3) logo on white background</p>',
	),
	array(
		'path' => 'webkul-logo-blue.png',
		'desc' => '<p> Color Logo</p><p class="text-light">Use white logo on blue (#2149f3) background</p>',
	),
	array(
		'path' => 'webkul-black.png',
		'desc' => '<p> Black & White Logo</p><p class="text-light">Use black logo on white background</p>',
	),
	array(
		'path' => 'webkul-logo-balck.png',
		'desc' => '<p> Black & White Logo</p><p class="text-light">Use white logo on black background</p>',
	),
);


$data      = array(
	'heading'   => 'Usage ',
	'desc'      => 'Use the same color and format of the text with symbol.',
	'img_array' => $img_array,
);
do_action( 'wk_brand_kit_template', $data );

$img_array = array(
	array(
		'path' => 'dont-1.png',
	),
	array(
		'path' => 'dont-2.png',
	),
	array(
		'path' => 'dont-3.png',
	),
	array(
		'path' => 'dont-4.png',
	),
);

$data      = array(
	'heading'   => 'Don’t Do  ',
	'desc'      => 'Remember the points before using our logo.',
	'img_array' => $img_array,
);
do_action( 'wk_brand_kit_template', $data );

?>
<section class="section-padding-0B">
</section>
<?php
get_footer();

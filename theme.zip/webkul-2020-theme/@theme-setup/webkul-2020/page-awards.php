<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();
?>

<div class="wk-award-hero-section">
	<div class="wk-award-placeholder">
		<div class="wk-award-slider owl-carousel owl-theme">
			<div class="item">
				<img class="wk-award-slider-img" src="<?php echo esc_url( get_template_directory_uri() . '/images/awards/award-deloitte-2019.png' ); ?>" alt="Technology Fast 50 2018 INDIA"/>
			</div>
			<div class="item">
				<img class="wk-award-slider-img" src="<?php echo esc_url( get_template_directory_uri() . '/images/awards/award-cover-startup-50-2018.jpg' ); ?>" alt="Startup 50 Award"/>
			</div>
			<div class="item">
				<img class="wk-award-slider-img" src="<?php echo esc_url( get_template_directory_uri() . '/images/awards/award-cover-deloitte-2018.jpg' ); ?>" alt="Deloitte-2015 Award"/>
			</div>
			<div class="item">
				<img class="wk-award-slider-img" src="<?php echo esc_url( get_template_directory_uri() . '/images/awards/2016.jpg' ); ?>" alt="Technology Fast 50 2018 INDIA"/>
			</div>
			<div class="item">
				<img class="wk-award-slider-img" src="<?php echo esc_url( get_template_directory_uri() . '/images/awards/2015.jpg' ); ?>" alt="Technology Fast 50 2018 INDIA"/>
			</div>
		</div>
	</div>
</div>

<section class="wk-awards-page section-padding">
	<div class="awards-gallery-part text-center">
		<div class="wkgrid-wide">
			<h1 class="col-main">Awards</h1>
			<p>Enlightening the glory of 10 years of hard work</p>
			<div class="section-padding-0B">
				<img src="<?php echo esc_url( get_template_directory_uri() . '/images/awards/award-logo-deloitte.png' ); ?>" alt="award-logo-deloitte"/>
				<img src="<?php echo esc_url( get_template_directory_uri() . '/images/awards/award-logo-startup-50-2018.jpg' ); ?>" alt="award-logo-startup-50-2018"/>
				<img src="<?php echo esc_url( get_template_directory_uri() . '/images/awards/award-logo-magento-imagine-technology-partner-winner-2018.png' ); ?>" alt="award-logo-magento-imagine-technology-partner-winner-2018"/>
				<img src="<?php echo esc_url( get_template_directory_uri() . '/images/awards/award-logo-magento-innovations-lab-winner-2018.png?v=1.0' ); ?>" alt="award-logo-magento-innovations-lab-winner-2018"/>
			</div>
		</div>
	</div>

	<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

	<?php

	$tweets = array(
		'<blockquote class="twitter-tweet" data-lang="en-gb"><p lang="en" dir="ltr">Congrats to <a href="https://twitter.com/hashtag/Magento?src=hash&amp;ref_src=twsrc%5Etfw">#Magento</a> Technology Partner <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a> for creating the Top Selling Extension in 2017 <a href="https://t.co/3YkX6sW0Dm">https://t.co/3YkX6sW0Dm</a>  <a href="https://twitter.com/hashtag/MagentoImagine?src=hash&amp;ref_src=twsrc%5Etfw">#MagentoImagine</a> <a href="https://t.co/VcFuuCiIjh">pic.twitter.com/VcFuuCiIjh</a></p>&mdash; Magento (@magento) <a href="https://twitter.com/magento/status/989745473958260736?ref_src=twsrc%5Etfw">27 April 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="cs" dir="ltr">Micron.JS - a [μ] microInteraction Library <a href="https://t.co/1wft2mQ7ii">https://t.co/1wft2mQ7ii</a></p>&mdash; Uber Engineering (@UberEng) <a href="https://twitter.com/UberEng/status/955266297285275649?ref_src=twsrc%5Etfw">January 22, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">During <a href="https://twitter.com/hashtag/AppDemoJam?src=hash&amp;ref_src=twsrc%5Etfw">#AppDemoJam</a>, <a href="https://twitter.com/odaseva?ref_src=twsrc%5Etfw">@odaseva</a> addresses <a href="https://twitter.com/hashtag/GDPR?src=hash&amp;ref_src=twsrc%5Etfw">#GDPR</a> and <a href="https://twitter.com/wedgecommerce?ref_src=twsrc%5Etfw">@wedgecommerce</a> shows a <a href="https://twitter.com/communitycloud?ref_src=twsrc%5Etfw">@communitycloud</a> integration. Cool! Check out the apps: <a href="https://t.co/qqofL2lTGv">https://t.co/qqofL2lTGv</a> <a href="https://t.co/ng92CErWHL">pic.twitter.com/ng92CErWHL</a></p>&mdash; Salesforce AppExchange (@appexchange) <a href="https://twitter.com/appexchange/status/997171935296532481?ref_src=twsrc%5Etfw">May 17, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">An interesting article by <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a> : <a href="https://t.co/CI8BI8qCpR">https://t.co/CI8BI8qCpR</a><br><br>Agree with that queues are the future of scalable eCommerce.<br>Actually, I am considering revamping <a href="https://twitter.com/hashtag/ElasticSuite?src=hash&amp;ref_src=twsrc%5Etfw">#ElasticSuite</a> indexing to use it.</p>&mdash; Aurélien FOUCRET (@afoucret) <a href="https://twitter.com/afoucret/status/996307596612132869?ref_src=twsrc%5Etfw">May 15, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en-gb"><p lang="en" dir="ltr">Check out the second round of selections for the <a href="https://twitter.com/hashtag/MagentoInnovationsLab?src=hash&amp;ref_src=twsrc%5Etfw">#MagentoInnovationsLab</a>. Innovations from Fast White Cat S.A., <a href="https://twitter.com/netstarter?ref_src=twsrc%5Etfw">@netstarter</a>, <a href="https://twitter.com/imgmage?ref_src=twsrc%5Etfw">@imgmage</a>, and <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a>.  <a href="https://t.co/kxU5jZ5UCN">https://t.co/kxU5jZ5UCN</a> <a href="https://t.co/nuzxRRp8o6">pic.twitter.com/nuzxRRp8o6</a></p>&mdash; Magento (@magento) <a href="https://twitter.com/magento/status/1039596447782645763?ref_src=twsrc%5Etfw">11 September 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Vivid.js - A new <a href="https://twitter.com/hashtag/JavaScript?src=hash&amp;ref_src=twsrc%5Etfw">#JavaScript</a> library that allows you to easily customize and use <a href="https://twitter.com/hashtag/SVG?src=hash&amp;ref_src=twsrc%5Etfw">#SVG</a> Icons with ease <a href="https://t.co/CA8iCxpguQ">https://t.co/CA8iCxpguQ</a></p>&mdash; Speckyboy (@speckyboy) <a href="https://twitter.com/speckyboy/status/1006571884484448256?ref_src=twsrc%5Etfw">June 12, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Open Source SVG Icons Library – Vivid.js <a href="https://t.co/UKvZtcDn5e">https://t.co/UKvZtcDn5e</a></p>&mdash; Hacker News (@newsycombinator) <a href="https://twitter.com/newsycombinator/status/1005933016844242945?ref_src=twsrc%5Etfw">June 10, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Here&#39;s a microInteraction library built with CSS and JavaScript for your next project 🛠️✨ <a href="https://t.co/Y4vLuBhqlT">https://t.co/Y4vLuBhqlT</a> <a href="https://t.co/hmyeYhBF0t">pic.twitter.com/hmyeYhBF0t</a></p>&mdash; Product Hunt (@ProductHunt) <a href="https://twitter.com/ProductHunt/status/955772376901455872?ref_src=twsrc%5Etfw">January 23, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">&quot;a microInteraction library built with CSS Animations and controlled by JavaScript&quot;<a href="https://t.co/udsWjoG7bm">https://t.co/udsWjoG7bm</a> <a href="https://t.co/NHCVx4BHWn">pic.twitter.com/NHCVx4BHWn</a></p>&mdash; CSS-Tricks (@css) <a href="https://twitter.com/css/status/955877805560131584?ref_src=twsrc%5Etfw">January 23, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">30 free gradient hues and swatches 🎨✨ <a href="https://t.co/FaPI9MiMGc">https://t.co/FaPI9MiMGc</a> <a href="https://t.co/q9yJAJOSwf">pic.twitter.com/q9yJAJOSwf</a></p>&mdash; Product Hunt (@ProductHunt) <a href="https://twitter.com/ProductHunt/status/876470106188124161?ref_src=twsrc%5Etfw">June 18, 2017</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Micron.js - a [μ] microInteraction library built with <a href="https://twitter.com/hashtag/CSS?src=hash&amp;ref_src=twsrc%5Etfw">#CSS</a> Animations and controlled by JavaScript Power <a href="https://t.co/QWPEfvu20p">https://t.co/QWPEfvu20p</a></p>&mdash; Speckyboy (@speckyboy) <a href="https://twitter.com/speckyboy/status/955893264141438976?ref_src=twsrc%5Etfw">January 23, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Bagisto - Open Source eCommerce Framework on Laravel <a href="https://t.co/FA7jxBZ2LS">https://t.co/FA7jxBZ2LS</a></p>&mdash; Laravel News Links (@LaravelLinks) <a href="https://twitter.com/LaravelLinks/status/1065792302206070784?ref_src=twsrc%5Etfw">November 23, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="ja" dir="ltr">前の記事: 最近のデザインでよく見かける色相を変化させた美しいグラデーションがまとめられた無料素材 -coolHue <a href="https://t.co/xs173NL8at">https://t.co/xs173NL8at</a></p>&mdash; コリス🍡 (@colisscom) <a href="https://twitter.com/colisscom/status/1019237395118501888?ref_src=twsrc%5Etfw">July 17, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Coolhue :: <a href="https://t.co/oQjaVynXzt">https://t.co/oQjaVynXzt</a> <a href="https://t.co/xuJ2FYJVAV">pic.twitter.com/xuJ2FYJVAV</a></p>&mdash; CSS-Tricks (@css) <a href="https://twitter.com/css/status/1018967769851809793?ref_src=twsrc%5Etfw">July 16, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Open-source, customizable SVG icons for your next project ✨ <a href="https://t.co/HBg4tnDtRg">https://t.co/HBg4tnDtRg</a> <a href="https://t.co/6AdJXewH2U">pic.twitter.com/6AdJXewH2U</a></p>&mdash; Product Hunt (@ProductHunt) <a href="https://twitter.com/ProductHunt/status/1007412878943637504?ref_src=twsrc%5Etfw">June 15, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="da" dir="ltr">SVG Icons Tutorial - A Look at Vivid.js: <a href="https://t.co/JDYQSs5afx">https://t.co/JDYQSs5afx</a> via <a href="https://twitter.com/YouTube?ref_src=twsrc%5Etfw">@YouTube</a></p>&mdash; Coursetro (@designcoursecom) <a href="https://twitter.com/designcoursecom/status/1006187646509514752?ref_src=twsrc%5Etfw">June 11, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Check out <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a> as they share a few commands with which you can execute the Unit Testing in Magento 2. <a href="https://twitter.com/hashtag/magento?src=hash&amp;ref_src=twsrc%5Etfw">#magento</a> <a href="https://twitter.com/hashtag/php?src=hash&amp;ref_src=twsrc%5Etfw">#php</a> <a href="https://twitter.com/hashtag/testing?src=hash&amp;ref_src=twsrc%5Etfw">#testing</a> <a href="https://t.co/oKDcogPjTM">https://t.co/oKDcogPjTM</a></p>&mdash; Nexcess (@nexcess) <a href="https://twitter.com/nexcess/status/961698680213573633?ref_src=twsrc%5Etfw">February 8, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">How to Quickly Add Microinteractions to Your Website <a href="https://t.co/2zG3HfVzL0">https://t.co/2zG3HfVzL0</a></p>&mdash; Envato Tuts+ Web (@wdtuts) <a href="https://twitter.com/wdtuts/status/983643274685665280?ref_src=twsrc%5Etfw">April 10, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">coolHue - Coolest Gradient Hues and Swatches <a href="https://t.co/09K43lOajJ">https://t.co/09K43lOajJ</a> <a href="https://t.co/Ac4B7OPgKy">pic.twitter.com/Ac4B7OPgKy</a></p>&mdash; Speckyboy (@speckyboy) <a href="https://twitter.com/speckyboy/status/877013225124110336?ref_src=twsrc%5Etfw">June 20, 2017</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">A new interesting project created with Symfony components: UVdesk (<a href="https://twitter.com/uvdesk?ref_src=twsrc%5Etfw">@uvdesk</a>) an open source helpdesk application: <a href="https://t.co/LJnoNLsLqQ">https://t.co/LJnoNLsLqQ</a></p>&mdash; Symfony News (@symfony_en) <a href="https://twitter.com/symfony_en/status/1069885120247726080?ref_src=twsrc%5Etfw">December 4, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en-gb"><p lang="en" dir="ltr">.<a href="https://twitter.com/vipinsahu?ref_src=twsrc%5Etfw">@vipinsahu</a> of <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a> leveraged &quot;Machine Learning Search&quot; to make searching an entire <a href="https://twitter.com/hashtag/Magento?src=hash&amp;ref_src=twsrc%5Etfw">#Magento</a> product catalog as easy as taking a selfie <a href="https://twitter.com/hashtag/MagentoInnovationsLab?src=hash&amp;ref_src=twsrc%5Etfw">#MagentoInnovationsLab</a> Check it out: <a href="https://t.co/GdYUUdw1kZ">https://t.co/GdYUUdw1kZ</a> <a href="https://t.co/5v0NEXMDQw">pic.twitter.com/5v0NEXMDQw</a></p>&mdash; Magento (@magento) <a href="https://twitter.com/magento/status/1064571843338797056?ref_src=twsrc%5Etfw">19 November 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">CoolHue – Coolest Gradient Hues and Swatches <a href="https://t.co/dKIVZTJhp6">https://t.co/dKIVZTJhp6</a></p>&mdash; Hacker News (@newsycombinator) <a href="https://twitter.com/newsycombinator/status/876439565703286784?ref_src=twsrc%5Etfw">June 18, 2017</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">&quot;a JavaScript library which is built to easily customize and use SVG Icons.&quot;<a href="https://t.co/MwGbGeE2Yk">https://t.co/MwGbGeE2Yk</a> <a href="https://t.co/ERIZfTjkPr">pic.twitter.com/ERIZfTjkPr</a></p>&mdash; CSS-Tricks (@css) <a href="https://twitter.com/css/status/1007759663989960705?ref_src=twsrc%5Etfw">June 15, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en-gb"><p lang="en" dir="ltr">New <a href="https://twitter.com/hashtag/Magento?src=hash&amp;ref_src=twsrc%5Etfw">#Magento</a> <a href="https://twitter.com/hashtag/DeveloperDiaries?src=hash&amp;ref_src=twsrc%5Etfw">#DeveloperDiaries</a>: Interview with <a href="https://twitter.com/vipinsahu?ref_src=twsrc%5Etfw">@vipinsahu</a>, Director of eCommerce at <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a>, creator of the Multi-Vendor Marketplace extension <a href="https://t.co/Ypdv1tr7mF">https://t.co/Ypdv1tr7mF</a> <a href="https://twitter.com/hashtag/developers?src=hash&amp;ref_src=twsrc%5Etfw">#developers</a> <a href="https://t.co/amPFt1sYNk">pic.twitter.com/amPFt1sYNk</a></p>&mdash; Magento (@magento) <a href="https://twitter.com/magento/status/1006193311454031872?ref_src=twsrc%5Etfw">11 June 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en-gb"><p lang="en" dir="ltr"><a href="https://twitter.com/hashtag/MagentonnovationsLab?src=hash&amp;ref_src=twsrc%5Etfw">#MagentonnovationsLab</a>: We are delighted to share outstanding innovations from Fast White Cat S.A., <a href="https://twitter.com/netstarter?ref_src=twsrc%5Etfw">@netstarter</a>, <a href="https://twitter.com/imgmage?ref_src=twsrc%5Etfw">@imgmage</a>, and <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a>. Check them out! <a href="https://t.co/kxU5jZ5UCN">https://t.co/kxU5jZ5UCN</a> <a href="https://t.co/ydt4O2cIF5">pic.twitter.com/ydt4O2cIF5</a></p>&mdash; Magento (@magento) <a href="https://twitter.com/magento/status/1032648426721357826?ref_src=twsrc%5Etfw">23 August 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="ja" dir="ltr">色を簡単にカスタマイズして使用できる無料アイコンライブラリ「vivid.js」<a href="https://t.co/EJGgFdrmkI">https://t.co/EJGgFdrmkI</a></p>&mdash; GIGAZINE(ギガジン) (@gigazine) <a href="https://twitter.com/gigazine/status/1006144189053132800?ref_src=twsrc%5Etfw">June 11, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr"><a href="https://twitter.com/mangopay?ref_src=twsrc%5Etfw">@mangopay</a> is pleased to welcome <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a> -reference in building marketplaces- into its community of partners! Members of <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a> can benefit from preferred conditions with <a href="https://twitter.com/mangopay?ref_src=twsrc%5Etfw">@mangopay</a>. Contact the team for more info <a href="https://t.co/arguYfRzdx">pic.twitter.com/arguYfRzdx</a></p>&mdash; MANGOPAY (@mangopay) <a href="https://twitter.com/mangopay/status/1041960074883866624?ref_src=twsrc%5Etfw">September 18, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">“Creating Isometric Illustrations—Made Simple with the Geometric Technique” — <a href="https://twitter.com/nitishkmrk?ref_src=twsrc%5Etfw">@nitishkmrk</a> <a href="https://t.co/SAC0CFKGar">https://t.co/SAC0CFKGar</a> <a href="https://t.co/dvJ8RjBgz1">pic.twitter.com/dvJ8RjBgz1</a></p>&mdash; awwwards. (@AWWWARDS) <a href="https://twitter.com/AWWWARDS/status/914866348433510400?ref_src=twsrc%5Etfw">October 2, 2017</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="ja" dir="ltr">クールで美しいグラデーションを集めたサイト「coolHue」 <a href="https://t.co/l7AJqRXsto">https://t.co/l7AJqRXsto</a> <a href="https://t.co/8JRa0eqSUx">pic.twitter.com/8JRa0eqSUx</a></p>&mdash; ライフハッカー［日本版］ (@lifehackerjapan) <a href="https://twitter.com/lifehackerjapan/status/881513682173214720?ref_src=twsrc%5Etfw">July 2, 2017</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Check out Micron.js – &quot;a [μ] microInteraction library built with CSS Animations and controlled by JavaScript Power&quot; <a href="https://t.co/uS2kUjxnzw">https://t.co/uS2kUjxnzw</a> <a href="https://t.co/fkPKWCbLCz">pic.twitter.com/fkPKWCbLCz</a></p>&mdash; Marvel (@marvelapp) <a href="https://twitter.com/marvelapp/status/955410047122714624?ref_src=twsrc%5Etfw">January 22, 2018</a></blockquote>',

		'<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">It’s so great to see the maturity of community who figured out by themselves <a href="https://twitter.com/hashtag/MagentoMSI?src=hash&amp;ref_src=twsrc%5Etfw">#MagentoMSI</a> functionality and spreading the knowledge with others! Well done, <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a> great intro to <a href="https://twitter.com/hashtag/Magento?src=hash&amp;ref_src=twsrc%5Etfw">#Magento</a> MSI project!<a href="https://t.co/ZyzsrGWvXP">https://t.co/ZyzsrGWvXP</a></p>&mdash; Igor Miniailo (@iminyaylo) <a href="https://twitter.com/iminyaylo/status/1025695432268234752?ref_src=twsrc%5Etfw">August 4, 2018</a></blockquote>',

	);

	// shuffle( $tweets );

	?>
	<div class="tweets-loader section-padding" >
		<div class="loader-container">
			<div class="wrapper">
				<div class="b-img lr"></div>
				<div class="b-parts">
					<span class="inline"><wk-circle class="lr"></wk-circle></span>
					<span class="inline"><wk-bar l="medium" class="lr"></wk-bar></span>
				</div>
				<div class="b-parts"><wk-bar l="full" class="lr"></wk-bar><wk-bar l="medium" class="lr"></wk-bar><wk-bar l="short" class="lr"></wk-bar></div>
			</div>
			<div class="wrapper">
				<div class="b-img lr"></div>
				<div class="b-parts">
					<span class="inline"><wk-circle class="lr"></wk-circle></span>
					<span class="inline"><wk-bar l="medium" class="lr"></wk-bar></span>
				</div>
				<div class="b-parts"><wk-bar l="full" class="lr"></wk-bar><wk-bar l="medium" class="lr"></wk-bar><wk-bar l="short" class="lr"></wk-bar></div>
			</div>
			<div class="wrapper">
				<div class="b-img lr"></div>
				<div class="b-parts">
					<span class="inline"><wk-circle class="lr"></wk-circle></span>
					<span class="inline"><wk-bar l="medium" class="lr"></wk-bar></span>
				</div>
				<div class="b-parts"><wk-bar l="full" class="lr"></wk-bar><wk-bar l="medium" class="lr"></wk-bar><wk-bar l="short" class="lr"></wk-bar></div>
			</div>
			<div class="wrapper">
				<div class="b-img lr"></div>
				<div class="b-parts">
					<span class="inline"><wk-circle class="lr"></wk-circle></span>
					<span class="inline"><wk-bar l="medium" class="lr"></wk-bar></span>
				</div>
				<div class="b-parts"><wk-bar l="full" class="lr"></wk-bar><wk-bar l="medium" class="lr"></wk-bar><wk-bar l="short" class="lr"></wk-bar></div>
			</div>
		</div>
	</div>
	<div class="twitter-feeds-part owl-carousel section-padding">
		<?php
		foreach ( $tweets as $tweet ) {
			?>
			<div class="twitter-card">
				<?php
				echo $tweet;
				?>
			</div>
			<?php
		}
		?>
	</div>

	<?php
	$awards = get_option( 'wktheme-page-awards' );
	if ( ! empty( $awards['awards']['items'] ) && count( array_filter( $awards['awards']['items'] ) ) > 0 ) {
		$awards     = $awards['awards']['items'];
		$award_year = array_unique( array_column( $awards, 'year' ) );
		rsort( $award_year ); // sort year according to year;

		function wk_awards_sort( $a, $b ) {

			if( ! empty( $a['date'] ) ) {
				$r = $a['date'] . '-' .$a["year"];
			} else {
				$r = '01-January-' . $a["year"];
			}

			if( ! empty( $b['date'] ) ) {
				$s = $b['date'] . '-' .$b["year"];
			} else {
				$s = '01-January-' . $b["year"];
			}
			return ( strtotime( $r ) <= strtotime( $s ) ) ? 1 : -1;
		}
		usort( $awards, 'wk_awards_sort' );
		$count = 0;
		?>
		<div class="award-listing-part">
			<div class="wkgrid-squeezy">
				<?php
				foreach ( $awards as $award ) {
			
					if ( isset( $award_year[ $count ] ) && $award_year[ $count ] === $award['year'] ) {
						echo '<div class="year-block">Year ' . esc_html( $award['year'] ) . '</div>';
						$count++;
					}
					$image = ( ! empty( $award['image'] ) ) ? wp_upload_dir()['baseurl'] . $award['image'] : false;
					$new_tab = ( 'yes' === $award['new-tab'] ) ? 'target="_blank" rel="noopener noreferrer"' : false;
					$date = ( ! empty( $award['date'] ) ) ? str_replace( '-', ' ', $award['date'] ) . ', ' . $award['year'] : false;
					?>
					<div class="award-block">
						<img class="award-thumbs" alt="<?php echo esc_html( $award['title'] ); ?>" title="<?php echo esc_html( $award['title'] ); ?>" src="<?php echo esc_url( $image ); ?>">
						<div class="award-info">
							<a href="<?php echo esc_url( $award['link'] ); ?>" <?php echo $new_tab; ?> class="link"><?php echo esc_html( $award['title'] ); ?></a>
							<?php
							if ( ! empty( $date ) ) {
								echo "<div class='date'>$date</div>";
							}
							?>
							<p class="desc"><?php echo esc_html( $award['content'] ); ?></p>
						</div>
					</div>
					<?php
				}
				?>
			</div>
		</div>
		<?php
	}
	?>
</section>
<script src="https://owlcarousel2.github.io/OwlCarousel2/assets/vendors/jquery.mousewheel.min.js"></script>
<script>
window.addEventListener( 'load', function(){

	/*Hero slider*/
	jQuery( '.wk-award-slider' ).addClass( 'owl-carousel' ).owlCarousel({
		singleItem: true,
		items: 1,
		nav: true,
		rewindNav :true,
		loop:true,
		dots: false,
		onInitialized: function(){
			document.querySelector( '.wk-award-hero-section .wk-award-placeholder' ).classList.add( 'gradflow-animate-off' );
		}
	});
	/*Hero slider//*/

	var tweets = jQuery( '.twitter-feeds-part' );
	var indexBeforeChange = -1;
	var twitterCards = jQuery( tweets ).find( '.twitter-card' );
	var twitterWidgets = jQuery( tweets ).find( 'twitter-widget' );
	if( jQuery( twitterWidgets ).length ) {
		jQuery( twitterWidgets ).each( function( i, el ){
			try{
				var allA = jQuery( el.shadowRoot ).find( 'a' );
				/*remove Listener from block*/
				var el = jQuery( el.shadowRoot ).find( '.js-clickToOpenTarget' ).get(0);
				elClone = el.cloneNode(true);
				el.parentNode.replaceChild( elClone, el );
				/*//remove Listener from block*/
			} catch(e){

			};
		});
	}

	function removeClicks(e){
		return false;
	}
	tweets.owlCarousel({
		nav:false,
		autoWidth:true,
		margin : 15,
		onDrag : function(event){
			var twitterWidgets = jQuery( tweets ).find( 'twitter-widget' );
			if( jQuery( twitterWidgets ).length ) {
				jQuery( twitterWidgets ).each( function( i, el ){
					var allA = jQuery( el.shadowRoot ).find( 'a' );
					jQuery( allA ).each( function(j,n){
						jQuery(n).click( removeClicks );
					} );
				});
			}
		},
		onDragged: function(e){
			var twitterWidgets = jQuery( tweets ).find( 'twitter-widget' );
			if( jQuery( twitterWidgets ).length ) {
				jQuery( twitterWidgets ).each( function( i, el ){
					var allA = jQuery( el.shadowRoot ).find( 'a' );
					jQuery( allA ).each( function(j,n){
						setTimeout( () => {
							jQuery(n).off( 'click', removeClicks );
						}, 1000);
					} );
				});
			}
		},
		onInitialized: function(){
			var twtLoader = document.querySelector( '.tweets-loader' );
			twtLoader.classList.add( 'off' );
			twtLoader.parentNode.removeChild( twtLoader );
		}
	});
	// window.processing = false;
	tweets.on( 'mousewheel', '.owl-stage', function(e){
		if (e.deltaY > 0) {
			tweets.trigger('next.owl');
		} else {
			tweets.trigger('prev.owl');
		}
		// if (processing === false) {
		// 	processing = true;
		// 	// do something
		// 	setTimeout(function() {
		// 		processing = false;
		// 	}, 250); // waiting 250ms to change back to false.
		// }
		e.preventDefault();
	});
	tweets.on( 'mousewheel', '.twitter-card', function(e){
		if ( this.querySelector('twitter-widget').offsetHeight > parseInt( window.getComputedStyle( this ).maxHeight ) ) {
			e.stopPropagation();
		}
	});
});
</script>

<?php
get_footer();

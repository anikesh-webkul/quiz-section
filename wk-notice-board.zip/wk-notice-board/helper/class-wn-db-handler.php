<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Wn_DB_Handler' )  ) {

	class Wn_DB_Handler {

		public function __construct() {
			add_action( 'wp_ajax_nopriv_wk_update_notification_order', array( &$this, 'wk_update_notification_order' ) );

			add_action( 'wp_ajax_wk_update_notification_order', array( &$this, 'wk_update_notification_order' ) );

		}

		public function wk_update_notification_order() {
			global $wpdb;
			$table_name = $wpdb->prefix . 'banner_list';
			$order      = array_reverse( $_POST['order_id'] );
			for ( $i = 1; $i <= count($order); $i++ ) {
				$wpdb->update( $table_name, array( 'priority' => (int) $i ), array( 'id' => (int) $order[ $i - 1 ] ), array( '%d' ), array( '%d' ) );
			}
			die;
		}

	}

	return new Wn_DB_Handler;

}
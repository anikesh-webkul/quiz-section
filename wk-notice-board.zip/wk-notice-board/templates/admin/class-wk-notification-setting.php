<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'Wk_Notification_Setting' ) ) {

	class Wk_Notification_Setting {

		public function __construct() {
			?>
			<div class="wrap">


				<?php
				add_action( 'wk_color-settings_page_setting_tab', function() {
					?>
					<form action="" method="POST">

						<table class="form-table">

							<tbody>

								<tr>

									<th colspan="2">

										<h3>Color Settings</h3>

									</th>

								</tr>

								<tr>

									<th class="inner-wrap">

										<label for="">Background Color</label>

									</th>

									<td>

										<input type="color" class="color-picker" name="wc_custom_banner_background_color" value="<?php echo get_option( 'wc_custom_banner_background_color' ); ?>" />


									</td>

								</tr>

								<tr>

									<th>

										<label for="">Text Color</label>

									</th>

									<td>

										<input type="color" class="color-picker" name="wc_custom_banner_text_color" value="<?php echo get_option( 'wc_custom_banner_text_color' ); ?>" />

									</td>

								</tr>

								<tr>

									<th class="inner-wrap">

										<label for="">Link Color</label>

									</th>

									<td>

										<input type="color" class="color-picker" name="wc_custom_banner_link_color" value="<?php echo get_option( 'wc_custom_banner_link_color' ); ?>" />

									</td>

								</tr>

								<tr>

									<th class="inner-wrap">

										<label for="">Link Background Color</label>

									</th>

									<td>

										<input type="color" class="color-picker" name="wc_custom_banner_link_background_color" value="<?php echo get_option( 'wc_custom_banner_link_background_color' ); ?>" />



									</td>

								</tr>

								<tr>

									<td>

										<input type="submit" class="button button-primary" name="banner_settings" value="Save Changes" />

									</td>

								</tr>

							</tbody>

						</table>

					</form>
					<?php

				} );
				add_action( 'wk_notification-rearrange_page_setting_tab', function() {
					global $wpdb;
					$table_name        = $wpdb->prefix . 'banner_list';
					$sort_notification = $wpdb->get_results( "SELECT * from $table_name WHERE status='enable' ORDER BY priority DESC", ARRAY_A );
					console_log( $sort_notification );
					echo '<p style="margin-top:15px;" class="description">' . __( 'Drag and Drop Categories to arrange order on front-end.', 'knw' ) . ' </p>';

					echo '<form action="" class="wk-notification-rearrange-form">';

					echo '<ul id="wk-notification-rearrange-list">';

						foreach ( $sort_notification as $key => $value ) {
							echo '<li id="order_id_' . $value['id'] . '" data-term-id="' . $value['id'] . '" class="wk-rearrange-order">' . _wk_remove_slashes( $value['banner_text'] ) . '</li>';

						}

					echo '</ul>';

					submit_button();

					echo '</form>';
					?>
					<?php
				});
				?>

				<div class="wkug-template">
					<nav class="nav-tab-wrapper">
						<?php
						$wkug_setting_tabs = array(
							'color-settings'         => 'Color Settings',
							'notification-rearrange' => 'Notification Rearrange',
						);
						$current_tab = empty( $_GET['tab'] ) ? 'color-settings' : sanitize_title( $_GET['tab'] );
						$id          = $current_tab;

						foreach ( $wkug_setting_tabs as $name => $label ) {

							echo '<a href="' . esc_url( admin_url( 'admin.php?page=notification-setting&tab=' . $name ) ) . '" class="nav-tab ' . ( $current_tab === $name ? 'nav-tab-active' : '' ) . '">' . esc_html( $label ) . '</a>';
						}
						?>
					</nav>
					<br />

					<?php
					do_action( 'wk_' . $current_tab . '_page_setting_tab' );
					?>
				</div>
			</div>


			<?php
		}

	}

	return new Wk_Notification_Setting();

}
<?php
global $wpdb;
$job_id     = sanitize_title_with_dashes( get_query_var( 'job' ) );
$table      = $wpdb->prefix . 'open_positions';
$upload     = wp_upload_dir();
$all_events = get_option( 'wktheme-page-events' );
$all_events = ( '' === $all_events ) ? array() : $all_events;
$query_job  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE slug='%s'", $job_id ), ARRAY_A );

function filter_shared_job( $positions_bag, $job_id ) {
	$job_obj = array_values( array_filter( $positions_bag, function ( $item ) use ( $job_id ) {
		if ( trim( $item['position_name'] ) === $job_id || get_jobpost_slug_from_name( $item['position_name'] ) === $job_id ) {
			return $item;
		}
	} ) );
	return $job_obj;
}

if ( empty( $query_job ) ) {
	$positions_bag = $wpdb->get_results( "SELECT * FROM $table", ARRAY_A );
	$job_bag       = filter_shared_job( $positions_bag, $job_id );
	$job_bag       = ( ! empty( $job_bag ) ) ? $job_bag[0] : array();
} else {
	$job_bag = $query_job[0];
}

/*404 if no post found*/
if ( empty( $job_bag ) ) {
	global $wp_query;
	$wp_query->set_404();
	status_header( 404 );
	get_template_part( 404 );
	exit(); // exit ok.
}
/*//404 if no post found*/

// Job open/close status flag.
$is_post_open = ( isset( $job_bag['visibility'] ) && ! empty( $job_bag['visibility'] ) && ( 'show' === $job_bag['visibility'] ) ) ? true : false;

/*----Include Job templates----*/
require_once WKTHEME_ROOT . '/core/includes/templates/class-wk-job-templates.php';
/*----//Include Job templates----*/

$job_templates = new WK_Job_Templates();

function get_matching_meetups( $all_events, $required ) {

	$meetups = array_filter( $all_events['events']['items'], function( $event ) use ( $required ) {
		return ( in_array( trim( $event['name'] ), $required, true ) );
	} );
	usort( $meetups, function( $a, $b ) {
		return ( strtotime( str_replace( ',', '', $a['date'] ) ) > strtotime( str_replace( ',', '', $b['date'] ) ) ) ? -1 : 1;
	} );

	return $meetups;
}

$extra_details = $job_bag['extra_details'];
$about_job     = '';
$featured_img  = '';
$other_editor  = '';
$platfrom_img  = array();
$meetup        = array();
$speaker_list  = array();
$tweets_list   = array();

if ( ! empty( $extra_details ) ) {

	$extra_details  = maybe_unserialize( $extra_details, true );
	$meetup         = isset( $extra_details['meet_ups'] ) ? json_decode( $extra_details['meet_ups'], true ) : array();
	$about_job      = isset( $extra_details['about_job'] ) ? stripslashes( $extra_details['about_job'] ) : '';
	$featured_img   = isset( $extra_details['banner_image'] ) ? $extra_details['banner_image'] : '';
	$bottom_content = isset( $extra_details['wk_next'] ) ? stripslashes( $extra_details['wk_next'] ) : '';
	$platfrom_img   = isset( $extra_details['platfrom_img'] ) && ! empty( $extra_details['platfrom_img'] ) ? $extra_details['platfrom_img'] : array();
	$speaker_list   = isset( $extra_details['speaker_list'] ) ? $extra_details['speaker_list'] : array();
	$tweets_list    = isset( $extra_details['tweet_links'] ) ? $extra_details['tweet_links'] : array();
	$widget         = isset( $extra_details['job_widget'] ) ? $extra_details['job_widget'] : array();
}

/*Prepare templates*/
$templates = array(
	'post_block'     => '',
	'top_content'    => '',
	'bottom_content' => '',
	'salary'         => '',
	'process'        => '',
	'actions'        => '',
	'platforms'      => '',
	'meetups'        => '',
	'speakers'       => '',
	'tweets'         => '',
	'post_closed'    => '',
);

if ( ! empty( $about_job ) ) {
	$templates['top_content'] = '<div class="wkgrid-left">' . $about_job . '</div>';
}

if ( ! empty( $bottom_content ) ) {
	$templates['bottom_content'] = '<div class="wkgrid-left section-padding-0B job-extra-details">' . $bottom_content . '</div>';
}

if ( '' !== $job_bag['expected_salary'] ) {
	$templates['salary'] = '<span class="ctc" data-val="' . esc_attr( $job_bag['expected_salary'] ) . '">CTC</span>';
}

if ( '' !== $job_bag['interview_process'] ) {

	$rounds = explode( ',', $job_bag['interview_process'] );
	foreach ( $rounds as $round ) {
		$templates['process'] .= '<span>' . esc_html( $round ) . '</span>';
	}
	$templates['process'] = '<span class="process">Interview Process</span><div class="rounds">' . $templates['process'] . '</div>';
}

if ( $is_post_open ) {

	$templates['actions'] = '<div class="details">
	<div><button data-profile="' . $job_bag['position_name'] . '" class="wk-button btn-dark open-form-btns">Apply Now</button>
		<div class="job-actions-parent"><a href="javascript:void(0);" data-jobTitle="' . $job_bag['position_name'] . '" data-jobId="' . $job_id . '" data-jobDesc="' . rawurlencode( $job_bag['position_detail'] ) . '" class="wk-button btn-dark share-job-btns">Share Job</a></div>
		</div>
	</div>';
}

if ( ! $is_post_open ) {

	$templates['post_closed'] = '<div class="wkgrid-wide"><div class="wkjob-post-closed-msg">Uhhh! Vacancy closed for the post of ' . esc_html( $job_bag['position_name'] ) . '. For updates, <a href="https://www.linkedin.com/company/webkul" title="Follow on LinkedIn" target="_blank" rel="nofollow noopener">Follow us on LinkedIn</a></div></div>';
}

$templates['post_block'] = '<div class="profile-slab profile-header post-' . esc_attr( wp_json_encode( $is_post_open, true ) ) . '" id="' . $job_id . '">
	<h1>' . $job_bag['position_name'] . '</h1>
	<p class="desc">' . nl2br( $job_bag['position_detail'] ) . '</p>
	<div class="details">
	<span class="exp" data-val="' . $job_bag['position_experience'] . '">Experience</span>
	<span class="count" data-val="' . $job_bag['openings'] . '">Openings</span>
	' . $templates['salary'] . $templates['process'] . '</div>' . $templates['actions'] . '</div>';

if ( ! empty( $featured_img ) ) {

	$templates['post_block'] = '<div class="wkgrid-wide wk-header-sec null"><div class="inline-dividers-50 inline-top profile-left dividers-50">' . $templates['post_block'] . '</div>
	<div class="inline-dividers-50 inline-top profile-right wk-banner-image-wrap dividers-50">
	<img class="wk-jobs-hero-img wk-hide-image" data-src="' . esc_url( $upload['baseurl'] . $featured_img ) . '" title="' . $job_bag['position_name'] . '" alt="' . $job_bag['position_name'] . '">
		</div>
	</div>';
}

if ( ! empty( $platfrom_img ) ) {

	$templates['platforms'] .= '<div class="wkgrid-left section-padding-0B"><h3>Frameworks</h3><div class="wk-framework-list">';

	foreach ( $platfrom_img as $key => $value ) {

		if ( ! empty( $value ) ) {
			$file = pathinfo( $value );
			$templates['platforms'] .= '<img src="' . esc_url( $upload['baseurl'] . $value ) . '" alt="' . $file['filename'] . '" title="' . $file['filename'] . '">';
		}
	}
	$templates['platforms'] .= '</div></div>';
}

if ( $meetup ) {

	$meetup = get_matching_meetups( $all_events, $meetup );

	if ( ! empty( $meetup ) ) {

		$templates['meetups'] = '<div class="wkgrid-left section-padding-0B wkop-meetups-section">
		<h3>Meetups &amp; Conferences</h3>
		<p>We have organised a set of meetups and workshops to engage with the community -</p>
		<div class="wk-career-meetups owl-carousel owl-theme">';

		foreach ( $meetup as $key => $value ) {

			$templates['meetups'] .= '<div class="wk-meetups-wrap">
			<img src="' . wp_upload_dir()['baseurl'] . $value['logo'] . '">
			<div class="data">
			<p>' . $value['name'] . '</p>
			<p>' . $value['date'] . '</p>';

			if ( ! empty( $value['link'] ) ) {
				$templates['meetups'] .= '<a class="link" href="' . $value['link'] . '" target="_blank" rel="noopener">Read More</a>';
			}

			$templates['meetups'] .= '</div></div>';
		}

		$templates['meetups'] .= '</div></div>';
	}
}

if ( ! empty( $speaker_list ) ) {

	foreach ( $speaker_list as $key => $value ) {

		$templates['speakers'] .= '<div class="card"><img style="border-radius:50%;" src="' . $upload['baseurl'] . $value['image'] . '"><a href="' . esc_url( $value['url'] ) . '" rel="nofollow" target="_blank" title="' . $value['name'] . '"><span class="wk-meetup-tweet"></span></a><p>' . $value['name'] . '</p><p class="card-des">' . $value['desg'] . '</p></div>';
	}

	$templates['speakers'] = '<div class="wkgrid-left section-padding-0B"><h3>Meetup Guest Speakers</h3><div class="meetup-speak-wrap">' . $templates['speakers'] .= '</div></div>';
}

// if ( ! empty( $tweets_list ) ) {

// 	$temp_holder = '';

// 	foreach ( $tweets_list as $key => $value ) {
// 		$temp_holder .= '<div class="wk-tweet-card"><div class="wk-tweet-content">' . stripslashes( json_decode( $value ) ) . '</div></div>';
// 	}

// 	$templates['tweets'] = '<div class="wkgrid-left section-padding-0B wkop-tweets-section">
// 		<h3>Popular Mentions and Tweets</h3>
// 		<div class="wk-awards-page">
// 			<div class="tweets-loader section-padding-0B" >
// 				<div class="loader-container">
// 					<div class="wrapper">
// 						<div class="b-img lr"></div>
// 						<div class="b-parts">
// 							<span class="inline"><wk-circle class="lr"></wk-circle></span>
// 							<span class="inline"><wk-bar l="medium" class="lr"></wk-bar></span>
// 						</div>
// 						<div class="b-parts"><wk-bar l="full" class="lr"></wk-bar><wk-bar l="medium" class="lr"></wk-bar><wk-bar l="short" class="lr"></wk-bar></div>
// 					</div>
// 					<div class="wrapper">
// 						<div class="b-img lr"></div>
// 						<div class="b-parts">
// 							<span class="inline"><wk-circle class="lr"></wk-circle></span>
// 							<span class="inline"><wk-bar l="medium" class="lr"></wk-bar></span>
// 						</div>
// 						<div class="b-parts"><wk-bar l="full" class="lr"></wk-bar><wk-bar l="medium" class="lr"></wk-bar><wk-bar l="short" class="lr"></wk-bar></div>
// 					</div>
// 				</div>
// 			</div>
// 		</div>
// 		<div class="wk-tweet-wrap display-none">
// 		<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script> ' . $temp_holder . '</div></div>';
// }
/*//Prepare templates*/


$GLOBALS['WEBKUL_THEME_OPTIONS']['job_header_meta'] = $job_bag;

get_header( 'job' );

$group_id = esc_attr( strtolower( str_replace( ' ', '-', trim( $job_bag['group_name'] ) ) ) );
?>

<section class="wk-open-position-detail-page wk-open-position jobs-details">

	<div class="section-padding wkjob-post-page-header">

		<div class="wkgrid-wide">
		<?php ob_start(); ?>
		<div class="wkjob-backtrack-links">
			<a href="<?php echo esc_url( home_url( 'careers' ) ); ?>">Careers</a>
			<a href="<?php echo esc_url( home_url( 'jobs' ) ); ?>">Jobs</a>
			<a href="<?php echo esc_url( home_url( 'jobs' ) . '#' . $group_id ); ?>"><?php echo esc_html( $job_bag['group_name'] ); ?></a>
		</div>
		<?php
		$job_breadcrumb = ob_get_contents();
		ob_end_clean();
		echo $job_breadcrumb;
		?>
			
		</div>
		<?php

		echo $templates['post_closed'];

		echo ( ! empty( $featured_img ) ) ? $templates['post_block'] : '<div class="wkgrid-wide">' . $templates['post_block']. '</div>';
		?>
	</div>

	<div class="wkjob-post-page-body">
		<div class="body-wrap">
			<div class="wkgrid-wide">
				<?php
				if ( ! empty( $about_job ) ) {
					?>
					<div class="profile-slab" id="<?php echo esc_attr( $job_id ); ?>">
						<h3><?php echo esc_html( $job_bag['position_name'] ); ?></h3>
						<p class="desc desc-job"><?php echo nl2br( $job_bag['position_detail'] ); ?></p>
						<table>
							<tr class="row">
								<td class="col">Experience</td>
								<td class="col"><?php echo esc_html( $job_bag['position_experience'] ); ?></td>
							</tr>
							<tr class="row">
								<td class="col">Openings</td>
								<td class="col"><?php echo esc_html( $job_bag['openings'] ); ?></td>
							</tr>
							<tr class="row">
								<td class="col">CTC</td>
								<td class="col"><?php echo esc_html( $job_bag['expected_salary'] ); ?></td>
							</tr>
							<tr class="row">
								<td class="col">Interview Process</td>
								<td class="col"><?php echo esc_html( $job_bag['interview_process'] ); ?></td>
							</tr>
						</table>
						<?php echo $templates['actions']; ?>
					</div>

					<?php
					echo $templates['top_content']; // ok.

					echo $templates['meetups'];

					echo $templates['speakers'];

					echo $templates['platforms'];

					echo $templates['bottom_content'];

					echo $templates['tweets'];
				}
				?>
			</div>
		</div>
	</div>
</section>

<?php
if ( ! empty( $about_job ) ) {
	?>
	<div class="wkgrid-wide">
		<div class="wk-jumbo-ad section-top" layout="lateral">
			<div class="wkgrid-squeezy">
				<div class="wk-jumbo-ad-wrap">
					<div class="wk-jumbo-ad-img">
						<img alt="Join Us" data-src="<?php echo get_template_directory_uri() . '/images/job-bag.png?1.0'; ?>" class="wk-lazify">
					</div>
					<div class="wk-jumbo-ad-content">
						<h2 class="title">Join Us</h2>
						<p class="desc">We hunt for creative people, who hunt for an opportunity. Be one of us and let's ship the rockets to the moon together.</p>
						<a href="javascript:void(0);" class="wk-button btn-white open-form-btns" data-profile="<?php echo esc_attr( $job_bag['position_name'] ); ?>">Apply Now</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
?>

<?php
if ( $is_post_open ) {
	$job_templates->cf7form( $job_bag['position_name'], $job_breadcrumb );
	$job_templates->share_brick();
}
?>

<script type="text/html" id="wk-tweet-template">
	<div class="wk-tweet-card">
		<div class="wkt-deck-inner-wrap">
			<div class="wkt-tweet-head">
				<img class="avatar" src="{{tweet_avtar}}">
				<div class="wkt-tweet-detail">
					<span class="wkt-author-name">{{tweet_user}}</span><a class="wkt-author-link" target="_blank" rel="noopener nofollow" href="{{tweet_user_link}}">&nbsp;@{{tweet_screen_name}}</a>
					<div class="wkt-date">{{tweet_date}}</div>
				</div>
			</div>
			<div class="wkt-tweet-body">
				<p class="wkt-tweet-text">{{tweet_data}}</p>{{tweet_media}}
				<div class="wkt-meta">
					<div class="wkt-retweets-likes"><span class="likes">{{tweet_likes}}</span><span class="retweets">{{tweet_retweets}}</span></div>
					<a class="wkt-icon" href="{{tweet_status_link}}" target="_blank" rel="noopener nofollow"></a>
				</div>
			</div>
		</div>
	</div>
</script>

<?php
if ( $is_post_open && ! empty( $widget['widget_label'] ) ) {
	?>
	<div class="wkjob-widget-wrap active">
		<div class="wkjob-widget-inner-wrap">
			<div class="wkjob-widget-opts">
				<div class="wkjob-widget-label"><?php echo esc_html( $widget['widget_label'] ); ?></div>
				<div class="wkjob-widget-desc"><?php echo esc_html( $widget['widget_description'] ); ?></div>
			</div>
			<a href="<?php echo esc_html( $widget['widget_link'] ); ?>" target="_blank" rel="noopener" class="wkjob-widget-link">Read More</a>
			<span class="wkjob-widget-close"></span>
		</div>
	</div>
	<?php
}

?>

<?php

get_footer( 'job' ); ?>

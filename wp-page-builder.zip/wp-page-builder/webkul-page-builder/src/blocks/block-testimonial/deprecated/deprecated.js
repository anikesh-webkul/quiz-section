/**
 * wk-caption-title Tag h5 deprecated, we are using p tag instead of that
 */

wp.hooks.addFilter( 'blocks.registerBlockType', 'wk-blocks/deprecated/testimonial', function(settings, name) {
    if ( name !== 'wk-blocks/testimonial' ) {
        return settings;
    }
    
    settings.deprecated = [
        {
            attributes: settings.attributes,
 
            save: function( props ) {
                return el(
                    Fragment,
                    {},
                    el(
                        'div',
                        {
                            className: ( props.attributes.className ) ? 'wk-testimonial-wrap ' + props.attributes.className : 'wk-testimonial-wrap'
                        },
                        el(
                            RichText.Content,
                            {
                                tagName: 'p',
                                value: props.attributes.content,
                            },
                        ),
                        ( props.attributes.imgURL ) &&
                        el(
                            'img',
                            {
                                alt:props.attributes.imgALT,
                                src:props.attributes.imgURL,
                            },
                        ),
                        el(
                            RichText.Content,
                            {
                                tagName:'h5',
                                value:props.attributes.title,
                            }
                        ),
                        el(
                            RichText.Content,
                            {
                                tagName:'span',
                                value:props.attributes.company,
                            }
                        )
                    ),
                );
            },
        }
    ]

    return settings;

} );
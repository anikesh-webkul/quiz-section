<?php

add_action( 'wktheme_featured-on_page_setting_tab', '_template_roadmap_tab' );

function _template_roadmap_tab() {

	$hp_featured = get_option( 'wktheme-page-featured-on' );
	$hp_featured = ( '' === $hp_featured ) ? array() : $hp_featured;
	?>

	<p><a target="_blank" href="<?php echo esc_url(  site_url() . '/#featured-on' ); ?>">Go To Homepage Featured-on Section</a></p>

	<template id="wktheme-block-template">
		<div class="wk-element-block" style="width: 28%;">
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<div>
				<label>
					<p class="description">Image</p>
					<img src="" class="_wk_uploader _uploader_src opac-72" style="width: 100%; height: 100px; object-fit: contain;">
					<input type="hidden" class="_wk_uploader_id image" value=""/>
				</label>

				<label>
					<p class="description">Link</p>
					<input type="text" class="link" value=""/>
				</label>
			</div>
		</div>
	</template>

	<hr /><br />

	<div id="wktheme-featured-on-wrapper">
		<div class="wk-is-sortable wk-pallete-data">

			<?php
			if ( isset( $hp_featured['featured-on'] ) ) {
				foreach ( $hp_featured['featured-on']['items'] as $value ) {
					$icon = ! empty( $value['image'] ) ? wp_get_attachment_image_src( $value['image'] )[0] : false;
					?>

					<div class="wk-element-block" style="width: 28%;">
						<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
						<div>
							<label>
								<p class="description">Image</p>
								<img src="<?php echo esc_url( $icon ); ?>" class="_wk_uploader _uploader_src opac-72" style="width: 100%; height: 100px; object-fit: contain;">
								<input type="hidden" class="_wk_uploader_id image" value="<?php echo ! empty( $value['image'] ) ? $value['image'] : false;  ?>"/>
							</label>

							<label>
								<p class="description">Link</p>
								<input type="text" class="link" value="<?php echo ! empty( $value['link'] ) ? esc_url( $value['link'] ) : false;  ?>"/>
							</label>
						</div>
					</div>
					<?php
				}
			}
			?>
		</div>
	</div>
	<?php
}
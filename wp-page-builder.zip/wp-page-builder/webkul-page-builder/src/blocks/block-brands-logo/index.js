/**
 * Register Custom Success Story Block
 */

registerBlockType( 'wk-blocks/brands-logo', {
    title : 'Brand\'s Logo',
    icon : 'images-alt',
    category: 'webkul',
    keywords: [ 'Customer Logo', 'Brand\'s Logo' ],
    parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    example: {},
    attributes : {
        defaultLogo: {
            selector: '.wk-items-inlined',
            type:'array',
            default:[ 'samsung','asus','BMW', 'digiweb', 'tm' ],
        },
        title: {
            type:'string',
            selector: '.title-mini',
            default: 'The world\'s top brands trust us'
        },
    },
    edit : function( props ) {
        var title = props.attributes.title,
        defaultLogo = props.attributes.defaultLogo;

        const onChangeTitle = ( newTitle ) => {
            props.setAttributes( { title: newTitle } );
        }
        const onRemoveLogo = ( logoID ) => {
            m = logoID.target.getAttribute('dataLogoID');
            
            newdefaultLogo = defaultLogo.filter( (a) => a != m );
            console.log(newdefaultLogo);
            defaultLogoCRUD( newdefaultLogo );
        }
        function defaultLogoCRUD( newSet = []) {
            props.setAttributes( {defaultLogo:newSet} );
        }

        return el(
            Fragment,
            {},

            /**Sidebar Setting (InspectorControls) */
            el(
                InspectorControls,
                {},
                el(
                    PanelBody,
                    {
                        title:'Select Brand\'s Logo',
                        initial:true,
                    },
                    el(
                        PanelRow,
                       {},
                       el(
                           ButtonGroup,
                           {
                               'aria-label':'Brand\'s Logo',
                           },
                           Object.values( wkBrandsLogo ).map( ( BL ) => {
                            return ( undefined != BL.src && undefined != BL.id ) && el(
                                Tooltip,
                                {
                                    text:BL.id,
                                    key:BL.id,
                                },
                                el(
                                    Button,
                                    {
                                        key:BL.id,
                                        disabled : ( defaultLogo.includes( BL.id ) ) && 'disabled',
                                        onClick : () => { defaultLogoCRUD( defaultLogo.concat([BL.id]) ) },
                                        style:{
                                            margin:'5px 10px'
                                        }
                                    },
                                    el(
                                        'img',
                                        {
                                            src:BL.src,
                                            style:{
                                                width:'75px',
                                                height:'50px',
                                            }
                                        }
                                    ),
                                ),

                            );
                            } ),

                       ),
                    )
                )
            ),
            /** //Sidebar Setting (InspectorControls) */

            el(
                'div',
                {
                    className : props.className + 'text-center'
                },
                el(
                    PlainText,
                    {
                        key: 'editable',
                        tagName: 'p',
                        className:'title-mini text-center',
                        onChange: onChangeTitle,
                        value: title,
                    }
                ),
                el(
                    Dashicon,
                    {
                        icon:'download',
                        className:'wk-setting-icon-right',
                        style:{
                            color:'#007cba',
                        }
                    }
                ),
                el('br'),el('br'),
                el(
                    'div',
                    {
                        className:'wk-item-inlined wk-globe-logo-sortable',
                        onClick:(e) => {
                            // if( ! jQuery( '.wk-globe-logo-sortable' ).is(':ui-sortable') ) {

                            //     jQuery( '.wk-globe-logo-sortable' ).sortable({
                            //         placeholder: 'placeholder-wrap',
                            //         // distance: 5,
                            //         start: function ( event, ui ) {
                            //             holderHeight = ui.item[0].offsetHeight;
                            //             holderWidth = ui.item[0].offsetWidth;
                            //             jQuery( '.placeholder-wrap' ).css( 'height', holderHeight + 'px' );
                            //             jQuery( '.placeholder-wrap' ).css( 'width', holderWidth + 'px' );
                            //         },
                            //         stop: function( event, ui ) {
                            //             ui.item[0].click();
                            //         }
                            //     });
                            // }
                        }
                    },
                    el(
                        'div',
                        {
                            style:{
                                display: 'flex',
                                'flex-wrap': 'wrap',
                            }
                        }
                    ),
                    defaultLogo.map( (t) => { return el(
                        'div',
                        {
                            'data-sort-key':t,
                            className:'logo-item',
                            style:{
                                display:'inline-block',
                                margin:'5px',
                                position:'relative',
                                padding:'5px',
                                border:'1px solid #dcdc',
                            },
                            onClick:function(e) {
                                // keyData = e.target.parentElement.querySelectorAll('.logo-item');
                                // sortArr = [];
                                // keyData.forEach( kd => {
                                //     sortArr.push(kd.getAttribute( 'data-sort-key' ));
                                // });
                                // if( 0 == sortArr.length ) {
                                //     return
                                // }
                                // if( sortArr.toString() != defaultLogo.toString() ) {
                                   
                                //     defaultLogoCRUD( sortArr )
                                    
                                // }
                                return;
                            }
                        },
                        el(
                            Dashicon,
                            {
                                icon:'dismiss',
                                dataLogoID:t,
                                style:{
                                    position: 'absolute',
                                    top: '-10px',
                                    left: '-10px',
                                    color: '#a02222',
                                    cursor:'pointer',
                                },
                                title:'Remove Item',
                                onClick: onRemoveLogo,

                            }
                        ),
                        el(
                            'img',
                            {   
                                'src' : wkBrandsLogo[t].src,

                            }
                        )
                    ) } )
                ),
                el('br')
            )
        );
    },
    save : function(props) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className:'title-mini',
                },
                props.attributes.title
            ),
            el(
                'div',
                {
                    className:'wk-window-to-toggle wk-items-inlined',
                },
                ( props.attributes.defaultLogo ) && props.attributes.defaultLogo.map( (dl) => {
                    return el(
                        'div',
                        {
                            className:'logo'
                        },
                        el(
                            'img',
                            {
                                className:'logo-img',
                                src:wkBrandsLogo[dl].src,
                                alt:wkBrandsLogo[dl].id,
                            }
                        )
                    );
                } ),
            )
        );
    }
} );


/**
 * Add Brand's Logo src and id
 */
const wkBrandsLogo = {
	'canon' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/canon.png',
        'id' : 'canon'
    },
    'costco' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/costco.png',
        'id' : 'costco'
    },
    'intel' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/intel.png',
        'id' : 'intel'
    },
    'nokia' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/nokia.png',
        'id' : 'nokia'
    },
    'tcs' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/tcs.png',
        'id' : 'tcs'
	},
	'UN' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/un.png',
        'id' : 'UN'
	},
	'huawei' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/huawei.png',
        'id' : 'huawei'
    },
    'accenture' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/accenture.png',
        'id' : 'accenture'
    },
    'acer' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/acer.png',
        'id' : 'acer'
    },
    'asus' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/asus.png',
        'id' : 'asus'
    },
    'bm' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/bharat-matrimony.png',
        'id' : 'bm'
    },
    'BMW' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/BMW.png',
        'id' : 'BMW'
    },
    'deloitte' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/deloitte.png',
        'id' : 'deloitte'
    },
    'digiweb' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/digiweb.png',
        'id' : 'digiweb'
    },
    'gt-bank' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/gt-bank.png',
        'id' : 'gt-bank'
    },
    'healthkart' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/healthkart.png',
        'id' : 'healthkart'
    },
    'htc' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/htc.png',
        'id' : 'htc'
    },
    'itc' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/international-trade-centre.png',
        'id' : 'itc'
    },
    'iron-man' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/iron-man.png',
        'id' : 'iron-man'
    },
    'mangopay' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/mangopay.png',
        'id' : 'mangopay'
    },
    'princeton-university' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/princeton-university.png',
        'id' : 'princeton-university'
    },
    'rainer-arms' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/rainer-arms.png',
        'id' : 'rainer-arms'
    },
    'tc' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/red-chillis.png',
        'id' : 'tc'
    },
    'samsung' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/samsung.png',
        'id' : 'samsung'
    },
    'tm' : {
        'src' : 'https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/tech-mahindra.png',
        'id' : 'tm'
    }
    
};
/** Function to add custom attribute propperty for image shadow toggle */

// var wkAllowedBlocks = ['wk-blocks/brands-logo'];
// const wkCoreImageAddAttr = ( settings ) => {
//     console.log( settings.name )
//     if( typeof settings.attributes !== 'undefined' && wkAllowedBlocks.includes(settings.name) ){
    
//     }
//     return settings;
// }
// wp.hooks.addFilter( 'blocks.registerBlockType', 'core/image', wkCoreImageAddAttr );
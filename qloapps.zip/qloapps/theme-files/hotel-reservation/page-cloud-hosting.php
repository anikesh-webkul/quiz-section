<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();
?>

<section class="qa-banner-wapper cloudpage">
  <div class="banner-content">
    <div class="cloudpage-head ">
      <div class="content-align">
        <img src="<?php echo get_template_directory_uri().'/images/cover-logo.svg'?>" title="QLO" alt="QLO">
        <h2 class="new-h2">Cloud Services</h2>
        <p class="white">Get low cost and scalable cloud hosting service to monitor server bandwidth and health on dashboard.</p>
      </div>
    </div>
  </div>
</section>

<section class="wk-feature-section cloud-feature wk-common-padding">
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<h1 class="text-center new-h1">Features</h1>
		</div>
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<p class="text-center head-detail">Our cloud service comes with highly advanced systems and features which provide guaranteed optimized performance.</p>
		</div>
		<div class="col-md-3"></div>
	</div>

	<div class="row text-center">
		<div class="cloud-brick">
			<div class="feature-box">
				<span class="img-responsive cloudpage support" title="Launch Marketplace"></span>
				<h3 class="new-h3">Support Period</h3>
				<p class="head-detail">With our cloud hosting plans we provide you a limited support period for server-side issue.</p>
			</div>
    </div>
    <div class="cloud-brick">
			<div class="feature-box">
				<span class="img-responsive cloudpage backup" title="Get More Hoteliers"></span>
				<h3 class="new-h3">Server Setup</h3>
				<p class="head-detail">One Time Installation and Server Setup.</p>
			</div>
    </div>
    <div class="cloud-brick">
			<div class="feature-box">
				<span class="img-responsive cloudpage secure" title="Earn Commission"></span>
				<h3 class="new-h3">Monitoring Alerts</h3>
				<p class="head-detail">Get Your Server Integrated with our Custom Monitoring Tools.</p>
			</div>
    </div>
	</div>
</section>

<hr class="custom">

<section class="wk-plans-tab-section section-padding-0B">
  <div class="container">
    <div class="row">
      <!-- <div class="col-md-12"> -->
        <div class="col-md-1"></div>
        <div class="col-md-10 text-center ">
            <h2 class="new-h1">Our Cloud Hosting Plans</h2>
            <p class="head-detail">We provide various cloud hosting services on vaious cloud platform to help you set up a fast and high performing hotel website.</p>
        </div>
        <div class="col-md-1"></div>
        <div class="col-md-2"></div>
        <div class="col-md-8">
          <div class="wk-qloapp-plans null">
            <h2 class="aws-hosting active-plan" data-tab="aws-hosting"></h2>
            <h2 class="google-cloud" data-tab="google-cloud"></h2>
            <h2 class="microsoft-azure" data-tab="microsoft-azure"></h2>
          </div>
        </div>
        <div class="col-md-2"></div>
      </div>
      </div>
    <!-- </div> -->
  </div>
</section>


<section class="qlo-pricing-section section-padding-0T large-screen">
  <div class="container">
    <div class="row">
      <div class="col-md-1"></div>
      <div class="col-md-10">
        <?php
$qlo_cloud_prices = maybe_unserialize( get_option( 'qlo_cloud_prices' ) );
$qlo_cloud_plans  = maybe_unserialize( get_option( 'qa_cloud_plans' ) );

if ( is_array( $qlo_cloud_prices ) ) {
  foreach ($qlo_cloud_prices as $key => $prices) {
    $package = str_replace( '-', ' ', $key );
    if( isset( $prices['prices'] )&& ! empty( $prices['prices'] ) && isset( $prices['prices']['platinum']['main'] ) && isset( $prices['prices']['gold']['main'] ) && ( ! empty($prices['prices']['gold']['main'] ) || ! empty( $prices['prices']['gold']['main'] ) )  ){
    ?>
        <table class="qlo-hosting-plan pricing-section <?php if( 'aws-hosting' == $key ) echo 'price-active'; ?>" data-tab="<?php echo $key; ?>">
        <tr class="cloud-plan-head">
          <td class="qlo-feat-head">Features</td>
          <?php
          
          foreach ( $prices['prices'] as $plan => $price ) {
            $class = '';
            if( $price['main'] || $price['offer'] || $price['link'] ) {
              ?>
                <td><div class="plan-icons <?php echo esc_html( $plan ); ?>-plan"></div>
              <?php
            echo '<p class="qlo-plan">' . esc_html( $plan ).' Plan'.'</p>';
            }
            if( ! empty( $price['offer'] ) ){
              ?>
              <p class="offer-cut"><?php echo ( ! empty( $price['main'] ) ) ? '$' . $price['main'] : false; ?></p>
              <h3 class="new-h1 small"><?php echo '$' . $price['offer']; ?></h3>
              <?php
              $class = 'qlo-bottom-less';
            }
            else if ( ! empty( $price['main'] ) ){
              ?><h3 class="new-h1 small"><?php echo '$' . $price['main']; ?></h3><?php
            }
            
            
            if ( ! empty( $price['link'] ) ) {
              ?>
              <a href="<?php echo esc_url( $price['link'] ); ?>" target="_blank" rel="nofollow" class="btn btn-bgcolor white normal-btn-style <?php echo esc_attr( $class );?>">Choose</a>
              <?php
            }
            ?>
            </td>
            <?php
          }
              ?>
            <td class="border-true">
              <div class="plan-icons enterprise-plan"></div>
              <p class="qlo-plan">Enterprise Plan Plan</p>
              <p class="qlo-plan-desc">If you have other plans of having this Service on more Large & Bigger Scale then Click on the Button Below.</p>
            </td>
          </tr>
          <?php
          $i =0;
          foreach ($qlo_cloud_plans as $value) {
            
            if( in_array( $package, array_map('strtolower', $value['package'] ) ) ) {
              echo '<tr><td>'.$value['feature'].'</td>';
              if( in_array( 'platinum', array_map('strtolower', $value['plan'] ) ) ) {
                if( 'displayed' == $value['status'] ) {
                  echo '<td class="qlo-check right"><img src=" ' . esc_url( get_template_directory_uri() . '/images/cloud-hosting/tick.png' ) . '"></td>';
                } else{
                  echo '<td class="qlo-check" ><img src=" ' . esc_url( get_template_directory_uri() . '/images/cloud-hosting/cross.png' ) . '"></td>';
                }
              } else{
                  echo '<td class="qlo-check" ><img src=" ' . esc_url( get_template_directory_uri() . '/images/cloud-hosting/cross.png' ) . '"></td>';
                }
              if( in_array( 'gold', array_map('strtolower', $value['plan'] ) ) ) {
                if( 'displayed' == $value['status'] ) {
                 echo '<td class="qlo-check right"><img src=" ' . esc_url( get_template_directory_uri() . '/images/cloud-hosting/tick.png' ) . '"></td>';
                } else{
                  echo '<td class="qlo-check" ><img src=" ' . esc_url( get_template_directory_uri() . '/images/cloud-hosting/cross.png' ) . '"></td>';
                }
              } else{
                  echo '<td class="qlo-check" ><img src=" ' . esc_url( get_template_directory_uri() . '/images/cloud-hosting/cross.png' ) . '"></td>';
                }
                if( $i == 0 ){
                ?>
                <td class="qlo-contat-tab" rowspan="1000"><a href="<?php echo site_url() . '/contact'; ?>" class="btn btn-bgcolor white normal-btn-style fixed-width">Contact Us</a></td>
                <?php
                } else{
                  echo '';
                }
                $i++;
                echo '</tr>';
              }
            }
          ?>
          
        </table>
        <?php
    }
        
          }
        }
        ?>
        <div class="small-screen text-center section-padding-0B">
          <div class="plan-icons enterprise-plan"></div>
              <p class="qlo-plan">Enterprise Plan Plan</p>
              <p>If you have other plans of having this Service on more Large & Bigger Scale then Click on the Button Below.</p>
              <a href="<?php echo site_url() . '/contact'; ?>" class="btn btn-bgcolor white normal-btn-style">Contact Us</a>
          </div>
        </div>
      <div class="col-md-1"></div>
    </div>
  </div>
</section>

<?php
   $string = 'Need assistance for hosting your own hotel booking website? Reach us out and we will help you in launching your hotel booking portal.';
   display_contact_section( $string );
?>

<?php get_footer(); ?>

<?php
/**
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();


$page_id     = get_the_id();
$has_header  = get_post_meta( $page_id, 'wk_page_has_header', true );
$has_infobox = get_post_meta( $page_id, 'wk_infobox_visible', true );
$all_infra   = get_option( 'wktheme-page-infrastructure' );
$all_infra   = ( '' === $all_infra ) ? array() : $all_infra;
$path        = wp_upload_dir()['baseurl'];

$opt_btn_attrs = maybe_unserialize( get_post_meta( $page_id, 'wk_opt_btn_attr', true ) );
?>

<?php
if ( '1' === $has_header ) {

	$layout      = get_post_meta( $page_id, 'wk_page_layout_view', true );
	$grid_class  = ( 'wide' === $layout ) ? 'wkgrid-wide' : 'wkgrid-squeezy';
	$has_bg_col  = ( 'wide' === $layout ) ? 'section-padding has-bgcol' : 'section-padding-0B';
	$tagline     = get_post_meta( $page_id, 'wk_banner_tagline', true );
	$feat_img    = get_the_post_thumbnail_url( $page_id, 'full' );
	?>

	<section class="wk-page-header <?php echo esc_attr( $has_bg_col ); ?>">
		<div class="<?php echo esc_attr( $grid_class ); ?>">
			<div class="page-tagline">
				<h1><?php echo $tagline; ?></h1>
				<?php
				if ( isset( $opt_btn_attrs['enable'] ) && '1' === $opt_btn_attrs['enable'] && ! empty( $opt_btn_attrs['link'] ) && ! empty( $opt_btn_attrs['label'] ) ) {

					$_link   = ( ! empty( $opt_btn_attrs['link'] ) ) ? $opt_btn_attrs['link'] : '';
					$_label  = ( ! empty( $opt_btn_attrs['label'] ) ) ? $opt_btn_attrs['label'] : '';
					$_rel    = ( ! empty( $opt_btn_attrs['rel'] ) ) ? ' rel=' . $opt_btn_attrs['rel'] : '';
					$_target = ( ! empty( $opt_btn_attrs['target'] ) ) ? ' target=_blank' : '';
					$_color  = ( ! empty( $opt_btn_attrs['color'] ) && 'prime' === $opt_btn_attrs['color'] ) ? 'wk-button' : 'wk-button ' . $opt_btn_attrs['color'];

					echo '<a class="' . esc_attr( $_color ) . '" href="' . esc_url( $_link ) . '"' . esc_attr( $_target . $_rel ) . '>' . esc_attr( $_label ) . '</a>';
				}
				?>
			</div>
			<div class="page-banner">
				<img src="<?php echo esc_url( $feat_img ); ?>" />
			</div>
			<?php echo ( 'wide' === $layout ) ? '' : '<hr/>'; ?>
		</div>
	</section>
	<?php
}
?>

<section class="section-padding">
	<div class="wk-page-content">
			<?php
			while ( have_posts() ) {
				the_post();
				the_content();
			}
			?>
		<hr />
	</div>
</section>
<section class="wk-infrastructure section-padding-0T">
	<div class="wkgrid-wide">
		<div class="wk-section-grid">		
			<?php
			if ( isset( $all_infra['infrastructure'] ) ) {
				$infrastructure = $all_infra['infrastructure']['items'];

				foreach ( $infrastructure as $key ) {

					$heading = ( $key['region'] == 'italy' ) ? 'Corbetta, Branch Office Italy' : ( $key['region'] == 'india' ? 'Noida, Head Office India' : ( $key['region'] == 'india-new' ? 'Noida, Branch Office India' : $key['region'] ) );
					?>
					<div class="gallery">
						<span class="map-mark" data-region="<?php echo esc_attr( $heading ); ?>"></span>
						<a href="<?php echo esc_url( $path . $key['logo'] ); ?>">
							<img class="img-responsive wk-lazify" data-src="<?php echo esc_url( $path . $key['logo'] ); ?>" />
						</a>
					</div>
					<?php
				}
			}
			?>
		</div>
	</div>
</section>
<div class="meetup-popup-wrapper">
	<div class="meetup-toolbar">
		<div class="meetup-leftbar">
			<a href="javascript:void(0)" class="meetup-close meetup-sprite"></a>
		</div>
		<div class="meetup-rightbar">
			<a href="javascript:void(0)" class="meetup-prev meetup-sprite"></a>
			<a href="javascript:void(0)" class="meetup-next meetup-sprite"></a>
		</div>
	</div>
	<div class="meetup-gallery-image">
		<div class="wk-waiting-loader"></div>

	</div>
	<div class="meetup-btm-toolbar">
		<a href="javascript:void(0)" class="meetup-minus meetup-sprite"></a>
		<a href="javascript:void(0)" class="meetup-full meetup-sprite btm-not-allowed"></a>
		<a href="javascript:void(0)" class="meetup-plus meetup-sprite"></a>
	</div>
</div>
<?php

get_footer();

<?php
/*
Plugin Name: QloApps Serivices
Description: Add New Services for QloApps ( for Services Page )
Author : Webkul
*/

ob_start();
define('PLUGIN_PATH', plugin_dir_url(__FILE__));

function add_admin_scripts() {
    wp_enqueue_script('wkqs-setting-js', PLUGIN_PATH . 'assets/js/setting.js', array( 'jquery' ));
    wp_enqueue_style('wkqs-style', PLUGIN_PATH . 'assets/css/style.css');
}

add_action('admin_enqueue_scripts', 'add_admin_scripts');

add_action('admin_menu', 'add_setting_menu_admin_dashboard');

  function add_setting_menu_admin_dashboard() {
      add_menu_page( 'Service Menu', 'Service Menu', 'edit_posts', 'service-menu', 'view_service_menu', 'dashicons-admin-site', 55 );

      add_submenu_page( 'service-menu', 'View Services', 'Services', 'edit_posts', 'service-menu', 'view_service_menu' );

      add_submenu_page( 'service-menu', 'Add New Service','Add New    ', 'edit_posts', 'add-content', 'add_service_content' );

      add_submenu_page( 'service-menu', 'View Service Type','View Service Type', 'edit_posts', 'view-service-type', 'view_service_type' );

      add_submenu_page( 'service-menu', 'Add Service Type','Add Service Type', 'edit_posts', 'add-service', 'add_service_menu' );

    }


  function add_service_menu() {
      $service = get_option('service_content');

      if (! $service) {
          $service = array();
      }

      $name = "";

      $type = "";

      $url = "";

      $id = isset($_GET['job']) ? $_GET['job'] : '';


    if(isset($_POST['submit']) && $_POST['service_type'] && $_POST['service_name']) {


        if (isset($_GET['job'])) {

            $data = get_option('service_content');
            $data[$id]['name'] = filter_var($_POST['service_name'],FILTER_SANITIZE_STRING);
            $data[$id]['type'] = filter_var($_POST['service_type'],FILTER_SANITIZE_STRING );
            $data[$id]['url'] =filter_var($_POST['url'],FILTER_SANITIZE_URL ) ;
            $data = array_values($data);
            $success = update_option('service_content', $data);
            if($success){

                 ?>  <div class="notice notice-success is-dismissible">
                         <p><strong>Successfull Updated.</strong></p>
                         <button type="button" class="notice-dismiss">
                            <span class="screen-reader-text">Dismiss this notice.</span>
                         </button>
                    </div>
            <?php
                }

        } else {

            $data = array('name' => filter_var($_POST['service_name'],FILTER_SANITIZE_STRING) ,
                'type' => filter_var($_POST['service_type'],FILTER_SANITIZE_STRING ),
                'url'  => filter_var($_POST['url'],FILTER_SANITIZE_URL ),
            );

              array_push($service, $data);
                $success=  update_option('service_content', $service);
                if($success){

                ?>  <div class="notice notice-success is-dismissible">
                        <p><strong>Successfull Inserted.</strong></p>
                        <button type="button" class="notice-dismiss">
                        <span class="screen-reader-text">Dismiss this notice.</span>
                        </button>
                    </div>
           <?php
               }
        }
      }
      if(isset($_POST['submit'])&& !$_POST['service_name']){
        ?>
        <div class="notice notice-error is-dismissible">
          <p><strong>Please Fill All The Fields.</strong></p>
          <button type="button" class="notice-dismiss">
          <span class="screen-reader-text">Dismiss this notice.</span>
       </button>
      </div>
    <?php  }

    $data = get_option('service_content');

    if (isset($data[$id])) {
      $name = $data[$id]['name'];
      $type = $data[$id]['type'];
      $url = $data[$id]['url'];
    }

    ?>
    <h2>ADD NEW SERVICES</h2>
    <form method="post">
      <table class="form-table" id="setting_table">
        <thead>
          <tr>
            <th>Field</th>
            <th>Option</th>
          </tr>
        </thead>
        <tbody>

        <tr valign="top">
          <th scope="row" class="titledesc"><label for="service_name">Service Name:</label></th>
          <td><input type="text" name="service_name" value="<?php echo $name; ?>" placeholder="Enter Service Name"></td>
        </tr>

        <tr valign="top">
          <th scope="row" class="titledesc"><label for="service_type">Service Type:</label></th>
          <td>
            <select id="type" name="service_type" <?php if ($type=='url') {?> value="<?php echo $type; ?>"     <?php } else {?> value=""<?php }?>>
              <?php if($type=='content') {?>
              <option value="content" selected>Content</option>
              <option value="url">Url</option>
              <?php } ?>
              <?php if($type=='url') {?>
                <option value="content" >Content</option>
                <option value="url" selected>Url</option> <?php }?>
              <?php if($type=='') {?>
                  <option value="content" >Content</option>
                  <option value="url">Url</option>
              <?php }?>
            </select>
          </td>
        </tr>

        <tr valign="top" class="url">
          <th scope="row" class="titledesc"><label for="service_name">Url:</label></th>
          <td><input type="text" name="url" value="<?php echo $url;?>" placeholder="Enter Url"></td>
        </tr>
      </tbody>

      </table>
      <p class="submit">
        <input type="submit" name="submit" class="button button-primary" value="Save Setting">
      </p>
    </form>
    <?php
  }

  function add_service_content(){

          global $wpdb;

                $result['title']="";
                $result['content']="";
                $result['price']="";
                $result['buynow']="";
                $result['image']="";
                $error="";
                $error1="";
                $table_name= $wpdb->prefix . "service_table";
                $upload_dir = wp_upload_dir();
                $upload_dir = $upload_dir['baseurl'];

        if(isset($_POST['save']) && $_POST['name'] && $_POST['content'] && $_POST['price'] && $_POST['buy_link'] && $_POST['image'] && $_POST['service_type']){

        if(isset($_GET['job'])){

                  $id=sanitize_key($_GET['job']);
                  $name = filter_var($_POST['name'],FILTER_SANITIZE_STRING);
                  $content = filter_var($_POST['content'],FILTER_SANITIZE_STRING);
                  // $price = filter_var($_POST['price'],FILTER_SANITIZE_NUMBER_INT);
                  $price=$_POST['price'];
                  if(is_numeric($price)){
                    $price = $price;
                  $buy_link = filter_var($_POST['buy_link'],FILTER_SANITIZE_URL);
                  $image = explode( $upload_dir, $_POST['image'] )[1];
                  $type = $_POST['service_type'];

                  $success = $wpdb->update("$table_name", array(
                     "title" => $name,
                     "content" => $content,
                     "price" => $price,
                     "buynow" => $buy_link,
                     "image" => $image,
                     "type" => $type,
                   ),array('id'=>$id));

            if($success){

                 ?>  <div class="notice notice-success is-dismissible">
                         <p><strong>Successfull Updated data.</strong></p>
                         <button type="button" class="notice-dismiss">
                         <span class="screen-reader-text">Dismiss this notice.</span>
                        </button>
                    </div>
            <?php
                }
            }
            else{
              $price = "";
              $error1= "please enter only numaric value";
            }

              }

        else{
            $name = filter_var($_POST['name'],FILTER_SANITIZE_STRING);
            $content = filter_var($_POST['content'],FILTER_SANITIZE_STRING);
            $price=$_POST['price'];
                  if(is_numeric($price)){
                    $price = $price;
            $buy_link = filter_var($_POST['buy_link'],FILTER_SANITIZE_URL);
            $img = explode( $upload_dir, $_POST['image'] )[1];
            $type = $_POST['service_type'];
            $filetype = wp_check_filetype($img);
            $typename = $filetype['type'];
            $get_type= explode("/","$typename");
            if($get_type[0]=="image"){
              $image = $img;

              $success = $wpdb->insert("$table_name", array(
               "title" => $name,
               "content" => $content,
               "price" => $price ,
               "buynow" => $buy_link,
               "image" => $image,
               "type" => $type,
             ) );

      if($success){

           ?>  <div class="notice notice-success is-dismissible">
                 <p><strong>Successfull Updated.</strong></p>
                 <button type="button" class="notice-dismiss">
                    <span class="screen-reader-text">Dismiss this notice.</span>
                 </button>
              </div>
      <?php
          }
        }
        else{
          $error="*Please upload only image.";
        }
    }
    else{
      $price = "";
      $error1= "please enter only numaric value";
    }
        }
    }
    if(isset($_POST['save']) && !$_POST['name'] && !$_POST['content'] && !$_POST['price'] && !$_POST['buy_link'] && !$_POST['image'] ){
      ?>
      <div class="notice notice-error is-dismissible">
        <p><strong>Please Fill All The Fields.</strong></p>
        <button type="button" class="notice-dismiss">
        <span class="screen-reader-text">Dismiss this notice.</span>
     </button>
    </div>
  <?php
    }
    if(isset($_GET['job'])){

        $id=sanitize_key($_GET['job']);
        $result = $wpdb->get_results( "SELECT * FROM $table_name WHERE id = $id", ARRAY_A );

      }
    ?>
    <h2>ADD SERVICES CONTENT</h2>
    <style>
    .img-wrap{
      width: 100px;
      cursor: pointer;
      height: 100px;
      border: 3px dotted #ddd;
      padding: 7px;
    }
    .img-wrap img{
      width: 100%;
    }
    .img-wrap:hover{
      border: 3px dotted #0073aa;
    }
    </style>
    <?php

    if ( ! empty( $result ) ) {
      if ( isset($_GET['job'] ) ) {
        $result = $result[0];
        $result['image'] = "$upload_dir/".$result['image'];
      }
      ?>
      <form method="post">
        <table class="form-table" id="setting_table">
          <thead>
            <tr>
              <th>Field</th>
              <th>Option</th>
            </tr>
          </thead>
          <tbody>
            <tr valign="top">
              <th scope="row" class="titledesc"><label for="service_name">Title:</label></th>
              <td><input type="text" name="name" value="<?php echo $result['title']; ?>" placeholder="Enter Service Title"></td>
            </tr>
            <tr valign="top">
              <th scope="row" class="titledesc"><label for="service_name">Content:</label></th>
              <td><textarea name="content"  placeholder="Enter Content"><?php echo $result['content']; ?></textarea></td>
            </tr>
            <tr valign="top">
              <th scope="row" class="titledesc"><label for="service_name">Price:</label></th>
              <td><input type="text" name="price" value="<?php echo $result['price']; ?>" placeholder="Enter Service Price"><p class="error"><?php echo $error1;?></p></td>
            </tr>
            <tr valign="top">
              <th scope="row" class="titledesc"><label for="service_name">Buy Link:</label></th>
              <td><input type="text" name="buy_link" value="<?php echo $result['buynow']; ?>" placeholder="Enter Buy Link"></td>
            </tr>
            <tr valign="top">
              <th scope="row" class="titledesc"><label for="service_type">Service Name:</label></th>
              <td>
                <select name="service_type" value="">
                  <?php
                    $option_link = get_option('service_content');
                      foreach($option_link as $option){
                        if($option['type']=="content"){
                      $links= $option['name'];
                    ?>
                      <option value="<?php echo $links;?>"><?php echo $links?></option>
                    <?php
                      }
                    }
                  ?>
                </select>
              </td>
            </tr>
            <tr>
              <th class="titledesc"><label for="service_name">Image:</label></th>

          		    <td><p class="error"><?php echo $error;?></p>
                    <div class="img-wrap">
                      <img id='image-preview' src="<?php echo $result['image']; ?>">
                    </div>
                  <!-- <input id="upload_image_button" type="button" class="button-upload" value="<?php _e( 'Upload image' ); ?>" /> -->
                  <input type="hidden" name="image" value="<?php echo $result['image']; ?>" id="image-path" placeholder="image url">
              </td>

            </tr>

          </tbody>
        </table>
        <br>
        <input type="submit" name="save" class="button button-primary" value="Save Services">
    </form>
      <?php
    } else {
      echo 'Something went wrong, Invalid argument passed!';
    }
    ?>

<?php
  }


  register_activation_hook( __FILE__, 'service_plugin_db' );

    function service_plugin_db() {

        global $wpdb;
      	$charset_collate = $wpdb->get_charset_collate();

      	$table_name = $wpdb->prefix . 'service_table';

        $sql = "CREATE TABLE $table_name (
        id int(255) NOT NULL AUTO_INCREMENT,
        title varchar(255),
        content varchar(255),
        price varchar(255),
        buynow varchar(255),
        image varchar(255),
        type varchar(255),
        PRIMARY KEY  (id)
      ) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );

}

function view_service_type(){
  if(!class_exists('WP_List_Table')){
      require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
  }
  class Service_Type_list extends WP_List_Table {

    function __construct(){
        global $status, $page;

        //Set parent defaults
        parent::__construct( array(
            'singular'  => 'movie',     //singular name of the listed records
            'plural'    => 'movies',    //plural name of the listed records
            'ajax'      => false        //does this table support ajax?
        ) );

    }


    function column_default($item, $column_name){
        switch($column_name){
          case 'name':
            case 'type':
              case 'url':
                  return $item[$column_name];
            default:
                return print_r($item,true); //Show the whole array for troubleshooting purposes
        }
    }

    function get_columns(){
        $columns = array(
            'cb'        => '<input type="checkbox" />',
            'name'      => 'Name',
            'type'      => 'Type',
            'url'       => 'Url',

        );
        return $columns;
    }

    function get_sortable_columns() {
        $sortable_columns = array(
            'name'    => array('name',false),  //true means it's already sorted

        );
        return $sortable_columns;
    }

    function get_bulk_actions() {
        $actions = array(
            'delete'    => 'Delete'
        );
       //  $id=$_GET['job'];
       //
       //  if(isset($_GET['job']) && ($_GET['action']=="delete") ){
       //
       //   $option= get_option('service_content');
       //   unset($option[$id]);
       //   $index=array_values($option);
       //   $run=update_option('service_content', $index);
       //
       //     if($run){
       //     wp_redirect( admin_url('admin.php?page=view-service-type') );
       //     exit();
       //   }
       //
       // }
        return $actions;

    }

    public static function service_type_list(){

      ?>

      <!-- <form action="" method="post">
          <p class="search-box">
            <input type="text" name="s" value="" />
            <input  class="button" type="submit" name="search" value="Search Service" />
          </p>
      </form> -->
      <?php

      global $wpdb;
      // if(isset($_POST['search']))
      //   {
      //   $title=$_POST['s'];
      //   $id=0;
      //   $values = array();
      //   $result = get_option('service_content');
      //   // if (strpos($option['name'], $word)
      //     foreach($result as $option){
      //       if($option['name']==$title){
      //         $name = $option['name'];
      //         $type = $option['type'];
      //         $url = $option['url'];
      //         $values[]= array(
      //           'cb'        => '<input type="checkbox" />',
      //           'id'   => $id,
      //           'name' => $name,
      //           'type' => $type,
      //           'url'  => $url,
      //         );
      //         $id++;
      //         }
      //       }
      //      return $values;
      //
      //   }
      //   else{
      $values = array();
      $id = '0';
      $result = get_option('service_content');

      foreach($result as $option){
          $name = $option['name'];
          $type = $option['type'];
          $url = $option['url'];
          $values[]= array(
            'cb'        => '<input type="checkbox" />',
            'id'   => $id,
            'name' => $name,
            'type' => $type,
            'url'  => $url,
          );
          $id++;
       }
       return $values;
     // }
    }

    function column_name($item){
        global $wpdb;
        //Build row actions
        $actions = array(
        'edit'      => sprintf('<a href="?page=%s&action=%s&job=%s">Edit</a>','add-service', 'edit',$item['id']),
        'delete'    => sprintf('<a    href="?page=%s&action=%s&ids=%s">Delete</a>',$_REQUEST['page'],'delete',$item['id']),

        );

        return sprintf('%1$s <span style="color:silver"></span>%3$s',
            /*$1%s*/ $item['name'],
            /*$2%s*/ $item['id'],
            /*$3%s*/ $this->row_actions($actions)
        );


      }
      function column_cb($item){

          return sprintf(
              '<input type="checkbox" name="%1$s[]" value="%2$s" />',
              /*$1%s*/ 'ids',  //Let's simply repurpose the table's singular label ("movie")
              /*$2%s*/ $item['id']                //The value of the checkbox should be the record's id
          );
      }


      function process_bulk_action() {
        //Detect when a bulk action is being triggered...
          if( 'delete'===$this->current_action() ) {
            // wp_die('Items deleted (or they would be if we had items to delete)!');

               if(isset($_GET['ids']) && ($_GET['action']=="delete") ){
                 if( is_array($_GET['ids'])) {

                   foreach ($_GET['ids'] as $id) {
                     $option= get_option('service_content');
                     unset($option[$id]);
                     $index=array_values($option);
                     $run=update_option('service_content', $index);
                   }
                 } else{
                   $id = $_GET['ids'];
                   $option= get_option('service_content');
                   unset($option[$id]);
                   $index=array_values($option);
                   $run=update_option('service_content', $index);
                 }

                 // $del_status = $wpdb->delete( $table_name, array( 'id' => $id ) );
                if($run){
                  wp_redirect( admin_url('admin.php?page=view-service-type') );
                  exit();
                }
              }

          }
        }

      function prepare_items() {
        $per_page = 5;
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array($columns,$hidden,$sortable);
        $data = $this->service_type_list();
        $this->process_bulk_action();



      function usort_reorder($a,$b){
          $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'name'; //If no sort, default to title
          $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc'; //If no order, default to asc
          $result = strcmp($a[$orderby], $b[$orderby]); //Determine sort order
          return ($order==='asc') ? $result : -$result; //Send final sort direction to usort
        }
       usort($data,'usort_reorder');

       $current_page = $this->get_pagenum();

       $total_items = count($data);

       $data = array_slice($data,(($current_page-1)*$per_page),$per_page);

       $this->items = $data;

       $this->set_pagination_args( array(
           'total_items' => $total_items,                  //WE have to calculate the total number of items
           'per_page'    => $per_page,                     //WE have to determine how many items to show on a page
           'total_pages' => ceil($total_items/$per_page)   //WE have to calculate the total number of pages
       ) );
    }


  }
  $service_view_table = new Service_Type_list();
  $service_view_table->prepare_items();

  ?>
          <div class="wrap">

              <form id="movies-filter" method="get">
                  <!-- For plugins, we also need to ensure that the form posts back to our current page -->
                  <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
                  <!-- Now we can render the completed list table -->
                  <?php   $service_view_table->display(); ?>
              </form>

          </div>
          <?php
}


function view_service_menu(){

    if(!class_exists('WP_List_Table')){
        require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
    }

    class Service_list extends WP_List_Table {
        public static function service_menu(){
          ?>

      <form action="" method="post">
          <p class="search-box">
            <input type="text" name="s" value="" />
            <input  class="button" type="submit" name="search" value="Search Service" />
          </p>
      </form>
      <?php
          global $wpdb;
          $table_name = $wpdb->prefix . 'service_table';
      if(isset($_POST['search']))
        {
        $title=$_POST['s'];
        $sql="SELECT * FROM $table_name WHERE title LIKE '%$title%' ";
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
        $upload_dir = wp_upload_dir();
        $upload_dir = $upload_dir['baseurl'];

          foreach($result as $data)
          {
              $id = $data['id'];
              $title = $data['title'];
              $content = $data['content'];
              $price = $data['price'];
              $buylink = $data['buynow'];
              $type = $data['type'];
              $image = "$upload_dir/".$data['image'];

            $values[] = array(
              'id'   => $id,

              'title' => $title,

              'content' => $content,

              'price' => $price,

              'buynow' => $buylink,

              'type' => $type,

              'image' => "<img src='$image' width='70' height='70' >",
            );
          }

        return $values;
        }
          else{
              $values = array();
              $sql="SELECT * FROM $table_name";
              $result = $wpdb->get_results( $sql, 'ARRAY_A' );
              $upload_dir = wp_upload_dir();
              $upload_dir = $upload_dir['baseurl'];

                foreach($result as $data)
                {
                    $id = $data['id'];
                    $title = $data['title'];
                    $content = $data['content'];
                    $price = $data['price'];
                    $buylink = $data['buynow'];
                    $type = $data['type'];
                    $image = "$upload_dir/".$data['image'];

                  $values[] = array(
                    'id'   => $id,

                    'title' => $title,

                    'content' => $content,

                    'price' => $price,

                    'buynow' => $buylink,

                    'type' => $type,

                    'image' => "<img src='$image' width='70' height='70' >",
                  );
                }

              return $values;
                }

            }

            function __construct(){
                global $status, $page;

                //Set parent defaults
                parent::__construct( array(
                    'singular'  => 'movie',     //singular name of the listed records
                    'plural'    => 'movies',    //plural name of the listed records
                    'ajax'      => false        //does this table support ajax?
                ) );

            }


            function column_default($item, $column_name){
                switch($column_name){
                  case 'title':
                    case 'content':
                      case 'price':
                        case 'buynow':
                          case 'type':
                            case 'image':
                          return $item[$column_name];
                    default:
                        return print_r($item,true); //Show the whole array for troubleshooting purposes
                }
            }



            function column_title($item){
                global $wpdb;

                //Build row actions
                $actions = array(
                'edit'      => sprintf('<a href="?page=%s&action=%s&job=%s">Edit</a>','add-content', 'edit',$item['id']),
                'delete'    => sprintf('<a    href="?page=%s&action=%s&ids=%s">Delete</a>',$_REQUEST['page'],'delete',$item['id']),

                );
                return sprintf('%1$s <span style="color:silver"></span>%3$s',
                    /*$1%s*/ $item['title'],
                    /*$2%s*/ $item['id'],
                    /*$3%s*/ $this->row_actions($actions)
                );


              }

            function column_cb($item){
                return sprintf(
                    '<input type="checkbox" name="%1$s[]" value="%2$s" />',
                    /*$1%s*/ 'ids',  //Let's simply repurpose the table's singular label ("movie")
                    /*$2%s*/ $item['id']                //The value of the checkbox should be the record's id
                );
            }

            function get_columns(){
                $columns = array(
                    'cb'        => '<input type="checkbox" />',
                    'title'     => 'Title',
                    'content'   => 'Content',
                    'price'     => 'Price',
                    'buynow'    => 'Buy Link',
                    'type'      => 'Type',
                    'image'     => 'Image',

                );
                return $columns;
            }


            function get_sortable_columns() {
                $sortable_columns = array(
                    'title'    => array('title',false),  //true means it's already sorted

                );
                return $sortable_columns;
            }

            function get_bulk_actions() {
              global $wpdb;

                $actions = array(
                    'delete'    => 'Delete'
                );

                return $actions;

            }

            function process_bulk_action() {
              //Detect when a bulk action is being triggered...
                if( 'delete'===$this->current_action() ) {
                  // wp_die('Items deleted (or they would be if we had items to delete)!');

                  global $wpdb;
                    $table_name = $wpdb->prefix . 'service_table';
                     if(isset($_GET['ids']) && ($_GET['action']=="delete") ){
                       if( is_array($_GET['ids'])) {
                         foreach ($_GET['ids'] as $id) {
                           $del_status = $wpdb->query( "DELETE FROM $table_name WHERE id IN($id)" );
                         }
                       } else{
                         $id = $_GET['ids'];
                         $del_status = $wpdb->query( "DELETE FROM $table_name WHERE id=$id" );
                       }

                       // $del_status = $wpdb->delete( $table_name, array( 'id' => $id ) );
                      if($del_status){
                        wp_redirect( admin_url('admin.php?page=service-menu') );
                        exit();
                      }
                    }
                }
              }


              function prepare_items() {
                $per_page = 5;

                $columns = $this->get_columns();
                $hidden = array();
                $sortable = $this->get_sortable_columns();
                $this->_column_headers = array($columns,$hidden,$sortable);
                $data = $this->service_menu();

                $this->process_bulk_action();


              function usort_reorder($a,$b){

                  $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'title'; //If no sort, default to title
                  $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc'; //If no order, default to asc
                  $result = strcmp($a[$orderby], $b[$orderby]); //Determine sort order
                  return ($order==='asc') ? $result : -$result; //Send final sort direction to usort
                }
               usort($data,'usort_reorder');

               $current_page = $this->get_pagenum();


               $total_items = count($data);

               $data = array_slice($data,(($current_page-1)*$per_page),$per_page);

               $this->items = $data;

               $this->set_pagination_args( array(
                   'total_items' => $total_items,                  //WE have to calculate the total number of items
                   'per_page'    => $per_page,                     //WE have to determine how many items to show on a page
                   'total_pages' => ceil($total_items/$per_page)   //WE have to calculate the total number of pages
               ) );
            }


          }

    $servicetable = new Service_list();
    $servicetable->prepare_items();

    ?>
          <div class="wrap">

              <form id="service-list" method="get">
                  <!-- For plugins, we also need to ensure that the form posts back to our current page -->
                  <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
                  <!-- Now we can render the completed list table -->
                  <?php  $servicetable->display(); ?>
              </form>

          </div>
          <?php
}
?>

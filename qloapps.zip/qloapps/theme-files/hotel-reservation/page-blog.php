<?php
/**
 * The template for displaying Blogs
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();

blog_navbar( 'all' );

global $wp_query;
global $queued_posts;
$queued_posts = array();
$current_page = $wp_query->get( 'paged' );

if ( 0 !== $current_page ) {

	get_filtered_posts( 'latest' );
} else {

	/* Get feature post on homepage ( current_page = 0 )*/
	show_featured_post();

	$filter_cat = array( 'article', 'doc', 'latest' );

	foreach ( $filter_cat as $cat ) {

		get_filtered_posts( $cat );
	}
}


/* Feature Post Getter method */
function show_featured_post() {

	global $queued_posts;

	$feat_args = array(
		'post_type'   => 'post',
		'post_status' => 'publish',
		'meta_key'   => 'meta-featured-post',
		'meta_value'  => 'yes',
	);

	$feat_post = new WP_Query( $feat_args );

	if ( $feat_post->have_posts() ) {
		?>
		<div class="qloblog-featured-poster">
		<?php

		while ( $feat_post->have_posts() ) {

			$feat_post->the_post();

			$post_id = get_the_ID();

			array_push( $queued_posts, $post_id );

			$author_id    = get_query_var( 'author' );
			$author_thumb = get_the_author_meta( 'profile-image', $author_id );
			$author_thumb = ( ! empty( $author_thumb ) ) ? $author_thumb : get_avatar_url( ( get_the_author_meta( 'user_email' ) ) );
			?>
			<div class="container">
				<a href="<?php the_permalink(); ?>">
					<div class="wk-cover">
						<h1><?php the_title(); ?></h1>
						<?php
						$featured_poster = get_the_post_thumbnail_url( $post_id, 'full' );

						if ( ! empty( $featured_poster ) ) {
							?>
							<img src="<?php echo esc_url( $featured_poster ); ?>" class="wk-cover-image" alt ="<?php echo get_the_title(); ?>" title ="<?php echo get_the_title(); ?>">
							<?php
						}
						?>
						<div class="wk-cover-author">
							<img src="<?php echo $author_thumb; ?> ">
							<div class="wk-cover-author-block">
								<span><?php echo get_the_author(); ?></span>
								<span><?php echo get_the_date( 'j F Y' ); ?></span>
							</div>
						</div>
					</div>
				</a>
			</div>
			<?php

			break;
		}
		?>
		</div>
		<?php
	}
}
/* //Feature Post Getter */

/* All posts driver function */
function get_filtered_posts( $meta_value ) {

	global $queued_posts;
	$meta_key      = 'qlo_filter';
	$count         = 3;
	$featured      = array( get_cat_ID( 'featured' ), get_cat_ID( 'culture featured' ) );
	$section_title = $meta_value . 's';
	$view_all_url  = site_url() . '/' . $meta_value;

	$query_args = array(
		'post_type'        => 'post',
		'post_status'      => 'publish',
		'posts_per_page'   => $count,
		'meta_key'         => $meta_key,
		'meta_value'       => $meta_value,
		'category__not_in' => $featured,
		'order_by'         => 'most_recent',
		'post__not_in'     => $queued_posts,
	);

	if ( 'latest' === $meta_value ) {

		unset( $query_args['meta_key'] );
		unset( $query_args['meta_value'] );
		unset( $query_args['posts_per_page'] );

		$query_args['paged'] = get_pagenumber_args();
		$section_title       = 'Latest';
		$view_all_url        = get_next_posts_page_link();
		$meta_value          = null;   /* Null : Gradient will be used acc. to Pages, Signifies it is a 'Paged' page */
	}

	$filter_query = new WP_Query( $query_args );

	if ( $filter_query->have_posts() ) {
		?>
		<!--Section-->
		<section class="qloapps-blog-page">
			<div class="container">
				<div class="wk-section">
					<div class="wk-section-header">
						<h2><?php echo esc_html( $section_title ); ?></h2>
						<div class="wk-section-link">
							<?php
							if ( null !== $meta_value ) {
								?>
								<a href="<?php echo esc_url( $view_all_url ); ?>">View All</a>
								<?php
							}
							?>
						</div>
					</div>

					<div class="qblog-archives text-left">
						<?php
						if ( $filter_query->have_posts() ) {
	
							while ( $filter_query->have_posts() ) {
	
								$filter_query->the_post();
	
								array_push( $queued_posts, get_the_ID() );
	
								get_template_part( 'content', 'blog' );
							}
						}
						?>
					</div>
	
					<?php
					if ( 'latest' === $meta_value || null === $meta_value ) {
					?>
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6">
								<div class="wk-pagination-wrapper">
									<?php hotelreservation_pagination( $filter_query->found_posts ); ?>
								</div>
							</div>
							<div class="col-md-3"></div>
						</div>
					<?php
					}
					?>
				</div>
			</div>
		</section>
		<?php
	}
}
/* //All posts driver function */

//Footer
get_footer();

var icons = ['colls'];
export default icons;
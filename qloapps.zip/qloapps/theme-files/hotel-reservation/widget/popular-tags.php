<?php
/*
Plugin Name: Popular Post Tags
Plugin URI: http://qloapps.com/blog
Description: A plugin for displaying post tags
Version: 0.1
Author: webkul
Author URI: http://hotelreservation.com/blog
Text Domain: Hotel Reservation
*/
 
 
class popularTags_Widget extends WP_Widget {
 
    public function __construct() {
     
        parent::__construct(
            'tag_id',
            __( 'Hotel Reservation Popular Tag Widget', 'tagwidget' ),
            array(
                'classname'   => 'tags_posts',
                'description' => __('Hotel Reservation Popular Tags Widget.', 'tagwidget' )
                )
        );
       
    }
 
    /**  
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {    
         
        extract( $args );
         
        ?>
        <div class="tags-wrapper">

        <?php
	  	
      	  	$tags = get_tags();
      $html = '<div class="post_tags">';
      foreach ( $tags as $tag ) {
        $tag_link = get_tag_link( $tag->term_id );
            
        $html .= "<a href='{$tag_link}' title='{$tag->name} Tag' class='{$tag->slug}'>";
        $html .= "{$tag->name}</a>";
      }
      $html .= '</div>';
      echo $html;
		
	?> </div><?php

                
    }
 
    /**
      * Sanitize widget form values as they are saved.
      *
      * @see WP_Widget::update()
      *
      * @param array $new_instance Values just sent to be saved.
      * @param array $old_instance Previously saved values from database.
      *
      * @return array Updated safe values to be saved.
      */
    public function update( $new_instance, $old_instance ) {        
         
        $instance = $old_instance;
         
        return $instance;
  		
    }
  
    /**
      * Back-end widget form.
      *
      * @see WP_Widget::form()
      *
      * @param array $instance Previously saved values from database.
      */
    public function form( $instance ) {    
     
        
       
    }
     
}
 
/* Register the widget */
add_action( 'widgets_init', function(){
     register_widget( 'popularTags_Widget' );
});

<?php
/**
 * Webkul MAIN Header Template
 * @package webkul
 * @subpackage webkul theme
 * @since WebkulTheme 1.0
 */

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?> >
	<head>
		<title><?php wp_title( '|', true, 'right' ); ?></title>
		<link rel="icon" type="image/x-icon" href="<?php echo esc_attr( get_bloginfo( 'template_url' ) ); ?>/images/favicon.ico"/>
		<link rel="apple-touch-icon" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-57.png' ); ?>" />
		<link rel="apple-touch-icon" sizes="72x72" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-72.png' ); ?>" />
		<link rel="apple-touch-icon" sizes="114x114" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-114.png' ); ?>" />
		<link rel="apple-touch-icon" sizes="144x144" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-144.png' ); ?>" />
		<link rel="preload" as="font" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap"/>
		<link rel="preload" as="image" href="<?php echo esc_url( get_template_directory_uri() . '/images/webkul-main-sprite.svg?v=4.6' ); ?>">
		<link rel="preconnect" href="https://www.gstatic.com" />
		<link rel="preconnect" href="https://www.google-analytics.com" />
		<link rel="preconnect" href="https://www.googletagmanager.com" />
		<link rel="preconnect" href="https://fonts.gstatic.com" />
		<link rel="manifest" href="<?php echo esc_url( get_template_directory_uri() . '/manifest.json' ); ?>">
		<link type="application/opensearchdescription+xml" rel="search" title="Webkul Blog" href="/blog/wp-content/themes/webkul-blog-bolt/assets/osdd.xml"/>
		<meta name="theme-color" content="#2149f3">
		<meta name="viewport" content="width=device-width,user-scalable=yes,initial-scale=1,maximum-scale=5">
		<meta name="keywords" content="webkul software, Opencart extension company, magento ecommerce extension, joomla, webkul opencart store, enterprise extensions"/>
		<meta name="google-site-verification" content="2ATbmQVR9BgdJ_fkEz6FOwiSzlCNd_FfdslAPxaUJOI"/>
		<link href="https://plus.google.com/+Webkul" rel="publisher" />
		<script>
		if('serviceWorker' in navigator) {
			navigator.serviceWorker.register('/wksw-install.js', { scope: '/' })
			.then(function(registration) {
			});
			navigator.serviceWorker.ready.then(function(registration) {
			});
		}
		</script>
		<?php wp_head(); ?>
	</head>

	<body>

		<script>
		/*! modernizr 3.6.0 (Custom Build) | MIT *
		* https://modernizr.com/download/?-webp-setclasses !*/
		!function(e,n,A){function o(e,n){return typeof e===n}function t(){var e,n,A,t,a,i,l;for(var f in r)if(r.hasOwnProperty(f)){if(e=[],n=r[f],n.name&&(e.push(n.name.toLowerCase()),n.options&&n.options.aliases&&n.options.aliases.length))for(A=0;A<n.options.aliases.length;A++)e.push(n.options.aliases[A].toLowerCase());for(t=o(n.fn,"function")?n.fn():n.fn,a=0;a<e.length;a++)i=e[a],l=i.split("."),1===l.length?Modernizr[l[0]]=t:(!Modernizr[l[0]]||Modernizr[l[0]]instanceof Boolean||(Modernizr[l[0]]=new Boolean(Modernizr[l[0]])),Modernizr[l[0]][l[1]]=t),s.push((t?"":"no-")+l.join("-"))}}function a(e){var n=u.className,A=Modernizr._config.classPrefix||"";if(c&&(n=n.baseVal),Modernizr._config.enableJSClass){var o=new RegExp("(^|\\s)"+A+"no-js(\\s|$)");n=n.replace(o,"$1"+A+"js$2")}Modernizr._config.enableClasses&&(n+=" "+A+e.join(" "+A),c?u.className.baseVal=n:u.className=n)}function i(e,n){if("object"==typeof e)for(var A in e)f(e,A)&&i(A,e[A]);else{e=e.toLowerCase();var o=e.split("."),t=Modernizr[o[0]];if(2==o.length&&(t=t[o[1]]),"undefined"!=typeof t)return Modernizr;n="function"==typeof n?n():n,1==o.length?Modernizr[o[0]]=n:(!Modernizr[o[0]]||Modernizr[o[0]]instanceof Boolean||(Modernizr[o[0]]=new Boolean(Modernizr[o[0]])),Modernizr[o[0]][o[1]]=n),a([(n&&0!=n?"":"no-")+o.join("-")]),Modernizr._trigger(e,n)}return Modernizr}var s=[],r=[],l={_version:"3.6.0",_config:{classPrefix:"",enableClasses:!0,enableJSClass:!0,usePrefixes:!0},_q:[],on:function(e,n){var A=this;setTimeout(function(){n(A[e])},0)},addTest:function(e,n,A){r.push({name:e,fn:n,options:A})},addAsyncTest:function(e){r.push({name:null,fn:e})}},Modernizr=function(){};Modernizr.prototype=l,Modernizr=new Modernizr;var f,u=n.documentElement,c="svg"===u.nodeName.toLowerCase();!function(){var e={}.hasOwnProperty;f=o(e,"undefined")||o(e.call,"undefined")?function(e,n){return n in e&&o(e.constructor.prototype[n],"undefined")}:function(n,A){return e.call(n,A)}}(),l._l={},l.on=function(e,n){this._l[e]||(this._l[e]=[]),this._l[e].push(n),Modernizr.hasOwnProperty(e)&&setTimeout(function(){Modernizr._trigger(e,Modernizr[e])},0)},l._trigger=function(e,n){if(this._l[e]){var A=this._l[e];setTimeout(function(){var e,o;for(e=0;e<A.length;e++)(o=A[e])(n)},0),delete this._l[e]}},Modernizr._q.push(function(){l.addTest=i}),Modernizr.addAsyncTest(function(){function e(e,n,A){function o(n){var o=n&&"load"===n.type?1==t.width:!1,a="webp"===e;i(e,a&&o?new Boolean(o):o),A&&A(n)}var t=new Image;t.onerror=o,t.onload=o,t.src=n}var n=[{uri:"data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAwA0JaQAA3AA/vuUAAA=",name:"webp"},{uri:"data:image/webp;base64,UklGRkoAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAwAAAABBxAR/Q9ERP8DAABWUDggGAAAADABAJ0BKgEAAQADADQlpAADcAD++/1QAA==",name:"webp.alpha"},{uri:"data:image/webp;base64,UklGRlIAAABXRUJQVlA4WAoAAAASAAAAAAAAAAAAQU5JTQYAAAD/////AABBTk1GJgAAAAAAAAAAAAAAAAAAAGQAAABWUDhMDQAAAC8AAAAQBxAREYiI/gcA",name:"webp.animation"},{uri:"data:image/webp;base64,UklGRh4AAABXRUJQVlA4TBEAAAAvAAAAAAfQ//73v/+BiOh/AAA=",name:"webp.lossless"}],A=n.shift();e(A.name,A.uri,function(A){if(A&&"load"===A.type)for(var o=0;o<n.length;o++)e(n[o].name,n[o].uri)})}),t(),a(s),delete l.addTest,delete l.addAsyncTest;for(var p=0;p<Modernizr._q.length;p++)Modernizr._q[p]();e.Modernizr=Modernizr}(window,document);

		Modernizr.on('webp', function(result) {
			if (result) {
				console.log('webp supported');
				document.body.classList.add('on-webp');
			} else {
				console.log('webp not-supported');
			}
		});
		</script>

		<a class="screen-reader-shortcut" href="#wkmain-content">Skip to main content</a>

		<header id="_wkheader">
			<div class="wk-fluid">
				<div class="wk-navbar">
					<div class="wk-logo-wrap neutral">
						<a class="wk-logo" href="<?php echo esc_url( site_url() ); ?>" title="<?php echo esc_url( site_url() ); ?>"></a>
					</div>

					<nav id="wk-super-menu">
						<?php
						$defaults = array(
							'theme_location' => 'webkul_mega_menu',
							'walker' => new WK_Walker_Mega_Menu(),
						);
						?>
						<?php
						wp_nav_menu( $defaults );
						?>
					</nav>
					<nav id="wk-mobi-menu">
						<div id="wk-hamburger-toggler"></div>
						<div class="mobi-nav-wrapper">
							<span class="link-back"></span>
							<span class="float-text"></span>
							<ul id="__parentMenuHolder"></ul>
							<ul id="__childMenuFan" class="fan-inactive"></ul>
						</div>

						<script type="text/html" id="mobiParentMenus-template">
							<li class="{{menu_class_wrap}}" >
								<a class="{{menu_class}}" data-identifier="{{menu_id}}" href="{{menu_link}}" target="{{target}}" rel="{{rel}}">{{menu_name}}</a>
							</li>
						</script>

						<script type="text/html" id="mobiChildMenus-template">
							<li class="wk-menu-item">
								<a class="wk-menu-icon wk-menu-icon-{{menu_class}}" href="{{menu_link}}" target="{{target}}" rel="{{rel}}">{{menu_name}}</a>
							</li>
						</script>

					</nav>
				</div>
			</div>
		</header>

<?php

$all_locations = get_nav_menu_locations();
$menu_items    = wp_get_nav_menu_object( $all_locations['webkul_mega_menu'] );
$menu_items    = wp_get_nav_menu_items( $menu_items->term_id );
$filtered_keys = array();

foreach ( $menu_items as $key => $item ) {

	$menu_title = $item->post_title;
	if ( '' === $item->post_title ) {
		$obj_id = get_post_meta( $item->ID, '_menu_item_object_id', true );
		$menu_title = get_the_title( $obj_id );
	}
	$menu_url = ( '' === $item->url ) ? 'javascript:void(0)' : $item->url;
	$filtered_keys[] = array(
		'id'         => $item->ID,
		'menu_slug'  => $item->post_name,
		'menu_name'  => $menu_title,
		'parent'     => $item->menu_item_parent,
		'menu_link'  => $menu_url,
		'icon_class' => implode( ' ', $item->classes ),
		'rel'        => $item->xfn,
		'target'     => $item->target,
	);
}

echo '<script id="mobileNavMenuData" type="application/json">' . wp_json_encode( $filtered_keys ) . '</script>';

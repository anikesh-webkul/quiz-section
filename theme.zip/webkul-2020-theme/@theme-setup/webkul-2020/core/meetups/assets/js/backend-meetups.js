var $wk = jQuery.noConflict();

(function () {
	$wk(document).ready(function () {
        if( $wk('.form-wrap .mp-add-new') ) {
            $wk( document ).on( 'click', '.mp-add-new', e => {
                mpDataInsert = $wk( e.target ).attr( 'data-insert' )
                mpContainer = $wk( e.target ).parents( '.form-wrap' );
                mpTmpl = mpContainer.find( '.meetupTmpl' ).html();

                if( 'append' === mpDataInsert ) {
                    mpContainer.find( '.meetup-tmpl-container' ).append( mpTmpl );
                } else {
                    mpContainer.find( '.meetup-tmpl-container' ).prepend( mpTmpl );
                }
            } );
        }

    } );
})($wk);
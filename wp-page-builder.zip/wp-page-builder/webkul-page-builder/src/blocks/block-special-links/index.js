registerBlockType( 'wk-blocks/special-links', {
    title : 'Special Links',
    icon : 'screenoptions',
    category: 'webkul',
    keywords: ['Special Links'],
    parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    example:{},

    attributes: {
        content: {
            type:'string',
            selector: '.brick',
        },
        link: {
            type:'string',
        },
        newWindow: {
            type:'boolean',
        },
       
    },
    edit : function( props ) {
        var content = props.attributes.content,
        link = props.attributes.link,
        newWindow = props.attributes.newWindow;

       
        return (
            el(
                Fragment,
                {},
                el(
                    InspectorControls,
                    {},
                    el(
                        Panel,
                        {},
                        el(
                            PanelBody,
                            {
                                title:'Special Link Setting',
                            },
                            el(
                                PanelRow,
                                {},
                                el(
                                    TextControl,
                                    {
                                        type:"string",
							            label:'ADD URL',
                                        value:link,
                                        onChange:(newLink) => {
                                            props.setAttributes({link:newLink});
                                        }
                                    }
                                ),
                            ),
                            el(
                                PanelRow,
                                {},
                                el(
                                    FormToggle,
                                    {
                                        checked:newWindow,
                                        onChange: ( event ) => {
                                            props.setAttributes( {
                                                newWindow: event.target.checked,
                                            } )
                                        },
                                    }
                                ),
                                el(
                                    'span',
                                    {},
                                    'Open in New Tab'
                                )
                            ),
                        )
                    )
                ),
                el(
                    'div',
                    {
                        className:'brick-wrap',

                    },
                    el(
                        PlainText,
                        {
                            key: 'editable',
                            tag:'div',
                            className:'brick',
                            value:content,
                            placeholder:'Special Link Text....',
                            onChange:(newContent) => {
                                props.setAttributes({content:newContent});
                            }
                        },

                    ),
                    el(
                        Dashicon,
                        {
                            icon:'admin-links'
                        }
                    )
                )
            )
        
        );
    },
    save:function(props) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className:'brick-wrap',
                },
                el(
                    'a',
                    {
                        href:props.attributes.link,
                        className:'wk-links-component',
                        target:(props.attributes.newWindow) ? '_blank' : false,
                        rel:(props.attributes.newWindow) ? 'noopener noreferrer' : false
                    },
                    el(
                        'div',
                        {
                            className:'brick',
                        },
                        props.attributes.content
                    )
                    
                )
            )
        )
    }


} );
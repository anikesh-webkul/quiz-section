<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/
get_header( 'two' );
?>
		<div class="wr-404 ">
			<div class="wr-404-lt">
				<div class="wr-otr-spc"></div>
			</div>
			<div class="wr-404-rt">
				<div class="wr-404-agn">
					<div class="wr-fixed">
						<h1>
							4<span class="wr-404-accent">0</span>4
						</h1>
						<h2>You are lost in the
							<span class="wr-404-accent">Space</span>!</h2>
						<p>The page you are looking for doesn’t exist or have secretly escaped; head back to home and make a fresh
							move again.
						</p>
						<a class="wr-404-back" href="<?php echo esc_url( site_url() ); ?>">Go to Home</a>
					</div>
				</div>
			</div>
		</div>

	</body>
</html>

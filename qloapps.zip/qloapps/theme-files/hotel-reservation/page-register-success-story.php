
<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();

?>
<section class="wk-common-padding wk-header-wrapper">
  <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="qlo-content-padd text-center">
            <h1>Share the story behind your success with QloApps.</h1>
            <p class="head-detail">Every success has a beautiful story behind it. Please let us know how QloApps was able to help you out in attaining what you desired. Your story will be our fuel and motivation to work even harder. Let us serve the hotel industry together. </p>
          </div>
        </div>
      </div>
  </div>
</section>
<section class="wk-common-padding border-shadow register-success-story">
  <div class="container">
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">

        <!-- <div id="uv_top_message" class="uv_load">
          <img src="https://cdn.uvdesk.com/bundles/webkuldefault/images/cssImages/loader.gif">
        </div>
        <script id="15b9222896fb755b9222896fc1e" src="https://webkul.uvdesk.com/apps/form-builder/en/form/15b9222896fb755b9222896fc1e?removePlaceholders=1&info=0" async="async" > </script> -->
        <?php echo do_shortcode( '[contact-form-7 id="4180" title="Register Success Story"]' ); ?>

      </div>
      <div class="col-md-3"></div>
    </div>
  </div>
</section>
<?php
get_footer();?>

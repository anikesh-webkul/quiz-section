<?php
/*
Plugin Name: Qloapp Cloud Plans
Plugin URI: http://qloapps.com
Description: A plugin for Adding Cloud Hosting Plan to qloapps themes
Author: qloapps
Author URI: http://qloapps.com
Text Domain: Qloapps
*/

add_action( 'admin_menu', 'qa_cloud_plans' );

function qa_cloud_plans() {

  $hook = add_menu_page( 'Cloud Plan', 'Cloud Plan', 'edit_posts', 'cloud_plans', 'qa_cloud_plans_list', 'dashicons-editor-ul', 15);

  add_submenu_page( 'cloud_plans', 'Add Plan', 'Add New Plan', 'edit_posts', 'add_cloud_plan', 'qa_add_cloud_plan_menu' );
  add_submenu_page( 'cloud_plans', 'Add Cloud Prices', 'Add Cloud Prices', 'edit_posts', 'add_cloud_prices', 'qa_add_cloud_prices_menu' );

  add_action( "load-".$hook, 'qa_cloud_add_option' );
}

function qa_cloud_add_option() {
  $option = 'per_page';

  $args = array(

         'label' => 'Results',

         'default' => 10,

         'option' => 'qa_cloud_plans_per_page'

         );

  add_screen_option( $option, $args );
}

// set screen option

function qa_cloud_plans_list() {
  add_filter( 'set-screen-option', function( $status, $option, $value ){
    if ( 'qa_cloud_plans_per_page' === $option ) return $value;
    return $status;
  }, 10, 3 );
  require_once( sprintf( "%s/class-qa-all-plans.php", dirname( __FILE__ ) ) );
}
function qa_add_cloud_prices_menu() {
  require_once( sprintf( "%s/cloud-prices.php", dirname( __FILE__ ) ) );
}

function qa_add_cloud_plan_menu() {
  require_once( sprintf( "%s/add-plan.php", dirname( __FILE__ ) ) );
}

?>

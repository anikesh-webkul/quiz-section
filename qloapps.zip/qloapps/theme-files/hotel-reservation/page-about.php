
<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();

?>
<section class="wk-common-padding qlo-mastermind border-shadow">
  <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="qlo-content-padd text-center">
            <h2>ABOUT QLOAPPS & TEAM</h2>
            <p class="head-detail">You've read about the importance of being courageous, rebellious and imaginative- These are all vital ingredients in an effective advertising campaign- However, they must be tempered with the most important ingredient of all.</p>
            <div class="mastermind-info">
              <p>Narwhal brunch edison bulb snackwave chicharrones hoodie. Raw denim taiyaki snackwave ennui everyday carry church-key vape shaman banjo migas poutine lumbersexual sartorial. Thundercats farm-to-table tumeric messenger bag, la croix fingerstache pop-up cornhole. Marfa subway tile fixie truffaut banjo snackwave austin deep v dreamcatcher mustache post-ironic fashion axe.</p>
              <h4>Vinay Yadav</h4>
              <h3>Mastermind of QloApps</h3>
            </div>
          </div>
        </div>
      </div>
  </div>
</section>

<section class="section-padding-0T wk-our-team text-center">
  <div class="container">
      <div class="row">
        <div class="col-md-12">
            <h1 class="text-center">OUR TEAM</h1>
            <p class="team-desc">You've read about the importance of being courageous, rebellious and imaginative. These are all vital ingredients in an effective advertising campaign</p>
            <?php do_action('wkt_team_listing'); ?>
        </div>
      </div>
  </div>
</section>

<section class="wk-common-padding business-wrapper section-lightgray text-center">
  <div class="container">
      <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
          <h1>Who's behind us</h1>
          <p class="head-detail">Webkul Softwares is the company who is behind this gigantic product “Booking Engine”, At Webkul we have Revolutionized the eCommerce world by our Lagendry Product Multi Vendor Marketplace, Our Sub-eCommerce Modules & Apps, & now we have built this Gigantic Product Booking Engine.</p>
        </div>
        <div class="col-md-1"></div>
      </div>
  </div>
</section>

<section class="wk-common-padding webkul-products space-common">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <img src="<?php echo get_template_directory_uri() . '/images/about-us/logo-webkul.png'; ?>" class="space-top-header img-responsive center-block">

                <div class="webkul-products-wrapper">
                    <i></i>
                    <span></span>
                    <div class="webkul-products-inner">

                        <a href="http://marketplace.webkul.com" target="_blank" rel="noopener" title="Marketplace Webkul">
                          <img src="<?php echo get_template_directory_uri() . '/images/about-us/marketplace.png'; ?>" class="img-responsive center-block" alt="Marketplace Webkul">
                        </a>
                        <a href="https://qloapps.com" target="_blank" rel="noopener" title="Qloapps">
                          <img src="<?php echo get_template_directory_uri() . '/images/about-us/qloapps.png'; ?>" class="img-responsive center-block" alt="Qloapps">
                        </a>
                        <a href="https://www.uvdesk.com" target="_blank" rel="noopener" title="Uvdesk">
                          <img src="<?php echo get_template_directory_uri() . '/images/about-us/uvdesk.png'; ?>" class="img-responsive center-block" alt="Uvdesk">
                        </a>
                        <a href="https://bookingcommerce.com" target="_blank" rel="noopener" title="Booking Engine">
                          <img src="<?php echo get_template_directory_uri() . '/images/about-us/booking-commerce.png'; ?>" class="img-responsive center-block" alt="Booking Engine">
                        </a>
                        <a href="http://chatwhizz.com:8080" target="_blank" rel="noopener" title="Chatwhizz">
                          <img src="<?php echo get_template_directory_uri() . '/images/about-us/chatwhizz.png'; ?>" class="img-responsive center-block" alt="Chatwhizz">
                        </a>
                        <a href="https://mobikul.com" target="_blank" rel="noopener" title="Mobikul">
                          <img src="<?php echo get_template_directory_uri() . '/images/about-us/mobikul.png'; ?>" class="img-responsive center-block" alt="Mobikul">
                        </a>
                        <a href="" target="_blank" rel="noopener" title="Seller Buyer Chat">
                          <img src="<?php echo get_template_directory_uri() . '/images/about-us/seller-buyer-chat.png'; ?>" class="img-responsive center-block" alt="Seller Buyer Chat">
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding-0T join-us-wrapper text-center">
  <div class="container">
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
          <p class="head-detail">Let’s collaborate & Build something gigantic...</p>
          <a href="contact" class="white btn-bgcolor btn-download-ext">Join Us</a>
        </div>
        <div class="col-md-2"></div>
      </div>
  </div>
</section>

<?php

get_footer();?>

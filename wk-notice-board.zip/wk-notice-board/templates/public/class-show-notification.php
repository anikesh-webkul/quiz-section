<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Show_Notification' ) ) {

	class Show_Notification {

		public function __construct() {
			add_action( 'wp_head', array( $this, 'wk_notification' ) );
		}
		function wk_notification() {
			if( is_404() ) {
				return false;
			}

			global $wpdb;
			$table_name           = $wpdb->prefix . 'banner_list';
			$wn_notification_data = $wpdb->get_results( "SELECT * from $table_name WHERE status='enable' ORDER BY priority DESC" );


		if ( isset( $wn_notification_data ) && ! empty( $wn_notification_data ) ) 
		{
			
				$wn_notification_data        = json_decode( json_encode( $wn_notification_data ), true);
				$notify_id                    = is_array( $wn_notification_data ) && ! empty( $notify_ids = array_column( $wn_notification_data, 'id' ) ) ? max( $notify_ids ) : false;
				
				$total_banners_exist          = count( $wn_notification_data );
				$background_color_banner      = get_option( 'wc_custom_banner_background_color' );
				$title_color_banner           = get_option( 'wc_custom_banner_text_color' );
				$link_background_color_banner = get_option( 'wc_custom_banner_link_background_color' );
				$link_color_banner            = get_option( 'wc_custom_banner_link_color' );

	
				if ( ! isset( $background_color_banner ) || empty( $background_color_banner ) ) {
					$background_color_banner = '#fe6b00';
				}
				if ( ! isset( $title_color_banner ) || empty( $title_color_banner ) ) {
					$title_color_banner = '#ffffff';
				}
				if ( ! isset( $link_background_color_banner ) || empty( $link_background_color_banner ) ) {
					$link_background_color_banner = '#0e1b51';
				}
				if ( ! isset( $link_color_banner ) || empty( $link_color_banner ) ) {
					$link_color_banner = '#ffffff';
				}
				echo '<div class="show-banners">';

			
if ( $total_banners_exist <= 1) 
{

	

	if(! empty($wn_notification_data[0]['auto_disable']))
	{
		date_default_timezone_set('Asia/Kolkata');
		$end_date=$wn_notification_data[0]['end_date'];
		$today=date('Y-m-d H:i') ;
		$id= $wn_notification_data[0]['id'];
	
		if(strtotime($end_date) <= strtotime($today) )
		{	
			
				$dataupdate = array( 
					'status' => 'disable',		
				  );

				  $where = [ 'id' => $id ];
				  $updated = $wpdb->update( $table_name, $dataupdate, $where);

		}

		if ( ! empty( $wn_notification_data[0]['title'] ) && strtotime($end_date) > strtotime($today)  ) 
		{
			
			echo '<div class="notification-wrapper " style="background:' . $background_color_banner . ';">
			<div class="notification-brick display-notification-brick">';
			if ( ! empty( $wn_notification_data[0]['label_title'] ) && ( $wn_notification_data[0]['label_title'] != 'none' && $wn_notification_data[0]['label_title'] != 'NONE' && $wn_notification_data[0]['label_title'] != 'None' ) ) {
			
				echo '<span class="label-title-view lable-title-display" style="background:'.$wn_notification_data[0]['label_background_color'].'; color:'.$wn_notification_data[0]['label_title_color'].';">'.$wn_notification_data[0]['label_title'].'</span>';
			}
			if (!empty($wn_notification_data[0]['label_title']) && ($wn_notification_data[0]['label_title']!='none' && $wn_notification_data[0]['label_title']!='NONE' && $wn_notification_data[0]['label_title']!='None')) {
				
				echo '<p style="color:'.$title_color_banner.';">'._wk_remove_slashes($wn_notification_data[0]['banner_text']).'</p>';
			} else {
				echo '<p class="banner-text-para" style="color:'.$title_color_banner.';">'._wk_remove_slashes($wn_notification_data[0]['banner_text']).'</p>';
			}
			if ( ! empty($wn_notification_data[0]['link'] ) ) 
			{
				
				echo '<a href="' . $wn_notification_data[0]['link'] . '" target="_blank" title="' . $wn_notification_data[0]['link_title'] . '" class="' . esc_attr( _wk_remove_slashes( $wn_notification_data[0]['link_title'] ) ) . '" rel="noopener noreferrer"><span id=' . $wn_notification_data[0]['priority'] . ' style="background:' . $link_background_color_banner . '; color:' . $link_color_banner . ';" class="notification-cta click-here-link" data-url="' . $wn_notification_data[0]['link'] . '">' . esc_html( _wk_remove_slashes( $wn_notification_data[0]['link_title'] ) ) . '</span></a>';
			}

			echo '</div><span class="notification-close"></span></div>';
		}
	}
	else{
					if ( ! empty( $wn_notification_data[0]['title'] )) 
					{
						echo '<div class="notification-wrapper " style="background:' . $background_color_banner . ';">
						<div class="notification-brick display-notification-brick">';
						if ( ! empty( $wn_notification_data[0]['label_title'] ) && ( $wn_notification_data[0]['label_title'] != 'none' && $wn_notification_data[0]['label_title'] != 'NONE' && $wn_notification_data[0]['label_title'] != 'None' ) ) {
						
							echo '<span class="label-title-view lable-title-display" style="background:'.$wn_notification_data[0]['label_background_color'].'; color:'.$wn_notification_data[0]['label_title_color'].';">'.$wn_notification_data[0]['label_title'].'</span>';
						}
						if (!empty($wn_notification_data[0]['label_title']) && ($wn_notification_data[0]['label_title']!='none' && $wn_notification_data[0]['label_title']!='NONE' && $wn_notification_data[0]['label_title']!='None')) {
							
							echo '<p style="color:'.$title_color_banner.';">'._wk_remove_slashes($wn_notification_data[0]['banner_text']).'</p>';
						} else {
							echo '<p class="banner-text-para" style="color:'.$title_color_banner.';">'._wk_remove_slashes($wn_notification_data[0]['banner_text']).'</p>';
						}
						if ( ! empty($wn_notification_data[0]['link'] ) ) 
						{
							
							echo '<a href="' . $wn_notification_data[0]['link'] . '" target="_blank" title="' . $wn_notification_data[0]['link_title'] . '" class="' . esc_attr( _wk_remove_slashes( $wn_notification_data[0]['link_title'] ) ) . '" rel="noopener noreferrer"><span id=' . $wn_notification_data[0]['priority'] . ' style="background:' . $link_background_color_banner . '; color:' . $link_color_banner . ';" class="notification-cta click-here-link" data-url="' . $wn_notification_data[0]['link'] . '">' . esc_html( _wk_remove_slashes( $wn_notification_data[0]['link_title'] ) ) . '</span></a>';
						}

						echo '</div><span class="notification-close"></span></div>';
					}
				}

				} 
				else {
					echo '<div class="notification-wrapper notification-wrapper-banner " style="background:'.$background_color_banner.';">';
						for ( $i=0; $i < $total_banners_exist; $i++ ) {
						
							

							if ( ! empty( $wn_notification_data[ $i ]['title'] ) && empty($wn_notification_data[$i]['auto_disable'])) 
							{
								if ( $i == 0 ) {
									echo '<div class="notification-brick active-paper">';
									} else {
										echo '<div class="notification-brick">';
										}
										if (!empty($wn_notification_data[$i]['label_title']) && ($wn_notification_data[$i]['label_title']!='none' && $wn_notification_data[$i]['label_title']!='NONE' && $wn_notification_data[$i]['label_title']!='None')) {
											echo '<span class="label-title-view lable-title-display" style="background:'.$wn_notification_data[$i]['label_background_color'].'; color:'.$wn_notification_data[$i]['label_title_color'].';">'.$wn_notification_data[$i]['label_title'].'</span>';
										}
										if (!empty($wn_notification_data[$i]['label_title']) && ($wn_notification_data[$i]['label_title']!='none' && $wn_notification_data[$i]['label_title']!='NONE' && $wn_notification_data[$i]['label_title']!='None')) {
											echo '<p style="color:'.$title_color_banner.';">'._wk_remove_slashes( $wn_notification_data[$i]['banner_text']).'</p>';
										}
										else {
											echo '<p class="banner-text-para" style="color:'.$title_color_banner.';">'._wk_remove_slashes( $wn_notification_data[$i]['banner_text']).'</p>';
										}
										if ( ! empty($wn_notification_data[$i]['link_title'] ) ) {

											echo '<a href="'.$wn_notification_data[$i]['link'].'" target="_blank" title="'.$wn_notification_data[$i]['link_title'].'" class="' . esc_attr( str_replace( ' ', '-', strtolower( _wk_remove_slashes( $wn_notification_data[$i]['link_title'] ) ) ) ) . '" rel="noopener noreferrer"><span id='.$i.' style="background:'.$link_background_color_banner.'; color:'.$link_color_banner.';" class="notification-cta click-here-link"  data-url="'.$wn_notification_data[$i]['link'].'">'._wk_remove_slashes($wn_notification_data[$i]['link_title']).'</span></a>';

										}
										echo  '</div>';
									}
									else{

							if(!empty($wn_notification_data[$i]['auto_disable']))
							{
								date_default_timezone_set('Asia/Kolkata');
								$end_date=$wn_notification_data[$i]['end_date'];
								$today=date('Y-m-d H:i') ;
								$id= $wn_notification_data[$i]['id'];
								
								
							
								if(strtotime($end_date) <= strtotime($today) )
								{	
										$dataupdate = array( 
											'status' => 'disable',		
										  );
						
										  $where = [ 'id' => $id ];
										  $updated = $wpdb->update( $table_name, $dataupdate, $where);
								}
								if ( ! empty( $wn_notification_data[ $i ]['title'] ) && strtotime($end_date) > strtotime($today) ) 
								{
								
							
									if ( $i == 0 ) {
										echo '<div class="notification-brick active-paper">';
										} else {
											echo '<div class="notification-brick">';
											}
											if (!empty($wn_notification_data[$i]['label_title']) && ($wn_notification_data[$i]['label_title']!='none' && $wn_notification_data[$i]['label_title']!='NONE' && $wn_notification_data[$i]['label_title']!='None')) {
												echo '<span class="label-title-view lable-title-display" style="background:'.$wn_notification_data[$i]['label_background_color'].'; color:'.$wn_notification_data[$i]['label_title_color'].';">'.$wn_notification_data[$i]['label_title'].'</span>';
											}
											if (!empty($wn_notification_data[$i]['label_title']) && ($wn_notification_data[$i]['label_title']!='none' && $wn_notification_data[$i]['label_title']!='NONE' && $wn_notification_data[$i]['label_title']!='None')) {
												echo '<p style="color:'.$title_color_banner.';">'._wk_remove_slashes( $wn_notification_data[$i]['banner_text']).'</p>';
											}
											else {
												echo '<p class="banner-text-para" style="color:'.$title_color_banner.';">'._wk_remove_slashes( $wn_notification_data[$i]['banner_text']).'</p>';
											}
											if ( ! empty($wn_notification_data[$i]['link_title'] ) ) {
	
												echo '<a href="'.$wn_notification_data[$i]['link'].'" target="_blank" title="'.$wn_notification_data[$i]['link_title'].'" class="' . esc_attr( str_replace( ' ', '-', strtolower( _wk_remove_slashes( $wn_notification_data[$i]['link_title'] ) ) ) ) . '" rel="noopener noreferrer"><span id='.$i.' style="background:'.$link_background_color_banner.'; color:'.$link_color_banner.';" class="notification-cta click-here-link"  data-url="'.$wn_notification_data[$i]['link'].'">'._wk_remove_slashes($wn_notification_data[$i]['link_title']).'</span></a>';
	
											}
											echo  '</div>';
										}
							}
						}
								
								}
								
								echo '<span class="nav-banner left"></span>
								<span class="nav-banner right" aria-hidden="true"></span>
								<span class="notification-close"></span></div>';
							}

							/*//TABLET*/
							?>
							<div class="wk-floating-noti-icon" data-weight="<?php echo esc_attr( count( $wn_notification_data ) ); ?>" data-position="<?php echo (int) $notify_id ?>"></div>
							<div class="notification-tab-banners">
								<div class="banner-header">Notifications<span class="close"></span></div>
								<ul class="banner-list">
									<?php
									foreach ( $wn_notification_data as $banner ) {
										echo '<li><a target="_blank" class="' . esc_attr( str_replace( ' ', '-', strtolower( $banner['link_title'] ) ) ) . '" rel="noopener noreferrer" title="' . _wk_remove_slashes( $banner['title'] ) . '" href="' . $banner['link'] . '">' . _wk_remove_slashes( $banner['banner_text'] ) . '</a></li>';
									}
									?>
								</ul>
							</div>

							<?php
							/*TABLET*/

							echo '</div>';

			}



	}
	}
	return new Show_Notification;

}

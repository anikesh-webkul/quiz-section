<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();
?>
<section class="wk-gdpr-section section-padding">
	<div class="wkgrid-squeezy">
		<h1>Exercise Your Rights Under <br><span class="col-main">GDPR</span></h1>
		<p>Send your GDPR request to Webkul Via form below. Your request will be sent to the support team at Webkul</p>
		<hr />
		<div class="reach-us">
			<div class="form-skull">
				<?php
				echo do_shortcode( '[contact-form-7 id="17818" title="GDPR"]' );
				?>
				<!-- <div id="uv_top_message" class="uv_load"> -->
					<!--Loader-->
					<!-- <div class="wk-skeleton-loader">
						<div class="wk-loader-grp">
							<div class="wk-loader-strip w-65"></div>
							<div class="wk-loader-strip w-full"></div>
						</div>
						<div class="wk-loader-grp">
							<div class="wk-loader-strip w-65"></div>
							<div class="wk-loader-strip w-full"></div>
						</div>
						<div class="wk-loader-grp">
							<div class="wk-loader-strip w-80"></div>
							<div class="wk-loader-strip w-full"></div>
						</div>
						<div class="wk-loader-grp">
							<div class="wk-loader-strip w-290"></div>
							<div class="wk-loader-strip w-full h-50"></div>
						</div>
						<div class="wk-loader-strip w-150"></div>
					</div> -->
					<!--//Loader -->
				<!-- </div>
				<style>
				.uv_form-group:nth-of-type(2) label,.uv_form-group:last-of-type label{
					transform: translateY(-20px) scale(.9) !important;
				}
				</style> -->
				<!-- <script id="15b064701cd99a5b064701cda4c" src="https://webkul.uvdesk.com/apps/form-builder/en/form/15b064701cd99a5b064701cda4c?removePlaceholders=1" async="async" > </script>
				<script>
				var limit=0,changeText=function(){if(document.getElementById("uv_submit1")){
					var uvFormInput = document.getElementsByClassName( 'uv_form-control' );
					for (var j = 0; j < uvFormInput.length; j++) {
						uvFormInput[j].addEventListener( 'focus', function () {
							this.previousElementSibling.classList.add( 'wk-label-active' );
						});
						uvFormInput[j].addEventListener( 'blur', function () {
							if (this.value == '') {
								__each( this.previousElementSibling ).removeClass( 'wk-label-active' );
							}
						});
					}document.getElementById("uv_submit1").innerHTML="Send my request";var e=document.querySelector(".uv_form .uv_form-group:nth-of-type(2)");if(e){e.style.display="none",document.getElementById("uv_reply").value="from "+window.location.href;var t=document.querySelector(".uv_form-group:nth-of-type(1)");if(t){var o=document.querySelector(".uv_form .uv_form-group:nth-last-of-type(2)"),r=t.parentNode.removeChild(t);o&&r&&o.parentNode.insertBefore(t,o)}var u=document.querySelectorAll('option[value=""]');for(i=0;i<u.length;i++){u[i].remove();}}}else limit<100&&(limit++,setTimeout(changeText,100))};setTimeout(changeText,100);
				</script> -->
			</div>
		</div>
	</div>
</section>


<?php
get_footer();?>

<?php

/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

function wk_get_testimonial_section() {
	$data_all = maybe_unserialize( get_option( 'wkct-client-testimonial-data' ) );

	/* Sort the reviews as per order*/
	
	if ( ! empty( $data_all ) && is_array( $data_all ) && count( $data_all ) >= 1 ) {
		// echo '<pre>';
		// var_dump($data_all);
		// die;
		$data_all = array_filter( $data_all, function($temp) {
			return 'checked' == $temp['status'] ? true : false;
		} );
		if( count( $data_all ) > 0 ) {

			usort( $data_all, function ( $a, $b ) {
				return ( $a['order'] < $b['order'] ) ? 1 : -1;
			});

			$c_order = 0;
			foreach ( $data_all as $key => $row ) {
				if ( isset( $row['order'] ) ) {
					$c_order       = 1;
					$order[ $key ] = $row['order'];
				}
			}
			if ( $c_order ) {
				array_multisort( $order, SORT_DESC, $data_all );
			}
		?>
		<section class="wk-testimonial-section section-padding">
			<div class="container">
				<div class="row">
					<div class="col-md-2"></div>
					<div class="col-md-8 text-center">
						<h3>What our clients think about us!</h3>
						<p class="testimonial-tagline">Meet our valuable clients and learn about their experiences with us.</p>
					</div>
					<div class="col-md-2"></div>
				</div>
			</div>
			<div class="wk-testimonial-carousel">
				<div class="glider-contain">
					<div class="carousel-items glider">
						<?php
						foreach ( $data_all as $key => $value ) {
							
							$imagae_url = isset( $value['imgUrl'] ) ? wp_get_upload_dir()['baseurl'] . $value['imgUrl'] : get_template_directory_uri() . '/images/default-image.png?v=1.0';
							$review       = isset( $value['testimonial'] ) ? $value['testimonial'] : '';
							$work         = isset( $value['design'] ) ? $value['design'] : '';
							$name         = isset( $value['name'] ) ? $value['name'] : '';
							$rating       = isset( $value['rating'] ) ? $value['rating'] : '';
							$country_code = isset( $value['country_code'] ) ? $value['country_code'] : false;
							$country_name = isset( $value['country_name'] ) ? $value['country_name'] : false;
							?>
							<div class="wk-testimonial-wrap">
								<div class="wk-testimonial-slide ">
									<div class="wk-testimonial-img-wrap">
										<div class="wk-testimonial-image-cover <?php echo ! isset( $value['imgUrl'] ) ? 'default-img' : false ?>">
											<img data-src="<?php echo  esc_url( $imagae_url ); ?>" class="wk-lazify" data-alt="<?php echo esc_html( $name ); ?>"/>
										</div>
									</div>
									<div class="wk-testimonial-content-wrap">
										<div class="wk-quote"><img data-src="<?php echo esc_url( get_template_directory_uri() . '/images/symbols.png' ); ?>" class="wk-lazify" data-alt="quote"></div>
										<div class="country-wrap">
											<h5><?php echo $name; ?></h5>
											<img data-src="https://restcountries.eu/data/<?php echo strtolower( $country_code ); ?>.svg" alt="<?php echo $country_name; ?>" class="wk-lazify" title="<?php echo $country_name; ?>" />
										</div>
										<p class="wk-testimonial-desg"><?php echo $work; ?></p>

										<?php
										if( $rating ) {
											?>
											<span class="wk-testimonial-rating" data-stars="<?php echo $rating ?>">
												<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="18px" height="20px" data-rating="1" viewBox="60 -62 309 309" style="stroke-width:10px;" ><polygon points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent;stroke: #ffd700;"></polygon><polygon points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="/* stroke-opacity: 0; */fill: transparent;"></polygon></svg>
												<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="18px" height="20px" data-rating="2" viewBox="60 -62 309 309" style="stroke-width:10px;" ><polygon points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent;stroke: #ffd700;"></polygon><polygon points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="/* stroke-opacity: 0; */fill: transparent;"></polygon></svg>
												<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="18px" height="20px" data-rating="3" viewBox="60 -62 309 309" style="stroke-width:10px;" ><polygon points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent;stroke: #ffd700;"></polygon><polygon points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="/* stroke-opacity: 0; */fill: transparent;"></polygon></svg>
												<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="18px" height="20px" data-rating="4" viewBox="60 -62 309 309" style="stroke-width:10px;" ><polygon points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent;stroke: #ffd700;"></polygon><polygon points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="fill: transparent;"></polygon></svg><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="18px" height="20px" data-rating="5" viewBox="60 -62 309 309" style="stroke-width:10px;margin-left: 3px;" ><polygon points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent;stroke: #ffd700;"></polygon><polygon class="svg-empty-467" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="/* stroke-opacity: 0; */fill: transparent;"></polygon></svg>
											</span>
											<?php

										}
										?>
										<p class="wk-testimonial-review">“<?php echo $review; ?>”</p>
									</div>
								</div>
							</div>
						<?php
						}
					?>
					</div>
					<button aria-label="Previous" class="glide-next-prev glider-prev wk-bg-lazify"></button>
					<button aria-label="Next" class="glide-next-prev glider-next wk-bg-lazify"></button>
				</div>
			</div>

		</section>
		<?php
		}
	}
}


/**
 * Homepage Banner Section
 * 
 */
display_banner_section();



/**
 * Homepage Feature Section
 * 
 */
display_feature_section();



/**
 * Homepage Marketplace Section
 * 
 */
?>
<section class="section-marketplace-homepage section-padding">
	<div class="container">
		<h3 class="text-center space-0">Marketplace</h3>
		<div class="section-marketplace-grid">
			
			<div class="brick-1">
				<div class="qa-card launch">
					<h4>Launch Marketplace</h4>
					<p>Launch your hotel marketplace and work as an online travel agency and earn a commission.</p>
				</div>

				<div class="qa-card hotelier">
					<h4>Get More Hoteliers</h4>
					<p>The QloApps Marketplace allows you to add as many hoteliers as you want. Those hotelier can add any number of hotels with any number of rooms.</p>
				</div>

				<div class="qa-card commission">
					<h4>Earn Commission</h4>
					<p>You can apply a different commission rate for different sellers. Then on their successful bookings earn your desired commission.</p>
				</div>
			</div>

			<div class="brick-2">
				<blockquote class="native-block">
					<p>Convert your hotel website into a marketplace of hotels and work as an online travel agency (OTA). Allow multiple vendors, hoteliers or property owners to list their properties/ hotels on your website and earn commission on their bookings.</p>
					<a href="<?php echo esc_url( site_url() . '/marketplace/' ); ?>" class="btn btn-bgcolor white normal-btn-style">Read More</a>
				</blockquote>
				<img src="<?php echo get_template_directory_uri() . '/images/homepage/marketplace.png' ?>" alt="markeplace">
			</div>


		</div>
	</div>
</section>



<?php
/**
 * Homepage Channel Manager Section
 * 
 */
?>
<section class="section-channel-manager-hompage section-offwhite section-padding">
	<div class="container">
		<h3 class="text-center space-0">Channel Manager</h3>

		<blockquote class="native-block">
			<p>With QloApps Channel Manager you will be able to synchronize all your hotel listings from a single platform. Syncronize your rates, inventories, and bookings to avoid under bookings, overbookings and price mismanagement.</p>

			<a href="<?php echo esc_url( site_url() . '/channel-manager/' ); ?>" class="btn btn-bgcolor white normal-btn-style">Read More</a>
		</blockquote>

		<div class="section-channel-manager-grid">
			
			<div class="qa-card integration">
				<h4>Multi Channel<br>Integration</h4>
				<p>Our channel manager is integrated with multiple online travel agencies to minimize manual data entry.</p>
			</div>

			<div class="qa-card inventory">
				<h4>Manage Prices & Inventory</h4>
				<p>Update Prices and Room Inventory across various online travel agencies (OTAs) through single platform in real time.</p>
			</div>

			<div class="qa-card channel">
				<h4>Add Multiple<br>Channels</h4>
				<p>Maximize your Hotel's global reach by adding more online travel agencies.</p>
			</div>

			<div class="qa-card hotel">
				<h4>Manage Multiple<br>Hotels</h4>
				<p>Our Channel Manager provides you an Intuitive User-friendly Interface to easily manage Multiple Hotels.</p>
			</div>

		</div>
	</div>
</section>



<?php
/**
 * Cloud Hosting Section
 */
display_cloud_hosting_section();



/**
 * Homepage Add-on Section
 * 
 */
$temp_args = array(
	'post_type' => 'add-ons',
	'post_status' => 'publish',
	'posts_per_page' => -1,
	'meta_key' => 'qa_featured_addon',
	'meta_value' => 'true',
);
$temp_addons = get_posts( $temp_args );
?>
<?php
if( count( $temp_addons ) > 0 ) {
	?>
	<section class="section-addon-homepage text-center section-padding">
		<div class="container">
			<h3>Add-Ons</h3>
			<p class="mid-para">Explore all the QloApps add-ons and find the best that suits your needs. Here you will find all the addons from the QloApps team. Every addon will add one or more unique features to your website.</p>
			<div class="qa-addon-grid">
				<?php
				foreach( $temp_addons as $addon ) {
					$temp_id = $addon->ID;

					$addon_opt = get_post_meta( $temp_id, "qlo_addons_extra_options", true );
					$addon_img = ! empty( $addon_opt['logo'] ) ? wp_get_attachment_image_src( (int) $addon_opt['logo'] )[0] : false;
					$addon_link = isset( $addon_opt['qlo-buy-btn-link'] ) ? esc_url( $addon_opt['qlo-buy-btn-link'] ) : false;
					?>
					<div class="qa-addon">
						<div class="border-circle">
							<a href="<?php echo esc_url( $addon_link ); ?>" target="_blank" rel-="noopener noreferrer">
							<?php
							if( $addon_img ) {
								?>
								<img src="<?php echo $addon_img; ?>" alt="<?php echo $addon->post_title; ?>"></a>
								<?php
							}
							?>
						</div>
						
						<a href="<?php echo esc_url( $addon_link ); ?>" target="_blank" rel-="noopener noreferrer"><h4><?php echo $addon->post_title; ?></h4></a>
						<p><?php echo has_excerpt( $temp_id ) ? esc_html( get_the_excerpt( $temp_id ) ) : esc_html( _wk_trim_post_content( $temp_id, 240, false ) ); ?></p>
					</div>
					<?php
				}
				?>
			</div>
			<a href="<?php echo site_url() . '/addons/'?>" class="btn btn-bgcolor white normal-btn-style">VIEW ALL ADD-ONS</a>
		</div>
	</section>
	<hr class="custom">
	<?php
}


/**
 * Homepage Become partner
 * 
 */
wk_become_partner_section();



/**
 * Homepage Contribution to Open Web Section
 * 
 */
?>
<section class="section-homepage-contribute section-padding text-center">
	<div class="container">
		<h3>Contribution to Open Web</h3>
		<p class="mid-para">Community contributions are the heart of any open source project's success. QloApps is the only true open source project serving the hotel industry. We invite you to make contributions so we can together serve the cause.</p>
		<div>
			<a href="https://github.com/webkul/hotelcommerce" class="btn btn-bgcolor white normal-btn-style" target="_blank" rel="noopener noreferrer">JOIN COMMUNITY</a>

			<a href="https://qloapps.com/how-to-contribute-to-qloapps-project/" class="btn btn-bgcolor white normal-btn-style">HOW TO CONTRIBUTE</a>

			<a href="https://forums.qloapps.com/" target="_blank" rel="noopener noreferrer" class="btn btn-bgcolor white normal-btn-style">JOIN FORUM</a>
		</div>
	</div>
</section>


<?php
/**
 * Homepage We Got Featured ! Section
 * 
 */
$hp_featured = get_option( 'wktheme-page-featured-on' );
$hp_featured = ( '' === $hp_featured ) ? array() : $hp_featured;
if( ! empty( $hp_featured['featured-on']['items'] ) ) {
	?>
	<section class="section-featured-on section-padding text-center" id="featured-on">
		<div class="container">
			<h3>We Got Featured !</h3>
			<p class="mid-para">QloApps got mentioned and listed on various platforms. You can find us here.</p>
			<div class="row">
				<div class="col-md-12">
					<div class="featured-on-wrap">
						<?php
						foreach ( $hp_featured['featured-on']['items'] as $value ) {
							$feat_sec_img = ! empty( $value['image'] ) ? wp_get_attachment_image_src( $value['image'], 'medium' )[0] : false;

							$fi_alt = ! empty( $fi_alt = get_post_meta( $value['image'], '_wp_attachment_image_alt', true ) ) ? $fi_alt : get_the_title( $value['image'] );


							if( ! empty ( $value['link'] ) ) {
								echo '<a href="' . $value['link'] . '" title="' . $fi_alt . '" target="_blank" rel="noopener noreferrer">
									<img src="' . $feat_sec_img . '" alt="' . $fi_alt . '">
									</a>';
							} else {
								echo '<img src="' . $feat_sec_img . '" alt="' . $fi_alt . '" title="' . $fi_alt . '">';
							}
						}
						?>
						
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
}

// echo '<hr class="space-0">';

/**
 * Homepage Testimonial Section
 * 
 */
wk_get_testimonial_section();

// echo '<hr class="space-0">';


/**
 * Homepage Recent Blogs Section
 * 
 */
$query_args = array(
	'post_type'      => 'post',
	'post_status'    => 'publish',
	'orderby'        => 'most_recent',
	'posts_per_page' => 3,
);

$blog_query = new WP_Query( $query_args );
?>
<section class="section-homepage-blog section-padding text-center">
	<div class="container">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10">
				<h3 class="space-0">Recent Blogs</h3>
				<p class="mid-para">We publish content regularly. Here are our most recent blogs. If you want to check out some awesome blogs on the hotel industry and guides to our add-ons then visit our blog section by clicking on the button below.</p>
				<div class="hp-blog-wrap">
					<?php
					if ( $blog_query->have_posts() ) {
						while ( $blog_query->have_posts() ) {
							$blog_query->the_post();
							?>
							<a href="<?php echo get_the_permalink(); ?>" class="blog-brick" title="<?php echo get_the_title(); ?>">
								<h3><?php echo get_the_title(); ?></h3>
							</a>
							<?php
						}

					}
					?>
				</div>
				<a href="<?php echo site_url() . '/blog/'; ?>" class="btn btn-bgcolor white normal-btn-style">READ MORE BLOGS</a>
			</div>
			<div class="col-md-1"></div>
		</div>
	</div>
</section>


<?php

/**
 * Homepage Video Section
 * 
 */
display_teaser_video_section();



/**
 * Hompage Add Story Section
 * 
 */
display_feature_suggestion_form();


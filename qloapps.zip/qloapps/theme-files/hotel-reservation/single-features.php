<?php

/**
 * The template for displaying Features Detail
 *
 * This is the template that displays Features Detail by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation	
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */
get_header(); ?>


<?php while ( have_posts() ) : the_post(); ?>

<section class="pattern-section wk-inner-wrapper"></section>	
	<section class="feature-outer-wrapper">
 
		<div class="feature-desc-header text-center">
				<?php 	$url = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID())); 

				if ( !empty($url)) : ?>

				<div class="border-circle-black"><img src="<?php echo $url;?>" class="img-responsive" alt="<?php echo get_the_title();?>"></div>
				
			<?php endif;?>	

				<h3 class="text-capitalize"><?php echo get_the_title();?></h3>
		</div>	

		<div class="feature-desc-content">
			
					<article <?php post_class();?>>

						<p><?php echo the_content (); ?></p>

						<!--/Post Article Content-->

					</article>

		</div>

				<!--/Feature Wrapper-->



</section>

		<!--/Page Container-->

		<?php endwhile; ?>


		<!--Semantic Footer-->

<?php  get_footer(); ?>




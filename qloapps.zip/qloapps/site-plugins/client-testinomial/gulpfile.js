// Just Change theme folder Name in 'pluginFolder';

const pluginFolder  = '';
const pluginPath    = './';
const gulp         = require( 'gulp' );
const less         = require( 'gulp-less' );
const cleanCSS     = require( 'gulp-clean-css' );
const rename       = require( 'gulp-rename' );
const terser       = require( 'gulp-terser' );


/* Task to compile less */
const compileLess = () => {
	return gulp.src( pluginPath + 'assets/less/*.less' )
		.pipe( less() )
		.pipe( gulp.dest( pluginPath + 'assets/build/css/' ) );
};

/*Minify CSS*/
throwPath = {}
throwPath.path = pluginPath + 'assets/dist/css/';
const minifyCss = () => {
	return gulp.src( pluginPath + 'assets/build/css/*.css' )
		.pipe( cleanCSS( { compatibility: 'ie8' } ) )
		.pipe( rename(function( path ) {
			path.basename += '.min';
		}))
		.pipe( gulp.dest( throwPath.path ) );
};

/* Minify JS*/
const minifyJs = () => {
	return gulp.src( pluginPath + 'assets/build/js/*.js' )
		.pipe( terser() )
		.pipe( rename({
			suffix: '.min'
		}))
		.pipe( gulp.dest( pluginPath + 'assets/dist/js/' ) );
};


/*Watch JS*/
const watchJs = () => {
	gulp.watch( pluginPath + 'assets/build/js/*.js', minifyJs );
};

/*Watch LESS*/
const watchLess = () => {
	gulp.watch( pluginPath + 'assets/less/**/*.less' , compileLess );
};

/*Watch CSS*/
const watchCss = () => {
	gulp.watch( pluginPath + 'assets/build/css/*.css' , minifyCss );
};

/* Tasks when running `gulp` from terminal */
const build = gulp.parallel( watchLess, watchCss, watchJs );

exports.compileLess = compileLess;
exports.minifyCss   = minifyCss;
exports.minifyJs    = minifyJs;
exports.watchLess   = watchLess;
exports.watchCss    = watchCss;
exports.watchJs     = watchJs;

gulp.task( 'default', build );

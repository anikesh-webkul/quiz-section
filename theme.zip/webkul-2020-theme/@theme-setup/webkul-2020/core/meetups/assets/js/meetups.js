document.addEventListener('DOMContentLoaded', () => {
	function copyTextToClipboard(text) {
		var textArea = document.createElement('textarea');
		textArea.value = text;
		document.body.appendChild(textArea);
		textArea.select();
		document.execCommand('copy');
		document.body.removeChild(textArea);
	}

	var siteLink = document.querySelector('.organizer-wrap .copy-link');
	if (undefined != siteLink) {
		var textCopied;
		var copyBtn = siteLink.querySelector('span');
		copyBtn.addEventListener('click', () => {
			copyTextToClipboard(siteLink.querySelector('input').value);
			siteLink.classList.add('copied');
			copyBtn.innerText = 'Copied';
			clearTimeout(textCopied);
			textCopied = setTimeout(() => {
				siteLink.classList.remove('copied');
				copyBtn.innerText = 'Copy';
			}, 10000);
		});
	}

	var orgsWrap = document.querySelector('.section-meetup-speakers .organizer-wrap');
	if (undefined != orgsWrap) {
		if (window.innerHeight > orgsWrap.clientHeight + 170) {
			orgsWrap.classList.add('stick');
		}
	}
	
	//forms
	var meetupFormWrap = document.querySelector('.meetup-apply-form-section');
	var successMsg = meetupFormWrap.querySelector('.form-response');
	var formBody = meetupFormWrap.querySelector('.form-group');
	var meetupTitle = meetupFormWrap.getAttribute('data-meetup');
	var speakerForm = meetupFormWrap.querySelector('#wk-speaker-form');
	var attendeeForm = meetupFormWrap.querySelector('#wk-attendee-form');
	var meetupUrl = '', currentCF7FormId = '', currentFormUrlHash = '';
	let _attendeeSelector = '[href="#become-attendee"]';
	let _speakerSelector = '[href="#become-speaker"]';

	var closeForm = () => {
		__each(meetupFormWrap).removeClass('activate-form');
		__each(formBody).removeClass('display-none');
		__each(successMsg).addClass('display-none');
		__each(currentForm).addClass('display-none');
		window.location.hash = '';
	};
	var openForm = () => {
		window.location.hash = currentFormUrlHash;
		meetupUrl = window.location.href;
		('undefined' !== typeof currentForm) && __each(currentForm).removeClass('display-none');
		__each(meetupFormWrap).addClass('activate-form');
		__each(formBody).removeClass('display-none');
		__each(successMsg).addClass('display-none');
	};

	var checkIfFormActionDirectly = () => {
		if (window.location.hash == '#become-attendee') {
			currentForm = attendeeForm;
			currentFormUrlHash = '#become-attendee';
			openForm();
		} else if (window.location.hash == '#become-speaker') {
			currentForm = speakerForm;
			currentFormUrlHash = '#become-speaker';
			openForm();
		}
	};

	if (elementExist(meetupFormWrap)) {

		checkIfFormActionDirectly();
	}

	document.addEventListener('click', (e) => {
		This = e.target;
		if (This.matches(_speakerSelector) || This.matches(_attendeeSelector) ) {
			e.preventDefault();
			currentFormUrlHash = This.getAttribute('href');
			currentForm = ('#become-attendee' == This.getAttribute('href')) ? attendeeForm : speakerForm;
			openForm();
		}
		if (This.matches('.wkm-close-form')) {
			closeForm();
		}
		if (This.matches('.wpcf7-submit')) {
			currentCF7FormId = This.form.querySelector('[name="_wpcf7"]').value;
			This.form.querySelector('#subject').value = meetupTitle;
			This.form.querySelector('#page-url').value = meetupUrl;
		}
	});

	document.addEventListener('keydown', (e) => {
		if (27 === e.keyCode) {
			closeForm();
		}
	});

	document.addEventListener('wpcf7mailsent', function (event) {
		if (event.detail.contactFormId == currentCF7FormId) {
			if ('mail_sent' == event.detail.status) {
				__each(formBody).addClass('display-none');
				__each(successMsg).removeClass('display-none');
			}
		}
	});

	__each('input[type="file"]', formBody).forAll(el => {
		el.closest('label').classList.add('file-input-wrap');
		el.addEventListener( 'change', function() {
			if( undefined != this.files ) {
				var fileName = this.files[0].name;
				if( undefined == document.querySelector( '.uploaded-filename' ) ) {
					el.closest('label').insertAdjacentHTML( 'afterend', '<span class="uploaded-filename">'+ fileName +'</span>');
				} else {
					document.querySelector( '.uploaded-filename' ).innerText = fileName;
				}
			}
		} );
	});

});


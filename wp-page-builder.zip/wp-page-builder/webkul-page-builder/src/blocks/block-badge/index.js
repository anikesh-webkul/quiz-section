registerBlockType( 'wk-blocks/badge', {
    title : 'Badge',
    icon : 'excerpt-view',
    category: 'webkul',
    keywords: ['Badge'],
    parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    example:{},
    attributes: {
        content: {
            type:'string',
            selector: 'h4',
        },
        newWindow: {
            type:'boolean',
        },
        imgLink: {
            type:'string',
            source: 'attribute',
			attribute: 'href',
            selector: 'a',
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgSrc: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
        }
    },
    edit : function( props ) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className: 'wk-badges-section wk-section-grid',
                },
                el(
                    'div',
                    {
                        className: 'wk-badge',
					},
					el(
						'span',
						{
							className: 'badge-icon mg',
						},
					),
					el(
						'span',
						{
							className: 'badge-label',
						},
						'Magento Commerce Certified Developer'
					)
				),
				el(
                    'div',
                    {
                        className: 'wk-badge',
					},
					el(
						'span',
						{
							className: 'badge-icon ps',
						},
					),
					el(
						'span',
						{
							className: 'badge-label',
						},
						'PrestaShop Superhero Seller'
					)
				),
				el(
                    'div',
                    {
                        className: 'wk-badge',
					},
					el(
						'span',
						{
							className: 'badge-icon sh',
						},
					),
					el(
						'span',
						{
							className: 'badge-label',
						},
						'Shopify Freelance Experts'
					)
                ),
            )
        )
    },
    save:function(props) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className: 'wk-badges-section wk-section-grid',
                },
                el(
                    'div',
                    {
                        className: 'wk-badge',
					},
					el(
						'span',
						{
							className: 'badge-icon mg',
						},
					),
					el(
						'span',
						{
							className: 'badge-label',
						},
						'Magento Commerce Certified Developer'
					)
				),
				el(
                    'div',
                    {
                        className: 'wk-badge',
					},
					el(
						'span',
						{
							className: 'badge-icon ps',
						},
					),
					el(
						'span',
						{
							className: 'badge-label',
						},
						'PrestaShop Superhero Seller'
					)
				),
				el(
                    'div',
                    {
                        className: 'wk-badge',
					},
					el(
						'span',
						{
							className: 'badge-icon sh',
						},
					),
					el(
						'span',
						{
							className: 'badge-label',
						},
						'Shopify Freelance Experts'
					)
                ),
            )
        )
    }
} );
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once( dirname( __FILE__ ) . '/includes/templates/class-wk-component-templates.php' );

if ( ! class_exists( 'Wk_Components_Setting_Handler' ) ) {

	class Wk_Components_Setting_Handler extends Wk_Component_Templates {

		public function __construct() {

			$components = json_decode( get_option( 'wk_registered_components' ) );
			foreach ( $components as $component ) {
				add_action( 'wktheme_' . $component->slug . '_setting_tab', array( $this, 'component_setting_callback' ), 10, 2 );
			}
		}

		public function component_setting_callback( $compo_slug, $sortable = '' ) {

			$prefix        = 'wktheme-';
			$db_option_key = $prefix . $compo_slug;

			$this->_wk_create_new_component_area( $db_option_key );


			$all_widgets = get_option( $db_option_key );
			$all_widgets = ( '' === $all_widgets ) ? array() : $all_widgets;

			$wk_component_tmpl = parent::get_template( $compo_slug );

			/**
			 * The image upload code is working from clients-reviews for homepage
			 * Both are similar, #CodeReuasability.
			 */
			?>
			<div id="wktheme-carousel-wrapper">
				<input type="hidden" id="wktheme-metakey" value="<?php echo esc_attr( $prefix . $compo_slug ); ?>">
				<?php
				$index = -1;
				$new_component = isset( $_POST['wktheme-widgets']['widget-import'] ) ? 'new-pallete-bricks' : false;
				foreach ( $all_widgets as $widget ) {
					$index ++;

					/**
					 *Finding key name, if the common "widget-title, etc" key is not isset ( for OLD components )
					 */
					$widget_title = ( isset( $widget['widget-title'] ) ) ? $widget['widget-title'] : ( array_filter( array_keys( $widget ), function( $key ) {
						return preg_match( '/-title$/', $key ); //have "-title" in key string
					} ) );

					$widget_slug = ( isset( $widget['widget-slug'] ) ) ? $widget['widget-slug'] : ( array_filter( array_keys( $widget ), function( $key ) {
						return preg_match( '/-slug$/', $key );  //have "-slug" in key string
					} ) );

					$widget_title = ( is_array( $widget_title ) ) ? $widget[ reset( $widget_title ) ] : $widget_title;
					$widget_slug  = ( is_array( $widget_slug ) ) ? $widget[ reset( $widget_slug ) ] : $widget_slug;
					/*END*/
					?>
					<wk-pallete id="<?php echo esc_attr( $widget_slug ); ?>" class="pallete-bricks <?php echo ( 0 === $index ) ? $new_component : false; ?>">
						<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
						<wk-pallete-props class="info">
							<span><b>Title : </b><?php echo esc_html( $widget_title ); ?></span>
							<span><b>Slug : </b>
								<div class="shortcode-area">
									<code><?php echo esc_html( $widget_slug ); ?></code>
									<span class="tooltip">Click to copy Slug</span>
								</div>
							</span>
							<span><b>Use this Shortcode : </b>
								<div class="shortcode-area">
									<code><?php echo '[wk-' . esc_html( $compo_slug ) . ' for=' . esc_html( $widget_slug ) . ']'; ?></code>
									<span class="tooltip">Click to copy Shortcode</span>
								</div>
							</span>
						</wk-pallete-props>

						<?php
						$meta_data = ( isset( $widget['meta'] ) ) ? $widget['meta'] : array();
						$this->_widget_setting_template_background( $meta_data, $index );
						$is_sort = ( 'true' === $sortable ) ? 'wk-is-sortable' : false;
						?>

						<wk-add-block>Add New<span class="dashicons dashicons-plus-alt"></span></wk-add-block>


						<wk-pallete-data class="<?php echo esc_attr( $is_sort ); ?>">
							<?php

							$rendered_tmpl       = '';
							$rendered_final_html = '';
							if ( isset( $widget['items'] ) && count( array_filter( $widget['items'] ) ) > 0 ) {

								foreach ( $widget['items'] as $item ) {

									$rendered_tmpl = preg_replace_callback( '/{{(.*?)}}/', function( $matches ) use ( &$item, &$upload_path ) {

										$placeholder    = trim( $matches[1] );
										$isset_esc_type = strpos( $placeholder, '#esc_type=' ); //false-notfound
										$prop_value     = '';
										$esc_str        = '';

										if ( $isset_esc_type ) {

											$esc_str     = explode( '#', $placeholder );
											$placeholder = trim( $esc_str[0] );
											$esc_str     = trim( $esc_str[1] );
										}

										if ( isset( $item[ $placeholder ] ) ) {

											if ( $isset_esc_type ) {

												$esc_type = explode( '=', trim( $esc_str ) )[1];

												if ( 'url' === $esc_type ) {

													return esc_url( $item[ $placeholder ] );

												} elseif ( 'attr' === $esc_type ) {

													return esc_attr( $item[ $placeholder ] );

												} elseif ( 'html' === $esc_type ) {

													return esc_html( $item[ $placeholder ] );

												} elseif ( 'src' === $esc_type ) {
													$upload_path = wp_upload_dir()['baseurl'];
													$upload_dir  = wp_upload_dir()['basedir'];
													$src         = explode( $upload_path, $item[ $placeholder ] );
													return ( $upload_path !== $src[0] ) ? ( file_exists( $upload_dir . $src[0] ) ?  $upload_path . $src[0] : $src[0] ) : $item[ $placeholder ];
												}
											}

											return $item[ $placeholder ];
										}

									}, $wk_component_tmpl );

									//Wrap the rendered block
									$rendered_final_html .= '<wk-block>' . $rendered_tmpl . '</wk-block>';
								}

								echo $rendered_final_html;

							}
							?>
						</wk-pallete-data>
					</wk-pallete>

					<?php
				}

				$wk_component_tmpl = preg_replace_callback( '/[{{](.*)[}}]/', function( $matches ) {
					return '';
				}, $wk_component_tmpl );  //remove placeholders
				?>
				<template id="wk-component-tmpl"><wk-block><?php echo $wk_component_tmpl; ?></wk-block></template>
			</div>
			<?php
		}


		/**
		 * Reusable templates
		 */
		public function _wk_create_new_component_area( $db_option_key ) {
			$error = false;

			if ( isset( $_POST['submit_new_widget'] ) ) {

				$fields     = $_POST['wktheme-widgets'];
				$curr_links = get_option( $db_option_key );
				$curr_links = ( '' !== $curr_links ) ? $curr_links : array();
				$curr_vals  = array_keys( $curr_links );

				if ( in_array( $fields['widget-slug'], $curr_vals, true ) ) {
					$error = true;
				} else {
					$new_link[ $fields['widget-slug'] ]  = array(
						'widget-title' => $fields['widget-title'],
						'widget-slug'  => $fields['widget-slug'],
						'options'      => array(),
					);
					if( ! empty( $fields['widget-import'] ) && in_array( $fields['widget-import'], $curr_vals, true ) ) {
						$new_link[ $fields['widget-slug'] ]['meta']  = $curr_links[ $fields['widget-import'] ]['meta'];
						$new_link[ $fields['widget-slug'] ]['items'] = $curr_links[ $fields['widget-import'] ]['items'];
					}

					$curr_links = ( '' === $curr_links ) ? array() : $curr_links;
					$curr_links = array_merge( $new_link, $curr_links );

					update_option( $db_option_key, $curr_links );
				}
			}

			get_shortcode_panel_form( array(
				'button_label'     => 'Add new component',
				'title'            => 'Theme Component',
				'array_field_name' => 'wktheme-widgets',
				'title_field_name' => 'widget-title',
				'slug_field_name'  => 'widget-slug',
				'submit_label'     => 'submit_new_widget',
			), $error );

			$all_widgets = get_option( $db_option_key );
			$all_widgets = ( '' === $all_widgets ) ? array() : $all_widgets;

			if ( ! empty( $all_widgets ) ) {
				?>
				<div class="save-widget-btn">
					<button id="wk-save-widgets" class="button button-primary">Save Widgets</button>
					<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />
				</div>
				<?php
			}
		}


		public function _widget_setting_template_background( $meta_data, $index = 0 ) {
			$title = ( isset( $meta_data['title'] ) ) ? $meta_data['title'] : '';
			$bg    = ( isset( $meta_data['bg'] ) ) ? $meta_data['bg'] : 'default';
			$grid  = ( isset( $meta_data['grid'] ) ) ? $meta_data['grid'] : 'squeezy';
			// console_log($grid);
			?>
			<wk-pallete-meta class="info options">
				<wk-options-bag>
					<span><b>Title ( Optional ) : </b><input wk-option="meta-title" type="text" class="meta-title" value="<?php echo esc_attr( $title ); ?>"/></span>
					<span class="custom-radios">
						<b>Background : </b>
						<div>
							<input type="radio" class="primary" id="primary-<?php echo esc_attr( $index ); ?>" data-name="meta-bg" name="meta-bg-<?php echo esc_attr( $index ); ?>" value="primary" <?php checked( 'primary', trim( $bg ) ); ?> >
							<label for="primary-<?php echo esc_attr( $index ); ?>">
								<span class="icon">
									<i class="dashicons dashicons-yes"></i>
								</span>
							</label>
						</div>
						<div>
							<input type="radio" class="secondary" id="secondary-<?php echo esc_attr( $index ); ?>" data-name="meta-bg" name="meta-bg-<?php echo esc_attr( $index ); ?>" value="secondary" <?php checked( 'secondary', trim( $bg ) ); ?> >
							<label for="secondary-<?php echo esc_attr( $index ); ?>">
								<span class="icon">
									<i class="dashicons dashicons-yes"></i>
								</span>
							</label>
						</div>
						<div>
							<input type="radio" class="dark" id="dark-<?php echo esc_attr( $index ); ?>" data-name="meta-bg" name="meta-bg-<?php echo esc_attr( $index ); ?>" value="dark" <?php checked( 'dark', trim( $bg ) ); ?> >
							<label for="dark-<?php echo esc_attr( $index ); ?>">
								<span class="icon">
									<i class="dashicons dashicons-yes"></i>
								</span>
							</label>
						</div>
						<div>
							<input type="radio" class="gray" id="gray-<?php echo esc_attr( $index ); ?>" data-name="meta-bg" name="meta-bg-<?php echo esc_attr( $index ); ?>" value="gray" <?php checked( 'gray', trim( $bg ) ); ?> >
							<label for="gray-<?php echo esc_attr( $index ); ?>">
								<span class="icon">
									<i class="dashicons dashicons-yes"></i>
								</span>
							</label>
						</div>
						<div>
							<input type="radio" class="default" id="default-<?php echo esc_attr( $index ); ?>" data-name="meta-bg" name="meta-bg-<?php echo esc_attr( $index ); ?>" value="default" <?php checked( 'default', trim( $bg ) ); ?> />
							<label for="default-<?php echo esc_attr( $index ); ?>">
								<span class="icon">
									<i class="dashicons dashicons-yes"></i>
								</span>
							</label>
						</div>
					</span>

					<span>
						<b>Grid : </b>
						<label for="wide-<?php echo esc_attr( $index ); ?>">Wide
							<input type="radio" id="wide-<?php echo esc_attr( $index ); ?>" data-name="meta-grid" name="meta-grid-<?php echo esc_attr( $index ); ?>" value="wide" <?php checked( 'wide', trim( $grid ) ); ?> >
						</label>&nbsp;&nbsp;&nbsp;
						<label for="compact-<?php echo esc_attr( $index ); ?>">Compact
							<input type="radio" id="compact-<?php echo esc_attr( $index ); ?>" data-name="meta-grid" name="meta-grid-<?php echo esc_attr( $index ); ?>" value="compact" <?php checked( 'compact', trim( $grid ) ); ?> >
						</label>&nbsp;&nbsp;&nbsp;
						<label for="squeezy-<?php echo esc_attr( $index ); ?>">Squeezy
							<input type="radio" id="squeezy-<?php echo esc_attr( $index ); ?>" data-name="meta-grid" name="meta-grid-<?php echo esc_attr( $index ); ?>" value="squeezy" <?php checked( 'squeezy', trim( $grid ) ); ?> >
						</label>
					</span>
				</wk-options-bags>

			</wk-pallete-meta>
			<?php
		}
		/*//Reusable templates*/
	}
	new Wk_Components_Setting_Handler();
}

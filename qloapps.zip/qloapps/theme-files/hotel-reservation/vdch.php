<?php 

header("Location: http://demo.qloapps.com");
die;

?>
<?php
 /*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();
global $wpdb;
$t_array        = array();
$table_name     = $wpdb->prefix . 'technology';
if ( $wpdb->get_var( "show tables like '$table_name'" ) == $table_name ) {
	$team_data      = $wpdb->get_results( "SELECT * FROM $table_name" );
	$tech_type_list = array();
	if ( ! empty( $team_data ) ) {
		foreach ( $team_data as $key => $value ) {
			if ( ! isset( $tech_type_list[ $value->tech_type ] ) ) {
				$tech_type_list[ $value->tech_type ] = array();
			}
			$tech_array = array(
				'name' => $value->tech_name,
				'type' => $value->tech_type,
				'team' => $value->tech_team,
			);
			array_push( $tech_type_list[ $value->tech_type ], $tech_array );
		}
	}

	?>

	<div class="wk-page-content section-padding-0T">
		<div class="wk-tech-jumbotron  color-darker null-margin">
			<div class="jumbotron-content">
				<h1>Technologies</h1>
				<p class="larger">We have expertise in an extensive range of astound technologies to build world class apps and extensions for enterprises and ventures.</p>
			</div>
		</div>
	</div>

	<section class="wk-technology-body section-padding container-margin-up">
		<div class="wkgrid-wide">
			<div class="wk-technology-row">
				<?php
				$i     = 0;
				$num   = count( $tech_type_list );
				$count = ceil( $num / 3 );

				if ( 3 * $count == $num ) {
					$c = [ $count, $count, $count ];
				} elseif ( 3 * $count - 1 == $num ) {
					$c = [ $count, $count, $count - 1 ];
				} else {
					$c = [ $count, $count - 1, $count - 1] ;
				}
				$ac = 0;

				foreach ( $tech_type_list as $key => $value ) {
					if ( $i == 0 ) {
						echo '<div class="wk-technology-col">';
					}
					?>
					<p><?php echo esc_attr($key); ?></p>
					<div class="wk-technology-row wk-tech-row-inner">
						<?php
						array_multisort( array_column( $value, 'name' ), SORT_ASC, $value );
						foreach ( $value as $k => $val ) {
							?>
							<div class="wk-technology-col wk-tech-col-inner">
								<?php echo esc_attr( $val['name'] ); ?>
							</div>
							<?php
						}
						if ( $ac != 3 && $i == $c[ $ac ] - 1 ) {
							echo '</div>';
							$i = 0;
							$ac++;
						} else {
							$i++;
						}
						?>
					</div>
					<?php
				}
				?>
			</div>
		</div>
	</section>

	<?php
}

get_footer();

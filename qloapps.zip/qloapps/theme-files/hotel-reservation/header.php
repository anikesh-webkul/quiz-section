<?php

/**
 *
 * The template for displaying Header
 *
 * This is the template that displays Header by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

?>

<!DOCTYPE html>

<html lang="en" class="<?php echo ( is_page( 'marketplace' ) || is_page( 'cloud-hosting' ) ) ? ' full-height' : ''; ?>">

	<head>
		<link href="<?php echo get_bloginfo( 'template_url' ); ?>/images/favicon.ico" rel="shortcut icon">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<meta name="keywords" content="qloapps, Qloapps, hotel softwares, free reservation system, online hotel reservation system, qloapps reservation system, qloapps booking system, hotel management software, free hotel management software, software open source, hotel management software open source, open source hotel management system, hotelier software, hotel software demo, hotel booking software open source, open source hotel booking system"/>
		<meta name="description" content="Qlo is an open source, free and customizable online reservation system. You can launch a userfriendly site and can manage online as well as offline bookings."/>
		<title><?php wp_title( '|', true, 'right' ); ?></title>
		<link rel="profile" href="https://gmpg.org/xfn/11" />
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
		<?php wp_head(); ?>
	</head>
	<body class="full-height" data-spy="scroll" data-target=".navbar" data-offset="50">
		<div class="hide-large-screen menu_count_right sidebar-navigation">
			<span class="close close-icon"></span>
			<ul class="mobi-nav-wrapper">
				<?php
				$menu_name = 'hotelreservation_main_menu';
				$all_locations = get_nav_menu_locations();
				$menu_items    = isset( $all_locations[$menu_name] ) ? wp_get_nav_menu_object( $all_locations[$menu_name] ) : array();
				$menu_items    = isset( $menu_items->term_id ) ? wp_get_nav_menu_items( $menu_items->term_id ) : array();
				$sub_menus = $parent_menus = $parent_ids = array();
			
				foreach ( $menu_items as $key => $item ) {
			
					$menu_title = $item->post_title;
					if ( '' === $item->post_title ) {
						$obj_id     = get_post_meta( $item->ID, '_menu_item_object_id', true );
						$menu_title = get_the_title( $obj_id );
					}
					$menu_url = ( '' === $item->url ) ? 'javascript:void(0)' : $item->url;
					
					
					if( 0 != $item->menu_item_parent ) {

						if( ! isset( $sub_menus[ $item->menu_item_parent ] ) ) {
							$sub_menus[ $item->menu_item_parent ] = array();
						}

						$temp = array(
							'id'         => $item->ID,
							'menu_slug'  => $item->post_name,
							'menu_name'  => $menu_title,
							'parent'     => $item->menu_item_parent,
							'menu_link'  => $menu_url,
							'icon_class' => $item->classes[0],
							'rel'        => $item->xfn,
							'target'     => $item->target,
						);
						array_push( $sub_menus[ $item->menu_item_parent ], $temp );
						array_push( $parent_ids, $item->menu_item_parent );
					} else {
						$parent_menus[] = array(
							'id'         => $item->ID,
							'menu_slug'  => $item->post_name,
							'menu_name'  => $menu_title,
							'menu_link'  => $menu_url,
							'icon_class' => $item->classes[0],
							'rel'        => $item->xfn,
							'target'     => $item->target,
						);
					}
				}
				$parent_ids = array_unique( $parent_ids );
				foreach( $parent_menus as $value ) {
					if( ! in_array( $value['id'], $parent_ids ) ) {
						?>
						<li>
							<a href="<?php echo $value['menu_link']; ?>" <?php echo ( ! empty( $value['target'] ) ) ? 'target="' . $value['target'] . '"' : false; ?> <?php echo ( ! empty( $value['rel'] ) ) ? 'rel="' . $value['rel'] . '"' : false; ?>><?php echo $value['menu_name']; ?></a>
						</li>
						<?php
					} else {
						?>
						<li>
							<div class="qlo-toggle-wrapper">
								<a class="qlo-toggle-menu" href="<?php echo $value['menu_link']; ?>" <?php echo ( ! empty( $value['target'] ) ) ? 'target="' . $value['target'] . '"' : false; ?> <?php echo ( ! empty( $value['rel'] ) ) ? 'rel="' . $value['rel'] . '"' : false; ?>><?php echo $value['menu_name']; ?></a>
								<span class="menu-trigger"></span>
							</div>
							<ul class="sub-menu">
								<?php
								foreach( $sub_menus[$value['id']] as $sub_item ) {
									?>
									<li>
									<a href="<?php echo $sub_item['menu_link']; ?>" <?php echo ( ! empty( $sub_item['target'] ) ) ? 'target="' . $sub_item['target'] . '"' : false; ?> <?php echo ( ! empty( $sub_item['rel'] ) ) ? 'rel="' . $sub_item['rel'] . '"' : false; ?>><?php echo $sub_item['menu_name']; ?></a>
									</li>
									<?php
								}
								?>
							</ul>
						</li>
						<?php
					}
					
				}
				?>
			</ul>
		</div>

		<div class="navigation">
			<nav class="navbar navbar-default main-navigation <?php echo is_home() ? 'qloapps-home-navbar' : ''; ?>">
				<div class="container">
					<a href="#" class="open-menu"></a>
					<div class="navbar-header">
						<a class="navbar-brand" href="<?php echo site_url()?>"><img src="<?php echo get_template_directory_uri().'/images/logo.png'?>" title="QLO" alt="QLO"></a>
					</div>
					<a class="white btn btn-download-ext-top btn-bgcolor pull-right" href="<?php echo get_template_directory_uri().'/vdch.php'?>" target="_blank" rel="noopener" title="View demo">View Demo</a>
					<a class="white btn btn-download-ext-top btn-bgcolor pull-right" href="<?php echo site_url().'/download'; ?>" title="Download">Download</a>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<?php
					$defaults = array(
						'theme_location' => 'hotelreservation_main_menu',
						'menu_class'     => 'nav navbar-nav navbar-right',
					);
					?>
					<?php wp_nav_menu( $defaults ); ?>
					</div>
				</div>
			</nav>
		</div>
		<?php
		

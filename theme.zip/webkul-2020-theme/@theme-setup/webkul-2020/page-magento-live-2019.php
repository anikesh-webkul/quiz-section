<?php
get_header();
?>

<section class="section-mleu-hero section-padding">
    <div class="wkgrid-wide">
        <div class="mleu-wrap">
            <div class="mleu">
                <h2>Meet us at</h2>
                <img src="<?php echo get_template_directory_uri() . '/images/mleu/mleu2019-logo-white.svg' ?>" alt="Magento Live Europe 2019" title="Magento Live Europe 2019" class="img-responsive" />
                <p>22-23 October, 2019 Amsterdam</p>
            </div>
        </div>
    </div>
</section>

<section class="wk-page-content section-padding wk-mleu-page">
    <!-- <div class="section-mleu-keynote wk-inline-blocks null">
        <div class="wkgrid-squeezy">
            <div class="wk-content-wrap dir-rtl">
                <div class="part-one dir-ltr">
                    <h2>Keynote Speaker at</h2>
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/mleu2019-logo-orange.png' ?>" alt="Magento Live" title="Magento Live" />
                    <h3>Nitish Kumar</h3>
                    <p>Sr. Product Manager -<br>Design, Webkul</p>
                    <a href="https://twitter.com/nitishkmrk" class="before-tw-icon" target="_blank" rel="noopener noreferrer">@nitishkmrk</a>
                </div>
                <div class="part-two">
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/nitish.png' ?>" alt="Nitish Kumar" title="Nitish Kumar" /> 
                </div>
            </div>
        </div>
    </div>

    <div class="section-mleu-speaker wk-component text-center" _bgcolor="dark">
        <div class="wkgrid-squeezy">
            <h3>Meet our teammate at Magento Live. We are available throughout the event.</h3>
            <div class="mleu-speaker-wrap">
                <div class="speaker">
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/rahul-circle.png' ?>" alt="Rahul Mahto" title="Rahul Mahto" /> 
                    <a href="https://twitter.com/i_rahul_mahto" class="tw-light" target="_blank" rel="noopener noreferrer"></a>
                    <h4>Rahul Mahto</h4>
                    <p>Technical Project Manager<br>Webkul</p>
                </div>
                <div class="speaker">
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/nitish-circle.png' ?>" alt="Nitish Kumar" title="Nitish Kumar" /> 
                    <a href="https://twitter.com/nitishkmrk" class="tw-light" target="_blank" rel="noopener noreferrer"></a>
                    <h4>Nitish Kumar</h4>
                    <p>Sr. Product Manager - Design<br>Webkul</p>
                </div>
            </div>
        </div>
    </div>

    <br><br>
    <div class="wkgrid-squeezy text-center">
        <br>
        <h2>We Talk Commerce</h2>
        <p>If you want to dig into commerce, we’ve got you covered. We are building eCommerce apps and plugins from last 9 years. Few of our most popular products includes-</p>
    </div>

    <div class="section-mleu-expertise">
        <div class="wkgrid-compact">
            <div class="mleu-expertise-wrap">
                <a href="https://webkul.com/expertise/ecommerce-marketplaces/" class="brick">
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/store.png' ?>" title="">
                    <h4>Multi Vendor Marketplace</h4>
                    
                </a>
                <a href="https://webkul.com/expertise/mobile-apps/" class="brick">
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/mobile.png' ?>" title="">
                    <h4>Mobile App Builder for iOS and Android</h4>
                </a>
                
                <a href="https://webkul.com/expertise/point-of-sale/" class="brick">
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/pos.png' ?>" title="">
                    <h4>Point of Sale</h4>
                </a>
                
                <a href="https://webkul.com/expertise/ecommerce-marketplaces/" class="brick">
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/b2b.png' ?>" title="">
                    <h4>B2B &amp; B2C Commerce</h4>
                </a>
                
                <a href="https://webkul.com/industries/booking/" class="brick">
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/booking.png' ?>" title="">
                    <h4>Booking &amp; Appointment</h4>
                </a>
                
                <a href="https://webkul.com/expertise/pwa-and-amp/" class="brick">
                    <img src="<?php echo get_template_directory_uri() . '/images/mleu/pwa.png' ?>" title="">
                    <h4>Progressive Web App<br>(PWA)</h4>
                </a>
            </div>
        </div>
    </div> -->
    <div class="wkgrid-squeezy">
        <?php
        while( have_posts() ) {
            the_post();
            the_content();
        }
        ?>
    </div>
    <div class="btn-b2t-wrap text-center">
        <br><br>
        <a href="#" title="Back to top">
            <img src="<?php echo get_template_directory_uri() . '/images/mleu/b2t.png'; ?>">
            <h4>back to top</h4>
        </a>
    </div>
</section>


<?php
get_footer();
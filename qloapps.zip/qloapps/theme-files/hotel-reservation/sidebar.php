<?php
/**
 * The Sidebar containing the main widget area
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */
?>


<!--Banner Wrapper-->

<div class="wk-sidebar-wrapper">

	<?php

	if(is_single()){

			if ( is_active_sidebar( 'hotel_singlesidebar' ) ) : ?>

				<div id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">

					<?php dynamic_sidebar('hotel_singlesidebar'); ?>

				</div><!-- #primary-sidebar -->

		<?php

		endif;

			}
	else{

			if ( is_active_sidebar( 'hotel_main_sidebar' ) ) : ?>

				<div id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">

					<?php dynamic_sidebar( 'hotel_main_sidebar' ); ?>

				</div><!-- #primary-sidebar -->

			<?php endif;

	}
?>


</div>

registerBlockType('wk-blocks/fancy-list', {
	title: 'Fancy List',
	icon: 'excerpt-view',
	category: 'webkul',
	keywords: ['list'],
	parent: [['wk-blocks/layout-container'], ['wk-blocks/block-wrapper']],
	example: {},
	attributes: {
		borderRadius: {
			type: 'number',
		},
		newWindow: {
			type: 'boolean',
		},
		imgLink: {
			type: 'string',
			source: 'attribute',
			attribute: 'href',
			selector: 'a',
		},
		imgID: {
			type: 'number',
		},
		imgALT: {
			type: 'string',
			source: 'attribute',
			attribute: 'alt',
			selector: 'img',
		},
		imgSrc: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
		},
		wkInserter:{
            type:'boolean',
            default:false
        }
	},
	edit: function (props) {
		var newWindow = props.attributes.newWindow,
			imgLink = props.attributes.imgLink,
			imgID = props.attributes.imgID,
			imgALT = props.attributes.imgALT,
			imgSrc = props.attributes.imgSrc;
			borderRadius = props.attributes.borderRadius;
			wkInserter = props.attributes.wkInserter;

		const onRemoveImage = () => {
			props.setAttributes({
				imgSrc: null,
				imgID: null,
				imgALT: null,
			});
		};
		return (
			el(
				Fragment,
				{},
				el(
					InspectorControls,
					{},
					el(
						Panel,
						{},
						el(
							PanelBody,
							{
								title: 'Link',
							},
							el(
								PanelRow,
								{},
								el(
									TextControl,
									{
										type: "string",
										label: 'ADD URL',
										value: imgLink,
										onChange: (newLink) => {
											props.setAttributes({ imgLink: newLink });
										}
									}
								),
							),
							el(
								PanelRow,
								{},
								el(
									FormToggle,
									{
										checked: newWindow,
										onChange: (event) => {
											props.setAttributes({
												newWindow: event.target.checked,
											})
										},
									}
								),
								el(
									'span',
									{},
									'Open in New Tab'
								)
							),
						),
						el(
							PanelBody,
							{
								title: 'Styling',
								initialOpen: true,
							},
							el(
								RangeControl,
								{
									label: 'Border Radius',
									value: props.attributes.borderRadius,
									onChange: (data) => {
										props.setAttributes({ borderRadius: data })
									},
									min: 0,
									max: 20,
									help: 'Border value in pixel(px)',
									allowReset: true,
									initialPosition: 8,
								}
							),
						)
					)
				),
				el(
					'div',
					{
						className: 'wk-image-uploader',
					},
					el(
						MediaUpload,
						{
							buttonProps: {
								className: 'change-image'
							},
							onSelect: img => props.setAttributes({
								imgID: img.id,
								imgSrc: img.url,
								imgALT: img.alt ? img.alt : img.title
							}),
							allowed: ALLOWED_MEDIA_TYPES,
							type: "image",
							value: imgID,
							render: ({ open }) => el(
								Fragment,
								null,
								el(
									Button,
									{
										className: imgSrc ? 'wk-change-image' : 'wk-add-image',
										onClick: open
									},
									!imgSrc ? wkUploadIcon : el("img",
										{
											src: imgSrc,
											alt: imgALT,
										}
									)
								),
								imgSrc && el(
									Button,
									{
										className: "wk-remove-image",
										onClick: onRemoveImage
									},
									el(
										Dashicon,
										{
											icon: 'dismiss'
										}
									)
								)
							)
						}
					),
				),
				el(
					InnerBlocks,
					{
						template:[
							['core/list'],
						],
						templateLock:true,
					},
				)
			)
		);
	},
	save: function (props) {

		let widgetStyle = {};
		widgetStyle['borderRadius'] = 8;
		(props.attributes.borderRadius) && (widgetStyle['borderRadius'] = props.attributes.borderRadius);

		let wrapperEl = (props.attributes.imgLink) ? 'a' : 'div';
		let wrapperElProps = (props.attributes.imgLink) ? {
			href: props.attributes.imgLink,
			className: 'block-fancy-list',
			title: props.attributes.linkText,
			target: (props.attributes.newContent) ? '_blank' : false,
			rel: (props.attributes.newContent) ? 'noopener noreferrer' : false,
			style: widgetStyle,
		} : {
				className: 'block-fancy-list no-link',
				title: props.attributes.linkText,
				style: widgetStyle,
			};
        
		return el(
			Fragment,
			{},
			el(
				wrapperEl,
				wrapperElProps,
				el(
					'img',
					{
						src: props.attributes.imgSrc,
						alt: props.attributes.imgALT,
						className: 'fancy-list-img',
						style: widgetStyle,
					},
				),
				el(
					InnerBlocks.Content
				)
            ),
        )
    }
});

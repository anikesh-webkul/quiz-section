<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class createFormDataModel extends Model
{
    use HasFactory;
    protected $table= "quesdata";
    public $timestamps= false;

}

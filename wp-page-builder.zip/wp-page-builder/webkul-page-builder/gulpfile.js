var pluginFolder = 'assets';
var pluginPath   = '' + pluginFolder + '/';
var gulp         = require('gulp');
var less         = require('gulp-less');
var cleanCSS     = require('gulp-clean-css');
var rename       = require('gulp-rename');
var terser       = require('gulp-terser');
var concat       = require('gulp-concat');


/* Task to compile less */
const compileLess = () => {
  return gulp.src( pluginPath + 'less/*.less' )
    .pipe( less() )
    .pipe(gulp.dest( pluginPath + 'build/css/' ) );
};


/*Minify CSS*/
const minifyCss = () => {
  return gulp.src( pluginPath + 'build/css/*.css' )
    .pipe(cleanCSS( { compatibility: 'ie8' } ) )
    .pipe(rename({
        suffix: '.min'
    }))
    .pipe(gulp.dest( pluginPath + 'dist/css/' ) );
};

const mergeBlockJs = (abc) => {
  return gulp.src( ['src/**/blocks.js','src/**/deprecated.js','src/**/index.js'])
        .pipe(concat('wk-builder.js'))
        .pipe(gulp.dest(pluginPath + 'build/js/'));
}
/* Minify JS*/
minifyJs = () => {
  return gulp.src( pluginPath + 'build/js/*.js' )
    .pipe( terser() )
    .pipe( rename({
      suffix: '.min'
    }))
    .pipe(gulp.dest(pluginPath + 'dist/js/'));
};



/*Watch LESS*/
const watchLess = () => {
  return gulp.watch(pluginPath + 'less/**/*.less' , compileLess );
};

/*Watch CSS*/
const watchCss = () => {
  return gulp.watch(pluginPath + 'build/css/*.css' , minifyCss );
};

/*Watch JS*/
const watchJs =  () => {
    return gulp.watch( pluginPath + 'build/js/*.js', minifyJs );
};

const watchBlockJs =  () => {
  return gulp.watch( ['src/**/index.js','src/**/deprecated.js','src/**/blocks.js'], mergeBlockJs );
};

const build = gulp.parallel( watchLess, watchCss, watchBlockJs, watchJs );

/* Task when running `gulp` from terminal */
// gulp.task('default', ['watch-less', 'watch-css', 'watch-js']);
exports.compileLess = compileLess;
exports.minifyCss = minifyCss;
exports.minifyJs = minifyJs;
exports.watchLess = watchLess;
exports.watchCss = watchCss;
exports.watchBlockJs = watchBlockJs;
exports.watchJs = watchJs;
gulp.task('default', build );

<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();

display_feature_suggestion_form();
?>


<section class="wk-header-wrapper wk-common-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="qlo-feature-msg qlo-content-padd text-center">
					<div id="uv_top_message" class=""><div class="uv_flash success"></div></div>
					<h1>Suggest your coveted feature</h1>
					<p class="head-p">Our aim is to help our users to attain what they desire. So we like to hear it from you. Please suggest a feature which you feel should be there in QloApps.</p>
					<a href="JavaScript:void(0)" class="sugg-btn white btn-bgcolor btn-download-ext">Suggest any feature</a>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="outer-wrapper">
	<div class="wk-features-list border-shadow wk-common-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-10 text-center">
					<h1>QloApps Characteristics</h1>
					<p class="head-p">We have developed QloApps keeping all the requirements in our mind for an online hotel booking system. QloApps has some outstanding and spectacular features which will definitely differentiate your site from others.</p>
				</div>
				<div class="col-md-1"></div>
			</div>

			<?php

				$query_args = array('post_type'=>'features','post_status'=>'publish','order'=>'ASC', 'posts_per_page' => -1 );

				$the_query = new WP_Query( $query_args );

				$i=0;

				if ( $the_query->have_posts() ) :

        		while($the_query->have_posts() ) :$the_query-> the_post();


        		if($i==0)
                  {?>
                    <div class="row">
              <?php
                  }
        		?>
				<div class="col-md-4">
					<div class="feature-detail">
						<div class="feature-image">
							<?php
								$url = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()));

							if ( !empty($url)) : ?>

							<img src="<?php echo $url;?>" class="img-responsive">

							<?php endif;?>
						</div>
						<h5><?php echo get_the_title();?></h5>
						<p class="text-justify"> <?php the_excerpt();?></p>
						<a href="<?php echo get_permalink();?>" class="btn btn-bgcolor white wk-read-more">Read More</a>
					</div>
				</div>
				<?php
			      if($i==2)
                  {?>
                    </div>
                <?php
                	$i=-1;
                  }
                  $i++;
				    endwhile;
			          else:
			            echo '<div class="no-data text-center"><span class="label label-success">We are Writting And will be here soon..</span></div>';
			         endif;
			         ?>
		</div>
	</div>
</section>
<?php get_footer();?>

/**
 * Register Custom Image Gallery Block
 */

registerBlockType( 'wk-blocks/icon-gallery', {
    title : 'Icon Gallery',
    icon : 'images-alt',
    category: 'webkul',
    keywords: ['Icon Gallery'],
    // parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    parent: [ ],
    example:{},

    attributes: {

        imgLink: {
            type:'string',
            source: 'attribute',
			attribute: 'href',
            selector: 'a',
        },
        newWindow: {
            type:'boolean',
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgSrc: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
        }
    },
    edit : function( props ) {
        var imgSrc = props.attributes.imgSrc,
        imgALT = props.attributes.imgALT,
        imgID = props.attributes.imgID,
        imgLink = props.attributes.imgLink,
        newWindow = props.attributes.newWindow;

        const onRemoveImage = () => {
			props.setAttributes( {
				imgSrc: null,
                imgID: null,
                imgALT:null,
			} )
        };
        return el(
            Fragment,
            {},

            /** Sidebar Setting */
            el(
                InspectorControls,
                null,
                el(
                    Panel,
                    {},
                    el(
                        PanelBody,
                        { title: 'Icon Link Setting', initialOpen: true },

                        el(
                            PanelRow,
                            {},
                            el(
                                TextControl,
                                {
                                    type:"string",
                                    label:'ADD URL',
                                    value:imgLink,
                                    onChange: ( value ) => {
                                        props.setAttributes( { imgLink: value } )
                                    }
                                }
                            )
                           
                        ),

                        el(
                            PanelRow,
                            {},
                            el(
                                FormToggle,
                                {
                                    checked:newWindow,
                                    onChange: ( event ) => {
                                        props.setAttributes( {
                                            newWindow: event.target.checked,
                                        } )
                                    },
                                }
                            ),
                            el(
                                'span',
                                {},
                                'Open in new Tab'
                            )
                           
                        )

                    )

                )
            ),

            /** // Sidebar Setting ( InspectorControls ) End */
            

            /** Backend Block Structure */
            el(
                'div',
                
                {
                    className:'block-icon-gallery-element text-center',
                },
                el(
                    'div',
                    {
                        className:'wk-image-uploader'
                    },
                    el(
                        MediaUpload,
                        {
                            buttonProps: {
                                className: 'change-image'
                            },
                            onSelect: img => props.setAttributes({
                                imgID: img.id,
                                imgSrc: img.url,
                                imgALT:img.alt ? img.alt : img.title 
                            }),
                            allowed: ALLOWED_MEDIA_TYPES,
                            type: "image",
                            value: imgID,
                            render: ({ open }) => el(
                                Fragment,
                                null,
                                el(
                                    Button,
                                    {
                                        className: imgSrc ? 'wk-change-image' : 'wk-add-image',
                                        onClick: open
                                    },
                                    ! imgSrc ? wkUploadIcon : el( "img",
                                        {
                                            src: imgSrc,
                                            alt: imgALT
                                        }
                                    )
                                ),
                                imgSrc && el(
                                    Button,
                                    {
                                        className: "wk-remove-image",
                                        onClick: onRemoveImage
                                    },
                                    el(
                                        Dashicon,
                                        {
                                            icon: 'dismiss'
                                        }
                                    )
                                )
                            )
                        }
                    )

                ),
                el(
                    Dashicon,
                    {
                        icon: 'admin-links'
                    }
                )
            )

            /** //Backend Block Structure End */
        );
    },
    save:function(props) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className:'block-icon-gallery-widget',
                },
                ( props.attributes.imgLink ) ?
				el(
					'a',
					{
						href:props.attributes.imgLink,
						target:(props.attributes.newWindow) ? '_blank' : false,
						rel: (props.attributes.newWindow) ? 'noopener noreferrer' : false,
						className:'block-icon-gallery-link',
					},
					el(
						'img',
						{
							src:props.attributes.imgSrc,
							alt: props.attributes.imgALT,
							className:'block-icon-gallery-image',
						}
					),
				) :
				el(
					'img',
					{
						src:props.attributes.imgSrc,
						alt:props.attributes.imgALT,
						className:'block-icon-gallery-image',
					}
				),
            )
        )
    }


} );
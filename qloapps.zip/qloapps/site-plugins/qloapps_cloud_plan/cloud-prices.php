 <?php
if( ! defined ( 'ABSPATH' ) ) {
  exit;
}
$err_status = array();
if( isset( $_POST['submit_prices'] ) ) {
  $qlo_cloud_prices = array();
  $qlo_gc['platinum']['main']                 = $_POST['cloud_platinum_main'];
  $qlo_gc['platinum']['offer']                = $_POST['cloud_platinum_offer'];
  $qlo_gc['platinum']['link']                 = $_POST['cloud_platinum_link'];
  $qlo_gc['gold']['main']                     = $_POST['cloud_gold_main'];
  $qlo_gc['gold']['offer']                    = $_POST['cloud_gold_offer'];
  $qlo_gc['gold']['link']                     = $_POST['cloud_gold_link'];
  $qlo_aws['platinum']['main']                = $_POST['hosting_platinum_main'];
  $qlo_aws['platinum']['offer']               = $_POST['hosting_platinum_offer'];
  $qlo_aws['platinum']['link']                = $_POST['hosting_platinum_link'];
  $qlo_aws['gold']['main']                    = $_POST['hosting_gold_main'];
  $qlo_aws['gold']['offer']                   = $_POST['hosting_gold_offer'];
  $qlo_aws['gold']['link']                    = $_POST['hosting_gold_link'];
  
  $qlo_micro['platinum']['main']                = $_POST['microsoft_platinum_main'];
  $qlo_micro['platinum']['offer']               = $_POST['microsoft_platinum_offer'];
  $qlo_micro['platinum']['link']                = $_POST['microsoft_platinum_link'];
  $qlo_micro['gold']['main']                    = $_POST['microsoft_gold_main'];
  $qlo_micro['gold']['offer']                   = $_POST['microsoft_gold_offer'];
  $qlo_micro['gold']['link']                    = $_POST['microsoft_gold_link'];

  $qlo_cloud_prices['google-cloud']['desc']   = trim( $_POST['cloud_desc'] );
  $qlo_cloud_prices['aws-hosting']['desc']    = trim( $_POST['hosting_desc'] );

  $qlo_cloud_prices['microsoft-azure']['desc']    = trim( $_POST['microsoft_desc'] );

  $qlo_cloud_prices['google-cloud']['prices'] = $qlo_gc;
  $qlo_cloud_prices['aws-hosting']['prices']  = $qlo_aws;

  $qlo_cloud_prices['microsoft-azure']['prices']  = $qlo_micro;


  $qlo_cloud_prices = maybe_serialize( $qlo_cloud_prices );
  if ( update_option( 'qlo_cloud_prices', $qlo_cloud_prices ) ) {
    $err_status['success'] = true;
  }
}
  $qlo_cloud_prices = maybe_unserialize( get_option( 'qlo_cloud_prices' ) );
  $qlo_cloud_prices = ( is_array( $qlo_cloud_prices) ) ? $qlo_cloud_prices : '';

  $qlo_gc  = ( isset( $qlo_cloud_prices['google-cloud']['prices'] ) ) ? $qlo_cloud_prices['google-cloud']['prices'] : false;

  $qlo_aws = ( isset( $qlo_cloud_prices['aws-hosting']['prices'] ) ) ? $qlo_cloud_prices['aws-hosting']['prices'] : false;

  $qlo_micro = ( isset( $qlo_cloud_prices['microsoft-azure']['prices'] ) ) ? $qlo_cloud_prices['microsoft-azure']['prices'] : false;
?>
<div class="wrap">
  <h1>Qlo Plan Prices</h1>
  <hr>
  <br>
  <?php
  if( isset($err_status['success']) && $err_status['success'] ) {
    ?>
    <div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible">
      <p>
        <strong>Prices has been successfully added.</strong>
      </p>
      <button type="button" class="notice-dismiss"></button>
    </div>
    <?php
  }
  ?>
  <style>
  .price-block {
    display: inline-block;
    width: 32%;
    max-width: 100%;
    vertical-align: top;
    margin-left: 3px;
  }
  .price-block:first-of-type{
    margin-left: 0;
  }
  .price-block input[type=number]{
    width: 77px;
  }
  </style>
  <div>
    <div>
      <form method="POST">
        <div class="price-block">
          <h2>Google Cloud Prices</h2>
          <span><strong>Platinum</strong></span>
          <p>
            <div class="price-block">
              <label>Main Price</label><br>
              <input type="number" name="cloud_platinum_main" placeholder="Main Price" value="<?php echo ( isset( $qlo_gc['platinum']['main'] ) ) ? $qlo_gc['platinum']['main'] : false; ?>">
            </div>
            <div class="price-block">
              <label>Offer Price</label><br>
              <input type="number" name="cloud_platinum_offer" placeholder="Offer Price" value="<?php echo ( isset( $qlo_gc['platinum']['offer'] ) ) ? $qlo_gc['platinum']['offer'] : false; ?>">
            </div>
            <br />
            <br />
            <label>Platinum Store Link</label><br>
            <input type="text" name="cloud_platinum_link" placeholder="Platinum Store link" value="<?php echo ( isset( $qlo_gc['platinum']['link'] ) ) ? esc_url( $qlo_gc['platinum']['link'] ) : false; ?>">
          </p>
          <span><strong>Gold</strong></span>
          <p>
            <div class="price-block">
              <label>Main Price</label><br>
              <input type="number" name="cloud_gold_main" placeholder="Main Price" value="<?php echo ( isset( $qlo_gc['gold']['main'] ) ) ? $qlo_gc['gold']['main'] : false; ?>">
            </div>
            <div class="price-block">
              <label>Offer Price</label><br>
              <input type="number" name="cloud_gold_offer" placeholder="Offer Price" value="<?php echo ( isset( $qlo_gc['gold']['offer'] ) ) ? $qlo_gc['gold']['offer'] : false; ?>">
            </div>
            &ensp;
            <br />
            <br />
            <label>Gold Store link</label><br>
            <input type="text" name="cloud_gold_link" placeholder="Gold Store link" value="<?php echo ( isset( $qlo_gc['gold']['link'] ) ) ? esc_url( $qlo_gc['gold']['link'] ) : false; ?>">
          </p>
          <label>Description</label>
          <textarea rows="4" style="width:90%;" name="cloud_desc"><?php echo ( isset( $qlo_cloud_prices['google-cloud']['desc'] ) ) ? esc_html( $qlo_cloud_prices['google-cloud']['desc'] ) : false; ?></textarea>
        </div>


        <div class="price-block">
          <h2>AWS Hosting Prices</h2>
          <span><strong>Platinum</strong></span>
          <p>
            <div class="price-block">
              <label>Main Price</label><br>
              <input type="number" name="hosting_platinum_main" placeholder="Main Price" value="<?php echo ( isset( $qlo_aws['platinum']['main'] ) ) ? $qlo_aws['platinum']['main'] : false; ?>">
            </div>
            <div class="price-block">
              <label>Offer Price</label><br>
              <input type="number" name="hosting_platinum_offer" placeholder="Offer Price" value="<?php echo ( isset( $qlo_aws['platinum']['offer'] ) ) ? $qlo_aws['platinum']['offer'] : false; ?>">
            </div>
            &ensp;
            <br />
            <br />
            <label>Platinum Store link</label><br>
            <input type="text" name="hosting_platinum_link" placeholder="Platinum Store link" value="<?php echo ( isset( $qlo_aws['platinum']['link'] ) ) ? esc_url( $qlo_aws['platinum']['link'] ) : false; ?>">
          </p>
          <span><strong>Gold</strong></span>
          <p>
            <div class="price-block">
              <label>Main Price</label><br>
              <input type="number" name="hosting_gold_main" placeholder="Main Price" value="<?php echo ( isset( $qlo_aws['gold']['main'] ) ) ? $qlo_aws['gold']['main'] : false; ?>">
            </div>
            <div class="price-block">
              <label>Offer Price</label><br>
              <input type="number" name="hosting_gold_offer" placeholder="Offer Price" value="<?php echo ( isset( $qlo_aws['gold']['offer'] ) ) ? $qlo_aws['gold']['offer'] : false; ?>">
            </div>
            &ensp;
            <br />
            <br />
            <label>Gold Store link</label><br>
            <input type="text" name="hosting_gold_link" placeholder="Gold Store Link" value="<?php echo ( isset( $qlo_aws['gold']['link'] ) ) ? esc_url( $qlo_aws['gold']['link'] ) : false; ?>">
          </p>
          <label>Description</label>
          <textarea rows="4" style="width:90%;" name="hosting_desc"><?php echo ( isset( $qlo_cloud_prices['aws-hosting']['desc'] ) ) ? trim( $qlo_cloud_prices['aws-hosting']['desc'] ) : false; ?></textarea>
        </div>

        <div class="price-block">
          <h2>Microsoft Azure</h2>
          <span><strong>Platinum</strong></span>
          <p>
            <div class="price-block">
              <label>Main Price</label><br>
              <input type="number" name="microsoft_platinum_main" placeholder="Main Price" value="<?php echo ( isset( $qlo_micro['platinum']['main'] ) ) ? $qlo_micro['platinum']['main'] : false; ?>">
            </div>
            <div class="price-block">
              <label>Offer Price</label><br>
              <input type="number" name="microsoft_platinum_offer" placeholder="Offer Price" value="<?php echo ( isset( $qlo_micro['platinum']['offer'] ) ) ? $qlo_micro['platinum']['offer'] : false; ?>">
            </div>
            &ensp;
            <br />
            <br />
            <label>Platinum Store link</label><br>
            <input type="text" name="microsoft_platinum_link" placeholder="Platinum Store link" value="<?php echo ( isset( $qlo_micro['platinum']['link'] ) ) ? esc_url( $qlo_micro['platinum']['link'] ) : false; ?>">
          </p>
          <span><strong>Gold</strong></span>
          <p>
            <div class="price-block">
              <label>Main Price</label><br>
              <input type="number" name="microsoft_gold_main" placeholder="Main Price" value="<?php echo ( isset( $qlo_micro['gold']['main'] ) ) ? $qlo_micro['gold']['main'] : false; ?>">
            </div>
            <div class="price-block">
              <label>Offer Price</label><br>
              <input type="number" name="microsoft_gold_offer" placeholder="Offer Price" value="<?php echo ( isset( $qlo_micro['gold']['offer'] ) ) ? $qlo_micro['gold']['offer'] : false; ?>">
            </div>
            &ensp;
            <br />
            <br />
            <label>Gold Store link</label><br>
            <input type="text" name="microsoft_gold_link" placeholder="Gold Store Link" value="<?php echo ( isset( $qlo_micro['gold']['link'] ) ) ? esc_url( $qlo_micro['gold']['link'] ) : false; ?>">
          </p>
          <label>Description</label>
          <textarea rows="4" style="width:90%;" name="microsoft_desc"><?php echo ( isset( $qlo_cloud_prices['microsoft-azure']['desc'] ) ) ? trim( $qlo_cloud_prices['microsoft-azure']['desc'] ) : false; ?></textarea>
        </div>


        <br/>
        <br/>
        <input type="submit" name="submit_prices" value="Save" class="button button-primary">
    </form>
    </div>
  </div>
</div>

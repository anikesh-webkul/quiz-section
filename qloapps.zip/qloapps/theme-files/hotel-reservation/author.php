<?php

get_header();

blog_navbar();

$author_id     = get_query_var( 'author' );
$twitter       = get_the_author_meta( 'twitter', $author_id );
$facebook      = get_the_author_meta( 'facebook', $author_id );
$designation   = get_the_author_meta( 'designation', $author_id );
$desc          = get_the_author_meta( 'description', $author_id );
$total_posts   = get_the_author_posts();
$prof_img      = get_the_author_meta( 'profile-image', $author_id );
$prof_img      = ( ! empty( $prof_img ) ) ? $prof_img : get_avatar_url( ( get_the_author_meta( 'user_email' ) ) );

?>
<div class="container">
	<div class="wk-author-paper">
		<div class="row">
			<img src="<?php echo esc_url( $prof_img ); ?>" width="96px" height="96px" />
			<h3><?php echo get_the_author(); ?></h3>
			<h4 class="desig"><?php echo esc_html( $designation ); ?></h4>
			<?php
			if ( $desc ) {
				echo '<h4 class="desc">' . wp_kses( $desc, array( 'a' => array( 'href' => array( '#!' ) ) ) ) . '</h4>';
			}
			?>
			<h4><?php echo esc_html( $total_posts ); echo ( $total_posts > 1 ) ? ' Publishings' : ' Publishing'; ?></h4>
			<div class="wk-author-social">
				<?php
				if ( ! empty( $twitter ) ) {
				?>
					<a href="<?php echo esc_url( $twitter ); ?>" class="wk-author-social-icon wk-author-twitter" title="Twitter" 	target="_blank" rel="nofollow"></a>
				<?php
				}
				if ( ! empty( $facebook ) ) {
					?>
					<a href="<?php echo esc_url( $facebook ); ?>" class="wk-author-social-icon wk-author-facebook" title="Facebook" target="_blank" rel="nofollow"></a>
					<?php
				}
				?>
			</div>
		</div>
	</div>
</div>
<!--//Paper-->

<?php
$author_query = new WP_Query( array(
	'post_type'      => 'post',
	'posts_per_page' => get_option( 'posts_per_page' ),
	'paged'          => get_pagenumber_args(),
	'author'         => $author_id,
	'post_status'    => 'publish',
) );
?>
<div class="container">
	<div class="row">
		<div class="col-md-12 text-center">
			<div class="qblog-archives text-left">
			<?php

			if ( $author_query->have_posts() ) {

				while ( $author_query->have_posts() ) {

					$author_query->the_post();

					get_template_part( 'content', 'blog' );
				}
			}
			?>
			</div>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<div class="wk-pagination-wrapper">
				<?php hotelreservation_pagination( $author_query->found_posts ); ?>
			</div>
		</div>
		<div class="col-md-3"></div>
	</div>
</div>

<?php
get_footer();

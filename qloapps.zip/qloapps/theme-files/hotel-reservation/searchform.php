<!--Form-->

<form class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>"  id="advanced-searchform" role="search" method="get">

	<div class="form-group has-feedback">
   	<input class="form-control wk-search-input" type="text" placeholder="Search Blog" value="<?php echo  get_search_query(); ?>" name="s" required autofocus onfocus='this.value=this.value'/>
		<span class="wk-search-btn"></span>
	</div>

</form>

<!--/Form-->

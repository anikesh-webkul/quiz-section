registerBlockType( 'wk-blocks/badgenew', {
    title : 'Badge New1',
    icon : 'admin-page',
    category: 'webkul',
    keywords: [
        'Anikesh Badge',
    ],
 
    example: {},

    attributes: {
        
        title: {
            type:'array',
            source: 'children',
            selector: '.badge-label',
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgURL: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
        },
        imgLink: {
            type:'string',
            source: 'attribute',
			attribute: 'href',
            selector: 'a',
        },
        newWindow: {
			type: 'boolean',
		},

    },
    edit : function( props ) {
        var content = props.attributes.content,
        title = props.attributes.title,
        imgURL = props.attributes.imgURL,
        imgALT = props.attributes.imgALT,
        imgLink= props.attributes.imgLink,
        newWindow = props.attributes.newWindow,
        imgID = props.attributes.imgID;

        const onChangeTitle = ( newTitle ) => {
            props.setAttributes( { title: newTitle } );
        }
        
        const onRemoveImage = () => {
			props.setAttributes( {
				imgURL: null,
                imgID: null,
                imgALT:null,
			} );
        };

        return (
            el('fragment', {},
            el(
                InspectorControls,
                {},
                el(
                    Panel,
                    {},
                    el(
                        PanelBody,
                        {
                            title:'Badge Link Setting',
                        },
                        el(
                            PanelRow,
                            {},
                            el(
                                TextControl,
                                {
                                    type:"string",
                                    label:'ADD URL',
                                    value:imgLink,
                                    onChange:(newLink) => {
                                        props.setAttributes({imgLink:newLink});
                                    }
                                }
                            ),
                        ),
                        el(
                            PanelRow,
                            {},
                            el(
                                FormToggle,
                                {
                                    checked: newWindow,
                                    onChange: (event) => {
                                        props.setAttributes({
                                            newWindow: event.target.checked,
                                        })
                                    },
                                }
                            ),
                            el(
                                'span',
                                {},
                                'Open in New Tab'
                            )
                        ),
                       
                    )
                )
            ),

            el(
                'div',
                
                {
                    className:'wk-badges-section wk-section-grid',
                },
                
                el(
                    'div',
                    {
                        className:'wk-badge'
                    },
                    el(
                        'div',        
                        {
                        className:'badge-icon mg wk-image-uploader'
                            
                        },
                    el(
                        MediaUpload,
                        {
                            buttonProps: {
                                className: 'change-image'
                            },
                            onSelect: img => props.setAttributes({
                                imgID: img.id,
                                imgURL: img.url,
                                imgALT:img.alt ? img.alt : img.title 
                            }),
                            allowed: ALLOWED_MEDIA_TYPES,
                            type: "image",
                            value: imgID,
                            render: ({ open }) => el(
                                Fragment,
                                null,
                                el(
                                    Button,
                                    {
                                        className: imgURL ? 'wk-change-image' : 'wk-add-image',
                                        onClick: open
                                    },
                                    ! imgURL ? wkUploadIcon : el( "img",
                                        {
                                            src: imgURL,
                                            alt: imgALT
                                        }
                                    )
                                ),
                                imgURL && el(
                                    Button,
                                    {
                                        className: "wk-remove-image",
                                        onClick: onRemoveImage
                                    },
                                    el(
                                        Dashicon,
                                        {
                                            icon: 'dismiss'
                                        }
                                    )
                                )
                            )
                        }
                    )
                    ),

               
                
                el(
                    RichText,
                    {
                        key: 'editable',
                        tagName: 'p',
                        value: title,
                        className:'badge-label',
                        id:'textbdge',
                        onChange: onChangeTitle,
                        placeholder:'Your text goes here..',
                    },
                    
                ),
                )
                
            )
            // el(
            //     Fragment,
            //     null,
                
            // )
            )
        );
    },
	save: function (props) {

        
        let wrapperEl = (props.attributes.imgLink) ? 'a' : 'div';
		let wrapperElProps = (props.attributes.imgLink) ? {
			href: props.attributes.imgLink,
			className: 'wk-badge',
			title: props.attributes.title,
			target: (props.attributes.newContent) ? '_blank' : false,
            rel: (props.attributes.newContent) ? 'noopener noreferrer' : false,
           
          
		} : {
				className: 'wk-badge no-link',
				title: props.attributes.title,
				
			};
        
        return el(
            Fragment,
            {},
            
            el(
                        wrapperEl,
                        wrapperElProps,   
                                    el(
                                        'img',
                                        {
                                            src:props.attributes.imgURL,
                                            alt:props.attributes.imgALT,
                                            className:'badge-icon mg, wk-image-uploader',
                                            
                                        }
                                    ),
                                    el(
                                        'p',
                                        {
                                            className:'badge-label',
                                            id:'textbdge',
                                        },
                                        props.attributes.title
                            ),
                )
                 
        )
    }
});
<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();
$request_list = array();
function get_faq_urls( $url ) {
	$ch = curl_init();

	//OPTIONS
	curl_setopt( $ch, CURLOPT_URL, $url );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

	//EXECUTE
	$results = curl_exec( $ch );
	curl_close( $ch );

	return $results;
}
$str          = get_faq_urls( get_template_directory_uri() . '/assets/json/uv_wk_articles.json' );
$request_list = json_decode( $str, true );
?>
<section class="wk-contact-section section-padding">
	<div class="wkgrid-squeezy">
		<h1>Howdy!<br />How <span class="col-main">We</span> can help?</h1>
		<p>Happy to see you here. We are really glad to know, that you had interest in our products or services. Whether you have a query, question or have something interesting to share, reach us and one of us will get back to you shortly.</p>
		<p>Get in touch and let us know how we can help -</p>
		<hr />
		<div class="link-panel text-center">
			<a class="link-tabs sale" href="https://webkul.uvdesk.com/en/customer/create-ticket/" target="_blank" rel="noopener" title="Sales Enquiries">
				<span class="icon">Sales Enquiries</span>
			</a>
			<a class="link-tabs support" href="http://webkul.uvdesk.com" target="_blank" rel="noopener" title="Support Center">
				<span class="icon">Support Center</span>
			</a>
			<a class="link-tabs story" href="https://webkul.com/blog" target="_blank" rel="noopener" title="Recent Stories">
				<span class="icon">Recent Stories</span>
			</a>
		</div>

		<div class="contact-details">
			<div class="contact-srs-wrapper">
				<div id="webkul-contact" class="reach-us">
					<div class="form-skull">

						<h3 class="text-center">Reach Us</h3>
						<p>If you wish to directly reach us, Please fill out the form below -</p>
						<?php
						echo do_shortcode( '[contact-form-7 id="17772" title="contact page"]' );
						?>
					</div>
				</div>
				<div class="wk-srs">
					<h3>Software Requirements Specification</h3>
					<p>Create an SRS for the needed features for any of the Webkul Plugin. </p>
					<a href="https://webkul.com/srs-builder/" target="_blank" rel="nofollow noopener" class="wk-button btn-ghost srs-builder">SRS Builder</a>
					<p>Read <a href="https://webkul.com/srs-builder/assets/Software-Requirements-Specification.pdf" target="_blank">SRS DOC</a> to get started</p>
					<div class="wk-srs-bg"></div>
				</div>
			</div>
		</div>
		<hr style="margin: 10px 0;" />
		<div class="contact-details info-full">
			<div class="cards">
				<p class="larger">Email and Phone</p>
				<div class="wk-email-phone">
					<div class="elements">
						<p>Careers</p>
						<a href="mailto:jobs@webkul.com?subject=Career-Query">jobs@webkul.com</a>
					</div>
					<div class="elements">
						<p>Query and Questions</p>
						<a href="mailto:support@webkul.com?subject=Support-Query">support@webkul.com</a>
					</div>
					<div class="elements">
						<p>Sales Enquiries</p>
						<a href="mailto:sales@webkul.com?subject=Sales-Query">sales@webkul.com</a>
					</div>
				</div>
				<div class="phone wk-phone-address">
					<span class="phone-drops">
						<p class="away">USA</p>
						<a href="tel:+19143531684" target="_blank" title="Click to Dial - Phone Only">(+1)-9143531684</a>
					</span>
					<span class="phone-drops">
						<p class="home">IN</p>
						<a href="tel:+919870284067" target="_blank" title="Click to Dial - Phone Only">(+91)-9870284067</a>
					</span>
				</div>
			</div>
		</div>
		<hr/>
		<div class="contact-details">
			<div class="cards address">
				<p class="larger">Address</p>
				<h4 class="country">India</h4>
				<div class="elements">
					<p>Head Office</p>
					<p>Webkul Software Pvt. Ltd.<br />H-28, 2nd floor, ARV Park, Sector 63, Noida<br />Uttar Pradesh 201301 (India)</p>
					<div><a href="https://www.google.com/maps/place/Webkul+-+ARV+Park+Branch/@28.62938,77.3772283,18.19z/data=!4m5!3m4!1s0x0:0xe32f99975336cf7b!8m2!3d28.6296059!4d77.3785369?hl=en-GB" target="_blank" rel="noopener">View on Map</a></div>
				</div>
				<div class="elements">
					<p>Delhi Region</p>
					<p>Webkul Software Pvt. Ltd.<br />Regus Office Center Services Pvt Ltd Level 15, Eros Corporate Towers,<br />Nehru Place New Delhi 110019 (India)</p>
				</div>
			</div>
			<div class="cards address">
				<h4 class="country">USA</h4>
				<div class="elements">
					<p>Santa Clara Region</p>
					<p>Webkul Software<br>1901 Halford Avenue, Suite 211<br>Santa Clara, CA - 95051</p>
				</div>
				<h4 class="country">Italy</h4>
				<div class="elements">
					<p>Corbetta Region</p>
					<p>Webkul Software<br />Via Giovanni Pascoli 16, 20011<br />Corbetta MI, Italy</p>
				</div>
			</div>
		</div>

	</div>
</section>

<?php
echo '<script id="uv-faq-list" type="application/json">' . wp_json_encode( $request_list ) . '</script>';
?>
<script type="text/html" id="wk-faq-suggest-template">
		<li>
			<a href="{{faq_link}}" target="_blank" rel="noopener">{{faq_name}}</a>
		</li>
</script>
<?php

get_footer();?>

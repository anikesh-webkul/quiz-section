
registerBlockType( 'wk-blocks/layout-container', {
    title : 'Layout Container',
    icon : 'admin-multisite',
    category: 'webkul',
    keywords: [
        'Container',
    ],
    example: {},
    // parent: ['core'],

    attributes: {
        gridField: {
            type: 'string',
            default: 'wide',
        },
       
        color:{
            type:'string',
            // default:'#ffffff',
        },
        colorClass:{
            type:'string',
            default:'default'
        },
        marginT: {
            type:'number',
        },
        marginB:{
            type:'number',
        },
        paddingT:{
            type:'number',
        },
        paddingB:{
            type:'number',
        },
        gridOveride:{
            type:'boolean',
            default:false
        },
        gridLayout:{
            type:'string',
            default:'1',
        },
        wkTemplateLock: {
           type:'boolean',
           default:false
        }
       
    },
    
    edit : function( props ) {
        gridField = props.attributes.gridField,
        colorClass = props.attributes.colorClass;
        gridLayout = props.attributes.gridLayout;
        wkTemplateLock = props.attributes.wkTemplateLock;
        let ALLOWED_BLOCKS = ['core/paragraph', 'core/heading', 'wk-blocks/block-wrapper' ];

        // let TEMPLATE = [
        //     ['core/heading',{align:'center', placeholder:'Section Title'}],
        //     ['core/paragraph',{align:'center', placeholder:'Section Description'}],
        //     ['wk-blocks/block-wrapper'],
        // ];

        function onChangeGridLayout( newValue ) {
            props.setAttributes( { gridLayout: newValue } );
        }
        
        function onChangegridField( newValue ) {
            props.setAttributes( { gridField: newValue } );
        }
        function wkGridColorClass( hex ) {
            temp = wkColorPallete.find(function(col){
                return col.color == hex;
            },hex);
            
            return (undefined != temp ) ? temp.name : 'default';
        }
        
        return (
            el(
                Fragment,
                null,
                el(
                    InspectorControls,
                    null,
                    el(
                        Panel,
                        {},

                        /** Start Code // Section Grid Setting */
                        el(
                            PanelBody,
                            { title: 'Choose Grid', initialOpen: true },
                            
                            el(
                                PanelRow,
                                {},

                                el(
                                    RadioControl,
                                    {
                                        // label: 'Block Grid',
                                        selected: gridField,
                                        options: [
                                            {
                                                label: 'Full',
                                                value: 'full'
                                            },
                                            {
                                                label: 'Wide',
                                                value: 'wide'
                                            },
                                            {
                                                label: 'Compact',
                                                value: 'compact'
                                            },
                                            {
                                                label: 'Squeezy',
                                                value: 'squeezy'
                                            }
                                        ],
                                        onChange: onChangegridField
        
                                    }
        
                                ),
                                
                            ),
                            
                        ),


                        /** Start Code // Section Backgroung Setting */
                        el(
                            PanelBody,
                            { title: 'Choose Background', initialOpen: true },
                            el(
                                PanelRow,
                                {},
                                el('b',{},'selected color'),

                                el(
                                    ColorIndicator,
                                    {
                                        colorValue:props.attributes.color
                                    }
                                ),

                            ),
                            el(
                                PanelRow,
                                {},
                                
                                el(
                                    ColorPalette,
                                    {
                                        colors:wkColorPallete,
                                        value:props.attributes.color,
                                        onChange:(newColor)=>{
                                            props.setAttributes({color:newColor});
                                            props.setAttributes({colorClass:wkGridColorClass(newColor)});
                                        }
                                    }
                                ),
                            ),

                        ),
                        /** End Code // Section Background Setting */

                        el(
                            PanelBody,
                            {
                                title:'Layout Spacing',
                                initialOpen:true,
                            },
                            el(
                                RangeControl,
                                {
                                    label:"Margin Top",
                                    value:props.attributes.marginT,
                                    onChange:(marginT) => { props.setAttributes({marginT:marginT}) },
                                    min:0,
                                    max:150,
                                    help :'margin value render in pixel(px)',
                                    allowReset:true,
                                    initialPosition :0,
                                    
                                }
                            ),
                            el(
                                RangeControl,
                                {
                                    label:"Margin Bottom",
                                    value:props.attributes.marginB,
                                    onChange:(marginB) => { props.setAttributes({marginB:marginB}) },
                                    min:0,
                                    max:150,
                                    help :'margin value render in pixel(px)',
                                    allowReset:true,
                                    initialPosition :0,
                                    
                                }
                            ),
                            el('hr',{style:{border:'1px solid #c3c3c3'}}),
                            el(
                                RangeControl,
                                {
                                    label:"Padding Top",
                                    value:props.attributes.paddingT,
                                    onChange:(paddingT) => { props.setAttributes({paddingT:paddingT}) },
                                    min:0,
                                    max:150,
                                    help :'Padding value render in pixel(px)',
                                    allowReset:true,
                                    initialPosition :0,
                                    
                                }
                            ),
                            el(
                                RangeControl,
                                {
                                    label:"Padding Bottom",
                                    value:props.attributes.paddingB,
                                    onChange:(paddingB) => { props.setAttributes({paddingB:paddingB}) },
                                    min:0,
                                    max:150,
                                    help :'Padding value render in pixel(px)',
                                    allowReset:true,
                                    initialPosition :0,
                                    
                                }
                            ),
                        ),
                        /** //End Layout Spacing */

                        /** Grid Layout Type */
                        el( PanelBody, { title:'Layout Type' },
                            el(
                                SelectControl,
                                {
                                    label:'BG Layout Type',
                                    value:gridLayout,
                                    options:[
                                        { label:'Full BG', value:'1' },
                                        { label:'Rounded BG', value:'2' }
                                    ],
                                    onChange:onChangeGridLayout,
                                }
                            )
                        ),
                        /** //Grid Layout Type */

                    ),

                ),
                el(
                    InspectorAdvancedControls,
                    {},
                    el(
                        PanelRow,
                        {},
                        el(
                            ToggleControl,
                            {
                                label:'Remove/Override theme container/grid',
                                checked:props.attributes.gridOveride,
                                onChange:(gridOveride) => {
                                    props.setAttributes({gridOveride:gridOveride});
                                    if(gridOveride) {
                                        if ( ! props.className.split( ' ' ).includes('wk-layout-stretch') ) {
                                            props.className = props.className.concat( ' ', 'wk-layout-stretch' ).trim();
                                        }
                                    } else {
                                        props.className = props.className.replace( 'wk-layout-stretch', '' ).trim();
                                    }
                                },
                            },
                        ),
                    ),
                ),
                el(
                    'div',
                    {
                        className:(props.className) ? 'wk-layout-section ' + props.className : 'wk-layout-section',
                        _bgColor: colorClass,
                        style:{
                            position:'relative',
                        },
                        _gridLayout:gridLayout
                    },
                    el(
                        Dashicon,
                        {
                            icon:'admin-generic',
                            style:{
                                position:'absolute',
                                right:'-10px',
                                top:'-10px',
                                cursor:'pointer'
                            }
                        }
                    ),
                    el(
                        'div',
                        {
                            _wkGrid:gridField,
                        },
                        el(
                            InnerBlocks,
                            {
                                allowedBlocks: (wkTemplateLock) ? [] : true,
                            }
                            
                        )
                    )
                )
            )
        );
    },
    save: function(props) {
        let layoutStyle = {};
        ( props.attributes.marginT ) && ( layoutStyle['marginTop'] = props.attributes.marginT );
        ( props.attributes.marginB ) && ( layoutStyle['marginBottom'] = props.attributes.marginB );
        ( props.attributes.paddingT ) && ( layoutStyle['paddingTop'] = props.attributes.paddingT );
        ( props.attributes.paddingB ) && ( layoutStyle['paddingBottom'] = props.attributes.paddingB );
        
        ( ! props.attributes.className ) && ( props.attributes.className = '' );
        
        if( props.attributes.gridOveride ) {
            if ( ! props.attributes.className.split( ' ' ).includes( 'wk-layout-stretch' ) ) {
                props.attributes.className = props.attributes.className.concat( ' ', 'wk-layout-stretch' ).trim();
            }
        } else {
            props.attributes.className = props.attributes.className.replace( 'wk-layout-stretch', '' ).trim();
        }

        /** We are using Two type of output layout { 'Full BG', 'Rounded BG' } */
        return el(
            Fragment,
            {},
            ( ! props.attributes.gridLayout || props.attributes.gridLayout == '1' )
                ?
            el(
                'div',
                {
                    className:'wk-component ' + props.attributes.className,
                    _bgColor: props.attributes.colorClass,
                    style:layoutStyle,
                },
                el(
                    'div',
                    {
                        _wkGrid:props.attributes.gridField,
                    },
                    el(
                        InnerBlocks.Content
                    )
                )
            )
                :
            el(
                'div',
                {
                    className:props.attributes.className,
                },
                el(
                    'div',
                    {
                        _wkGrid:props.attributes.gridField,
                    },
                    el(
                        'div',
                        {
                            _bgColor: props.attributes.colorClass,
                            style:layoutStyle,
                        },
                        el(
                            InnerBlocks.Content
                        )
                    )
                )
            )   

        )
    }


} );
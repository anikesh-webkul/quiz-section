var $wkp = jQuery.noConflict();
(function( $wkp ){
    $wkp(document).ready(function(){
        $wkp('#wkp_restoration').on('click',function(e){
            e.preventDefault();
            var wkEditor = $wk('#content');
            var wkVisual = $wk('#content_ifr').contents().find('body');

            if ( $wk('input[name=wkp_restore]:checked')[0] ) {
            $wk('.wkp-restore-require').css('display','none');
            var restore_tags  = $wk('input[name=wkp_restore]:checked');
            var res_revision  = restore_tags.val();
            var res_version   = restore_tags.attr('version');
            var res_framework = restore_tags.attr('framework');
            var post_ID        = $wk('#post_ID').val()
            $wk('#wkp_version').val(res_version);
            $wk('#wkp_frameversion').val(res_framework);
            $wk('#wkp_final_version').prop('checked',true);
            $wk.ajax({

                type: 'post',
                url: wkpVersionVar.url,
                data: {
                    action :'wkp_revision_res',
                    'nonce' : wkpVersionVar.nonce,
                    wkp_res_revision : res_revision,
                    post_ID : post_ID,

                },
                beforeSend:function() {
                    $wk('.wkp-loader.spinner').css('visibility','visible');
                },
                success:function(res) {
                    $wk('.wkp-loader.spinner').css('visibility','hidden');
                    if ( 'block' === wkEditor.css('display') ) {

                        $wk(window).scrollTop(0);

                        wkEditor.html(res);

                        $wk('#wpwrap .wrap').find('.wp-header-end').after('<div class="notice notice-success is-dismissible"><p><strong>Restore Post Version '+res_framework+'</strong></p></div>')

                        $wk('#wpwrap .wrap').find('.wp-header-end').next().fadeOut(4000,function(){$wk(this).remove();});

                    } else {
                        $wk(window).scrollTop(0);

                        wkVisual.html(res);

                        $wk('#wpwrap .wrap').find('.wp-header-end').after('<div class="notice notice-success is-dismissible"><p><strong>Restore Post Version '+res_framework+'</strong></p></div>')

                        $wk('#wpwrap .wrap').find('.wp-header-end').next().fadeOut(4000,function(){ $wk(this).remove(); });

                    }

                }
            });
        } else {
            $wk('.wkp-restore-require').css('display','block').delay( 4000 ).fadeOut(1000);
        }
        });
    });
})($wkp);

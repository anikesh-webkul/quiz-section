<?php
/**
 * @package webkul
 * @subpackage webkul theme 2K18
 * @since webkul theme 2.0
 */
get_header();

$page_id     = get_the_id();
$has_header  = get_post_meta($page_id, 'wk_page_has_header', true);
$has_infobox = get_post_meta($page_id, 'wk_infobox_visible', true);
$all_press   = get_option('wktheme-page-press');
$all_press   = ('' === $all_press) ? array() : $all_press;
$path        = wp_upload_dir()['baseurl'];

$opt_btn_attrs = maybe_unserialize(get_post_meta($page_id, 'wk_opt_btn_attr', true));
?>

<?php
if ('1' === $has_header) {

	$layout      = get_post_meta($page_id, 'wk_page_layout_view', true);
	$grid_class  = ('wide' === $layout) ? 'wkgrid-wide' : 'wkgrid-squeezy grid-extended';
	$has_bg_col  = ('wide' === $layout) ? 'section-padding has-bgcol' : 'section-padding-0B';
	$tagline     = get_post_meta($page_id, 'wk_banner_tagline', true);
	$feat_img    = get_the_post_thumbnail_url($page_id, 'full');
	$style       = "background-image: url('" . get_template_directory_uri() . "/images/career/career-hero-image.jpg?v=2.0'),linear-gradient(to right,#e6f5fd 50%,#e6f5fd 50%);"
	?>
	<section class="wk-page-header <?php echo esc_attr($has_bg_col); ?> wk-career-header wk-bg-lazify" style="<?php echo $style; ?>" data-src="<?php echo get_template_directory_uri() . '/images/career/career-hero-image.jpg?v=2.0'; ?>">
		<div class="<?php echo esc_attr($grid_class); ?>">
			<div class="page-tagline">
				<?php echo $tagline; ?>
				<?php
				if (isset($opt_btn_attrs['enable']) && '1' === $opt_btn_attrs['enable'] && !empty($opt_btn_attrs['link']) && !empty($opt_btn_attrs['label'])) {

					$_link   = (!empty($opt_btn_attrs['link'])) ? $opt_btn_attrs['link'] : '';
					$_label  = (!empty($opt_btn_attrs['label'])) ? $opt_btn_attrs['label'] : '';
					$_rel    = (!empty($opt_btn_attrs['rel'])) ? ' rel=' . $opt_btn_attrs['rel'] : '';
					$_target = (!empty($opt_btn_attrs['target'])) ? ' target=_blank' : '';
					$_color  = (!empty($opt_btn_attrs['color']) && 'prime' === $opt_btn_attrs['color']) ? 'wk-button' : 'wk-button ' . $opt_btn_attrs['color'];

					echo '<a class="' . esc_attr($_color) . '" href="' . esc_url($_link) . '"' . esc_attr($_target . $_rel) . ' title="' . $_label . '">' . esc_attr($_label) . '</a>';
				}
				?>
			</div>
		</div>
	</section>
<?php
}
global $wp;
?>
<section class="wk-career-grand-staff">
	<div class="wkgrid-squeezy text-center">
		<h2>Meet the People</h2>
		<p class="wk-career-staff-des">Great things happen, when like-minded people symphonize together.</p>
		<div class="wk-career-grand-staff-wrap">
			<div class="wk-career-main-staff">
				<div class="wk-career-staff-large display-none">
					<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/large-ratnesh.png?v=1.0'); ?>" alt="Ratnesh Kumar">
				</div>
				<div class="wk-career-staff-large display-none">
					<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/large-deepika.png?v=1.0'); ?>" alt="Deepika Singh">
				</div>
				<div class="wk-career-staff-large">
					<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/large-avneesh.png?v=1.0'); ?>" alt="Avneesh Kumar">
				</div>
			</div>
			<div class="wk-career-list-staff">
				<div class="wk-career-wrap" data-index="0">
					<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/thumb-ratnesh.png'); ?>" alt="Ratnesh Kumar">
				</div>
				<div class="wk-career-wrap" data-index="1">
					<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/thumb-deepika.png'); ?>" alt="Deepika Singh">
				</div>
				<div class="wk-career-wrap" data-index="2">
					<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/thumb-avneesh.png'); ?>" alt="Avneesh Kumar">
				</div>
			</div>
		</div>
	</div>
</section>

<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_IN/sdk.js#xfbml=1&version=v5.0"></script>

<section class="wk-career-like-section section-padding-0T">
	<div class="wkgrid-wide">
		<div class="inline-dividers-50 inline-dividers-wide text-center">
			<img src="<?php echo get_template_directory_uri() . '/images/career/webkul-lifestyle.png' ?>" alt="Webkul LifeStyle">
		</div>
		<div class="inline-dividers-50 text-left inline-dividers-narrow">
			<div>
				<h2>Webkul is not about Work, it’s all about Lifestyle.</h2>
				<p>Connect with us and know what's happening around Webkul.</p>
				<div class="career-social-wrap">
					
					<div class="fb-like" data-href="https://www.facebook.com/webkul/" data-width="" data-layout="button" data-action="like" data-size="small" data-share="false"></div>
					&ensp;
					
					<script src="https://platform.linkedin.com/in.js" async defer type="text/javascript"> lang: en_US</script>
					<script type="IN/FollowCompany" data-id="914889" data-counter=""></script>

				</div>
				
			</div>
		</div>
	</div>
</section>

<section class="wk-career-rewards section-padding">
	<div class="wkgrid-wide">
		<div class="inline-dividers-50 inline-dividers-wide text-center">
			<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/award.png') ?>" alt="Webkul Awards">
		</div>
		<span class="wk-career-rewards-reverse">
			<div class="inline-dividers-50 text-left inline-dividers-narrow">
				<h2>Best Place to Work</h2>
				<p>Enlightening the glory of 10 years of hard work.</p>
				<a class="wk-career-explore" href="<?php echo esc_url(site_url() . '/awards'); ?>" title="Awards" rel="noopener">Explore Our Awards</a>
			</div>
			<div class="wk-career-social">
				<div class="wk-awards-wrap">
					<div class="wk-img-wrap">
						<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/deloitte.png?2.0'); ?>" alt="Deloitte Award" title="Deloitte Award">
					</div>
					<div class="wk-img-wrap">
						<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/glassdoor.png?v=2.0'); ?>" alt="Glassdoor" title="Glassdoor">
					</div>
					<div class="wk-img-wrap">
						<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/startup-50.png'); ?>" alt="Startup-50 Award" title="Startup-50 Award">
					</div>
					<div class="wk-img-wrap">
						<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/imagine.png?v=1.0'); ?>" alt="Magento Award" title="Magento Award">
					</div>
					<div class="wk-img-wrap">
						<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/innovation-lab.png?v=2.0'); ?>" alt="Innovation Lab Winner" title="Innovation Lab Winner">
					</div>
					<div class="wk-img-wrap">
						<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/superhero-seller.png'); ?>" alt="Superhero Seller Award" title="Superhero Seller Award">
					</div>
				</div>
			</div>
		</span>
	</div>
</section>

<section class=" wk-career-life-at-webkul section-padding">
	<div class="wkgrid-wide">
		<h2>Life at Webkul</h2>
		<div class="wk-career-life-card">
			<p>Outcome Oriented</p>
			<p class="tile-desc">We work on a wide range of products. So its employee's will power, where they want to work.</p>
		</div>
		<div class="wk-career-life-card">
			<p>Mentorship</p>
			<p class="tile-desc">Mentor gives honest feedback and provides executive industrial coaching to the colleague.</p>
		</div>
		<div class="wk-career-life-card">
			<p>Employee Feedback</p>
			<p class="tile-desc">This feature brings positive waves inside the employee and we take its very serious for the betterment of employee.</p>
		</div>
		<div class="wk-career-life-card">
			<p>Meetups</p>
			<p class="tile-desc">Webkul organizes set of talks, conferences and networking events to engage with the community by sharing both the resources and business insights. </p>
		</div>
		<div class="wk-career-life-card">
			<p>Activity</p>
			<p class="tile-desc">We have tons of activity to engage our colleague inside the office premises when they get time to make some bold move.</p>
		</div>
		<div class="wk-career-life-card">
			<p>Events</p>
			<p class="tile-desc">We are quite social about learning and sharing our ideas with the community. You can see the glimpses of our presence below.</p>
		</div>
	</div>
</section>

<section class="wk-career-slider-wrap section-padding-0T">
	<div class="wkgrid-wide">
		<div class="wk-career-slider-img owl-theme">
			<?php
			$slider_dir    = get_template_directory() . '/images/career/slider/';
			$slider_images = glob( $slider_dir . '*.{jpg,png}', GLOB_BRACE );
			foreach ( $slider_images as $slider ) {
				?>
				<div><img class="wk-career-slider-img" src="<?php echo esc_url( get_template_directory_uri() . '/images/career/slider/' . basename( $slider ) ); ?>"></div>
			<?php
			}
			?>
		</div>
	</div>
</section>

<section class="wk-career-job-wrap section-padding container-margin-down-40">
	<div class="wkgrid-wide">
		<div class="inline-dividers-50 inline-dividers-narrow">
			<h2>Open Positions</h2>
			<p>We are always on to say “Hello” to both creative and expert craftsmen. If you want to help us to create and solve the real world problems, you’ll enjoy your road trip with us.</p>
			<a class="wk-career-explore wk-jobs" href="<?php echo esc_url(site_url() . '/jobs/'); ?>" rel="noopener" title="Jobs">Explore Jobs</a>
		</div>
		<div class="inline-dividers-50 inline-dividers-wide text-center">
			<div class="wk-career-img-wrapper">
				<div class="wk-career-job-img border-right">
					<a class="wk-job-link" target="_blank" rel="noopener" href="<?php echo esc_url(site_url() . '/jobs/#engineering'); ?>" title="Engineering"><img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/engineering.png?v=2.1'); ?>" alt="Engineering" title="Engineering"><br>Engineering</a>
				</div>
				<div class="wk-career-job-img">
					<div class="wk-career-job-img">
						<a class="wk-job-link" target="_blank" rel="noopener" href="<?php echo esc_url(site_url() . '/jobs/#quality-analyst'); ?>" title="Quality Analyst"><img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/qualtiy.png?v=2'); ?>" alt="Qualtiy" title="Quality Analyst"><br>Quality Analyst</a>
					</div>
					<div class="wk-career-job-img border-top">
						<a class="wk-job-link" target="_blank" rel="noopener" href="<?php echo esc_url(site_url() . '/jobs/#design'); ?>" title="Design"><img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/design.png?v=2'); ?>" alt="Design" title="Design"><br>Design</a>
					</div>
				</div>
				<div class="wk-career-job-img border-left" id="business">
					<a class="wk-job-link" target="_blank" rel="noopener" href="<?php echo esc_url(site_url() . '/jobs/#business'); ?>" title="Business"><img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/business.png?v=2'); ?>" alt="Business" title="Business"><br>Business</a>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="wk-career-perks section-padding container-margin-down">
	<div class="wkgrid-wide">
		<div class="inline-dividers-50 inline-dividers-wide">
			<ul>
				<h2>See the amazing perks</h2>
				<li>Mentorship and Guidance</li>
				<li>Hackathons and Tech Talks</li>
				<li>Flexible Office Timings</li>
				<li>Cab till your Doorstep</li>
				<li>Health First, Build Later Preference</li>
				<li>Beverages and Snacks</li>
				<li>Occasional Team Events and Parties</li>
				<li>Activity and Fun Zones</li>
				<a class="wk-button btn-ghost wk-life-webkul" href="https://webkul.com/blog/life-at-webkul/" rel="noopener" target="_blank" title="Life At Webkul">Explore Culture</a>
			</ul>
		</div>
		<div class="inline-dividers-50 text-center inline-dividers-narrow">
			<img src="<?php echo esc_url(get_template_directory_uri() . '/images/career/perks.png?1.0'); ?>">
		</div>
	</div>
</section>

<section class="wk-team-words-popup">
	<div class="altered_video_popup" style="display: none;">
		<div class="altered_popup_wrapper">
			<span class="altered_popup_close"></span>
			<div class="altered_popup_content text-center">
			<video id="altered_video_player" controls autoplay poster="" preload="1">

				<source src="" type="video/mp4">

				</video>
			</div>
		</div>
	</div>
</section>


<section class="wk-team-words-slider section-padding-0B text-center">
	<div class="wkgrid-wide grid-extended">
		<h2 class="text-center">Check Out IGTV</h2>
		<div class="wk-slider-wrap-outer">
			<div class="cards" data-src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-rahul.mp4' ); ?>">
				<img class="visible" src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-poster-rahul.png' ); ?>" />
				<video poster="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-poster-rahul.png' ); ?>" muted loop>
					<source src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-rahul.mp4' ); ?>" type="video/mp4">
				</video>
				<div class="ico-wrap">
					<div class="ico-play" data-src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-rahul.mp4' ); ?>"></div>
				</div>
			</div>
			<div class="cards" data-src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-sachin.mp4' ); ?>">
				<img class="visible" src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-poster-sachin.jpg' ); ?>" />
				<video poster="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-poster-sachin.jpg' ); ?>" muted loop>
					<source src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-sachin.mp4' ); ?>" type="video/mp4">
				</video>
				<div class="ico-wrap">
					<div class="ico-play"></div>
				</div>
			</div>
			<div class="cards" data-src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-nishad.mp4' ); ?>">
			<img class="visible" src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-poster-nishad.jpg' ); ?>" />
			<video poster="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-poster-nishad.jpg' ); ?>" muted loop>
					<source src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-nishad.mp4' ); ?>" type="video/mp4">
				</video>
				<div class="ico-wrap">
					<div class="ico-play"></div>
				</div>
			</div>
			<div class="cards" data-src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-ayushi.mp4' ); ?>">
				<img class="visible" src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-poster-ayushi.png' ); ?>" />
				<video poster="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-poster-ayushi.png' ); ?>" muted loop>
					<source src="<?php echo esc_url( get_template_directory_uri() . '/images/career/igtv/igtv-ayushi.mp4' ); ?>" type="video/mp4">
				</video>
				<div class="ico-wrap">
					<div class="ico-play"></div>
				</div>
			</div>

		</div>
	</div>

</section>

<script>
window.addEventListener( 'load', function(){

	var wkScreenHeight = window.innerHeight;
	/*Hero slider*/
	jQuery( '.wk-career-slider-img' ).addClass('owl-carousel').owlCarousel({
		singleItem: true,
		items: 1,
		nav: false,
		rewindNav :true,
		loop:false,
		dots: true,
	});
	document.onkeydown = ( e ) => {
		e = e || window.event;

		// console.log(e);
		if( e.keyCode == '37' || e.keyCode == '39' ) {
			var sliderRect = jQuery( '.wk-career-slider-img ')[0].getBoundingClientRect();
			var wkSliderOffsetTop = wkScreenHeight - sliderRect.height*(2/3);
			if( sliderRect.top < wkSliderOffsetTop && 0 < sliderRect.bottom ) {
				if ( e.keyCode == '37' ) {
					// left arrow
					jQuery( '.wk-career-slider-img .owl-prev' ).click();
				} else if (e.keyCode == '39') {
					// right arrow
					jQuery( '.wk-career-slider-img .owl-next' ).click();
				}
			}
		}
	}

});
</script>
<?php
get_footer();

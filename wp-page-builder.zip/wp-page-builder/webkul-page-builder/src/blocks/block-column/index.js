const wkColumnLayout = [
    {
        name: '2 Columns - 50/50',
        key: 'equal-col',
        col: 2,
        icon: wkBlockIcons.twoEqual,
    },
    {
        name: '2 Columns - 75/25',
        key: 'wideleft',
        col: 2,
        icon: wkBlockIcons.twoLeftWide,
    },
    {
        name: '2 Columns - 25/75',
        key: 'wideright',
        col: 2,
        icon: wkBlockIcons.twoRightWide,
    },
    {
        name: '2 Columns - 45/55',
        key: 'squeezyright',
        col: 2,
        icon: wkBlockIcons.twoRightSqueezy,
    },
    {
        name: '2 Columns - 55/45',
        key: 'squeezyleft',
        col: 2,
        icon: wkBlockIcons.twoLeftSqueezy,
    },
];

registerBlockType( 'wk-blocks/inline-column', {
    title : 'Inline Column',
    icon : 'controls-pause',
    category: 'webkul',
    keywords: [
        'Inline Column',
        'Two Column',
        'Doc Section'
    ],
    parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    example: {},

    attributes: {
        layout:{
            type:'string',
        },
        rowSpace:{
            type:'number',
        },
        colSpace:{
            type:'string',
            default:30,
        },
        marginT:{
            type:'string',
        },
        marginB:{
            type:'string',
        },
        resAlign: {
            type:'boolean',
            default:false
        },
        rowSwap: {
            type:'boolean',
            default:false,
        }
        
       
    },
    edit : function( props ) {
        layout = props.attributes.layout;
        rowSpace = props.attributes.rowSpace;
        colSpace = props.attributes.colSpace;
        rowSwap = props.attributes.rowSwap;
        
        const onChangeRowSwap = (rowSwap) => {
            props.setAttributes({rowSwap:rowSwap})
            
           
            
        }

        var TEMPLATE = [
            [ 'wk-blocks/inline-inner-column' ],
            [ 'wk-blocks/inline-inner-column', {placeholder:'core/image'} ]
        ];
        let ALLOWED_BLOCKS = [];

       
        return (
           el(
               Fragment,
               null,
               el(
                   BlockControls,
                   { key: 'controls' },
                   
                   el(
                       Button,
                       {
                           isSmall:true,
                           style:{
                               height:'auto',
                               background: '#fff',
                               'border-top': '1px solid #b5bcc2',
                               'border-bottom': '1px solid #b5bcc2',
                               'border-right': '1px solid #b5bcc2',
                           },
                           title:'Swap Column',
                           onClick:() => {
                                currentBlock = wp.data.select('core/block-editor').getSelectedBlock();
                                clientid = currentBlock.clientId;
                                moverId = currentBlock.innerBlocks[0].clientId;
                                wp.data.dispatch( 'core/block-editor' ).selectBlock(moverId);
                                setTimeout(()=>{
                                    document.querySelector('.block-editor-block-mover__control[aria-label="Move down"]').click();
                                    wp.data.dispatch( 'core/block-editor' ).selectBlock(clientid);

                                });

                           }
                       },
                       el(
                           'svg',
                           {
                               xmlns:'http://www.w3.org/2000/svg',
                               viewBox:'0 0 24 24',
                               className:'block-editor-block-switcher__transform',
                               role:'role',
                               ariaHidden:true,
                               width:'32',
                               height:'30'
    
                           },
                           el(
                               'path',
                               {
                                   d:'M6.5 8.9c.6-.6 1.4-.9 2.2-.9h6.9l-1.3 1.3 1.4 1.4L19.4 7l-3.7-3.7-1.4 1.4L15.6 6H8.7c-1.4 0-2.6.5-3.6 1.5l-2.8 2.8 1.4 1.4 2.8-2.8zm13.8 2.4l-2.8 2.8c-.6.6-1.3.9-2.1.9h-7l1.3-1.3-1.4-1.4L4.6 16l3.7 3.7 1.4-1.4L8.4 17h6.9c1.3 0 2.6-.5 3.5-1.5l2.8-2.8-1.3-1.4z'
                               }
                           )
                       )
                   ),
                   
               ),
               el(
                   InspectorControls,
                   {},
                  el(
                      PanelBody,
                      {
                          title:'Column & Gap Setting',
                          intialOPen:true,
                      },
                      el( 'p', {}, 'Column Layout' ),
                      el(
                          ButtonGroup,
                          {
                              'aria-label':'Column Layout',
                          },
                          wkColumnLayout.map( (lt) => {
                              return el(
                                  Tooltip,
                                  {
                                      text:lt.name,
                                      key:lt.key,
                                  },
                                  el(
                                      Button,
                                      {
                                          key:lt.key,
                                          onClick:function(key) {
                                              props.setAttributes( {
                                                  layout: lt.key,
                                              } );
                                          },
                                      },
                                      lt.icon
                                  ),

                              );
                        } ),
                      ),
                      el('hr'),
                      el(
                        RangeControl,
                        {
                            label:"Column Space",
                            value:colSpace,
                            onChange:(colSpace) => { props.setAttributes({colSpace:colSpace}) },
                            min:5,
                            max:100,
                            help :'Space Between column in pixel(px)',
                            allowReset:true,
                            initialPosition :0,
                        }
                    ),
                    el('hr'),
                    el(
                        RangeControl,
                        {
                            label:"Margin Top",
                            value:props.attributes.marginT,
                            onChange:(marginT) => { props.setAttributes({marginT:marginT}) },
                            min:0,
                            max:150,
                            help :'margin value render in pixel(px)',
                            allowReset:true,
                            initialPosition :0,
                            
                        }
                    ),
                    el(
                        RangeControl,
                        {
                            label:"Margin Bottom",
                            value:props.attributes.marginB,
                            onChange:(marginB) => { props.setAttributes({marginB:marginB}) },
                            min:0,
                            max:150,
                            help :'margin value render in pixel(px)',
                            allowReset:true,
                            initialPosition :0,
                            
                        }
                    ),
                    
                  ),
                  el(
                      PanelBody,
                      {
                          title:'Resposive Setting',
                      },
                      el(
                          RangeControl,
                          {
                              label:"Column Space",
                              value: ( rowSpace ) ? rowSpace : colSpace,
                              onChange:(rowSpace) => { props.setAttributes({rowSpace:rowSpace}) },
                              min:10,
                              max:100,
                              help :'Space Between column in pixel(px)',
                              allowReset:true,
                              initialPosition :0,
                          }
                      ),
                      el('hr', {} ),
                      el(
                        ToggleControl,
                        {
                            label:'Content Center for Mobile Screen',
                            checked:props.attributes.resAlign,
                            onChange:(resAlign) => {
                                props.setAttributes({resAlign:resAlign});
                            },
                        },
                      ),
                      el('hr', {} ),
                      el(
                        ToggleControl,
                        {
                            label:'Swap Column on Mobile Screen',
                            checked:props.attributes.rowSwap,
                            onChange:onChangeRowSwap,
                        },
                      ),
                               
                  )
               ),
               el(
                   'div',
                   {
                       className:'wkColumnGrid',
                       __columnType:layout,
                       style:{
                           position:'relative'
                       }
                   },
                   el(
                        Dashicon,
                        {
                            icon:'admin-generic',
                            style:{
                                position:'absolute',
                                right:'-25px',
                                top:'-25px',
                                cursor:'pointer'
                            }
                        }
                    ),
                   el(
                       InnerBlocks,
                       {
                           template:TEMPLATE,
                           allowedBlocks: [],
                       }
                   ),
               )
           )
        );
    },
    save:function(props) {
        let layoutStyle = {};
        ( props.attributes.marginT ) && ( layoutStyle['marginTop'] = props.attributes.marginT );
        ( props.attributes.marginB ) && ( layoutStyle['marginBottom'] = props.attributes.marginB );
        ( props.attributes.colSpace ) && ( layoutStyle['gridColumnGap'] = props.attributes.colSpace + 'px' );
        layoutStyle['gridRowGap'] = ( props.attributes.rowSpace ) ? props.attributes.rowSpace + 'px' : props.attributes.colSpace + 'px' ;
        
        ( ! props.attributes.className ) && ( props.attributes.className = '' );
        
        if( props.attributes.rowSwap ) {
            if ( ! props.attributes.className.split( ' ' ).includes( 'row-swap' ) ) {
                props.attributes.className = props.attributes.className.concat( ' ', 'row-swap' ).trim();
            }
        } else {
            props.attributes.className = props.attributes.className.replace( 'row-swap', '' ).trim();
        }
        
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className:'wkColumnGrid ' + props.attributes.className,
                    style:layoutStyle,
                    __columnType:props.attributes.layout,
                    __responsive:( props.attributes.resAlign ) ? 'center' : false,
                },
                el(
                    InnerBlocks.Content
                )
            )
        )
    }


} );
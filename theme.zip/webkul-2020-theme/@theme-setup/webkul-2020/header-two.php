<?php

/**
 * Webkul Header Template TWO
 * @package webkul
 * @subpackage webkul theme
 * @since WebkulTheme 1.0
 */
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?> class="<?php echo ((is_home() || is_404()) ? 'height-100' : ''); ?>">
<head>
	<title><?php wp_title('|', true, 'right'); ?></title>
	<link rel="icon" type="image/x-icon" href="<?php echo esc_attr(get_bloginfo('template_url')); ?>/images/favicon.ico?1.0.1" />
	<link rel="apple-touch-icon" href="<?php echo esc_url(get_template_directory_uri() . '/images/icon-57.png'); ?>" />
	<link rel="apple-touch-icon" sizes="72x72" href="<?php echo esc_url(get_template_directory_uri() . '/images/icon-72.png'); ?>" />
	<link rel="apple-touch-icon" sizes="114x114" href="<?php echo esc_url(get_template_directory_uri() . '/images/icon-114.png'); ?>" />
	<link rel="apple-touch-icon" sizes="144x144" href="<?php echo esc_url(get_template_directory_uri() . '/images/icon-144.png'); ?>" />
	<link rel="preload" as="image" href="<?php echo esc_url(get_template_directory_uri() . '/images/webkul-main-sprite.svg?v=4.6'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no">
	<meta name="keywords" content="webkul software, Opencart extension company, magento ecommerce extension, joomla, webku	opencart store, enterprise extensions" />
	<meta name="google-site-verification" content="2ATbmQVR9BgdJ_fkEz6FOwiSzlCNd_FfdslAPxaUJOI" />
	<link href="https://plus.google.com/+Webkul" rel="publisher" />
	<?php wp_head(); ?>
</head>

<body class="<?php echo ((is_home() || is_404()) ? 'height-100' : ''); ?>">
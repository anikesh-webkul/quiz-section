<?php
add_action( 'wp_enqueue_scripts', function() {
    if( is_singular( 'meetups' ) ) {

        wp_enqueue_style( 'wk-meetups-style', get_template_directory_uri() . '/core/meetups/assets/css/min/wk-meetups.min.css', array(), '1.6' );

        wp_enqueue_script( 'wk-meetups-script', get_template_directory_uri() . '/core/meetups/assets/js/min/meetups.min.js', array(), '1.1' );

    }
} );

add_action( 'admin_enqueue_scripts', function() {
    if( 'meetups'  === get_post_type() ) {

        wp_enqueue_style( 'wk-meetups-style', get_template_directory_uri() . '/core/meetups/assets/css/min/wk-backend_meetups.min.css', array(), '1.2' );

        wp_enqueue_script( 'wk-meetups', get_template_directory_uri() . '/core/meetups/assets/js/min/backend-meetups.min.js', array(), '1.1' );

    }
} );

add_action( 'init', function() {

    /*-- Custom Post Type Meetups --*/

    $feature_labels = array(
        'name'                  => 'Meetups',
        'singular_name'         => 'Meetup',
        'all_items'             => 'Meetups',
        'add_new'               => 'Add Meetup',
        'add_new_item'          => 'Add New Meetup',
        'edit_item'             => 'Edit Meetup',
        'new_item'              => 'New Meetup',
        'view_item'             => 'View Meetup',
        'search_items'          => 'Search Meetup',
        'not_found'             => 'Nothing found',
        'not_found_in_trash'    => 'Nothing found in Trash',
        'set_featured_image'    => 'Set Meetup featured Image',
        'remove_featured_image' => 'Remove Meetup featured Image',
        'use_featured_image'    => 'Use Meetup featured Image',
        'featured_image'        => 'Meetup featured Image',
        'parent_item_colon'     => '',
    );

    $feature_rewrite = array(
        'slug'          => 'meetups',
        'with_front'    => true,
        'pages'         => false,
        'feeds'         => false,
    );

    $feature_args = array(
        'label'               => 'Meetups',
        'labels'              => $feature_labels,
        'public'              => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'query_var'           => true,
        'menu_icon'           => 'dashicons-paperclip',
        'capability_type'     => 'post',
        'supports'            => array( 'title', 'editor', 'thumbnail', 'revisions', 'excerpt' ),
        'rewrite'             => $feature_rewrite,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => true,
    );

    register_post_type( 'meetups', $feature_args );

    /*-- //Custom Post Type Meetups --*/
} );

WK_Tab_Meta_Box::add( 'webkul-meetups', 'Meetup Settings', 'webkul_meetups_cb', 'meetups', '_as_topbar', 'advanced', 'high' );

function webkul_meetups_cb( $post ) {

    $evt_page_data = ! empty( $evt_page_data = get_post_meta( $post->ID, '__wk_meetup_page_data_', true  ) ) ? $evt_page_data : array();

    $arc_img = isset( $evt_page_data['archive-image'] ) ? $evt_page_data['archive-image'] : false;

    $evt_data = ! empty( $evt_data = get_post_meta( $post->ID, '__wk_meetup_data_', true  ) ) ? $evt_data : array();

    
    return array(
        'Header' => function() use ( $evt_page_data ) {
            wp_nonce_field( '__wkmeetup_nonce_key_', '__wkmeetup_nonce' );
            $img_src = ! empty( $evt_page_data['header']['image'] ) ? wp_get_attachment_image_src( $evt_page_data['header']['image'], 'main' )[0] : false;
            ?>
            <div class="form-wrap">
                <label><strong>Header Background Image</strong></label>
                <div class="_wk_image_uploader_" style="height: 120px;">
                    <img src="<?php echo esc_url( $img_src ); ?>" class="wk_image_src" style="display: block; height: 100%; width: 100%; object-fit: cover;">
                    <input type="hidden" class="wk_image_id" name="meetup[header][image]" value="<?php echo ! empty( $evt_page_data['header']['image'] ) ? $evt_page_data['header']['image'] : false; ?>">
                </div>
                <br>
                <div>
                    <label>
                        <strong>Header Background Color</strong>
                        <p class="description">* Set Header Background Color If Image is not available.</p>
                        <input type="color" name="meetup[header][color]" value="<?php echo isset( $evt_page_data['header']['color'] ) ? $evt_page_data['header']['color'] : '#1139df'; ?>" class="form-input" style="height:45px">
                    </label>
                </div>
                <br>
                <div><label><strong>Header Content Position</strong></label></div>
                <?php
                $head_pos = isset( $evt_page_data['header']['position'] ) ? $evt_page_data['header']['position'] : 'bottom';
                ?>
                <div class="inline-grid">
                    <div class="wk-img-toggle">
                        <label>
                            <strong>Bottom</strong>
                            <input type="radio" name="meetup[header][position]" value="bottom" <?php checked( 'bottom', $head_pos ); ?>>
                            <img src="<?php echo get_template_directory_uri() . '/core/meetups/images/header-bottom.png'; ?>" alt="bottom">
                        </label>
                    </div>
                    <div class="wk-img-toggle">
                        <label>
                            <strong>Middle</strong>
                            <input type="radio" name="meetup[header][position]" value="middle" <?php checked( 'middle', $head_pos ); ?>>
                            <img class="wider" src="<?php echo get_template_directory_uri() . '/core/meetups/images/header-middle.png'; ?>" alt="middle">
                        </label>
                    </div>
                </div>
                <br><hr><br>
                <div>
                    <label>
                        <strong>Title</strong>
                        <input type="text" name="meetup[header][title]" value="<?php echo ! empty( $evt_page_data['header']['title'] ) ? $evt_page_data['header']['title'] : false; ?>" class="form-input">
                    </label>
                </div>
                <div>
                    <label>
                        <strong>Tag Line</strong>
                        <input type="text" name="meetup[header][tagline]" value="<?php echo ! empty( $evt_page_data['header']['tagline'] ) ? $evt_page_data['header']['tagline'] : false; ?>" class="form-input">
                    </label>
                </div>
                <br>
                <hr>
                <br>
                <fieldset>
                    <legend>Book Your Spot Details :-</legend>
                    <div>
                        <label>
                            <strong>Booking link</strong>
                            <input type="text" name="meetup[header][booking-link]" value="<?php echo ! empty( $evt_page_data['header']['booking-link'] ) ? $evt_page_data['header']['booking-link'] : false; ?>" class="form-input">
                        </label>
                    </div>
                    <div>
                        <label>
                            <strong>Booking Button Text</strong>
                            <input type="text" name="meetup[header][booking-linklabel]" value="<?php echo ! empty( $evt_page_data['header']['booking-linklabel'] ) ? $evt_page_data['header']['booking-linklabel'] : 'Grab Your Ticket Now !'; ?>" class="form-input">
                        </label>
                    </div>
                    
                </fieldset>
            </div>
            <?php
        },
        'Speakers' => function() use ( $evt_page_data ) {
            ?>
            <div class="form-wrap">

                <span class="mp-add-new">
                    ADD NEW
                    <span class="dashicons dashicons-plus-alt"></span>
                </span>

                <div class="speaker-wrap meetup-tmpl-container ui-sortable wk-is-sortable">
                    <?php
                    if( isset( $evt_page_data['speakers']['meta'] ) ) {
                        foreach( $evt_page_data['speakers']['meta'] as $speaker ) {
                            $speaker_img = ! empty( $speaker['image'] ) ? wp_get_attachment_image_src( $speaker['image'], 'main' )[0] : false;
                            ?>
                            <div class="speaker">
                                <span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
                                <div class="_wk_image_uploader_">
                                    <img src="<?php echo esc_url( $speaker_img ); ?>" class="speaker-img wk_image_src">
                                    <input type="hidden" name="meetup[speaker][meta][image][]" class="wk_image_id" value="<?php echo $speaker['image']; ?>">
                                </div>
                                
                                <div>
                                    <label>
                                        <strong>Name</strong>
                                        <input type="text" name="meetup[speaker][meta][name][]" value="<?php echo $speaker['name']; ?>" class="form-input">
                                    </label>
                                </div>

                                <div>
                                    <label>
                                        <strong>Designation</strong>
                                        <input type="text" name="meetup[speaker][meta][design][]" value="<?php echo $speaker['design']; ?>" class="form-input">
                                    </label>
                                </div>

                                <hr>
                                <br>

                                <div>
                                    <label>
                                        <span class="ssl-icon twitter"></span>
                                        <input type="text" name="meetup[speaker][meta][social][twitter][]" value="<?php echo $speaker['social']['twitter']; ?>" class="form-input">
                                    </label>
                                </div>
                                
                                <div>
                                    <label>
                                        <span class="ssl-icon linkedin"></span>
                                        <input type="text" name="meetup[speaker][meta][social][linkedin][]" value="<?php echo $speaker['social']['linkedin']; ?>" class="form-input">
                                    </label>
                                </div>

                                <div>
                                    <label>
                                        <span class="ssl-icon dribbble"></span>
                                        <input type="text" name="meetup[speaker][meta][social][dribbble][]" value="<?php echo $speaker['social']['dribbble']; ?>" class="form-input">
                                    </label>
                                </div>

                                <div>
                                    <label>
                                        <span class="ssl-icon medium"></span>
                                        <input type="text" name="meetup[speaker][meta][social][medium][]" value="<?php echo $speaker['social']['medium']; ?>" class="form-input">
                                    </label>
                                </div>

                            </div>
                            <?php
                        }
                    }
                    ?>

                </div>

                <template id="meetupSpekearstmpl" class="meetupTmpl">
                    <div class="speaker">
                        <span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
                        <div class="_wk_image_uploader_">
                            <img src="" class="speaker-img wk_image_src">
                            <input type="hidden" name="meetup[speaker][meta][image][]" class="wk_image_id" value="">
                        </div>
                        
                        <div>
                            <label>
                                <strong>Name</strong>
                                <input type="text" name="meetup[speaker][meta][name][]" value="" class="form-input">
                            </label>
                        </div>

                        <div>
                            <label>
                                <strong>Designation</strong>
                                <input type="text" name="meetup[speaker][meta][design][]" value="" class="form-input">
                            </label>
                        </div>

                        <hr>
                        <br>

                        <div>
                            <label>
                                <span class="ssl-icon twitter"></span>
                                <input type="text" name="meetup[speaker][meta][social][twitter][]" value="" class="form-input">
                            </label>
                        </div>
                        
                        <div>
                            <label>
                                <span class="ssl-icon linkedin"></span>
                                <input type="text" name="meetup[speaker][meta][social][linkedin][]" value="" class="form-input">
                            </label>
                        </div>

                        <div>
                            <label>
                                <span class="ssl-icon dribbble"></span>
                                <input type="text" name="meetup[speaker][meta][social][dribbble][]" value="" class="form-input">
                            </label>
                        </div>

                        <div>
                            <label>
                                <span class="ssl-icon medium"></span>
                                <input type="text" name="meetup[speaker][meta][social][medium][]" value="" class="form-input">
                            </label>
                        </div>

                    </div>
                </template>

                <br><hr><br>

                <fieldset>
                    <legend>Register Speaker:-</legend>
                    <?php $speak_reg = ! empty( $evt_page_data['speakers']['registration'] ) ? $evt_page_data['speakers']['registration'] : array(); ?>
                    <div>
                        <label>
                            <strong>Title</strong>
                            <input type="text" name="meetup[speaker][registration][title]" value="<?php echo ! empty( $speak_reg['title'] ) ? $speak_reg['title'] : 'Be a Speaker'; ?>" class="form-input">
                        </label>
                    </div>
                    <div>
                        <label>
                            <strong>Reg. Tagline</strong>
                            <input type="text" name="meetup[speaker][registration][tagline]" value="<?php echo ! empty( $speak_reg['tagline'] ) ? $speak_reg['tagline'] : 'Express your idea or thought which helps the design community.'; ?>" class="form-input">
                        </label>
                    </div>
                    <div>
                        <label>
                            <strong>Reg. Link</strong>
                            <input type="text" name="meetup[speaker][registration][link]" value="<?php echo ! empty( $speak_reg['link'] ) ? $speak_reg['link'] : false; ?>" class="form-input">
                        </label>
                    </div>
                    <!-- <label>
                        <span class="switcher">
                            <input name="meetup[speaker][registration][linktab]" type="checkbox" value="true">
                            <span class="slider round" data-default="Open in Current Screen" data-active="Open in New Tab"></span>
                        </span>
                    </label>
                    <br> -->
                    <div>
                        <label>
                            <strong>Reg. Button Text</strong>
                            <input type="text" name="meetup[speaker][registration][linklabel]" value="<?php echo ! empty( $speak_reg['linklabel'] ) ? $speak_reg['linklabel'] : 'Registration Now'; ?>" class="form-input">
                        </label>
                    </div>
                </fieldset>


            </div>
            <?php
        },
        'Organizers' => function() use ( $evt_page_data ) {
            ?>
            <div class="form-wrap">

                <span class="mp-add-new">
                    ADD NEW
                    <span class="dashicons dashicons-plus-alt"></span>
                </span>

                <br><hr><br>

                <div class="speaker-wrap meetup-tmpl-container ui-sortable wk-is-sortable">
                    <?php
                    if( isset( $evt_page_data['organizers'] ) ) {
                        foreach( $evt_page_data['organizers'] as $org ) {
                            $org_img = ! empty( $org['image'] ) ? wp_get_attachment_image_src( $org['image'], 'main' )[0] : false;
                            ?>
                            <div class="speaker">
                                <span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
                                <div class="_wk_image_uploader_ circular" style="width:100px;height:100px;margin-bottom:20px;">
                                    <img src="<?php echo esc_url( $org_img ); ?>" class="wk_image_src">
                                    <input type="hidden" name="meetup[organizer][image][]" class="wk_image_id" value="<?php echo $org['image']; ?>">
                                </div>
                                
                                <div>
                                    <label>
                                        <strong>Organizer Name</strong>
                                        <input type="text" name="meetup[organizer][name][]" value="<?php echo $org['name']; ?>" class="form-input">
                                    </label>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>

                <template id="meetupSpekearstmpl" class="meetupTmpl">
                    <div class="speaker">
                        <span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
                        <div class="_wk_image_uploader_ circular" style="width:100px;height:100px;margin-bottom:20px;">
                            <img src="" class="wk_image_src">
                            <input type="hidden" name="meetup[organizer][image][]" class="wk_image_id" value="">
                        </div>
                        
                        <div>
                            <label>
                                <strong>Organizer Name</strong>
                                <input type="text" name="meetup[organizer][name][]" value="" class="form-input">
                            </label>
                        </div>
                    </div>
                </template>
            </div>
            <?php
        },
        'Sponsors' => function() use ( $evt_page_data ) {
            ?>
            <div class="form-wrap">
                <span class="mp-add-new">
                    ADD NEW
                    <span class="dashicons dashicons-plus-alt"></span>
                </span>
                <br><hr><br>
                <div class="speaker-wrap meetup-tmpl-container ui-sortable wk-is-sortable">
                    <?php
                    if( isset( $evt_page_data['sponsors']['meta'] ) ) {
                        foreach ( $evt_page_data['sponsors']['meta'] as $sponsor ) {
                            $sponsor_logo = ! empty( $sponsor['logo'] ) ? wp_get_attachment_image_src( $sponsor['logo'] )[0] : false;
                            ?>
                            <div class="speaker">
                                <span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
                                <div class="_wk_image_uploader_">
                                    <img src="<?php echo esc_url( $sponsor_logo ); ?>" class="wk_image_src" style="width: 200px; height: 50px;">
                                    <input type="hidden" name="meetup[sponsors][meta][logo][]" class="wk_image_id" value="<?php echo $sponsor['logo']; ?>">
                                    <input type="hidden" name="meetup[sponsors][meta][name][]" class="wk_image_alt" value="<?php echo $sponsor['name']; ?>">
                                </div>
                                <br>
                                <div>
                                    <label>
                                        <strong>Sponsors Site URL</strong>
                                        <input type="text" name="meetup[sponsors][meta][link][]" value="<?php echo esc_url( $sponsor['link'] ); ?>" class="form-input">
                                    </label>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
                <br><hr><br>
                <fieldset>
                    <legend>Register Sponsors</legend>
                    <?php $spon_reg = ! empty( $evt_page_data['sponsors']['registration'] ) ? $evt_page_data['sponsors']['registration'] : array(); ?>
                    <div class="inline-grid">
                        <div>
                            <label>
                                <strong>Register Link</strong>
                                <input type="text" name="meetup[sponsors][registration][link]" value="<?php echo ! empty( $spon_reg['link'] ) ? $spon_reg['link'] : false; ?>" class="form-input">
                            </label>
                        </div>
                        <div>
                            <label>
                                <strong>Register Link Text</strong>
                                <input type="text" name="meetup[sponsors][registration][linklabel]" value="<?php echo ! empty( $spon_reg['linklabel'] ) ? $spon_reg['linklabel'] : 'Become Sponsor'; ?>" class="form-input">
                            </label>
                        </div>
                    </div>
                </fieldset>
                <template class="meetupTmpl">
                    <div class="speaker">
                        <span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
                        <div class="_wk_image_uploader_">
                            <img src="" class="wk_image_src" style="width: 200px; height: 50px;">
                            <input type="hidden" name="meetup[sponsors][meta][logo][]" class="wk_image_id" value="">
                            <input type="hidden" name="meetup[sponsors][meta][name][]" class="wk_image_alt" value="">
                        </div>
                        <br>
                        <div>
                            <label>
                                <strong>Sponsors Site URL</strong>
                                <input type="text" name="meetup[sponsors][meta][link][]" value="" class="form-input">
                            </label>
                        </div>
                    </div>
                </template>

            </div>
            <?php
        },
        'Gallery' => function() use ( $evt_page_data ) {
            $gal = ! empty( $evt_page_data['gallery'] ) ? $evt_page_data['gallery'] : array();
            $img = ! empty( $evt_page_data['images'] ) ? $evt_page_data['images'] : array();
            ?>
            <div class="form-wrap">
                <div class="gallery-wrapper">
                    <div class="g1">
                        <div class="_wk_img_uploader_">
                            <img src="<?php echo ! empty( $gal['g1']['logo'] ) ? wp_get_attachment_image_src( $gal['g1']['logo'], 'main' )[0] : false; ?>" class="wk_image_src">
                            <input type="hidden" name="meetup[gallery][g1][logo]" class="wk_image_id" value="<?php echo ! empty( $gal['g1']['logo'] ) ? $gal['g1']['logo'] : false; ?>">
                            <input type="hidden" name="meetup[gallery][g1][title]" class="wk_image_alt" value="<?php echo ! empty( $gal['g1']['title'] ) ? $gal['g1']['title'] : false; ?>">
                        </div>
                    </div>
                    <div class="g2">
                        <div class="_wk_img_uploader_">
                            <img src="<?php echo ! empty( $gal['g2']['logo'] ) ? wp_get_attachment_image_src( $gal['g2']['logo'], 'main' )[0] : false; ?>" class="wk_image_src">
                            <input type="hidden" name="meetup[gallery][g2][logo]" class="wk_image_id" value="<?php echo ! empty( $gal['g2']['logo'] ) ? $gal['g2']['logo'] : false; ?>">
                            <input type="hidden" name="meetup[gallery][g2][title]" class="wk_image_alt" value="<?php echo ! empty( $gal['g2']['title'] ) ? $gal['g2']['title'] : false; ?>">
                        </div>
                    </div>
                    <div class="g3">
                        <div class="_wk_img_uploader_">
                            <img src="<?php echo ! empty( $gal['g3']['logo'] ) ? wp_get_attachment_image_src( $gal['g3']['logo'], 'main' )[0] : false; ?>" class="wk_image_src">
                            <input type="hidden" name="meetup[gallery][g3][logo]" class="wk_image_id" value="<?php echo ! empty( $gal['g3']['logo'] ) ? $gal['g3']['logo'] : false; ?>">
                            <input type="hidden" name="meetup[gallery][g3][title]" class="wk_image_alt" value="<?php echo ! empty( $gal['g3']['title'] ) ? $gal['g3']['title'] : false; ?>">
                        </div>
                    </div>
                    <div class="g4">
                        <div class="_wk_img_uploader_">
                            <img src="<?php echo ! empty( $gal['g4']['logo'] ) ? wp_get_attachment_image_src( $gal['g4']['logo'], 'main' )[0] : false; ?>" class="wk_image_src">
                            <input type="hidden" name="meetup[gallery][g4][logo]" class="wk_image_id" value="<?php echo ! empty( $gal['g4']['logo'] ) ? $gal['g4']['logo'] : false; ?>">
                            <input type="hidden" name="meetup[gallery][g4][title]" class="wk_image_alt" value="<?php echo ! empty( $gal['g4']['title'] ) ? $gal['g4']['title'] : false; ?>">
                        </div>
                    </div>
                    <div class="g5">
                        <div class="_wk_img_uploader_">
                            <img src="<?php echo ! empty( $gal['g5']['logo'] ) ? wp_get_attachment_image_src( $gal['g5']['logo'], 'main' )[0] : false; ?>" class="wk_image_src">
                            <input type="hidden" name="meetup[gallery][g5][logo]" class="wk_image_id" value="<?php echo ! empty( $gal['g5']['logo'] ) ? $gal['g5']['logo'] : false; ?>">
                            <input type="hidden" name="meetup[gallery][g5][title]" class="wk_image_alt" value="<?php echo ! empty( $gal['g5']['title'] ) ? $gal['g5']['title'] : false; ?>">
                        </div>
                    </div>
                    <div class="g6">
                        <div class="_wk_img_uploader_">
                            <img src="<?php echo ! empty( $gal['g6']['logo'] ) ? wp_get_attachment_image_src( $gal['g6']['logo'], 'main' )[0] : false; ?>" class="wk_image_src">
                            <input type="hidden" name="meetup[gallery][g6][logo]" class="wk_image_id" value="<?php echo ! empty( $gal['g6']['logo'] ) ? $gal['g6']['logo'] : false; ?>">
                            <input type="hidden" name="meetup[gallery][g6][title]" class="wk_image_alt" value="<?php echo ! empty( $gal['g6']['title'] ) ? $gal['g6']['title'] : false; ?>">
                        </div>
                    </div>
                </div>
                <br><hr><br>
                <fieldset>
                    <legend>Meetup Images Link</legend>
                    <p class="description">*Setup link button for Meetup Images</p>
                    <div class="inline-grid">
                        <div>
                            <label>
                                <strong>Images Link Label</strong>
                                <input type="text" name="meetup[images][linklabel]" value="<?php echo isset( $img['linklabel'] ) ? esc_html( $img['linklabel'] ) : 'Photos'; ?>" class="form-input">
                            </label>
                        </div>
                        <div>
                            <label>
                                <strong>Images Link</strong>
                                <input type="text" name="meetup[images][link]" value="<?php echo isset( $img['link'] ) ? esc_url( $img['link'] ) : false; ?>" class="form-input">
                            </label>
                        </div>
                    </div>
                </fieldset>
            </div>
            <?php
        },
        'Event Data' => function() use ( $evt_data ) {

            ?>
            <div class="form-wrap">
                <div class="inline-grid">
                    <div>
                        <label>
                            <strong>Start Date & Time( 24hrs )</strong>
                            <input type="datetime-local" name="meetup[event-data][start-date]" value="<?php echo ! empty( $evt_data['start-date'] ) ? $evt_data['start-date'] : false; ?>" class="form-input">
                        </label>
                    </div>
                    <div>
                        <label>
                            <strong>End Date & Time( 24Hrs )</strong>
                            <input type="datetime-local" name="meetup[event-data][end-date]" value="<?php echo ! empty( $evt_data['end-date'] ) ? $evt_data['end-date'] : false; ?>" class="form-input">
                        </label>
                    </div>
                </div>
                
                <label><strong>Venue</strong></label>
                <div class="inline-grid">
                    <!-- <br> -->
                    <?php $venue = ! empty( $evt_data['venue'] ) ? $evt_data['venue'] : 'head-office'; ?>
                    <label>
                        <span class="switcher">
                            <input name="meetup[event-data][venue]" type="radio" value="head-office" <?php checked( 'head-office', $venue ); ?>>
                            <span class="slider round" data-default="Webkul Head-Office(H-28)" data-active="Webkul Head-Office(H-28)"></span>
                        </span>
                    </label>
                    <label>
                        <span class="switcher">
                            <input name="meetup[event-data][venue]" type="radio" value="branch" <?php checked( 'branch', $venue ); ?>>
                            <span class="slider round" data-default="Webkul Branch(A-67)" data-active="Webkul Branch(A-67)"></span>
                        </span>
                    </label>
                </div>


                <br><hr><br>

                <fieldset>
                    <legend>*Only For SEO</legend>
                    <div>
                        <label for="">
                            <strong>Event Name</strong>
                            <input name="meetup[event-data][name]" type="text" class="form-input" value="<?php echo ! empty( $evt_data['name'] ) ? esc_html( $evt_data['name'] ) : false; ?>">
                        </label>
                    </div>
                    <div>
                        <label for="">
                            <strong>Event Description</strong>
                            <textarea name="meetup[event-data][description]" class="form-input" ><?php echo ! empty( $evt_data['description'] ) ? esc_html( $evt_data['description'] ) : false; ?></textarea>
                        </label>
                    </div>
                </fieldset>

                
                <br><hr><br>

                <fieldset>
                    <legend>Twitter Hashtags</legend>
                    <div>
                        <label>
                            <span class="mpsl-link twitter"></span>
                            <input type="text" name="meetup[event-data][social][twitter]" class="form-input" value="<?php echo ! empty( $evt_data['social']['twitter'] ) ? esc_html( $evt_data['social']['twitter'] ) : false; ?>">
                            <p class="description">*No need to add "#". Eg. Webkul Meetup, Webkul Event</p>
                        </label>
                    </div>
                </fieldset>

            </div>
            <?php
        },
        'Highlights' => function() use ( $evt_page_data ) {
            ?>
            <div class="form-wrap">
                <div>
                    <label>
                        <strong>Title</strong>
                        <input type="text" name="meetup[highlights][title]" value="<?php echo ! empty( $evt_page_data['highlights']['title'] ) ? $evt_page_data['highlights']['title'] : 'Highlights'; ?>" class="form-input">
                    </label>
                </div>
                <div><label><strong>Points</strong></label></div>

                <span class="mp-add-new" data-insert="append">
                    Add Points
                    <span class="dashicons dashicons-plus-alt"></span>
                </span>
                <div class="meetup-tmpl-container">
                    <?php
                    if( isset( $evt_page_data['highlights']['points'] ) ) {
                        foreach( $evt_page_data['highlights']['points'] as $point ) {
                            if( ! empty( $point ) ) {
                                echo '<input type="text" name="meetup[highlights][points][]" class="form-input" value="' .  esc_html( $point ) . '">';
                            }
                        }
                    }
                    ?>
                </div>
                <template class="meetupTmpl">
                    <div>
                        <label>
                            <input type="text" name="meetup[highlights][points][]" value="" class="form-input">
                        </label>
                    </div>
                </template>
            </div>
            <?php

        },
        'Past Event & suggestion' => function() use ( $evt_page_data ) {
            $past_event = ! empty( $evt_page_data['past-event'] ) ? $evt_page_data['past-event'] : array();
            $suggestion = ! empty( $evt_page_data['suggestion'] ) ? $evt_page_data['suggestion'] : array();
            ?>
            <div class="form-wrap">
                <fieldset>
                    <legend>Past Event</legend>
                    <div class="_wk_image_uploader_" style="display: inline-block;">
                        <img src="<?php echo ! empty( $past_event['image'] ) ? wp_get_attachment_image_src( $past_event['image'], 'main' )[0] : false; ?>" class="wk_image_src" style="width: 250px;display:block;min-height:80px;">
                        <input type="hidden" class="wk_image_id" name="meetup[past-event][image]" value="<?php echo ! empty( $past_event['image'] ) ? $past_event['image'] : false; ?>">
                    </div>
                    <div>
                        <label>
                            <strong>Section Title</strong>
                            <input type="text" class="form-input" name="meetup[past-event][text]" value="<?php echo ! empty( $past_event['text'] ) ? $past_event['text'] : 'See our past events'; ?>">
                        </label>
                    </div>
                    <div>
                        <label>
                            <strong>Section Description</strong>
                            <input type="text" class="form-input" name="meetup[past-event][description]" value="<?php echo ! empty( $past_event['description'] ) ? $past_event['description'] : 'We organized the meetup regularly to deliver our best to the community.';?>">
                        </label>
                    </div>
                    <span class="mp-add-new">
                        ADD Links
                        <span class="dashicons dashicons-plus-alt"></span>
                    </span>
                    <div class="meetup-tmpl-container">
                        <?php
                        if( isset( $past_event['links'] ) ) {
                            foreach( $past_event['links'] as $pe_link ) {
                                if( ! empty( $pe_link['link'] ) || ! empty( $pe_link['linklabel'] ) ) {
                                    ?>
                                    <div class="inline-grid">
                                        <div>
                                            <label>
                                                <strong>Past Event Link</strong>
                                                <input type="text" class="form-input" name="meetup[past-event][links][link][]" value="<?php echo $pe_link['link']; ?>">
                                            </label>
                                        </div>
                                        <div>
                                            <label>
                                                <strong>Past Event link Label</strong>
                                                <input type="text" class="form-input" name="meetup[past-event][links][linklabel][]" value="<?php echo $pe_link['linklabel']; ?>">
                                            </label>
                                        </div>
                                    </div>
                                    <?php

                                }
                            }
                        }
                        ?>
                    </div>

                    <template class="meetupTmpl">
                        <div class="inline-grid">
                            <div>
                                <label>
                                    <strong>Past Event Link</strong>
                                    <input type="text" class="form-input" name="meetup[past-event][links][link][]">
                                </label>
                            </div>
                            <div>
                                <label>
                                    <strong>Past Event link Label</strong>
                                    <input type="text" class="form-input" name="meetup[past-event][links][linklabel][]" value="Meetup 2019">
                                </label>
                            </div>
                        </div>
                    </template>

                </fieldset>
                
                <br><hr><br>

                <fieldset>
                    <legend>Suggestion Box</legend>
                    <div class="_wk_image_uploader_" style="display: inline-block;">
                        <img src="<?php echo ! empty( $suggestion['image'] ) ? wp_get_attachment_image_src( $suggestion['image'], 'main' )[0] : false; ?>" class="wk_image_src" style="width: 250px;display:block;min-height:80px;">
                        <input type="hidden" class="wk_image_id" name="meetup[suggestion][image]" value="<?php echo ! empty( $suggestion['image'] ) ? $suggestion['image'] : false; ?>">
                    </div>
                    <div>
                        <label>
                            <strong>Section Text</strong>
                            <input type="text" class="form-input" name="meetup[suggestion][text]" value="<?php echo ! empty( $suggestion['text'] ) ? $suggestion['text'] : 'We are eager to know your\'s opinion about our pre or post meetups and speakers. Your valuable suggestion will consider.'; ?>">
                        </label>
                    </div>
                    <div class="inline-grid">
                        <div>
                            <label>
                                <strong>Suggestion Link</strong>
                                <input type="text" class="form-input" name="meetup[suggestion][link]" value="<?php echo ! empty( $suggestion['link'] ) ? $suggestion['link'] : false; ?>">
                            </label>
                        </div>
                        <div>
                            <label>
                                <strong>Suggestion link Label</strong>
                                <input type="text" class="form-input" name="meetup[suggestion][linklabel]" value="<?php echo ! empty( $suggestion['linklabel'] ) ? $suggestion['linklabel'] : 'Say Hi!'; ?>">
                            </label>
                        </div>
                    </div>
                </fieldset>
            </div>
            <?php
        },
        'Archive Image' => function() use( $arc_img ) {
            $org_img = ! empty( $org['image'] ) ? wp_get_attachment_image_src( $org['image'], 'main' )[0] : false;
            ?>
            <div class="form-wrap">
                <label><strong>Archive Image</strong></label>
                <p>*This image will be used on meetup listing page. <a href="<?php echo site_url( '/meetups/' ); ?>" target="_blank" rel="noopener noreferrer">Check Listing Page.</a></p>
                <div class="_wk_image_uploader_" style="height: 180px;width:350px">
                    <img src="<?php echo ! empty( $arc_img ) ? wp_get_attachment_image_src( $arc_img, 'main' )[0] : false; ?>" class="wk_image_src" style="display: block; height: 100%; width: 100%; object-fit: cover;">
                    <input type="hidden" class="wk_image_id" name="meetup[archive-image]" value="<?php echo $arc_img; ?>">
                </div>
            </div>
            <?php
        },
    );
}

add_action( 'save_post', function( $post_id ) {

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( ! isset( $_POST['__wkmeetup_nonce'] ) || ! wp_verify_nonce( $_POST['__wkmeetup_nonce'], '__wkmeetup_nonce_key_' ) ) {
        return;
    }

    if ( 'meetups' !== get_post_type( $post_id ) ) {
        return;
    }
    $event_location = array(
        'branch' => array(
            'street'  => 'A-67, Sector 63',
            'city'    => 'Noida',
            'state'   => 'Uttar Pradesh',
            'pincode' => '201301',
            'country' => 'India',
            'lat'     => '28.62664031982422',
            'lon'     => '77.38480377197266',
            'map'     => 'https://goo.gl/maps/6K5ASGepiwbtN2yq7',
        ),
        'head-office' => array(
            'street'  => 'H-28, ARV Park, Sector 63',
            'city'    => 'Noida',
            'state'   => 'Uttar Pradesh',
            'pincode' => '201301',
            'country' => 'India',
            'lat'     => '28.629606246948242',
            'lon'     => '77.3785400390625',
            'map'     => 'https://goo.gl/maps/bQDs1JPKRFe4WDhE8',
        ),
    );

    
    /*========================================================================================
                                         Speaker Section
    ==========================================================================================*/

    $speaker_meta = ! empty( $_POST['meetup']['speaker']['meta'] ) ? $_POST['meetup']['speaker']['meta'] : array();

    $speaker_links = ! empty( $_POST['meetup']['speaker']['meta']['social'] ) ? $_POST['meetup']['speaker']['meta']['social'] : array();

    $speaker_reg   = $_POST['meetup']['speaker']['registration'];
    $s_keys        = array_keys( $speaker_meta );
    $s_links_keys  = array_keys( $speaker_links );

    $ssl = $speaker = $temp_speak = $temp_ssl = array();
    
    // Array restructure for Speaker Social Links
    if( isset( $speaker_links['twitter'] ) ) {
        foreach ( $speaker_links['twitter'] as $key => $value ) {
            foreach( $s_links_keys as $social ) {
                $temp_ssl[ $social ] = $speaker_links[ $social ][ $key ];
            }
            array_push( $ssl, $temp_ssl );
        }
    }
    
    // Array restructure for Speaker meta
    if( isset( $speaker_meta['name'] ) || isset( $speaker_meta['image'] ) ) {
        foreach( $speaker_meta['name'] as $key => $value ) {
            foreach( $s_keys as $s_meta ) {
                if( 'social' === $s_meta ) {
                    $temp_speak['social'] = $ssl[ $key ];
                } else {
                    $temp_speak[ $s_meta ] = $speaker_meta[ $s_meta ][ $key ];
                }
            }
            array_push( $speaker, $temp_speak );
        }
    }

    $meetup['speakers'] = array(
        'meta'         => $speaker,
        'registration' => $speaker_reg,
    );


    /*========================================================================================
                                         Sponsors Section
    ==========================================================================================*/

    $sponsor_meta = ! empty( $_POST['meetup']['sponsors']['meta'] ) ? $_POST['meetup']['sponsors']['meta'] : array();

    $sponsor_reg = ! empty( $_POST['meetup']['sponsors']['registration'] ) ? $_POST['meetup']['sponsors']['registration'] : array();

    $spon_keys = array_keys( $sponsor_meta );

    $sponsors = $temp_sponsor = array();

    if ( isset( $sponsor_meta['logo'] ) ) {
        foreach ( $sponsor_meta['logo'] as $key => $value ) {
            foreach ( $spon_keys as $spon ) {
                $temp_sponsor[ $spon ] = $sponsor_meta[ $spon ][ $key ];
            }
            array_push( $sponsors, $temp_sponsor );
        }
    }

    $meetup['sponsors'] = array(
        'meta'         => $sponsors,
        'registration' => $sponsor_reg,
    );


    /*========================================================================================
                                         Organizer Section
    ==========================================================================================*/

    $organizer_meta = ! empty( $_POST['meetup']['organizer'] ) ? $_POST['meetup']['organizer'] : array();

    $orgs_keys = array_keys( $organizer_meta );
    
    $orgs = $temp_orgs = array();
    
    if ( isset( $organizer_meta['image'] ) ) {
        foreach ( $organizer_meta['image'] as $key => $value ) {
            foreach ( $orgs_keys as $org_k ) {
                $temp_orgs[ $org_k ] = $organizer_meta[ $org_k ][ $key ];
            }
            array_push( $orgs, $temp_orgs );
        }
    }
    
    $meetup['organizers'] = $orgs;

    /*========================================================================================
                                         Past Event Section
    ==========================================================================================*/

    $past_evt = ! empty( $_POST['meetup']['past-event'] ) ? $_POST['meetup']['past-event'] : array();

    $past_evt_links = ! empty( $_POST['meetup']['past-event']['links'] ) ? $_POST['meetup']['past-event']['links'] : array();

    $evt_links = array();

    if( isset( $past_evt_links['link'] ) ) {
        foreach ( $past_evt_links['link'] as $key => $value ) {
            if( ! empty( $value ) || ! empty( $past_evt_links['linklabel'][ $key ] ) ) {
                $temp_links['link']      = $value;
                $temp_links['linklabel'] = $past_evt_links['linklabel'][ $key ];
                array_push( $evt_links, $temp_links );
            }
        }
    }
    $past_evt['links'] = $evt_links;
    
    $meetup['past-event'] = $past_evt;

    /*========================================================================================
    ==========================================================================================*/

    $meetup['header']        = $_POST['meetup']['header'];
    $meetup['gallery']       = $_POST['meetup']['gallery'];
    $meetup['images']        = $_POST['meetup']['images'];
    $meetup['suggestion']    = $_POST['meetup']['suggestion'];
    $meetup['archive-image'] = $_POST['meetup']['archive-image'];

    $meetup['highlights'] = array(
        'title'  => $_POST['meetup']['highlights']['title'],
        'points' => isset( $_POST['meetup']['highlights']['points'] ) ? array_filter( $_POST['meetup']['highlights']['points'] ) : array(),
    );

    update_post_meta( $post_id, '__wk_meetup_page_data_', $meetup );


    /*========================================================================================
                                    Event Data Section
    ==========================================================================================*/

    $event_data = ! empty( $_POST['meetup']['event-data'] ) ? $_POST['meetup']['event-data'] : array();
    $event_venue = ! empty( $event_data['venue'] ) ? $event_data['venue'] : 'branch';

    $event_data['location'] = $event_location[ $event_venue ];

    $event_date = isset( $_POST['meetup']['event-data']['start-date'] ) ? $_POST['meetup']['event-data']['start-date'] : false;

    update_post_meta( $post_id, '__wk_meetup_data_', $event_data );

    
    // This key used to sort event on it's listing page.
    update_post_meta( $post_id, '__wk_meetup_date_', $event_date );
} );

function __wkimg_by_id( $id, $size = 'thumbnail' ) {
    if( empty( $id ) ) {
        return;
    }
    return wp_get_attachment_image_src( $id, $size )[0];
}

function wk_meetup_single_template( $single_template ) {
    global $post;

    if ( $post->post_type == 'meetups' ) {
         $single_template = dirname( __FILE__ ) . '/single-meetups.php';
    }
    return $single_template;
}

add_filter( "single_template", "wk_meetup_single_template" );

function wk_meetup_archive_template( $archive_template ) {
    global $post;

    if ( $post->post_type == 'meetups' ) {
         $archive_template = dirname( __FILE__ ) . '/archive-meetups.php';
    }
    return $archive_template;
}

add_filter( "archive_template", "wk_meetup_archive_template" );
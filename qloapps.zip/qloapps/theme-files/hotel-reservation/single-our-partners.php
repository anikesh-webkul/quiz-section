
<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation   
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();
?>
<section class="wrapper">
    <div class="our-partner-header">
        <div class="container">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="partner-detail-header">
                    <div class="col-md-10">
                        <?php
                            $url = get_post_meta($post->ID, 'partner-logo', true);

                            if ( !empty($url)) : 
                        ?>

                                <img src="<?php echo $url;?>" class="img-responsive front-partner-logo">
                               
                            <?php endif;?>
                    </div>
                </div>
                <div class="col-md-1"></div>
            </div>
        </div>
    </div>
    <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="who-they-are">
                        <h1>Who They Are ? </h1>
                         <?php
               
                        if ( have_posts() ) :
                            while(have_posts() ) : the_post(); ?>
                                <?php echo the_content(); ?>
                                <?php $abc = get_post_meta($post->ID, 'partner-url', true);?>
                                
                                <p>Site Link -<a href="<?php  echo $abc; ?>" target="_blank">&emsp;<?php echo $abc; ?></a></p>
                        <?php                                              
                            endwhile;
                        endif; 
                        ?>
                    </div>
                </div>   
            </div>         
    </div>
    <div class="newsletter-wrapper">
        <div class="container">
            <div id="mc_embed_signup" class="subscribe-now">           
              <form action="//qloapps.us8.list-manage.com/subscribe/post?u=a6022fbcc8eb59ebd26658e1c&amp;id=96917c5642" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                <div id="mc_embed_signup_scroll">
                  <h3 class="text-default text-center">Subscribe Our Newsletter <span>Get the Latest Updates About Our Product on Subscribing Here</span></h3>
                    
                  <div class="mc-field-group">
                      <input type="email" placeholder="Enter Your Email Here" name="EMAIL" class="required email" id="mce-EMAIL">
                  </div>
                  <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_a6022fbcc8eb59ebd26658e1c_be6f4be20e" tabindex="-1" value=""></div>
                  <div class="clear"> 
                    <input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="white btn btn-bgcolor btn-subscribe">
                  </div>
                  <div id="mce-responses" class="clear">
                    <div class="response" id="mce-error-response" style="display:none"></div>
                    <div class="response" id="mce-success-response" style="display:none"></div>
                  </div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                </div>
              </form>
            </div>
        </div>
    </div>

 
</section>   
<?php get_footer();?>



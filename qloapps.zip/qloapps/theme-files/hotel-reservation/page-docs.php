<?php
/**
 * The template for displaying Blogs
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();

blog_navbar( $post->post_name );

?>
<div class="wk-page-blog-sec ">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<?php
				$args = array(
					'post_type'      => 'post',
					'posts_per_page' => get_option( 'posts_per_page' ),
					'meta_key'       => 'qlo_filter',
					'meta_value'     => 'doc',
					'paged'          => get_pagenumber_args(),
					'post_status'    => 'publish',
				);

				$all_posts = new WP_Query( $args );

				if ( $all_posts->have_posts() ) {

					?>
					<div class="qblog-archives text-left">
					<?php

					while ( $all_posts->have_posts() ) {

						$all_posts->the_post();

						get_template_part( 'content', 'blog' );
					}

					?>
					</div>
					<?php

				} else {
					get_template_part( 'content', 'none' );
				}
				?>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<div class="wk-pagination-wrapper">
					<?php hotelreservation_pagination( $all_posts->found_posts ); ?>
				</div>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
</div>

<?php
get_footer();

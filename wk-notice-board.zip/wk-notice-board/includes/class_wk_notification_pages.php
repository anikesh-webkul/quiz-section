<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Wk_Notification_Handler' ) ) {

	class Wk_Notification_Handler {

		function __construct() {

			add_action( 'wp_enqueue_scripts', array( $this, 'wk_notification_script' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'wk_admin_notification_script' ) );
			add_action( 'init', array( $this, 'wn_admin_menus' ) );
		}

		// Front css & js enqueue
		function wk_notification_script() {
			wp_enqueue_style( 'wn-style', WN_DIR . 'assets/dist/css/wn_style.min.css', array(), WN_VERSION );
			wp_enqueue_script( 'wn-script', WN_DIR . 'assets/dist/js/wn_script.min.js', array(), WN_VERSION );
		}

		// Backend css & js enqueue
		function wk_admin_notification_script() {
			$up = wp_upload_dir();
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script( 'jquery-ui-sortable' );
			wp_enqueue_style( 'wn-admin-style', WN_DIR . 'assets/dist/css/wn_admin.min.css', array(), WN_VERSION );
			wp_enqueue_script( 'wn-admin-script', WN_DIR . 'assets/dist/js/wn_admin.min.js', array( 'jquery', 'jquery-ui-sortable', 'wp-color-picker' ), WN_VERSION );
			wp_localize_script( 'wn-admin-script', 'wn_baseurl_var', array(
				'base'  => $up['baseurl'],
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'wk_notification_nonce' ),
			));
		}

		function wn_admin_menus() {
			add_action( 'admin_menu', array( $this, 'notification_admin_menus' ) );
		}

		// Added Notification Dashboard Menus
		function notification_admin_menus() {

			$hook  = add_menu_page( __( 'Notice Board' ), __( 'Notice Board' ), 'publish_posts', 'webkul-notifications', array( $this, 'webkul_notification_list' ), '', 20 );
			$hook .= add_submenu_page( 'webkul-notifications', __( 'Add Notification' ), __( 'Add Notification' ), 'edit_posts', 'add-notifications', array( $this, 'webkul_add_notification' ), 10 );

			add_submenu_page( 'webkul-notifications', __( 'Settings' ), __( 'Settings' ), 'edit_posts', 'notification-setting', array( $this, 'notification_settings' ), 10 );

			add_action( "load-$hook", array( $this, 'notification_option_detail' ) );
			add_filter( 'set-screen-option', array( $this, 'notification_set_option' ), 10, 3 );
		}

		function webkul_notification_list() {
			require_once WN_DIR_PATH . 'templates/admin/class-wk-notification-list.php';
		}

		public function notification_set_option( $status, $option, $value ) {
			return $value;
		}

		public function notification_option_detail() {
			$option = 'per_page';
			$args   = array(
				'label'   => 'Notification',
				'default' => 10,
				'option'  => 'notification_per_page',
			);
			add_screen_option( $option, $args );
		}

		public function webkul_add_notification() {
			require_once WN_DIR_PATH . '/templates/admin/class-wk-add-notification.php';
		}
		public function notification_settings() {
			if ( isset( $_POST['banner_settings'] ) ) {
				$_POST['wc_custom_banner_background_color']      = sanitize_text_field( $_POST['wc_custom_banner_background_color'] );
				$_POST['wc_custom_banner_text_color']            = sanitize_text_field( $_POST['wc_custom_banner_text_color'] );
				$_POST['wc_custom_banner_link_color']            = sanitize_text_field( $_POST['wc_custom_banner_link_color'] );
				$_POST['wc_custom_banner_link_background_color'] = sanitize_text_field( $_POST['wc_custom_banner_link_background_color'] );
				$banner_background_wb                            = update_option( 'wc_custom_banner_background_color', $_POST['wc_custom_banner_background_color'] );
				$banner_text_color_wb                            = update_option( 'wc_custom_banner_text_color', $_POST['wc_custom_banner_text_color'] );
				$banner_link_color_wb                            = update_option( 'wc_custom_banner_link_color', $_POST['wc_custom_banner_link_color'] );
				$banner_link_back_color_wb                       = update_option( 'wc_custom_banner_link_background_color', $_POST['wc_custom_banner_link_background_color'] );
				if ( $banner_link_back_color_wb || $banner_link_color_wb || $banner_text_color_wb || $banner_background_wb ) {
								echo '<div class="notice notice-success">';
								echo '<p>Settings Changed successfully.</p>';
								echo '</div>';
				} else {
								echo '<div class="notice notice-error">';
								echo '<p>There was an error.</p>';
								echo '</div>';
				}
			}

			require_once WN_DIR_PATH . '/templates/admin/class-wk-notification-setting.php';
		}

	}
	return new Wk_Notification_Handler();
}
registerBlockType( 'wk-blocks/block-wrapper', {
    title : 'Block Wrapper',
    category: 'webkul',
    attributes:{
        selectField: {
            type: 'string',
            default:'wk-blocks/all-block-allowed'
        },
        gridItem: {
            type:'string',
            default:'1'
        },
        bgElement: {
            type:'boolean',
            default:false
        },
		layoutVariant: {
			type: 'string',
			default: 'view-variant--fall'
		}
    },

    edit: function( props ) {
        bgElement = props.attributes.bgElement;
        ('undefined' == typeof ALLOWED_BLOCKS) && ( ALLOWED_BLOCKS = [] );
        selectField = props.attributes.selectField;
		ALLOWED_BLOCKS = [selectField];

        layoutVariant = props.attributes.layoutVariant;

		('undefined' == typeof props.attributes.layoutVariant) && (props.attributes.layoutVariant = 'view-variant--fall');
		

        if( ALLOWED_BLOCKS.includes('wk-blocks/all-block-allowed') ) {
            ALLOWED_BLOCKS = [];
        }

        function onChangeBGElement( newValue ) {
            props.setAttributes( {bgElement:newValue} );
        }
        
        function onChangeSelectField( newValue ) {
            props.setAttributes( { selectField: newValue } );
            if(newValue.includes('wk-blocks/all-block-allowed')) {
                ALLOWED_BLOCKS = [];
            } else {
                ALLOWED_BLOCKS = [newValue];
            }
        }
        function onChangeGridView(newView) {
            props.setAttributes( { gridItem: newView } );
		}
		function onChangeVariation(variant) {
            props.setAttributes( { layoutVariant: variant } );
		}
        return el(
            Fragment,
            {},
            el(
                InspectorControls,
                {},
                el(
                    PanelBody,
                    {
                        title:'Allowed Blocks Setting',
                        initial:true
                    },
                    el(
						SelectControl,
						{
							label: 'Select Allowed blocks',
                            value: selectField,
                            style:{
                                'pointer-events': 'none',
                            },
                            multiple:false,
							options: [
                                {
                                    value: 'wk-blocks/all-block-allowed',
									label: 'All'
								},
                                {
                                    value: 'wk-blocks/review-slider',
                                    label: 'Review Slider'
                                },
                                {
                                    value: 'wk-blocks/caption-icons',
                                    label: 'Caption Icons'
                                },
                                {
                                    value: 'wk-blocks/special-links',
                                    label: 'Special Links'
                                },
                                {
                                    value: 'wk-blocks/fancy-links',
                                    label: 'Fancy Links'
                                },
                                {
                                    value: 'wk-blocks/image-gallery',
                                    label: 'Image Gallery'
                                },
                                {
                                    value: 'wk-blocks/jumbotron',
                                    label: 'Jumbotron'
                                },
                                {
                                    value: 'wk-blocks/inline-column',
                                    label: 'Column Layout'
                                },
                                {
                                    value: 'wk-blocks/success-story',
                                    label: 'Success Story'
                                },
                                {
                                    value: 'wk-blocks/block-wrapper',
                                    label: 'Block Wrapper'
								},
								{
                                    value: 'wk-blocks/card',
                                    label: 'Card'
                                },
                                {
                                    value: 'wk-blocks/wk-no-block-allowed',
                                    label: 'No Block'
                                },
							],
							onChange: onChangeSelectField
						}
                    ),
                    el(
                        PanelRow,
                        {},
                        el(
                            SelectControl,
                            {
                                label: 'Editor Item View',
                                value: props.attributes.gridItem,
                                multiple:false,
                                options: [
                                    {
                                        value: '1',
                                        label: '1'
                                    },
                                    {
                                        value: '2',
                                        label: '2'
                                    },
                                    {
                                        value: '3',
                                        label: '3'
                                    },
                                    {
                                        value: '4',
                                        label: '4'
                                    },
                                    {
                                        value: '5',
                                        label: '5'
                                    },
                                    {
                                        value: '6',
                                        label: '6'
                                    },
                                   
                                ],
                                onChange:onChangeGridView
                            },
                        ),
                    ),
                    el('p',{className:'description'},'*Only use in editor, there is not any impact on frontend'),
					el('hr', {}),
					el(
						SelectControl,
						{
							label: 'Layout Variations',
                            value: layoutVariant,
                            multiple:false,
							options: [
                                {
                                    value: 'view-variant--fall',
									label: 'Fall'
								},
                                {
                                    value: 'view-variant--lateral',
                                    label: 'Lateral'
                                },
							],
							onChange: onChangeVariation
						}
                    ),
                    el(
                        ToggleControl,
                        {
                            label:'Add Background on Each Item**',
                            checked:props.attributes.bgElement,
                            onChange:onChangeBGElement,
                        },
                    ),

                ),
            ),
            el(
                'div',
                {
                    className:'wk-block-wrapper',
                },
                el(
                    'div',
                    {
                        className: props.className + ' ' + layoutVariant,
                        'wk-data-type':selectField,
                        'data-view-count':props.attributes.gridItem,
                        // 'layout-variant':props.attributes.layoutVariant
                    },
                    el( InnerBlocks,
                        {
                            allowedBlocks: ('undefined' != typeof ALLOWED_BLOCKS && ALLOWED_BLOCKS.length > 0 ) ? ALLOWED_BLOCKS : true,
                        }
                    )
                )
            )

        );
    },

    save: function( props ) {
        ( ! props.attributes.className ) && ( props.attributes.className = '' );
        if( props.attributes.bgElement ) {
            if ( ! props.attributes.className.split( ' ' ).includes( 'block-with-bg' ) ) {
                props.attributes.className = props.attributes.className.concat( ' ', 'block-with-bg' ).trim();
            }
        } else {
            props.attributes.className = props.attributes.className.replace( 'block-with-bg', '' ).trim();
		}
		
        layoutVariant = props.attributes.layoutVariant;

		('undefined' == typeof props.attributes.layoutVariant) && (props.attributes.layoutVariant = 'view-variant--fall');

        return el(
            Fragment,
            null,
            el(
                'div',
				{
					className: props.attributes.className + ' ' + layoutVariant,
					// layoutVariant:props.attributes.layoutVariant
				},
                el( InnerBlocks.Content )
            )
        );
    },


} );
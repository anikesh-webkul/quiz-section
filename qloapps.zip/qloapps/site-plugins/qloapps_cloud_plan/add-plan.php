<?php
if( ! defined ( 'ABSPATH' ) ) {
  exit;
}
$qa_plan_error = array();
if ( isset( $_POST['submit'] ) ) {


  if ( '' == $_POST['feature'] || empty( $_POST['plan-id'] ) || ! isset( $_POST['plan'] ) || ! isset( $_POST['package'] ) ) {
    $qa_plan_error['error'] = true;
    goto cancel;
  }

  $all_plans = ( get_option( 'qa_cloud_plans' ) ) ? maybe_unserialize( get_option( 'qa_cloud_plans' ) ) : array() ;
  if( isset( $_GET['action'] ) && 'edit' == $_GET['action'] ) {
    foreach ($all_plans as $key => $value) {
      if( $_POST['plan-id'] == $value['id'] ) {
        $all_plans[$key]['plan'] = wp_unslash( $_POST['plan'] );
        $all_plans[$key]['feature'] = wp_unslash( $_POST['feature'] );
        $all_plans[$key]['package'] = wp_unslash( $_POST['package'] );
      }
    }

  } else {
    foreach ($all_plans as $key => $value) {
      if( strtolower( $value['feature'] ) === strtolower( wp_unslash( $_POST['feature'] ) ) ) {
        $qa_plan_error['plan_exist'] = true;
        goto cancel;
      }
    }
    $save_plan = array(
      'id'      => wp_unslash( $_POST['plan-id'] ),
      'feature' => wp_unslash( $_POST['feature'] ),
      'plan'    => wp_unslash( $_POST['plan'] ),
      'package' => wp_unslash( $_POST['package'] ),
      'status'  => 'displayed',
    );
    array_push($all_plans,$save_plan);

  }

  $all_plans = maybe_serialize( $all_plans );
  if ( update_option( 'qa_cloud_plans', $all_plans ) ) {
    $qa_plan_error['status'] = true;
    wp_redirect( admin_url() . 'admin.php?page=add_cloud_plan&&status=success' );
  }
}
cancel: false; //break if condition when value is not field
$plan_id = ( isset( $_GET['plan-id'] ) && ! empty( $_GET['plan-id'] ) ) ? $_GET['plan-id'] : false;
$qa_plan_error['status'] = ( isset( $_GET['status'] ) && 'success' == $_GET['status'] ) ? true: false;


$qa_plan_button = ( isset($_GET['page']) && $_GET['page'] = 'add_cloud_plan' ) ? 'Update' : 'Save';
?>
<div Class="wrap">
  <h1>Add Plan Feature</h1>
  <hr><br>
  <?php
  if( isset($qa_plan_error['status']) && 'success' == $qa_plan_error['status'] ) {
    ?>
    <div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible">
      <p>
        <strong>Plan has been successfully added. <a href="<?php echo admin_url("admin.php?page=cloud_plans"); ?>" >View Plans</a></strong>
      </p>
      <button type="button" class="notice-dismiss"></button>
    </div>
    <?php
  } elseif ( isset($qa_plan_error['plan_exist']) && $qa_plan_error['plan_exist'] ) {
    ?>
    <div id="setting-error-settings_updated" class="error settings-error notice is-dismissible">
      <p>
        <strong><?php echo wp_unslash( $_POST['feature'] ); ?> Plan Already Exist. View Plans<a href="<?php echo admin_url("admin.php?page=cloud_plans"); ?>" > View Plans</a></strong>
      </p>
      <button type="button" class="notice-dismiss">
      </button>
    </div>
    <?php

  } elseif ( isset($qa_plan_error['error']) && $qa_plan_error['error'] ) {
    ?>
    <div id="setting-error-settings_updated" class="error settings-error notice is-dismissible">
      <p>
        <strong>Please fill all fields.</strong>
      </p>
      <button type="button" class="notice-dismiss"></button>
    </div>
    <?php
  }

  $qa_plan_feature = '';
  $qa_plan         = array();
  $qa_plan_package = array();

  if ( isset( $_GET['action'] ) && isset( $_GET['plan-id'] ) && ! empty( $_GET['plan-id'] ) && 'edit' == $_GET['action'] ) {
    $edit_data = ( get_option( 'qa_cloud_plans' ) ) ? maybe_unserialize( get_option( 'qa_cloud_plans' ) ) : array();
    foreach ($edit_data as $key => $value) {
      if( $value['id'] == wp_unslash( $_GET['plan-id'] ) ) {
        $qa_plan_feature = $value['feature'];
        @$qa_plan         = $value['plan'];
        @$qa_plan_package = $value['package'];
      }
    }
  }
  ?>

  <form method="POST">
    <table class="form-table">
      <tbody>
        <tr>
          <th scope="row"><label for="wp_title">Plan Feature</label></th>
          <td><input type="text" class="regular-text" id="wp_title" name="feature" value="<?php echo esc_html( $qa_plan_feature ); ?>" required></td>
        </tr>
        <tr>
          <th scope="row"><label for="wp_title">Plan Name</label></th>
          <td>
            <select class="regular-text" name="plan[]" multiple >
              <?php
              fo
              ?>
              <option value="Platinum" <?php echo ( in_array( 'Platinum', $qa_plan ) ) ? 'selected' : false; ?>>Platinum</option>
              <option value="Gold" <?php echo ( in_array( 'Gold', $qa_plan ) ) ? 'selected' : false; ?>>Gold</option>
            </select>
          </td>
        </tr>
        <tr>
          <th scope="row"><label for="wp_title">Package Name</label></th>
          <td>
            <select class="regular-text" name="package[]" multiple required>
              <option value="AWS Hosting" <?php echo ( in_array( 'AWS Hosting', $qa_plan_package ) ) ? 'selected' : false; ?> >AWS Hosting</option>
              <option value="Google Cloud" <?php echo ( in_array( 'Google Cloud', $qa_plan_package ) ) ? 'selected' : false; ?>>Google Cloud</option>
              <option value="Microsoft Azure" <?php echo ( in_array( 'Microsoft Azure', $qa_plan_package ) ) ? 'selected' : false; ?>>Microsoft Azure</option>
            </select>
            <input type="hidden" name="plan-id" value="<?php echo ( ! empty( $plan_id ) ) ? $plan_id : strtotime( 'now' ); ?>">
          </td>
        </tr>
      </tbody>
    </table>
    <br>
    <button type="submit" name="submit" class="button button-primary"><?php echo $qa_plan_button; ?></button>
  </form>
</div>

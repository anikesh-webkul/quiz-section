<?php
/**
 *Plugin Name: Notice Board
 *Plugin URI: http://www.webkul.com
 *Description: Add Notification on the top of header of site
 *Version: 3.0.0
 *Author: Webkul
 * Author URI: https://webkul.com
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

! defined( 'WN_DIR' ) && define( 'WN_DIR', plugin_dir_url( __FILE__ ) );

! defined( 'WN_VERSION' ) && define( 'WN_VERSION', '2.0.3' );

! defined( 'WN_DIR_PATH' ) && define( 'WN_DIR_PATH', plugin_dir_path( __FILE__ ) );

if ( ! function_exists( 'wn_notification_install_schema' ) ) {

	function wn_notification_install_schema() {
		require_once( WN_DIR_PATH . '/helper/class_wk_installer.php' );
		$obj = new Wk_notification_install();
		$obj->create_notification_table();
	}

		register_activation_hook( __FILE__, 'wn_notification_install_schema' );
}

require_once( WN_DIR_PATH . '/includes/class_wk_notification_pages.php' );
require_once( WN_DIR_PATH . '/templates/public/class-show-notification.php' );
require_once( WN_DIR_PATH . '/helper/class-wn-db-handler.php' );

function _wk_remove_slashes( $content ) {
	
    /*
     * Replace one or more backslashes followed by a single quote with
     * a single quote.
     */
    $content = preg_replace( "/\\\+'/", "'", $content );

    /*
     * Replace one or more backslashes followed by a double quote with
     * a double quote.
     */
    $content = preg_replace( '/\\\+"/', '"', $content );

    // Replace one or more backslashes with one backslash.
    $content = preg_replace( '/\\\+/', '\\', $content );

    return $content;
}



<?php
/**
 * Plugin Name: Webkul Page Builder
 * Plugin URI: https://webkul.com/
 * Description: Custom Blocks for create page predefined layouts.
 * Author: Webkul
 * Author URI: https://webkul.com/
 * Version: 1.0.0
 *
 * @package Wk
 */

defined( 'WK_PAGE_BUILDER_URL' ) || define( 'WK_PAGE_BUILDER_URL', plugin_dir_url( __FILE__ ) );


add_action('init', function () {

	$wk_stylesheet = plugin_dir_url( __FILE__ ) . '/assets/dist/css/wk-builder.min.css';

	wp_register_style(
		'wkpage-builder-style',
		$wk_stylesheet,
		'v1.1.4'
	);

   $gutenberg_blocks_file = plugin_dir_url( __FILE__ ) . '/assets/dist/js/wk-builder.min.js';
   
   wp_register_script(
      'wkpage-builder-script',
      $gutenberg_blocks_file,
      array( 'wp-blocks', 'wp-element', 'wp-editor', 'wp-data', 'wp-compose' ),
      'v1.1.6'
   );

   wp_localize_script(
	   'wkpage-builder-script',
	   'wkBlocks',
	   array(
		   'plugin_url' => plugin_dir_url( __FILE__ ),
	   )
	);

   register_block_type( 'wk-blocks/wkpage-builder-blocks', array(
      'editor_style'  => 'wkpage-builder-style',
      'editor_script' => 'wkpage-builder-script',
   ) );
});

/**
 * Create Gutenberg Block Category
 * @category webkul
 */
add_filter( 'block_categories', function( $categories, $post ) {
   return array_merge(
       $categories,
       array(
           array(
               'slug'  => 'webkul',
               'title' => 'Webkul',
           ),
       )
   );
}, 10, 2 );

add_theme_support( 'editor-color-palette', array(
	array(
		'name'  => 'Primary Color',
		'slug'  => 'primary',
		'color'	=> '#2149f3',
	),
	array(
		'name'  => 'Secondary Color',
		'slug'  => 'secondary',
		'color' => '#0cf0cf',
	),
	array(
		'name'  => 'Dark Color',
		'slug'  => 'dark',
		'color' => '#0e1b51',
   ),
   array(
		'name'  => 'Gray',
		'slug'  => 'gray',
		'color' => '#efefef',
   ),
   array(
		'name'  => 'Default',
		'slug'  => 'default',
		'color' => '#ffffff',
   ),
) );

// add_action( 'enqueue_block_editor_assets', function() {
add_action( 'wp_enqueue_scripts', function() {

	// Here you can also check several conditions,
	// for example if you want to add this link only on CPT  you can
	// $screen = get_current_screen();
	// if ( 'page' === $screen->post_type ) {
		// wp_enqueue_script( 'custom-link-in-toolbar', get_template_directory_uri() . '/assets/js/custom-link-in-toolbar.js', array(), '1.0', true );
		/**Enqueued Page Builder Front Style */
		$wk_front_stylesheet = plugin_dir_url( __FILE__ ) . '/assets/dist/css/wk-front.min.css';
		$wk_front_script = plugin_dir_url( __FILE__ ) . '/assets/dist/js/wk-front.min.js';

		wp_register_style(
			'wkpage-front-style',
			$wk_front_stylesheet,
			array(),
			'v2.1.4'
		);
		wp_register_script(
			'wkpage-front-script',
			$wk_front_script,
			array(),
			'v2.1.4',
			true
		);

		wp_enqueue_style( 'wkpage-front-style' );
		wp_enqueue_script( 'wkpage-front-script' );
	// }
} );

require_once plugin_dir_path(__FILE__) . 'includes/layout/register-layout-components.php';
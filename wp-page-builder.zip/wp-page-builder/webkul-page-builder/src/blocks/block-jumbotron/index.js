/**
 * Register Custom Block Jumbotron
 */

registerBlockType( 'wk-blocks/jumbotron', {
    title : 'Jumbotron',
    icon : 'align-center',
    category: 'webkul',
    keywords: [
        'Jumbotron',
    ],
    // parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],

    example: {},

    attributes: {
        alignment: {
            type: 'string',
            // default: 'none',
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgURL: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
        },
        jumboLayout: {
            type:'srtring',
            default:'1',
        },
        
       
    },
    edit : function( props ) {
        var imgURL = props.attributes.imgURL,
        imgALT = props.attributes.imgALT,
        imgID = props.attributes.imgID;
        jumboLayout = props.attributes.jumboLayout;

        const onChangeJumboLayout = ( newLayout ) => {
            props.setAttributes( { jumboLayout:newLayout } );
            tempAlign = newLayout == '2' ? 'center' : false;
            props.setAttributes( { alignment: tempAlign } );
        }

        const onRemoveImage = () => {
			props.setAttributes( {
				imgURL: null,
                imgID: null,
                imgALT:null,
			} );
        };
        const onChangeAlignment = ( newAlignment ) => {
            props.setAttributes( { alignment: newAlignment === undefined ? 'none' : newAlignment } );
        };
        return el(
            Fragment,
            {},

            /**Sidebar Setting */
            ( jumboLayout == '2' ) &&
            el(
                BlockControls,
                {},
                el(
                    AlignmentToolbar,
                    {
                        value:props.attributes.alignment,
                        onChange:onChangeAlignment,
                    }
                )
            ),
            el(
                InspectorControls,
                {},
                el(
                    PanelBody,
                    {
                        title:'Jumbotron Layout Setting',
                        initial:true,
                    },
                    el(
                        PanelRow,
                        {},
                        el(
                            SelectControl,
                            {
                                label:'Layout Type',
                                value:jumboLayout,
                                options:[
                                    { label:'Jumbo Image Content', value:'1' },
                                    { label:'Jumbo Content', value:'2' }
                                ],
                                onChange:onChangeJumboLayout,
                            }
                        )
                    ),
                )
            ),
            /** //Sidebar Setting */
            el(
                'div',
                {
                    style:{
                        position:'relative'
                    }
                },
                wkSettingIcon,
                el(
                    'div',
                    {
                        className:'wk-jumbotron-wrap ' + props.className,
                        _jumboLayout:jumboLayout,
                        
                    },
                   
                    ( jumboLayout == '1' ) &&
    
                    el(
                        'div',
                        {
                            className:'wk-image-uploader',
                        },
                        el(
                            MediaUpload,
                            {
                                type: "image",
                                allowed: ALLOWED_MEDIA_TYPES,
                                value: imgID,
                                onSelect: img => props.setAttributes({
                                    imgID: img.id,
                                    imgURL: img.url,
                                    imgALT:img.alt ? img.alt : img.title 
                                }),
                                render: ({ open }) => el(
                                    Fragment,
                                    null,
                                    el(
                                        Button,
                                        {
                                            className: imgURL ? 'wk-change-image' : 'wk-add-image',
                                            onClick: open
                                        },
                                        ! imgURL ? wkUploadIcon : el( "img",
                                            {
                                                src: imgURL,
                                                alt: imgALT
                                            }
                                        )
                                    ),
                                    imgURL && el(
                                        Button,
                                        {
                                            className: "wk-remove-image",
                                            onClick: onRemoveImage
                                        },
                                        el(
                                            Dashicon,
                                            {
                                                icon: 'dismiss'
                                            }
                                        )
                                    )
                                )
                            }
                        )
                        /** //MediaUpload End */
                        
                    ),
                    el(
                        'div',
                        {
                            className:props.attributes.alignment,
                            style:{
                                'grid-column-end':'none'
                            }
                        },
                        el(
                            InnerBlocks,
                            {
                                allowedBlocks:['core/heading', 'core/paragraph', 'core/button'],
                                template:[
                                    ['core/heading',{"level":2}],
                                    ['core/button',{"backgroundColor":"primary", "borderRadius":4}]
                                ]
                            },
                        ),
                    )
                    
    
                )
            ),
        );
        /** //WP Fragment End */
    },

    save:function(props) {
        jumboClass = ( props.attributes.jumboLayout == '2' || ! props.attributes.imgURL ) ? 'block-jumbotron-wrap full-grid' : 'block-jumbotron-wrap';
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className:jumboClass,
                },
                ( props.attributes.jumboLayout == '1' ) &&
                (props.attributes.imgURL) &&
                el(
                    'div',
                    {
                        className:'jumbotron-image',
                    },
                    el(
                        'img',
                        {
                            src:props.attributes.imgURL,
                            alt:props.attributes.imgALT,
                        }
                    )
                ),
                el(
                    'div',
                    {
                        className:( !! props.attributes.alignment ) ? 'jumbotron-content ' + props.attributes.alignment : 'jumbotron-content',
                        
                    },
                    el( InnerBlocks.Content ),
                )

            )
        );
    }


} );
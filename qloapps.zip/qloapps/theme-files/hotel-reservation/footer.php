 <?php

/**
 * The Footer template for Dsiaplaying footer content theme
 *
 * @package Hotel and Reservation
 * @subpackage hotel reservation
 * @since Hotel and Reservation 1.0
 */

?>

 <!---Footer Section-->

<footer class="mega-footer">
	<div class="container">

		<div class="row">

			<div class="col-md-3 col-sm-6">
				<div class="mega-menu-item">
				<h4><span>Add-ons & Services</span></h4>
					<?php wp_nav_menu( array('theme_location' => 'hotelreservation_products')); ?>
				</div>
			</div>
			<!-- <div class="col-md-2 col-sm-6">
				<div class="mega-menu-item">
					<h4><span>Add-Ons<span></h4>
					<?php wp_nav_menu( array('theme_location' => 'hotelreservation_addons')); ?>
				</div>
			</div> -->
			<div class="col-md-3 col-sm-6">
				<div class="mega-menu-item">
					<h4><span>Explore</span></h4>
					<?php wp_nav_menu( array('theme_location' => 'hotelreservation_explore')); ?>
				</div>
			</div>
			<div class="col-md-3 col-sm-6">
				<div class="mega-menu-item">
					<h4><span>Quick Links</span></h4>
					<?php wp_nav_menu( array('theme_location' => 'hotelreservation_quicklinks')); ?>
				</div>
			</div>

			<div class="col-md-3 col-sm-6">
				<div class="mega-menu-item">
					<h4><span>Subscribe</span></h4>
					<div id="mc_embed_signup" class="">
						<form action="//qloapps.us8.list-manage.com/subscribe/post?u=a6022fbcc8eb59ebd26658e1c&amp;id=96917c5642" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
							<div id="mc_embed_signup_scroll">
								<div class="mc-field-group">
									<input type="email" placeholder="Enter Your Email Here" name="EMAIL" class="required email" id="mce-EMAIL">
								</div>
								<div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_a6022fbcc8eb59ebd26658e1c_be6f4be20e" tabindex="-1" value=""></div>
								<div class="clear">
									<input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="white btn btn-bgcolor btn-subscribe">
								</div>
								<div id="mce-responses" class="clear">
									<div class="response" id="mce-error-response" style="display:none"></div>
									<div class="response" id="mce-success-response" style="display:none"></div>
								</div>
							</div>
						</form>
					</div>

					<h4><span>Follow Us</span></h4>
					<div class="wk-footer-social-links">
						<a href="https://www.facebook.com/qloapps" target="_blank" rel="nofollow" class="footer-facebook"></a>
						<a href="https://twitter.com/qloapps" target="_blank" rel="nofollow" class="footer-twitter"></a>
						<a href="https://medium.com/qloapps" target="_blank" rel="nofollow" class="footer-xyz"></a>
					</div>

				</div>
			</div>
		</div>
	</div>
</footer>

<footer class="mini-footer">
	<div class="container">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8"><hr></div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
                <p class="text-center">&copy; 2010-<?php echo date('Y'); ?> Webkul Software. All Rights Reserved.
                &ensp;&ensp;<img src='https://webkul.com/wp-content/uploads/2019/09/security-logo-2.png'></p>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</footer>

<script type='text/javascript' src='//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script><script type='text/javascript'>(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[1]='FNAME';ftypes[1]='text';fnames[2]='LNAME';ftypes[2]='text';}(jQuery));var $mcj = jQuery.noConflict(true);
</script>
<!--End mc_embed_signup-->
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.1.1/socket.io.js"></script>
<script type="text/javascript" src="https://webkul.chatwhizz.com/chat-support/js/wk-chat-support.js"></script>

<script type="text/javascript>">
	// Hotjar Tracking Code for https://qloapps.com/
	window.addEventListener('load',function(){
		(function(h,o,t,j,a,r){
			h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
			h._hjSettings={hjid:559333,hjsv:5};
			a=o.getElementsByTagName('head')[0];
			r=o.createElement('script');r.async=1;
			r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
			a.appendChild(r);
		})(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');
	});

</script>

<script>
document.addEventListener('DOMContentLoaded',function(){
	if ( document.querySelector( '.show-banners.notification-visible .notification-brick .book-now' ) ) {

		(function () {
			var widget = document.createElement('script');
			widget.async = true;
			widget.src = 'https://webkul.bookingcommerce.com/widget/js/widget.js';
			widget.charset = 'UTF-8';
			widget.setAttribute('crossorigin', '*');
			widget.onload = function () {
				new beWidget({
					'baseurl': 'https://webkul.bookingcommerce.com/en',
					'brandColor': '#1747E3',
					'widgetType': 'individual',
					'btnLabel': 'Book Now',
					'bookingProductPath': 'qlo',
				})
			};
			document.head.appendChild(widget);
		})();
	}
});
</script>


<!-- //Footer Section -->

 <?php wp_footer() ?>

 <script type='application/ld+json'>
{
	"@context": "http://www.schema.org",
	"@type": "Organization",
	"name": "Qloapps",
	"url": "https://qloapps.com/",
	"sameAs": [
	"https://twitter.com/qloapps",
	"https://www.facebook.com/qloapps"
	],
	"logo": "https://qloapps.com/wp-content/themes/hotel-reservation/images/logo.png",
	"image": "https://qloapps.com/wp-content/themes/hotel-reservation/images/logo.png",
	"description": "Qlo is an open source, free and customizable online reservation system. You can launch a userfriendly site and can manage online as well as offline bookings.",
	"address": {
	"@type": "PostalAddress",
	"streetAddress": "A-67 Sector 63",
	"addressLocality": "Noida",
	"addressRegion": "Uttar Pradesh",
	"postalCode": "201301",
	"addressCountry": "India"
	},
	"contactPoint": {
	"@type": "ContactPoint",
	"telephone": "+91 9870284067",
	"contactType": "customer service"
	},
	"founder": "Vipin Sahu, Vinay Yadav and Prakash Sahu",
	"foundingDate": "2010",
	"foundingLocation": "Noida, India"

}
 </script>



</body>

</html>

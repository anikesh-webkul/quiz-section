const version = "1.0.0";
const cacheName = `webkul-${version}`;
self.addEventListener( 'install', e => {
	const timeStamp = Date.now();
	e.waitUntil(
		caches.open( cacheName ).then( cache => {
			return cache.addAll([
				'/',
				`/index.php?timestamp=${timeStamp}`,
				`/wp-content/themes/webkul-2018/style.css?timestamp=${timeStamp}`,
				`/wp-content/themes/webkul-2018/assets/dist/js/wk-script.min.js?timestamp=${timeStamp}`,
			])
			.then( () => self.skipWaiting() );
		})
	);
});
self.addEventListener( 'activate', event => {
	event.waitUntil( self.clients.claim() );
});
self.addEventListener( 'fetch', event => {
	if ( event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
		return;
	}
	if ( false === navigator.onLine ) {

		event.respondWith(
			caches.open( cacheName )
			.then( cache => cache.match( event.request, { ignoreSearch: true } ) )
			.then( cacheResponse => {
				return cacheResponse || fetch( event.request ).then( fetchResponse => { return fetchResponse }, e => {} );
			})
		);
	}
});

<?php
/*Include Custom MetaBox*/
require_once dirname( __FILE__ ) . '/utils/class-wk-tab-meta-box.php';
/*Include Custom MetaBox*/

require_once dirname( __FILE__ ) . '/class-wk-walker-mega-menu.php';

/*----Include Theme Shortcodes----*/
require_once dirname( __FILE__ ) . '/includes/shortcodes/shortcodes.php';
/*----//Include Theme Shortcodes----*/

/*----Include Meetup Directory----*/
require_once dirname( __FILE__ ) . '/meetups/meetup-functions.php';
/*----//Include Meetup Directory----*/


/* Injecting Custom sitemap for Job posts in Yoast sitemaps */
/* by using one of the Interface from yoast plugin */
if ( class_exists( 'WPSEO_Sitemaps' ) ) {

	/*----Include Custom job sitemap----*/
	require_once dirname( __FILE__ ) . '/includes/job-sitemap/wkyoast-job-sitemap.php';
	/*----//Include Custom job sitemap----*/

	add_filter( 'wpseo_sitemaps_providers', function() {
		return array( new WKYoast_Job_Sitemap() );
	} );
}
/* //Injecting Custom sitemap for Job posts in Yoast sitemaps */


add_filter( 'wpseo_schema_faq', function( $graph_piece, $context ) {

	if ( is_page() && ! empty( $context->blocks['yoast/faq-block'] ) ) {
		if ( 'question' === strtolower( $graph_piece['@type'] ) ) {
			$graph_piece['mainEntityOfPage'] = [ '@id' => $context->generate_main_schema_id() ];
		}
	}

	return $graph_piece;

}, 2, 10 );


add_filter( 'wpseo_schema_website', function( $data ) {

	unset( $data['potentialAction'] );
	return $data;
} );


// add_filter( 'wpseo_schema_webpage', function( $data ) {

// 	/**
// 	* Changes @type of Webpage Schema data.
// 	*
// 	* @param array $data Schema.org Webpage data array.
// 	*
// 	* @return array Schema.org Webpage data array.
// 	*/

// 	$data['@type'] = 'FAQPage';
// 	return $data;
// } );

function img_dir( $path ) {
	return esc_url( get_template_directory_uri() . '/images/' . $path );
}

function wk_data_src( $src = null, $alt = '', $class = '', $only_srcset = false ) {

	$src        = get_template_directory_uri() . '/images/' . $src;

	return '<img alt="' . $alt . '" class="' . $class . '" src="' . $src . '.png" srcset="' . $src . '.png 1x, ' . $src . '-2x.png 2x, ' . $src . '-3x.png 3x" />';
}

function wk_webp( $src = null, $alt = '', $class = '', $srcset = false ) {

	// array(4) {
	// ["dirname"]=>
	// string(77) "http://192.168.15.145/webkul-2018/wp-content/themes/webkul-2020/images/orphan"
	// ["basename"]=>
	// string(22) "team-profile-megha.png"
	// ["extension"]=>
	// string(3) "png"
	// ["filename"]=>
	// string(18) "team-profile-megha"
	// }

	$path_info  = pathinfo( $src );

	$alt        = ( '' === $alt ) ? $path_info['filename'] : $alt;

	$webp_path  = get_template_directory_uri() . '/images/webp/' . $path_info['filename'];

	if ( $srcset ) {
		$webp_scrset = $webp_path . '.webp 1x, ' . $webp_path . '-2x.webp 2x, ' . $webp_path . '-3x.webp 3x';
	} else {
		$webp_scrset = $webp_path . '.webp';
	}

	$img_path = get_template_directory_uri() . '/images/' . $path_info['dirname'] . '/' . $path_info['filename'];

	$fragment = '<picture>';
	$fragment .= '<source srcset="' . $webp_scrset . '" type="image/webp">';

	if ( $srcset ) {
		$fragment .= '<img alt="' . $alt . '" class="' . $class . '" src="' . $img_path . '.' . $path_info['extension'] . '" srcset="' . $img_path . '.' . $path_info['extension'] . ' 1x, ' . $img_path . '-2x.' . $path_info['extension'] . ' 2x, ' . $img_path . '-3x.' . $path_info['extension'] . ' 3x" />';
	} else {
		$fragment .= '<img src="' . $img_path . '.' . $path_info['extension'] . '" alt="' . $alt . '" class="' . $class . '">';
	}
	$fragment .= '</picture>';
	return $fragment;
}


/**
 * wk_parse_img function create html from image src.
 *
 * @param string $src
 * @param string $size
 * @param string $attr
 * @param boolean $icon
 * @return HTML
 */
function wk_get_img_html( $src = '', $size = 'full', $attr = '', $icon = false ) {

	if ( empty( $src ) ) {
		return;
	}

	$upload_dir = wp_upload_dir();

	$img_id = strpos( $upload_dir['baseurl'], $src ) ? attachment_url_to_postid( $src ) : false;

	$img_id = file_exists( $upload_dir['basedir'] . $src ) ? attachment_url_to_postid( $upload_dir['baseurl'] . $src ) : $img_id;

	if( $img_id ) {
	
		return wp_get_attachment_image( $img_id, $size, $icon, $attr );
	
	} else {
	
		$default_attr = array(
            'class' => '',
			'alt'   => explode( '.', wp_basename( $src ) )[0],
			'title' => '',
			'src'   => $src,
        );

		$attr = wp_parse_args( $attr, $default_attr );

		$tmp_html = '<img';

		foreach( $attr as $key => $value ) {
			if ( ! empty( $value ) ) {
				$tmp_html .= " $key=\"$value\"";
			}
		}
		$tmp_html .= ' />';

		return $tmp_html;
	}
}

add_filter( 'wpcf7_form_elements', 'filter_wpcf7_form_elements', 10, 1 );
function filter_wpcf7_form_elements( $form_html ) {

	$form_html = str_replace( '<p><label', '<p class="wk-control wk-textfield"><label', $form_html );

	$form_html = str_replace( 'wpcf7-form-control wpcf7-submit', 'wpcf7-form-control wpcf7-submit wk-button btn-dark', $form_html );

	$form_html = str_replace( 'wpcf7-list-item', 'wpcf7-list-item wk-control wk-radio', $form_html );

	$form_html = preg_replace_callback( '/<\s* input \s* type="radio" + [^>] + /xi', function( $m ) {
		return $m[0] . '><span class="symbol"></span';
	}, $form_html );

	$form_html = str_replace( '<option value="">---</option>', '<option value="">---Select Platform---</option>', $form_html );

	$form_html = preg_replace_callback( '/<select .*<\/select>/', function( $m ) {
		return '<div class="wk-control wk-dropdown">' . $m[0] . '</div>';
	}, $form_html );

	return $form_html;
};

add_filter( 'get_edit_post_link', function( $link, $post_id, $text ) {

	if ( ! empty( get_query_var( 'pagename' ) ) && 'jobs' === get_query_var( 'pagename' ) && ! empty( get_query_var( 'job' ) ) ) {

		global $wpdb;
		$link_slug     = get_query_var( 'job' );
		$table         = $wpdb->prefix . 'open_positions';
		$positions_bag = $wpdb->get_results( "SELECT id FROM $table WHERE slug='$link_slug'", ARRAY_A );
		if ( ! empty( $positions_bag ) && isset( $positions_bag[0] ) ) {
			$positions_bag = $positions_bag[0];
			$link = admin_url( "admin.php?page=wkjob_post_new&action=edit&op_id=$positions_bag[id]&tab=position_details" );
			return $link;
		}
	}
	return $link;
}, 10, 3 );

add_filter( 'template_include', function( $template ) {

	if ( ! empty( get_query_var( 'pagename' ) ) && 'jobs' === get_query_var( 'pagename' ) ) {

		if ( ! empty( get_query_var( 'embedpage' ) ) && ! empty( get_query_var( 'job' ) ) ) {
			$new_template = locate_template( array( 'core/embed-job-share.php' ) );
			if ( ! empty( $new_template ) ) {
				return $new_template;
			}
		}
		if ( ! empty( get_query_var( 'job' ) ) ) {
			$new_template = locate_template( array( 'core/wk-job-details.php' ) );
			if ( ! empty( $new_template ) ) {
				return $new_template;
			}
		}
	}

	return $template;
} );
/*Career-Page JobShare*/


add_filter( 'rewrite_rules_array', 'wp_insertcustom_rules' );
add_filter( 'query_vars', 'wp_insertcustom_vars' );

function wp_insertcustom_vars( $vars ) {
	$vars[] = 'pagename';
	$vars[] = 'job';
	$vars[] = 'embedpage';
	return $vars;
}
function wp_insertcustom_rules( $rules ) {

	$newrules = array(
		'jobs/embed-job/(.+)/?' => 'index.php?pagename=jobs&embedpage=embed-job&job=$matches[1]',
		'jobs/(.+)/?'           => 'index.php?pagename=jobs&job=$matches[1]',
	);

	return $newrules + $rules;
}
/*//Career-Page JobShare*/

/*JOB_POST UTILS*/
function get_jobpost_slug_from_name( $name ) {

	if ( empty( $name ) ) {
		return '';
	}
	return sanitize_title_with_dashes( $name );
}

function get_jobpost_permalink( $slug ) {

	if ( empty( $slug ) ) {
		return '';
	}

	return home_url( 'jobs' ) . '/' . $slug;
}
/*//JOB_POST UTILS*/

/*Page MetaBoxes*/
add_action( 'add_meta_boxes', 'add_page_template_metaboxes' );
function add_page_template_metaboxes() {

	add_meta_box( 'wk_layout_settings', 'Page Layout Setting', '_layout_option_meta_cb', 'page', 'side', 'high' );
}
function _layout_option_meta_cb() {

	global $post;

	$enable_page_header = get_post_meta( $post->ID, 'wk_page_has_header', true );
	$curr_layout        = get_post_meta( $post->ID, 'wk_page_layout_view', true );
	$banner_tag         = get_post_meta( $post->ID, 'wk_banner_tagline', true );
	$info_title         = get_post_meta( $post->ID, 'wk_infobox_title', true );
	$info_content       = get_post_meta( $post->ID, 'wk_infobox_content', true );
	$info_btn_label     = get_post_meta( $post->ID, 'wk_infobox_btn_label', true );
	$info_btn_url       = get_post_meta( $post->ID, 'wk_infobox_btn_url', true );
	$info_box_visible   = get_post_meta( $post->ID, 'wk_infobox_visible', true );
	$opt_btn_attrs      = maybe_unserialize( get_post_meta( $post->ID, 'wk_opt_btn_attr', true ) );
	$opt_video_atts     = maybe_unserialize( get_post_meta( $post->ID, 'wk_opt_video_attr', true ) );

	$default_info_box = array(
		'title'   => 'Do you need something else?',
		'content' => 'We have pioneered and created the cost-friendly tools and extensions which generally have plug and play behavior which saves your time and keeps you on top of the productivity.

If you have any particular project or app requirement, you can reach us anytime with a small brief and We’ll get back to you.',
		'btn_label' => 'Send Message',
		'btn_url'   => 'https://webkul.com/contacts/',
	);

	$info_title     = ( ! empty( $info_title ) ) ? $info_title : $default_info_box['title'];
	$info_content   = ( ! empty( $info_content ) ) ? $info_content : $default_info_box['content'];
	$info_btn_label = ( ! empty( $info_btn_label ) ) ? $info_btn_label : $default_info_box['btn_label'];
	$info_btn_url   = ( ! empty( $info_btn_url ) ) ? $info_btn_url : $default_info_box['btn_url'];

	if( !empty( $banner_tag ) ) {
		$banner_tag = '<h1>' . $banner_tag . '</h1>';
	}
	wp_nonce_field( 'page_layout_metabox_nonce', '__wk_layout_nonce' );
	?>
	<div id="wk-page-meta-boxes">
		<input title="Visibility" type="checkbox" value="1" <?php checked( '1', $enable_page_header ); ?> name="wk_page_has_header" />
		<span class="wk-collapse-toggle" data-target="collapse-box-pHeader" title="Add Box"><i><b>PAGE HEADER SETTINGS</b></i><span class="dashicons dashicons-arrow-down"></span></span><br />
		<div class="wk-collapse-boxes" id="collapse-box-pHeader">
			<label for="layout-1" style="width:49%;display:inline-block">
				<i>FULL WIDTH</i>
				<input type="radio" id="layout-1" name="wk_page_layout_view" value="full" <?php checked( 'full', $curr_layout ); ?> />
				<img style="width:100%;background:#7b7b7b;margin-top:5px" src="<?php echo esc_url( get_template_directory_uri() . '/images/page-layout-wide.png' ); ?>" />
			</label>
			<label for="layout-2" style="width:49%;display:inline-block">
				<i>WIDE</i>
				<input type="radio" id="layout-2" name="wk_page_layout_view" value="wide" <?php checked( 'wide', $curr_layout ); ?> />
				<img style="width:100%;background:#7b7b7b;margin-top:5px;" src="<?php echo esc_url( get_template_directory_uri() . '/images/page-layout-wide.png' ); ?>" />
			</label>
			<br>
			<label for="layout-3" style="width:49%;display:inline-block">
				<i>SQUEEZY</i>
				<input type="radio" id="layout-3" name="wk_page_layout_view" value="squeezy" <?php checked( 'squeezy', $curr_layout ); ?> />
				<img style="width:100%;background:#7b7b7b;margin-top:5px" src="<?php echo esc_url( get_template_directory_uri() . '/images/page-layout-squeezy.png' ); ?>" />
			</label>
			<div style="position:relative">
				<div>
					<p style="margin-bottom: 3px;"><i><u>Select the text to Highlight</i></u></p>
					<label for="wk-banner-tagline"><i><b>BANNER TAGLINE</b></i><br /><textarea class="has-highlight" style="width:100%;min-height:130px;" placeholder="Banner Tagline..." name="wkfields[wk_banner_tagline]" id="wk-banner-tagline"><?php echo $banner_tag ; ?></textarea></label>
				</div>
				<?php
				if ( isset( $opt_btn_attrs ) ) {

					$_enable = ( ! empty( $opt_btn_attrs['enable'] ) ) ? $opt_btn_attrs['enable'] : '';
					$_link   = ( ! empty( $opt_btn_attrs['link'] ) ) ? $opt_btn_attrs['link'] : '';
					$_label  = ( ! empty( $opt_btn_attrs['label'] ) ) ? $opt_btn_attrs['label'] : '';
					$_rel    = ( ! empty( $opt_btn_attrs['rel'] ) ) ? $opt_btn_attrs['rel'] : '';
					$_target = ( ! empty( $opt_btn_attrs['target'] ) ) ? $opt_btn_attrs['target'] : '';
					$_color  = ( ! empty( $opt_btn_attrs['color'] ) ) ? $opt_btn_attrs['color'] : 'prime';
				}
				if ( isset( $opt_video_atts ) ) {
					$_video_enable = ( ! empty( $opt_video_atts['enable'] ) ) ? $opt_video_atts['enable'] : '';
					$_video_link   = ( ! empty( $opt_video_atts['link'] ) ) ? $opt_video_atts['link'] : '';
					$_video_label  = ( ! empty( $opt_video_atts['label'] ) ) ? $opt_video_atts['label'] : '';
					$_video_rel    = ( ! empty( $opt_video_atts['rel'] ) ) ? $opt_video_atts['rel'] : '';
					$_video_target = ( ! empty( $opt_video_atts['target'] ) ) ? $opt_video_atts['target'] : '';
					$_video_color  = ( ! empty( $opt_video_atts['color'] ) ) ? $opt_video_atts['color'] : 'prime';
				}
				?>
				<br/>
				<input title="Visibility" type="checkbox" value="1" <?php checked( '1', $_enable ); ?> name="wkfields[wk_opt_btn_attr][enable]" />
				<span style="margin: 0px;"><i><b>ADD A LINK ( Optional )</b></i></span><br><br>
				<label>Button Label
					<input type="text" name="wkfields[wk_opt_btn_attr][label]" placeholder="Button Label" value="<?php echo esc_attr( $_label ); ?>"/>
				</label><br><br>
				<label>Button Link
					<input type="text" name="wkfields[wk_opt_btn_attr][link]" placeholder="Button Link" value="<?php echo esc_attr( $_link ); ?>"/>
				</label><br><br>
				<label>Link Relationship ( Xnf )
					<input type="text" name="wkfields[wk_opt_btn_attr][rel]" placeholder="rel=''" value="<?php echo esc_attr( $_rel ); ?>"/>
				</label>
				<br/><br/>
				<label class="all-top-inline">
					<b>Open in New Tab</b>
					<span class="switch">
						<input name="wkfields[wk_opt_btn_attr][target]" type="checkbox" value="true" <?php checked( 'true', $_target ); ?>>
						<span class="slider round"></span>
					</span>
				</label><br><br>
				<div class="custom-radios">
					<b>Color Scheme</b>
					<div>
						<input type="radio" id="color-1" name="wkfields[wk_opt_btn_attr][color]" value="prime" <?php checked( 'prime', $_color ); ?>>
						<label for="color-1">
							<span>
								<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg" alt="Checked Icon" />
							</span>
						</label>
					</div>
					<div>
						<input type="radio" id="color-2" name="wkfields[wk_opt_btn_attr][color]" value="btn-light" <?php checked( 'btn-light', $_color ); ?>>
						<label for="color-2">
							<span>
								<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg" alt="Checked Icon" />
							</span>
						</label>
					</div>
					<div>
						<input type="radio" id="color-3" name="wkfields[wk_opt_btn_attr][color]" value="btn-dark" <?php checked( 'btn-dark', $_color ); ?>>
						<label for="color-3">
							<span>
								<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg" alt="Checked Icon" />
							</span>
						</label>
					</div>
				</div>
			</div>
		</div>
		
	</div>

	<hr /><br />

	<input title="Visibility" type="checkbox" value="1" <?php checked( '1', $info_box_visible ); ?> name="wk_infobox_visible" />
	<span class="wk-collapse-toggle" data-target="collapse-box-info" title="Add Box"><i><b>OPTIONAL INFO BOX</b></i><span class="dashicons dashicons-arrow-down"></span></span><br />

	<div class="wk-collapse-boxes" id="collapse-box-info">
		<br />
		<div>
			<label for="wk-infobox-title">Title</br><input type="text" placeholder="Title..." name="wkfields[wk_infobox_title]" id="wk-infobox-title" value="<?php echo esc_attr( $info_title ); ?>"/></label>
		</div>
		<br />
		<div>
			<label for="wk-infobox-content">Content</br><textarea style="width:100%;min-height:130px;" placeholder="Content..." name="wkfields[wk_infobox_content]" id="wk-infobox-content"><?php echo $info_content; ?></textarea></label>
		</div>
		<br />
		<div>
			<label for="wk-infobox-btn-label">Button Label</br><input type="text" placeholder="Button label..." name="wkfields[wk_infobox_btn_label]" id="wk-infobox-btn-label" value="<?php echo esc_attr( $info_btn_label ); ?>"/></label>
		</div>
		<br />
		<div>
			<label for="wk-infobox-btn-url">Button URL</br><input type="text" placeholder="Button URL..." name="wkfields[wk_infobox_btn_url]" id="wk-infobox-btn-url" value="<?php echo esc_attr( $info_btn_url ); ?>"/></label>
		</div>
	</div>
	<hr />
	<?php
}

add_action( 'save_post', 'save_page_template_metaboxes' );
function save_page_template_metaboxes( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! isset( $_POST['__wk_layout_nonce'] ) || ! wp_verify_nonce( $_POST['__wk_layout_nonce'], 'page_layout_metabox_nonce' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post' ) ) {
		return;
	}

	if ( isset( $_POST['wk_page_layout_view'] ) ) {

		$curr_layout = $_POST['wk_page_layout_view'];
		$curr_layout = ( '' === $curr_layout ) ? 'squeezy' : $curr_layout;
		update_post_meta( $post_id, 'wk_page_layout_view', $curr_layout );
	}

	$info_visiblity  = ( '1' === $_POST['wk_infobox_visible'] ) ? '1' : '0';
	update_post_meta( $post_id, 'wk_infobox_visible', $info_visiblity );

	$head_visiblity  = ( '1' === $_POST['wk_page_has_header'] ) ? '1' : '0';
	update_post_meta( $post_id, 'wk_page_has_header', $head_visiblity );

	if ( isset( $_POST['wkfields'] ) ) {

		$all_fields = $_POST['wkfields'];
		foreach ( $all_fields as $key => $val ) {
			update_post_meta( $post_id, $key, $val );
		}
	}
}
/* //Page MetaBoxes*/


/*Add Options fields*/
add_action( 'admin_init', function() {

	$options = array(
		array(
			'slug'      => 'caption-icons',
			'label'     => 'Caption Icons',
			'shortcode' => 'true',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'image-gallery',
			'label'     => 'Image Gallery',
			'shortcode' => 'true',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'section-component',
			'label'     => 'Doc Section',
			'shortcode' => 'true',
			'sortable'  => 'false',
		),
		array(
			'slug'      => 'link-component',
			'label'     => 'Fancy Links',
			'shortcode' => 'true',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'fancy-links',
			'label'     => 'Fancy Links 2',
			'shortcode' => 'true',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'page-customer',
			'label'     => 'Our Customers',
			'shortcode' => 'false',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'page-press',
			'label'     => 'In The Press',
			'shortcode' => 'false',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'page-certification',
			'label'     => 'Certifications',
			'shortcode' => 'false',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'page-infrastructure',
			'label'     => 'Infrastructure',
			'shortcode' => 'false',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'carousels',
			'label'     => 'Carousels',
			'shortcode' => 'true',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'jumbotron',
			'label'     => 'Jumbotron',
			'shortcode' => 'true',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'success-story',
			'label'     => 'Success Story',
			'shortcode' => 'true',
			'sortable'  => 'true',
		),
		array(
			'slug'      => 'homepage-clients',
			'label'     => 'Homepage Clients',
			'shortcode' => 'false',
			'sortable'  => 'true',
		),
	);

	$options            = apply_filters( 'wk_registered_components', $options );
	$backup_option_keys = array();
	$prefix             = 'wktheme-';

	if ( ! is_null( $options ) ) {

		update_option( 'wk_registered_components', wp_json_encode( $options ) );

		foreach ( $options as $opt ) {
			add_option( $prefix . $opt['slug'], '' );
		}
	}

} );
/* //Add Options fields*/

/* Add New Role For theme setting */
add_action( 'admin_init', 'add_wk_theme_config_access_role' );
function add_wk_theme_config_access_role() {
	global $wp_roles;
	if ( ! isset( $wp_roles ) ) {
		$wp_roles = new WP_Roles();
	}
	$editor = $wp_roles->get_role( 'editor' );
	$wp_roles->add_role( 'webkul_theme_editor', 'Webkul Theme Editor', $editor->capabilities );
}
/* Add New Role For theme setting */


/*--Theme Page Options--*/
add_action( 'admin_menu', '_add_wk_theme_options' );
function _add_wk_theme_options() {
	$user = wp_get_current_user();
	if ( in_array( 'administrator', (array) $user->roles, true ) || in_array( 'webkul_theme_editor', (array) $user->roles, true ) ) {
		add_menu_page( 'Theme Settings', 'Theme Settings', 'edit_posts', 'wk-theme-pages-config', '_wk_pages_config_template', 'dashicons-layout', 3 );
		add_submenu_page( 'wk-theme-pages-config', 'Generate Shortcodes', 'Generate Shortcodes', 'edit_posts', 'wk-theme-shortcodes-config', '_wk_generate_shortcodes_template' );
		add_submenu_page( 'wk-theme-pages-config', 'Manage Options', 'Manage Options', 'edit_posts', 'wk-theme-manage-options', '_wk_manage_options_template' );
	}
}

function _wk_generate_shortcodes_template() {

	require_once( dirname( __FILE__ ) . '/wk-generate-shortcodes-config.php' );
	?>
	<div class="webkul-theme-bar"></div>
	<div class="wrap">
		<div class="wk-theme-settings-page">
			<h1>Generate Shortcodes</h1>
			<p class="description">Generate UI shortcodes for various theme elements and use them in your page content.</p>
			<br /><br />
			<nav class="nav-tab-wrapper">
				<?php
				$components  = json_decode( get_option( 'wk_registered_components' ) );
				$current_tab = empty( $_GET['tab'] ) ? $components[0]->slug : sanitize_title( $_GET['tab'] );
				$id          = $current_tab;
				$sortable    = '';

				foreach ( $components as $tab ) {
					if ( 'true' !== $tab->shortcode ) {
						continue;
					}

					echo '<a href="' . esc_url( admin_url( 'admin.php?page=wk-theme-shortcodes-config&tab=' . $tab->slug ) ) . '" class="nav-tab ' . ( $current_tab === $tab->slug ? 'nav-tab-active' : '' ) . '">' . esc_html( $tab->label ) . '</a>';

					if ( $current_tab === $tab->slug ) {
						$sortable = $tab->sortable;
					}
				}
				?>
			</nav>
			<br /><br />

			<?php
			do_action( 'wktheme_' . $current_tab . '_setting_tab', $current_tab, $sortable );
			?>
		</div>
		</div>
	<?php
}

function _wk_pages_config_template() {

	require_once( dirname( __FILE__ ) . '/wk-theme-pages-config.php' );
	?>
	<div class="webkul-theme-bar"></div>
	<div class="wrap">
		<div class="wkug-template">
			<h1>Content for various Pages</h1>
			<p class="description">Set the content for your pages.</p>
			<br /><br />
			<nav class="nav-tab-wrapper">
				<?php
				$wkug_setting_tabs = array(
					'customer'       => 'Customer Page',
					'press'          => 'In-The-Press Page',
					'certification'  => 'Certification & Partners Page',
					'infrastructure' => 'Infrastructure Page',
					'events'         => 'Webkul Events Page',
					'awards'         => 'Webkul Awards Page',
					'innovations'    => 'Innovation Page',
					'clients'        => 'Clients',
				);
				$current_tab = empty( $_GET['tab'] ) ? 'customer' : sanitize_title( $_GET['tab'] );
				$id          = $current_tab;

				foreach ( $wkug_setting_tabs as $name => $label ) {

					echo '<a href="' . esc_url( admin_url( 'admin.php?page=wk-theme-pages-config&tab=' . $name ) ) . '" class="nav-tab ' . ( $current_tab === $name ? 'nav-tab-active' : '' ) . '">' . esc_html( $label ) . '</a>';
				}
				?>
			</nav>
			<br />

			<?php
			do_action( 'wktheme_' . $current_tab . '_page_setting_tab' );
			?>
		</div>
	</div>
	<?php
}

function _wk_manage_options_template() {

	require_once( dirname( __FILE__ ) . '/wk-manage-theme-options.php' );

	?>
	<div class="webkul-theme-bar"></div>
	<div class="wrap">
		<div class="wkug-template">
			<h1>Manage Options</h1>
			<p class="description"></p>
			<br /><br />
			<nav class="nav-tab-wrapper">
				<?php
				$wkug_setting_tabs = array(
					'backup_recovery' => 'BackUp & Recovery',
					'users'           => 'Users',
				);
				$current_tab = empty( $_GET['tab'] ) ? 'backup_recovery' : sanitize_title( $_GET['tab'] );
				$id          = $current_tab;

				foreach ( $wkug_setting_tabs as $name => $label ) {

					echo '<a href="' . esc_url( admin_url( 'admin.php?page=wk-theme-manage-options&tab=' . $name ) ) . '" class="nav-tab ' . ( $current_tab === $name ? 'nav-tab-active' : '' ) . '">' . esc_html( $label ) . '</a>';
				}
				?>
			</nav>
			<br />

			<?php
			do_action( 'wktheme_' . $current_tab . '_tab' );
			?>
		</div>
	</div>
	<?php
}
/*--//Theme Page Options--*/

function get_shortcode_panel_form( $args, $error ) {

	?>
	<button class="button button-secondary" id="add-panel"><?php echo esc_html( $args['button_label'] ); ?></button>
	<br />
	<form id="new-shortcode-panel-form" method="post" action="" style="<?php echo ( isset( $error ) && true === $error ) ? 'display:block;' : ''; ?>">
		<table class="form-table">
			<tbody>
				<tr>
					<th scope="row"><label for="panel-title"><?php echo esc_html( $args['title'] ); ?> Label</label></th>
					<td>
						<input required id="panel-title" type="text" name="<?php echo esc_html( $args['array_field_name'] . '[' . $args['title_field_name'] . ']' ); ?>" value="" placeholder="Componenet Label"/>
						<p class="description">*Label to identify this panel.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="panel-slug"><?php echo esc_html( $args['title'] ); ?> ID</label></th>
					<td>
						<?php
						if ( isset( $error ) && true === $error ) {
							echo '<p style="color: red" class="description">Slug already exists! Try anything else.</p>';
						}
						?>
						<input required id="panel-slug" type="text" name="<?php echo esc_html( $args['array_field_name'] . '[' . $args['slug_field_name'] . ']' ); ?>" value="" placeholder="Component ID"/>
						<p class="description">*This should be unique.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="panel-inport">Import Component<br>(Optional)</label></th>
					<td>
						<input id="panel-import" type="text" name="wktheme-widgets[widget-import]" value="" placeholder="Componenet Slug"/>
						<p class="description">*Component Slug.</p>
					</td>
				</tr>
			</tbody>
		</table>
		<input type="submit" name="<?php echo esc_html( $args['submit_label'] ); ?>" id="submit-panel" class="button button-primary" value="Save">
	</form><br /><hr /><br />

	<div style="display:none;" class="notice notice-success is-dismissible">
		<p><strong>New component added.</strong></p>
	</div>
	<div style="display:none;" class="notice notice-error is-dismissible">
		<p><strong>Something Went Wrong! Please Try Again.</strong></p>
	</div>
	<br />
	<?php
}

/* BackUp-Recovery Ajax */
add_action( 'wp_ajax_wktheme_backup_recovery', 'wk_theme_backup_recovery_handler' );
add_action( 'wp_ajax_nopriv_wktheme_backup_recovery', 'wk_theme_backup_recovery_handler' );

function wk_theme_backup_recovery_handler() {

	$label = ( isset( $_POST['wklabel'] ) && ! empty( $_POST['wklabel'] ) ) ? trim( strip_tags( $_POST['wklabel'] ) ) : '';
	var_dump($label);
	die;

}
/* //BackUp-Recovery Ajax */

/* Common Ajax Method to save all SETTINGS options */
add_action( 'wp_ajax_wktheme_shortcode_panels_save_data', 'wk_shortcode_panels_handler' );
function wk_shortcode_panels_handler() {

	$bag            = isset( $_POST['wkdata'] ) ? $_POST['wkdata'] : array();
	$db_option_name = $_POST['option'];   //option name
	$all_panels     = get_option( $db_option_name );
	$curr_panel_ids = array_keys( $all_panels );
	$new_panel_ids  = array_keys( $bag );

	foreach ( $curr_panel_ids as $id_check ) {
		if ( ! in_array( $id_check, $new_panel_ids, true ) ) {
			unset( $all_panels[ $id_check ] );
		}
    }

	foreach ( $bag as $key => $data ) {
		/**
		 * Option settings for the Component
		 * Added after new version of widgets' layout
         *
		 * @param array $all_panels[ $key ]['options'] Array of extra options/settings
		 */
		$all_panels[ $key ]['meta'] = array();
		if ( isset( $data['meta'] ) ) {
			$meta_array = array();
			foreach ( array_keys( $data['meta'] ) as $meta_field ) {
				$meta_array[ $meta_field ] = $data['meta'][ $meta_field ];
			}
			$all_panels[ $key ]['meta'] = $meta_array;
		}
		/*//Option settings for the Component*/

		$all_panels[ $key ]['items'] = array();

        $items = ( isset( $data['items'] ) ) ? ( $data['items'] ) : $data;  // $data for old way.

		foreach ( $items as $item ) {

            $data_arr = array();

            if ( ! empty( $item ) ) {
                foreach ( array_keys( $item ) as $k ) {
                    $data_arr[ $k ] = wp_unslash( $item[ $k ] );
                }
                $all_panels[ $key ]['items'][] = $data_arr;
            }
		}
    }
	update_option( $db_option_name, $all_panels );   // Update to DB.
	exit;
}
/* //Common Ajax Method to save all SETTINGS options */


require_once dirname( __FILE__ ) . '/twitteroauth/twitteroauth.php';


function get_connection_with_access_token( $cons_key, $cons_secret, $oauth_token, $oauth_token_secret ) {
	$connection = new TwitterOAuth( $cons_key, $cons_secret, $oauth_token, $oauth_token_secret );
	return $connection;
}

function wkt_custom_twitter_text_parser( $text ) {

	$parsed_text     = '';
	$url_regx        = '/http[s]?:\/\/[aA-zZ0-9\.\/]+/';
	$tweet_text_regx = '/(#|@)[A-Za-z0-9\-\.\_]+(?:\s|$)/';

	/**
	 * Parse URL strings first
	 */
	$parsed_text = preg_replace_callback( $url_regx, function( $matches ) {

		$matched_sequence = trim( $matches[0] );

		return ' <a target="_blank" rel="noopener" role="link" title="' . $matched_sequence . '" href="' . $matched_sequence . '">' . $matched_sequence . '</a> ';

	}, $text );

	/**
	 * Parse Mentions (@) and Hashtags (#) strings after parsing the URL string
	 */
	$parsed_text = preg_replace_callback( $tweet_text_regx, function( $matches ) {

		$matched_sequence = trim( $matches[0] );

		if ( '@' === $matched_sequence[0] ) {
			return ' <a target="_blank" rel="noopener" role="link" title="' . $matched_sequence . '" href="https://twitter.com/' . ltrim( $matched_sequence, '@' ) . '">' . $matched_sequence . '</a> ';
		}
		if ( '#' === $matched_sequence[0] ) {
			return ' <a target="_blank" rel="noopener" role="link" title="' . $matched_sequence . '" href="https://twitter.com/hashtag/' . ltrim( $matched_sequence, '#' ) . '">' . $matched_sequence . '</a> ';
		}

	}, $parsed_text );

	return $parsed_text;
}

function wkt_prepare_media_data( $twt_obj ) {

	if ( isset( $twt_obj->extended_entities ) && ! isset( $twt_obj->extended_entities->media ) ) {
		return null;
	}

	$media = $twt_obj->extended_entities->media;

	$media_data = array();

	foreach ( $media as $key => $entity ) {

		$media_data[ $key ] = array(

			'media_url'     => $entity->media_url_https . '?format=png&name=small', // thumb,large,media.
			'type'          => $entity->type,
			'expanded_url'  => $entity->expanded_url,
		);

		if ( 'video' === $entity->type || 'animated_gif' === $entity->type ) {

			$media_data[ $key ]['video_info'] = $entity->video_info;
		}
	}

	return $media_data;
}

add_action( 'wp_ajax_wkt_fetch_twitter_deck_data', 'wkt_fetch_twitter_deck_data_cb' );
add_action( 'wp_ajax_nopriv_wkt_fetch_twitter_deck_data', 'wkt_fetch_twitter_deck_data_cb' );

function wkt_fetch_twitter_deck_data_cb() {

	check_ajax_referer( 'wkXhr_handler_nonce', 'token' );

	if ( ! isset( $_POST['options'] ) || empty( $_POST['options'] ) ) {
		die;
	}

	try {

		$opt_string         = json_decode( wp_unslash( strip_tags( (string) $_POST['options'] ) ) );
		$position           = wp_unslash( strip_tags( (string) $opt_string->position ) );
		$count              = isset( $opt_string->count ) ? wp_unslash( strip_tags( (string) $opt_string->count ) ) : 6;

		// $twitteruser        = 'demo_wk';
		// $collectionid       = 'custom-1102497266063966208';
		// $consumerkey        = 'kt4gei2l0r7K8enbjSRmIyEIE';
		// $consumersecret     = '8J4Vv0ZFCSzOMS4bFw19QgCv54U1vYeCUaUtGhuEBo0eeHCbKV';
		// $accesstoken        = '1102493973946327041-3uXI4eoQDvc2y7Ti8uLYYUp2G6agi4';
		// $accesstokensecret  = 'uR8TejTMMAMBhQYIEuA9872N8tBpnWj8A6J0PDL7PTLwS';

		$twitteruser        = 'webkul';
		$collectionid       = 'custom-1105469060161036288';
		$consumerkey        = '3guwH9DbxwXtLVS54UvlDg';
		$consumersecret     = 'HQDXh6tBmLmEL6fNMz6usUgIhjhXOroeAAfDuxo3d3M';
		$accesstoken        = '129196071-RBU6WgH8MFxMYEy6qBjFlrAv15aj0GPAwQ3eGjf2';
		$accesstokensecret  = '6wHJrU0M255ryjbLLvkUuAFYFN9FzOzR9pCLHA2KqsM';

		$connection         = get_connection_with_access_token( $consumerkey, $consumersecret, $accesstoken, $accesstokensecret );
		$max_position_query = ( 'false' !== $position && ! is_null( $position ) && 'null' !== strtolower( $position ) ) ? ( '&max_position=' . $position ) : '';

		$tweet_collection   = $connection->get( 'https://api.twitter.com/1.1/collections/entries.json?id=' . $collectionid . $max_position_query . '&tweet_mode=extended&sort_by=created_at-desc&count=' . $count );
		$built_response     = array(
			'tweets'   => array(),
			'response' => array(),
		);

		$tweets             = $tweet_collection->objects->tweets;
		$tweet_data         = array();

		foreach ( $tweets as $twt_key => $twt ) {

			$full_text   = $twt->full_text;
			$media_data  = wkt_prepare_media_data( $twt );
			$parsed_text = stripslashes( wkt_custom_twitter_text_parser( $full_text ) );
			$user_object = $connection->get( 'https://api.twitter.com/1.1/users/show.json?id=' . $twt->user->id );

			$user_object = array(
				'screen_name'   => $user_object->screen_name,
				'name'          => $user_object->name,
				'profile_image' => $user_object->profile_image_url_https,
				'profile_link'  => 'https://twitter.com/' . $user_object->screen_name,
			);

			$created_date = date( 'M d, Y', strtotime( $twt->created_at ) );

			$tweet_data[ $twt_key ] = array(
				'date'           => $created_date,
				'id'             => $twt->id,
				'retweeted'      => $twt->retweeted,
				'like_count'     => $twt->favorite_count,
				'retweet_count'  => $twt->retweet_count,
				'url'            => $twt->enitities->urls,
				'text'           => $parsed_text,
				'media'          => $media_data,
				'user'           => $user_object,
				'url'            => 'https://twitter.com/i/web/status/' . $twt->id,
			);
		}

		/**
		 * Prepared Api Response
		 */
		$built_response['tweets']   = $tweet_data;
		$built_response['response'] = array(
			'max_position'  => $tweet_collection->response->position->max_position,
			'min_position'  => $tweet_collection->response->position->min_position,
			'was_truncated' => $tweet_collection->response->position->was_truncated,
		);

		wp_send_json( (object) [
			'body'   => $built_response,
			'status' => 'true',
		] );

	} catch ( Exception $e ) {
		wp_send_json( (object) [
			'body'   => $e->getMessage(),
			'status' => 'false',
		] );
	}

	die;
}

/**
 * Jobs OG init handler File
 */
require_once WKTHEME_CORE . 'wk-jobog-init-handler.php';
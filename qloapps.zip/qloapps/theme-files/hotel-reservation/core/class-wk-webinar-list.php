<?php
if( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}
if ( ! class_exists( 'wk_webinar_list' ) ) {

  class wk_webinar_list extends WP_LIST_TABLE {

    public function __construct() {
      parent::__construct( [
        'singular' => __( 'Webinar', 'qa' ), //singular name of the listed records
        'plural'   => __( 'Webinars', 'qa' ), //plural name of the listed records
        'ajax'     => false //should this table support ajax?
        ] );
    }

    public function prepare_items() {
      $qa_webinar            = $this->get_webinar();
      $columns               = $this->get_columns();
      $hidden                = array();
      $sortable              = $this->get_sortable_columns();
      $this->_column_headers = array( $columns, $hidden, $sortable );

      $this->process_bulk_action();

      function usort_reorder( $a, $b ) {
        $orderby = ( ! empty( $_GET['orderby'] ) ) ? $_GET['orderby'] : 'post_date';
        $order   = ( ! empty( $_GET['order'] ) ) ? $_GET['order'] : 'asc';
        $result  = strcmp( strtolower( $a[ $orderby ] ), strtolower( $b[ $orderby ] ) );
        return ( $order === 'desc' ) ? $result : -$result;
      }
      usort( $qa_webinar, 'usort_reorder' );

      $per_page     =  $this->get_items_per_page( 'qa_webinar_per_page', 5 );
      $current_page = $this->get_pagenum();
      $total_items  = count( $qa_webinar );

      $data_found   = array_slice( $qa_webinar, ( ( $current_page - 1 ) * $per_page ), $per_page );

      $this->items = $data_found;
      $this->set_pagination_args( array( 'total_items' => $total_items, 'per_page' => $per_page ) );
    }

    public function no_items() {
			_e( 'No Webinar yet, Sorry!' );
		}

    public function get_webinar() {
      $args = array(
        'post_type' => 'webinar',
				'posts_per_page' => '-1',
      );
      if( isset( $_GET['s'] ) && ! empty( $_GET['s'] ) ) {
        $args['s'] = $_GET['s'];
      }
      $response = get_posts( $args );
      $data = array();
      foreach ( $response as $key => $value ) {
        $data[ $key ]['post_title']   = $value->post_title;
        $data[ $key ]['post_excerpt'] = $value->post_excerpt;
        $data[ $key ]['ID']           = $value->ID;
        $data[ $key ]['post_date']    = $value->post_date;
				$data[ $key ]['live_date']    = get_post_meta( $value->ID, 'webinar-date', true );
				// $data[ $key ]['live_date']    = str_replace( '-', '/', $data[ $key ]['live_date'] );
      }
      return $data;
    }

    public function get_columns() {
      $columns = array(
        'cb'           => '<input type="checkbox">',
        'post_title'   => 'Title',
        'post_excerpt' => 'Excerpt',
				'live_date'    => 'Webinar On',
        'post_date'    => 'Publish Date',
      );
    return $columns;
    }

    //show plan table data
    public function column_default( $item, $column_name ) {
      switch( $column_name ) {
        case 'post_title':
        case 'post_excerpt':
        case 'post_date':
				case 'live_date':
        return $item[ $column_name ];
      }
    }

    function column_cb( $item ) {
			return sprintf( '<input type="checkbox" name="post[]" value="%s" />', $item['ID'] );
		}

    //set which column is sortable
    public function get_sortable_columns() {
      $sortable_columns = array(
        'post_title' => array( 'post_title', false ),
        'post_date'  => array( 'post_date', true ),
				'live_date'  => array( 'live_date', true ),
      );
      return $sortable_columns;
    }

    /*Perform Bulk Action*/
    public function get_bulk_actions(){
      $actions = array(
        'delete'      => 'Delete',
      );
      return $actions;
    }

    public function process_bulk_action() {
      if( 'delete' == $this->current_action() ) {
        if( isset( $_GET['post'] ) && ! empty( $_GET['post'] ) ) {
          if( is_array( $_GET['post'] ) ) {
            foreach ( $_GET['post'] as $post_id ) {
              if( get_post_type( $post_id ) && 'webinar' === get_post_type( $post_id ) ) {
                wp_delete_post( $post_id );
              }
            }
          } else {
            if( get_post_type( $_GET['post'] ) && 'webinar' === get_post_type( $_GET['post'] ) ) {
              wp_delete_post( $_GET['post'] );
            }
          }
          wp_safe_redirect( admin_url() . 'admin.php?page=webinar' );
          exit;
        }
      }
    }

    //set action to specific column
    public function column_post_title($item) {
        $actions = array(
          'edit'   => sprintf('<a href="?page=add_webinar&action=%s&post=%s">Edit</a>','edit',$item['ID']),
          'delete' => sprintf('<a href="?page=webinar&action=%s&post=%s">Delete</a>','delete',$item['ID']),
        );

        return sprintf('%1$s %2$s', $item['post_title'], $this->row_actions($actions) );
    }

    //set action to specific column
    public function column_post_excerpt( $item ) {
        return '<p style="overflow: hidden; -webkit-line-clamp: 3; display: -webkit-box; text-overflow: ellipsis; -webkit-box-orient: vertical; max-height:57px;">' . $item['post_excerpt'] . '</p>';
    }

    public function column_post_date( $item ) {
        return date( 'd M Y', strtotime( $item['post_date'] ) );
    }

		public function column_live_date( $item ) {
				return date( 'd M Y h:i A', strtotime( $item['live_date'] ) );
		}

  }

  $qa_webinar = new wk_webinar_list();
  ?> <div class="wrap">
          <h1 class="wp-heading-inline">Qlo Webinars</h1>
          <a href="<?php echo admin_url(); ?>admin.php?page=add_webinar" class="page-title-action">Add New</a>
  <?php
  $qa_webinar->prepare_items();
  ?>

  <form method="get">
  <input type="hidden" name="page" value="<?php echo $_REQUEST['page']; ?>"/>
  <?php
  $qa_webinar->search_box( 'search', 'search_plans' );
  $qa_webinar->display();
  echo " </form> ";
  echo "</div>";

}

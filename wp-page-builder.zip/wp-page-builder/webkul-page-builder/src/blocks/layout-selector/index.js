/**
 * Layout Selector Blocks and Open Layout Library
 */
var wkLayoutsData;
wp.apiFetch( {
    method: 'GET',
    path: '/wk-page-layouts/v1/layouts',
} ).then( ( layouts ) => {
    wkLayoutsData = Object.values( layouts );
});
function wkReplaceBlock( blockLayout ) {
    var wkSelectBlock = wp.data.select('core/block-editor');
    var currentBlockID = wkSelectBlock.getSelectedBlockClientId();
    
    
    wp.data.dispatch( 'core/block-editor' ).replaceBlocks(
        currentBlockID,
        rawHandler( {
            HTML: blockLayout,
            mode: 'BLOCKS',
        } )
    );

    const wkPrevBlockID = wkSelectBlock.getPreviousBlockClientId();
    ( null != wkPrevBlockID  ) && (wkSelectBlock.getBlocksByClientId(wkPrevBlockID)[0].name == 'wk-blocks/layout-selector') && wp.data.dispatch( 'core/block-editor' ).removeBlock( wkPrevBlockID );
    
};


registerBlockType( 'wk-blocks/layout-selector', {
    title : 'Layout Selector',
    icon:'layout',
    category:'webkul',
    example:{},
    edit: function(props) {
        const [isOpen, setOpen] = useState(false);
        const openModal = () => setOpen(true);

        const closeModal = () => setOpen(false);

		return(
            el(
                Fragment,
                null,
                el(
                    Placeholder,
                    {
                        key:'placeholder',
                        label:'Layout Selector',
                        instructions:'Launch the layout library to browse pre-designed sections.',
                        className:'wk-layout-selector-placeholder',
                        icon:'layout'
                    },
                    el(
                        Button,
                        {
                            isSecondary: true,
                            onClick: openModal,
                            className:'wk-open-modal-library'
                        },
                        "Open Layout Library",
                    ),
                    isOpen && el (
                        Modal,
                        {
                            title:'Layout Selector',
                            onRequestClose:closeModal,
                            className:'wk-layout-modal'
                        },
                        el(
                            'div',
                            {
                                className:'wk-modal-container'
                            },
                            ( undefined != wkLayoutsData && wkLayoutsData.length > 0 ) ? wkLayoutsData.map(
                                (layout) => {
                                   return( el(
                                                    'div',
                                                    {
                                                    className:'wk-modal-item',
                                                    onClick:function() {
                                                        wkReplaceBlock(layout.content)
                                                        }
                                                    },
                                                    el(
                                                        'img',
                                                        {
                                                            src:layout.image,
                                                            alt:'Image Gallery'
                                                        }
                                                    ),
                                                    el(
                                                        'span',
                                                        {
                                                            className:'wk-modal-item-info',
                                                        },
                                                        layout.name
                                                    )
                                                    
                                                ) )
                                }
                            ) : el(
                                'div',
                                {},
                                'No Layout Found'
                            ),
                        ),
                        el(
                            Button,
                            {
                                isSecondary:true,
                                onClick:closeModal,

                            },
                            'Close'
                        )
                    )
                )
            )
        );
    },
    /* Save the block markup. */
    save: () => {
        return null;
    },
} );
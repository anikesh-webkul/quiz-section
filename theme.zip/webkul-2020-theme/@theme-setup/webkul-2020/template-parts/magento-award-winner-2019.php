<?php
// Magento Award Winner 2019 Section.
?>
	<div class="aw-wrapper">
		<div class="aw-static">
			<span class="aw-close">Close</span>
			<span class="aw-logo-m"></span>
			<div class="aw-controls">
				<span class="aw-ctrl-prev aw-ctrl-hide"></span>
				<span class="aw-ctrl-info">01 <span>//</span> 02</span>
				<span class="aw-ctrl-next"></span>
			</div>
		</div>

		<div class="aw-grd">
				<!-- aw-vid -->
			<div class="aw-slideWrapA">
				<div class="aw-content aw-slideA">
					<div class="aw-trophy-wrapper">
					<div class="aw-trophy">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/images/award-winner/magento-award.png' ); ?>" title="Magento Top Selling Extension Award 2019" alt="Magento Top Selling Extension Award 2019">
					</div>
					</div>

					<div class="aw-desc">
						<span>Webkul</span>
						<h3>Technology Partner Awards</h3>
						<h4>Top Selling Extension 2018 Winner</h4>
						<h3>
							<a class="product" href="https://store.webkul.com/magento2-multi-vendor-marketplace.html" target="_blank" rel="noopener">
								<dText>Multi</dText>&nbsp;<dText>Vendor</dText>&nbsp;<dText>Marketplace</dText>
							</a>
						</h3>
						<p>2 times in a row - 2017 & 2018</p>
					</div>

				</div>
			</div>

			<div class="aw-slideWrapB">
				<div class="aw-content">
					<div class="aw-cursor-arrow-lt"></div>
					<div class="aw-cursor-arrow-rt"></div>
					<div class="aw-control-vid"></div>
					<div class="aw-caption">Top Selling Extension Winner</div>
					<span class="aw-tap"></span>
					<video id="ws-imagine-vid" controls loop>
						<source src="<?php echo esc_url( get_template_directory_uri() . '/images/award-winner/imagine-sneaks-2019.mp4' ); ?>" type="video/mp4">
					</video>
				</div>
			</div>

		</div>
	</div>
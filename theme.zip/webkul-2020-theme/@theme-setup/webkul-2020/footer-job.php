<?php
wp_footer();

get_template_part( 'template-parts/content', 'modal-contact' );

?>

<footer class="wk-footer wkgrid-wide">
	<div class="wk-mega-footer section-padding-0B">
		<div class="wk-footer-col">
			<h3 class="footer-title">Follow Us</h3>
			<ul class="menu">
				<li><a href="https://instagram.com/webkul/" target="_blank" rel="nofollow noopener" title="Instagram" class="icon insta">Instagram</a></li>
				<li><a href="https://twitter.com/webkul" target="_blank" rel="nofollow noopener" title="Twitter" class="icon twitter">Twitter</a></li>
				<li><a href="https://www.facebook.com/webkul" target="_blank" rel="nofollow noopener" title="Facebook" class="icon fb">Facebook</a></li>
				<li><a href="https://in.linkedin.com/company/webkul" title="Linkdin" rel="nofollow noopener" target="_blank" class="icon linkedin">LinkedIn</a></li>
				<li><a href="https://www.youtube.com/webkul" title="Youtube" rel="nofollow noopener" target="_blank" class="icon youtube">Youtube</a></li>
			</ul>
		</div>

		<div class="wk-footer-col">
			<p class="footer-title">Services</p>
			<?php wp_nav_menu( array( 'theme_location' => 'wk_our_expertise' ) ); ?>
		</div>
		<div class="wk-footer-col">
			<p class="footer-title">Technologies</p>
			<?php wp_nav_menu( array( 'theme_location' => 'wk_industries' ) ); ?>
		</div>
		<div class="wk-footer-col">
			<p class="footer-title">Explore</p>
			<?php wp_nav_menu( array( 'theme_location' => 'wk_explore' ) ); ?>
		</div>
		<div class="wk-footer-col">
			<p class="footer-title">Quick Links</p>
			<?php wp_nav_menu( array( 'theme_location' => 'wk_quick_link' ) ); ?>
		</div>
	</div>

	<div class="wk-mini-footer">
		<div class="wk-items-inlined">
			<div class="footer-entity google">
				<span class="logo"></span>
				<span class="rating">4.3<span></span><span></span><span></span><span></span><span></span></span>
				<span>911+ Google Reviews</span>
			</div>
			<div class="footer-entity trustpilot">
				<span class="logo"></span>
				<span class="rating">4.6<span></span><span></span><span></span><span></span><span></span></span>
				<span>652+ TrustPilot Reviews</span>
			</div>
			<div class="footer-entity">
				<?php echo wk_webp( 'orphan/norton-security-logo.png', 'powered-by-norton' ); ?>
			</div>
			<div class="footer-entity">
				<?php echo wk_webp( 'orphan/magento-certified-badge.png?v=1', 'magento-certified-badge' ); ?>
			</div>
		</div>
		<div class="footer-entity">
			<p>&copy; Copyright 2010-<?php echo esc_html( date( 'Y' ) ); ?>, Webkul Software (Registered in India). All rights reserved.</p>
			<p>Webkul <a href="<?php echo home_url() . '/disclaimer/'; ?>" class="inherited">doesn't authorize any third party sellers</a> to re-sell Webkul modules.</p>
		</div>

	</div>
</footer>

<script type="application/javascript">
console.log("%cWe are Webkul %c\n\nWe love people like you, who are curious about the source codes ¯\_(ツ)_/¯.\nWhen you can join us, Why you only want to peep into it here. Check out open positions and join us - https://webkul.com/careers", "color: #2149f3; font-size:30px;", "color:##0e1b51;font-size:14px");
</script>

<script type='application/ld+json'>
{
  "@context": "http://www.schema.org",
  "@type": "Organization",
  "name": "Webkul Software",
  "url": "https://webkul.com/",
  "sameAs": [
    "https://www.linkedin.com/company/webkul",
    "https://www.youtube.com/webkul",
    "https://twitter.com/webkul",
    "https://www.facebook.com/webkul"
  ],
  "logo": "https://webkul.com/wp-content/themes/webkul-2018/images/icon-144.png",
  "image": "https://webkul.com/wp-content/themes/webkul-2018/images/icon-144.png",
  "description": "Webkul is the hook for enterprise businesses and helps enterprises to upscale easily with a wider range of ready to use and highly customisable eCommerce centric products.",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "A-67 Sector 63",
    "addressLocality": "Noida",
    "addressRegion": "Uttar Pradesh",
    "postalCode": "201301",
    "addressCountry": "India"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91 9870284067",
    "contactType": "customer service"
  },
  "founder": "Vipin Sahu, Vinay Yadav and Prakash Sahu",
  "foundingDate": "2010",
  "foundingLocation": "Noida, India"
}
</script>

<?php
$job_data = isset( $GLOBALS['WEBKUL_THEME_OPTIONS']['job_header_meta'] ) ? $GLOBALS['WEBKUL_THEME_OPTIONS']['job_header_meta'] : array();

$jobposting_schema_assoc = array(
	'@type'              => 'JobPosting',
	'title'              => $job_data['position_name'],
	'description'        => '<p>' . $job_data['position_detail'] . '</p>',
	'datePosted'         => '2019-08-06',   // ISO 8601 format. For example, "2017-01-24" or "2017-01-24T19:33:17+00:00".
	'validThrough'       => '2019-12-06',
	'employmentType'     => 'FULL_TIME',
	'hiringOrganization' => array(
		'@type'  => 'Organization',
		'name'   => 'Webkul Software',
		'sameAs' => 'https://webkul.com/',
		'logo'   => 'https://webkul.com/wp-content/themes/webkul-2018/images/icon-144.png',
	),
	'jobLocation' => array(
		'@type'   => 'Place',
		'address' => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => 'A-67',
			'addressLocality' => 'Sector 63',
			'addressRegion'   => 'Noida, UP',
			'postalCode'      => '201301',
			'addressCountry'  => 'IND',
		),
	),
);

if ( ! empty( $job_data['expected_salary'] ) ) {

	// remove unwanted strings.
	$salary     = strtolower( $job_data['expected_salary'] );
	$salary     = str_replace( 'lpa', '', $salary );
	$salary     = str_replace( 'ctc', '', $salary );
	$salary     = str_replace( ' ', '', $salary );
	$salary     = explode( '-', $salary );
	$min_salary = isset( $salary[0] ) ? intval( $salary[0] ) * 100000 : $salary[0];
	$max_salary = isset( $salary[1] ) ? intval( $salary[1] ) * 100000 : 'above';

	$jobposting_schema_assoc['baseSalary'] = array(
		'@type'    => 'MonetaryAmount',
		'currency' => 'INR',
		'value' => array(
			'@type'    => 'QuantitativeValue',
			'minValue' => $min_salary,
			'maxValue' => $max_salary,
			'unitText' => 'YEAR',
		),
	);
}

function the_wk_richsnippet( $data, $bound_tag = false ) {

	$flags     = 0;
	$formatted = '';

	if ( $bound_tag ) {
		$formatted = '<script type="application/ld+json">';
	}

	if ( version_compare( PHP_VERSION, '5.4', '>=' ) ) {
		// @codingStandardsIgnoreLine This is used in the wp_json_encode call, which checks for this.
		$flags = ( $flags | JSON_UNESCAPED_SLASHES );
	}

	if ( ! isset( $data['@context'] ) ) {

		$data = array( '@context' => 'http://schema.org' ) + $data;
	}

	$formatted .= wp_json_encode( $data, $flags );

	if ( $bound_tag ) {
		$formatted .= '</script>';
	}

	return $formatted;
};

if ( is_page() ) {

	echo '<script type="application/ld+json">';

	$child_position = 1;

	if ( $post->post_parent > 0 ) {
		$parent_id = $post->post_parent;
		$parent_url = get_permalink( $parent_id );
		$parent_title = get_the_title( $parent_id );
		$parent_schema = '{
			"@type": "ListItem",
			"position": "1",
			"item": {
				"@id": "' . esc_url( $parent_url ) . '",
				"name": "' . esc_html( ucwords( $parent_title ) ) . '"
			}
		},';

		$child_position = 2;
	}

	$url      = site_url();
	$page_url = get_permalink( get_queried_object()->ID );
	$page     = get_queried_object()->post_title;
	$schema   = '{
			"@context": "http://schema.org",
			"@type": "BreadcrumbList",
			"itemListElement": [<!--PARENT-->{
				"@type": "ListItem",
				"position": "' . $child_position . '",
				"item": {
					"@id": "' . esc_url( $page_url ) . '",
					"name": "' . esc_html( ucwords( $page ) ) . '"
				}
			}<!--JOBCHILD-->]
		}';

	$child_position ++;

	if ( $post->post_parent > 0 ) {
		$schema = str_replace( '<!--PARENT-->', $parent_schema, $schema );
	} else {
		$schema = str_replace( '<!--PARENT-->', '', $schema );
	}

	$job_slug = get_query_var( 'job' );

	if ( ! empty( $job_slug ) ) {
		$job_schema = ',{
			"@type": "ListItem",
			"position": "' . $child_position . '",
			"item": {
				"@id": "' . esc_url( $page_url . $job_slug ) . '",
				"name": "' . esc_html( ucwords( $job_data['position_name'] ) ) . '"
			}
		}';

		$schema = str_replace( '<!--JOBCHILD-->', $job_schema, $schema );
	} else {
		$schema = str_replace( '<!--JOBCHILD-->', '', $schema );
	}

	echo $schema;

	echo '</script>';
}

echo the_wk_richsnippet( $jobposting_schema_assoc, true );
?>
</body>
</html>

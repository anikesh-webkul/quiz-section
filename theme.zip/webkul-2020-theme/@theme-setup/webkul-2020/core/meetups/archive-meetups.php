<?php
/**
*The template for displaying All Pages
*
*@package webkul
*@subpackage webkul theme 2K18
*@since webkul theme 2.0
*/

get_header();
?>
<section class="wk-page-content section-padding-0T section-top">
	<div class="wkgrid-squeezy">
        <h1 style="text-align: center;">MeetUps</h1>
        <p>Webkul truly believes bringing the local design, dev, and marketing community altogether. Webkul organizes set of talks, conferences and networking events to engage with the community by sharing both the resources and business insights. You can check both the past and upcoming meetups below.</p>
	</div>
</section>
<?php

function strip_excerpt_regex( $string ) {

	return preg_replace( '#(<h([1-6])[^>]*>)\s?(.*)?\s?(<\/h\2>)#', '', $string ); 
}

$wk_args = array(
    'post_type' => 'meetups',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'meta_key' => '__wk_meetup_date_',
    'orderby' => 'meta_value',
    'order'   => 'DESC', 
);

$meetups = get_posts( $wk_args );

date_default_timezone_set( 'Asia/kolkata' );
$upcoming_meetup = array_filter( $meetups, function( $m ) {
    $t = get_post_meta( $m->ID, '__wk_meetup_date_', true );
    // return ( date('Ymd', strtotime( $t ) ) >  date('Ymd') );
    return ( 'magento-meetup' == $m->post_name ) || ( date('Ymd', strtotime( $t ) ) >  date('Ymd') ) ? true : false;
} );

$past_meetup = array_filter( $meetups, function( $m ) {
    $t = get_post_meta( $m->ID, '__wk_meetup_date_', true );
    // return ( date('Ymd', strtotime( $t ) ) < date('Ymd') );
    return ( date('Ymd', strtotime( $t ) ) < date('Ymd') && ( 'magento-meetup' != $m->post_name ) ) ? true : false;
} );

if( ! empty( $upcoming_meetup ) ) {
	usort( $upcoming_meetup, function( $a, $b ) {
		$d1 = get_post_meta( $a->ID, '__wk_meetup_data_', true );
		$d2 = get_post_meta( $b->ID, '__wk_meetup_data_', true );
		
		if( strtotime( $d1['start-date'] ) > strtotime( $d2['start-date'] ) ) {
			return 1;
		} else {
			return -1;
		}
	} );
    ?>
    <section class="wk-meetup-section section-padding-0T">
        <div class="wkgrid-squeezy">
            <?php
            echo  '<h2>Upcoming</h2>';
            foreach ( $upcoming_meetup as $value ) {
                wk_meetup_wodge( (array) $value, true );
            }
            echo '<hr>';
            ?>
        </div>
    </section>
    <?php
}

if( ! empty( $past_meetup ) ) {
    ?>
    <section class="wk-meetup-section section-padding-0T">
        <div class="wkgrid-squeezy">
            <?php
            echo  '<h2>Past</h2>';
            foreach ( $past_meetup as $value ) {
                wk_meetup_wodge( (array) $value, false );
            }
            ?>
        </div>
    </section>
    <?php
}

function wk_read_more_text( $string, $link ) {

	$string = strip_tags( $string );

	if ( strlen( $string ) > 300 ) {

			// truncate string
			$string_cut     = substr( $string, 0, 300 );
			$string_cut_end = substr( $string, 300 );
			$end_point      = strrpos( $string_cut, ' ' );
			//if the string doesn't contain any space then it will cut without word basis.
			$string  = $end_point ? substr( $string_cut, 0, $end_point ) : substr( $string_cut, 0 );
			$string .= ' ... <a href="' . $link . '" class="wk-meetup-more-btn">Read more</a>';

	}

	return $string;

}

function wk_meetup_wodge ( $args, $calendar = false ) {

    $id       = $args['ID'];

    $wk_page_data  = get_post_meta( $id, '__wk_meetup_page_data_', true );
    $wk_event_data = get_post_meta( $id, '__wk_meetup_data_', true );

    $image = ( isset( $wk_page_data['archive-image'] ) ) ? $wk_page_data['archive-image'] : false;
    $image = ! empty( $image ) ? wp_get_attachment_image_src( $image, 'main' )[0] : false;
	$title       = ( isset( $args['post_title'] ) ) ? $args['post_title'] : '';

    $date        = ( isset( $wk_event_data['start-date'] ) ) ? $wk_event_data['start-date'] : '';
    $end_date        = ( isset( $wk_event_data['end-date'] ) ) ? $wk_event_data['end-date'] : '';

	$description = ( isset( $args['post_content'] ) ) ? $args['post_content'] : '';

	$description = ( $exc = $args['post_excerpt'] ) ? $exc :  strip_excerpt_regex( $description );

	$tlink       = get_the_permalink( $id );

	?>
	<div class="meetup-wodge">

		<?php
		if ( ! empty( $image ) ) {

		?>
			<div class="meetup-img-wrap">
				<a href="<?php echo esc_url( $tlink ); ?>">
					<img class="meetup-img" src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" title="<?php echo esc_attr( $title ); ?>" >
				</a>
			</div>

		<?php

		}

		?>

		<div class="meetup-content">

			<?php

			if ( ! empty( $title ) ) {

			?>

				<div class="meetup-title"><a href="<?php echo esc_url( $tlink ); ?>"><?php echo esc_attr( $title ); ?></a></div>

			<?php

			}

			if ( ! empty( $date ) ) {
				if( 'magento-meetup' !== $args['post_name'] ) {
					?>

					<div class="meetup-date-time"><?php echo date( 'l, F d, Y, h:i A', strtotime( $date ) ); ?></div>

					<?php
				}

			}


			if ( ! empty( $calendar ) ) {
				if( 'magento-meetup' !== $args['post_name'] ) {
				?>
				<a href='https://www.google.com/calendar/render?action=TEMPLATE&text=<?php echo wp_kses_post( $title ); ?>&dates=<?php echo date( 'Ymd\\THi00', strtotime( $date ) ) ?>/<?php echo date( 'Ymd\\THi00', strtotime( $end_date ) ) ?>&details=<?php echo wp_kses_post( $title ); ?>&sf=true&output=xml' target="_blank" rel="noopener" class="wk-button open-form-btns">ADD TO CALENDER</a>

				<?php
				} else {
				 echo '<p class="coming-soon" style=" color: #f94646; border: 1px solid #f94646; display: inline-block; padding: 3px 6px 2px; border-radius: 4px; font-size: 16px; cursor: wait; font-weight: 500; ">Coming Soon...</p>';
				}

			}

			if ( ! empty( $description ) ) {
				?>
				<div class="meetup-desc">
					<p><?php echo wk_read_more_text( $description, $tlink ); ?></p>
				</div>
				<?php
			}
			?>
		</div>
	</div>
	<?php
}



get_footer();

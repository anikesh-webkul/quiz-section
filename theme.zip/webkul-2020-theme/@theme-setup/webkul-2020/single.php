<?php 
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package webkul  
 * @subpackage webkul theme
 * @since webkul theme 1.0
*/
get_header();	
		?>	
<div class="wk-content">
	<div class="full-background">
		<div class="wk-blank-banner"></div>
		<div class="mdl-grid wk-content-wrapper-1140 background-white z-index-up">
				            <?php	

						    while (have_posts() ) :the_post();
						    $company_name=get_post_meta(get_the_ID(),'company_name',true);
						    $company_location=get_post_meta(get_the_ID(),'company_location',true);
						    $author_fb_link=get_post_meta(get_the_ID(),'author_fb_link',true);
				            $author_twitter_link=get_post_meta(get_the_ID(),'author_twitter_link',true);
				            $author_linkedin_link=get_post_meta(get_the_ID(),'author_linkedin_link',true);
				            $estab_year=get_post_meta(get_the_ID(),'estab_year',true); 
				            $profile_image=get_post_meta(get_the_ID(),'profile_image',true);
				            $dir=wp_upload_dir();
				            $profile_image=$dir['baseurl'].$profile_image;
							?>						
							<div class="mdl-cell mdl-cell--1-col"></div>
								<div class="mdl-cell mdl-cell--10-col">
									<div class="webkul-blog">
									<!-- 	<div class="blog-title">
											<h2 class="about-us-h2"><?php echo get_the_title(); ?></h2>	
										</div> -->
										<div class="blog-banner">
											<?php $src=wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );
										    	if($src){?>
										    	<img src="<?php echo $src?>" alt="<?php echo $src?>" />
										    	<?php 
										    	}?>
										    <div class="profile-status">
										    	<div class="profile-image">
										    		<img src="<?php echo $profile_image;?>" alt="<?php echo $profile_image?>">
										    	</div>
										    	<div class="profile-detail mdl-typography--text-center">
										    		<h2><?php echo $company_name; ?></h2>			
										    		<p><?php echo $company_location?></p>
										    		<p>Established In - 
										    			<span><?php echo $estab_year?></span>
										    		</p>
										    		<?php if(!empty($author_linkedin_link)){
										    		echo "<a href='".$author_twitter_link."' id='twitter' class='wk-twitter' target='_blank'>"."</a>";
														}
													if(!empty($author_fb_link)){																							    	
										    		echo "<a href='".$author_fb_link."' class='wk-facebook' id='facebook' target='_blank'>"."</a>";
										    			}
										    		if(!empty($author_twitter_link)){	
										    		echo "<a href='".$author_linkedin_link."' class='wk-linkedin' id='linkedin' target='_blank'>"."</a>";
										    		}?>
										    	</div>
										    </div>  
										</div>
									</div>	
								</div>	
								<div class="mdl-cell mdl-cell--1-col"></div>
								<div class="mdl-cell mdl-cell--1-col"></div>		 
								<div class="mdl-cell mdl-cell--10-col">		
										<div class="our-story mdl-typography--text-center">
											<h2 class="mdl-typography--text-center margin-top-22">Success Story</h2>
										</div>
								</div>	
								<div class="mdl-cell mdl-cell--1-col"></div>
								<div class="mdl-cell mdl-cell--1-col"></div>
								<div class="mdl-cell mdl-cell--10-col">		
										<div class="blog-dashboard-content"> 
											<?php the_content(); 
											?>
										</div>	
								</div>
								<div class="mdl-cell mdl-cell--1-col"></div>
								<div class="mdl-cell mdl-cell--1-col"></div>
								<div class="mdl-cell mdl-cell--10-col">
									<!--Disqus Wrapper-->


										<div class="disqus-wrapper  mdl-card mdl-shadow--4dp">

											<?php display_disqus_body();?>

										</div>

										<!--/Disqus Wrapper-->	
								</div>
								<div class="mdl-cell mdl-cell--1-col"></div>
							<?php 

						endwhile;
				 ?>
		</div>
	</div>
		
<?php
get_footer();

?>

<?php
/*
Plugin Name: Subscribe News letter
Plugin URI: http://hotelreservation.com/blog
Description: A plugin for Subscribing News letter
Author: Webkul
Author URI: http://webkul.com.com/blog
Text Domain: Hotel Reservation
*/
 
class subscribeNewsletter_Widget extends WP_Widget {
 
    public function __construct() {
     
        parent::__construct(
            'subs_id',
            __( 'Hotel Reservation Subscribe News Letter', 'subscribe' ),
            array(
                'classname'   => 'subscribe_news_letter',
                'description' => __('Hotel Reservation Subscribe News Letter Widget for adding Link To Post.', 'subscribe' )
                )
        );
       
    }
 
    /**  
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {    
         
        extract( $args );
         
        ?>

        <!--Banner Wrapper-->

         <div id="mc_embed_signup" class="subscribe-now">           
          <form action="//qloapps.us8.list-manage.com/subscribe/post?u=a6022fbcc8eb59ebd26658e1c&amp;id=96917c5642" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
            <div id="mc_embed_signup_scroll">
              <h3 class="text-default text-center">Subscribe Our Newsletter to Get Latest Updates</h3>
                <img src="<?php echo get_template_directory_uri().'/images/icon-mail.png'?>" class="img-responsive" alt="Subscribe Newsletter">
              <div class="mc-field-group">
                  <input type="email" placeholder="Type Your Email" name="EMAIL" class="required email" id="mce-EMAIL">
              </div>
              <div id="mce-responses" class="clear">
                <div class="response" id="mce-error-response" style="display:none"></div>
                <div class="response" id="mce-success-response" style="display:none"></div>
              </div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
              <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_a6022fbcc8eb59ebd26658e1c_be6f4be20e" tabindex="-1" value=""></div>
              <div class="clear"> 
              <input type="submit" value="Update Me" name="subscribe" id="mc-embedded-subscribe" class="white btn btn-bgcolor btn-subscribe"></div>
            </div>
          </form>
          </div>
                
       <!--/Banner Wrapper-->
<?php                    
    }
 
  
    /**
      * Sanitize widget form values as they are saved.
      *
      * @see WP_Widget::update()
      *
      * @param array $new_instance Values just sent to be saved.
      * @param array $old_instance Previously saved values from database.
      *
      * @return array Updated safe values to be saved.
      */
    public function update( $new_instance, $old_instance ) {        
         
        $instance = $old_instance;
         
        return $instance;
         
    }
  
    /**
      * Back-end widget form.
      *
      * @see WP_Widget::form()
      *
      * @param array $instance Previously saved values from database.
      */
    public function form( $instance ) {    
     
        
       
    }
     
}
 
/* Register the widget */
add_action( 'widgets_init', function(){
     register_widget( 'subscribeNewsletter_Widget' );
});
<?php
get_header();
?>
<!--Banner section-->
<section class="merchandise-banner">
  <div class="container">
    <div class="row text-center">
      <div class="col-md-2"></div>
      <div class="col-md-8">
        <h2>QloApps Band Merchandise</h2>
        <p>For Order Any Merchandise Product</p>

          <a class="contact-link" href="<?php echo site_url('contact');?>">CONTACT US</a>
      </div>
      <div class="col-md-2"></div>
    </div>
  </div>
</section>

<section class="merchandise-content">
  <div class="container">
    <div class="row">

          <h1>T-SHIRT</h1>

    </div>
    <div class="row text-center">
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/T-shirt-1.png'?>" >
        <p class="product-name">BLACK T-SHIRTS</p>
        <p class="product-price">$ 15.00</p>
      </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/T-shirt-2.png'?>">
        <p class="product-name">BLACK T-SHIRTS</p>
        <p class="product-price">$ 15.00</p>
      </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/T-shirt-3.png'?>">
        <p class="product-name">BLACK T-SHIRTS</p>
        <p class="product-price">$ 15.00</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/T-shirt-4.png'?>" >
        <p class="product-name">BLACK T-SHIRTS</p>
        <p class="product-price">$ 15.00</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/T-shirt-5.png'?>" >
        <p class="product-name">T-SHIRTS</p>
        <p class="product-price">$ 15.00</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/T-shirt-6.png'?>" >
        <p class="product-name">T-SHIRTS</p>
        <p class="product-price">$ 15.00</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/T-shirt-7.png'?>" >
        <p class="product-name">T-SHIRTS</p>
        <p class="product-price">$ 15.00</p>
        </div>
      </div>
      <!-- <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/T-shirt-8.png'?>" >
        <p class="product-name">T-SHIRTS</p>
        <p class="product-price">$ 15.00</p>
      </div>
      </div> -->
    </div>
    <div class="row">
      <h1>STICKER</h1>
    </div>
    <div class="row text-center">
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/Sticker-1.png'?>" >
        <p class="product-name">STICKER</p>
        <p class="product-price">$ 5.00</p>
      </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/Sticker-2.png'?>" >
        <p class="product-name">Q-STICKER</p>
        <p class="product-price">$ 5.00</p>
      </div>
      </div>
      <!-- <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php //echo get_template_directory_uri().'/images/merchandise/Sticker-3.png'?>" >
        <p class="product-name">LAPTOP STICKER</p>
        <p class="product-price">$ 5.00</p>
      </div>
      </div> -->
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/Sticker-4.png'?>" >
        <p class="product-name">LAPTOP STICKER</p>
        <p class="product-price">$ 5.00</p>
      </div>
      </div>
    </div>
    <!-- <div class="row">
      <h1>BAGS</h1>
    </div>
    <div class="row text-center">
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/Bag-1.png'?>" >
        <p class="product-name">STICKER</p>
        <p class="product-price">$ 15.00</p>
      </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/Bag-2.png'?>" >
        <p class="product-name">Q-STICKER</p>
        <p class="product-price">$ 15.00</p>
      </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/Bag-3.png'?>" >
        <p class="product-name">LAPTOP STICKER</p>
        <p class="product-price">$ 30.00</p>
      </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/Bag-4.png'?>" >
        <p class="product-name">LAPTOP STICKER</p>
        <p class="product-price">$ 30.00</p>
      </div>
      </div>
    </div>
    <div class="row">
      <h1>KEY RINGS</h1>
    </div>
    <div class="row text-center">
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/Key-ring-1.png'?>" >
        <p class="product-name">STICKER</p>
        <p class="product-price">$ 15.00</p>
      </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="body-content">
        <img src="<?php echo get_template_directory_uri().'/images/merchandise/Key-ring-2.png'?>" >
        <p class="product-name">Q-STICKER</p>
        <p class="product-price">$ 15.00</p>
      </div>
      </div>
    </div> -->
    </div>
</section>
<?php get_footer();
?>

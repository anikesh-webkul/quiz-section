<?php
/**
*The template for displaying All Pages
*
*@package webkul
*@subpackage webkul theme 2K18
*@since webkul theme 2.0
*/

/*Page template shortcodes. To be used in editor*/
add_shortcode( 'award_mention_section', function() {
	ob_start();
	?>
	<div class="wkColumnGrid " style="grid-column-gap:30px;grid-row-gap:30px;">
	<div class="wk-award-page-bricks">
		<a href="https://magento.com/innovations-lab/ar-product-sizing-innovations-lab" class="award-brick" target="noopener nofollow">
			<img src="<?php echo img_dir( '/award/magento-imagine-logo.png' ); ?>" alt="magento-imagine-logo" />
			<p class="award-title">Innovation Lab Winner</p>
			<p class="award-desc">4 Times in a row</p>
		</a>
		<a href="https://webkul.com/magento-imagine-2019-award/" class="award-brick">
			<img src="<?php echo img_dir( '/award/magento-imagine-logo.png' ); ?>" alt="magento-imagine-logo" />
			<p class="award-title">Magento Imagine Award</p>
			<p class="award-desc">4 Times in a row</p>
		</a>
		<a href="https://webkul.com/deloitte-award/" class="award-brick">
			<img src="<?php echo img_dir( '/award/deloitte-logo.png' ); ?>" alt="deloitte-logo" />
			<p class="award-title">Technology Fast 50 India</p>
			<p class="award-desc">5 Times in a row</p>
		</a>
		<a href="https://webkul.com/blog/webkul-awarded-by-smart-ceo-for-startup-50/" class="award-brick" target="_blank" rel="noopener">
			<img src="<?php echo img_dir( '/award/startup50-logo.png' ); ?>" alt="startup50-logo" />
			<p class="award-title">Startup 50 Smart CEO</p>
			<p class="award-desc">4 Times in a row</p>
		</a>
	</div>
	<div class="wk-award-page-bricks-content"><h2><strong>Constantly proving our capabilities & commitment to quality</strong></h2>
	<p>Webkul is being recognized and appretiated constantly by industry leaders proving our capabilities and commitment to quality and innovation.</p>
	</div>
	</div>
	<?php
	return ob_get_clean();
} );
/*//Page template shortcodes. To be used in editor*/

get_header();

$page_id     = get_the_id();
$layout      = get_post_meta( $page_id, 'wk_page_layout_view', true );
$grid_class  = ( 'wide' === $layout ) ? 'wkgrid-wide' : 'wkgrid-squeezy';
$has_bg_col  = ( 'wide' === $layout ) ? 'section-padding has-bgcol' : 'section-padding-0B';
$tagline     = get_post_meta( $page_id, 'wk_banner_tagline', true );
$feat_img    = get_the_post_thumbnail_url( $page_id, 'full' );
$has_infobox = get_post_meta( $page_id, 'wk_infobox_visible', true );
$has_header  = get_post_meta( $page_id, 'wk_page_has_header', true );

$banner_resp_img = get_post_meta( $page_id, 'wk_banner_resp_img', true );

$opt_btn_attrs = maybe_unserialize( get_post_meta( $page_id, 'wk_opt_btn_attr', true ) );
?>

<?php
if ( '1' === $has_header ) {

	$layout        = get_post_meta( $page_id, 'wk_page_layout_view', true );
	$grid_class    = ( 'wide' === $layout ) ? 'wkgrid-wide' : 'wkgrid-squeezy';
	$grid_class    = ( 'full' === $layout ) ? 'wkgrid-full' : $grid_class;
	$has_bg_col    = ( 'wide' === $layout || 'full' === $layout ) ? 'section-padding has-bgcol' : 'section-padding-0B';
	$tagline       = get_post_meta( $page_id, 'wk_banner_tagline', true );
	$feat_img      = get_the_post_thumbnail( $page_id, 'full' );
	$full_headline = ( false === $feat_img ) ? 'wk-tagline-fill' : '';
	?>

	<section class="wk-page-header">
		<div class="wkgrid-squeezy">
			<div class="page-tagline <?php echo esc_attr( $full_headline ); ?>">
				<?php echo $tagline; ?>
				<?php
				if ( isset( $opt_btn_attrs['enable'] ) && '1' === $opt_btn_attrs['enable'] && ! empty( $opt_btn_attrs['link'] ) && ! empty( $opt_btn_attrs['label'] ) ) {

					$_link   = ( ! empty( $opt_btn_attrs['link'] ) ) ? $opt_btn_attrs['link'] : '';
					$_label  = ( ! empty( $opt_btn_attrs['label'] ) ) ? $opt_btn_attrs['label'] : '';
					$_rel    = ( ! empty( $opt_btn_attrs['rel'] ) ) ? ' rel=' . $opt_btn_attrs['rel'] : '';
					$_target = ( ! empty( $opt_btn_attrs['target'] ) ) ? ' target=_blank' : '';
					$_color  = ( ! empty( $opt_btn_attrs['color'] ) && 'prime' === $opt_btn_attrs['color'] ) ? 'wk-button' : 'wk-button ' . $opt_btn_attrs['color'];

					echo '<a class="' . esc_attr( $_color ) . '" href="' . esc_url( $_link ) . '"' . esc_attr( $_target . $_rel ) . '>' . esc_attr( $_label ) . '</a>';
				}
				?>
			</div>
		</div>

		<section id="wkmain-content" class="wk-customers-section section-padding-0B">
			<div class="wkgrid-wide text-center">
				<p class="title-mini">The world's top brands trust us</p>
				<div class="wk-window-to-toggle text-center wk-items-inlined">
					<div class="logo">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/images/customer/customer-logo-intel.png' ); ?>" alt="customer-logo-intel" />
					</div>
					<div class="logo">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/images/customer/customer-logo-tcs.png' ); ?>" alt="customer-logo-tcs" />
					</div>
					<div class="logo">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/images/customer/customer-logo-costco.png' ); ?>" alt="customer-logo-costco" />
					</div>
					<div class="logo">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/images/customer/customer-logo-nokia.png' ); ?>" alt="customer-logo-nokia" />
					</div>
					<div class="logo">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/images/customer/customer-logo-un.png' ); ?>" alt="customer-logo-un" />
					</div>
					<div class="logo">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/images/customer/customer-logo-huawei.png' ); ?>" alt="customer-logo-huawei" />
					</div>
					<div class="logo">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/images/customer/customer-logo-canon.png' ); ?>" alt="customer-logo-canon" />
					</div>
				</div>
			</div>
		</section>
		<hr/>

		<?php
		if ( is_page( 'magento-development' ) ) {
			?>
			<section class="page-notice-board">
				<div class="wkgrid-squeezy">
					<div class="notice-board-body">
						<?php echo wk_data_src( 'orphan/magento-certified', 'magento-certified-logo', 'notice-img' ); ?>
						<p class="notice-title">Magento Commerce Certified Developer</p>
						<p class="notice-detail">We are Magento certified specialists who understand both the business and commerce.</p>
					</div>
				</div>
			</section>
			<?php
		}
		?>

	</section>
	<?php
}
?>

<section class="wk-page-content">
	<?php
	while ( have_posts() ) {
		the_post();

		the_content();
	}
	?>
</section>

<?php
get_footer();

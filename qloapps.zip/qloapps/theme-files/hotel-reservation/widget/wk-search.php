<?php
/*
Plugin Name: Search Blog
Plugin URI: http://hotelreservation.com/blog
Description: A plugin for Search Blog
Author: Webkul
Author URI: http://hotelreservation.com/blog
Text Domain: Hotel Reservation
*/
 
class searchBlog_Widget extends WP_Widget {
 
    public function __construct() {
     
        parent::__construct(
            'search_id',
            __( 'Hotel Reservation Search feature', 'search' ),
            array(
                'classname'   => 'search_for_blog',
                'description' => __('Hotel Reservation Search Provide search related to blogs.', 'search' )
                )
        );
       
    }
 
    /**  
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {    
         
        extract( $args );
         
        ?>

        <!--Search Wrapper-->
        <div class="sidebar-search">
        
            <?php get_search_form();?>
        
        </div>        
       <!--/Search Wrapper-->
<?php                    
    }
 
  
    /**
      * Sanitize widget form values as they are saved.
      *
      * @see WP_Widget::update()
      *
      * @param array $new_instance Values just sent to be saved.
      * @param array $old_instance Previously saved values from database.
      *
      * @return array Updated safe values to be saved.
      */
    public function update( $new_instance, $old_instance ) {        
         
        $instance = $old_instance;
         
        return $instance;
         
    }
  
    /**
      * Back-end widget form.
      *
      * @see WP_Widget::form()
      *
      * @param array $instance Previously saved values from database.
      */
    public function form( $instance ) {    
     
        
       
    }
     
}
 
/* Register the widget */
add_action( 'widgets_init', function(){
     register_widget( 'searchBlog_Widget' );
});
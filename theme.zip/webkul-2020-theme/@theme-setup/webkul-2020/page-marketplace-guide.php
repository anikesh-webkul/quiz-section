<?php
get_header();
?>
<section class="wk-mp-user-guide">
	<div class="wkgrid-squeezy">
		<section class="wk-mp-userguide-header section-top">
			<div class="page-banner">
				<img id="mpguide-img" src="<?php echo esc_url( get_template_directory_uri() . '/images/doc-thumbnail.png' ); ?>">
			</div>
			<div class="page-tagline">
				<h1>Marketplace Business</h1>
				<ul>
					<li><p>Overview</p></li>
					<li><p>Marketplace</p></li>
					<li><p>Why we need marketplace</p></li>
					<li><p>Category of marketplace</p></li>
					<li><p>Marketplace business model</p></li>
					<li><p>Types of Marketplace</p></li>
					<li><p>Marketplace pricing model</p></li>
					<li><p>How to start Marketplace</p></li>
					<li><p>How to set up marketplace</p></li>
					<li><p>Marketplace mobile app</p></li>
					<li><p>Summary</p></li>
				</ul>
				<a id="mp-guide-btn" href="https://cdn.uvdesk.com/webkul/marketplace/marketplace-guide.pdf" class="wk-button" download>DOWNLOAD</a>
				<a href="https://marketplace.webkul.com/how-to-create-an-online-marketplace-store/" target="_blank" rel="noopener" class="wk-button" download="">Read More</a>
			</div>
		</section>
	</div>
	<div class="wkgrid-wide">
		<section class="wk-mp-platform section-padding-0B">
			<div class="col-md-12">
				<div class="platform-plank">
					<h1 id="mp-products">Products you may be interested in</h1>
					<div class="platform-card platform-magento">

						<div>
							<span class="wk-mp-platform-icon wk-mp-platform-icon-magento"></span>
							<h4>Magento&reg;</h4>
						</div>
						<p>Magento Multi Vendor Extension works in both Community (Free) and Enterprise Versions of Magento. Magento Marketplace Extension is feature enriched and easy to setup and install.</p>
						<a href="https://store.webkul.com/Magento-Extensions.html" target="_blank" rel="noopener" class="wk-mp-btn">View Extension</a>

					</div>

					<div class=" platform-card platform-magento">
						<div>
							<span class="wk-mp-platform-icon wk-mp-platform-icon-magento"></span>
							<h4>Magento&reg;2</h4>
						</div>
						<p>Magento Multi Vendor Extension works in both Community (Free) and Enterprise Versions of Magento. Magento Marketplace Extension is feature enriched and easy to setup and install.</p>
						<a href="https://store.webkul.com/Magento-2.html" target="_blank" rel="noopener" class="wk-mp-btn">View Extension</a>
					</div>

						<div class=" platform-card platform-prestashop">
						<div>
							<span class="wk-mp-platform-icon wk-mp-platform-icon-prestashop"></span>
							<h4>Prestashop</h4>
						</div>
						<p>Prestashop Marketplace Extension turns Prestashop Store into an Advanced Marketplace Store. Prestashop Marketplace focuses upon More Sellers, More Products, More Traffic, and More Revenues.</p>
						<a href="https://store.webkul.com/PrestaShop-Extensions.html" target="_blank" rel="noopener" class="wk-mp-btn">View Extension</a>
					</div>

					<div class=" platform-card platform-opencart">
						<div>
							<span class="wk-mp-platform-icon wk-mp-platform-icon-opencart"></span>
							<h4>Opencart</h4>
						</div>
						<p>Marketplace Extension for Opencart is quite flexible in functionality. It comes with the custom shipping features, where partners can add their own shipping rates according to respective factors.</p>
						<a href="https://store.webkul.com/OpenCart-Modules.html" target="_blank" rel="noopener" class="wk-mp-btn">View Extension</a>
					</div>

					<div class=" platform-card platform-cs-cart">
						<div>
							<span class="wk-mp-platform-icon wk-mp-platform-icon-cs-cart"></span>
							<h4>CS-Cart</h4>
						</div>
						<p>CS-Cart Marketplace Extension turns CS-Cart Store into Full Fledged Marketplace Store. In a matter of few clicks Marketplace Extension creates a rigid Multi Functional Cart System.</p>
						<a href="https://store.webkul.com/CS-Cart.html" target="_blank" rel="noopener" class="wk-mp-btn">View Extension</a>
					</div>

					<div class=" platform-card platform-shopify">
						<div>
							<span class="wk-mp-platform-icon wk-mp-platform-icon-shopify"></span>
							<h4>Shopify</h4>
						</div>
						<p>Shopify Marketplace App turns Shopify Store into a full fledged marketplace. The Seller has his own profile to sell products. Merchant charges the Commission on the number of Sales.</p>
						<a href="https://store.webkul.com/Shopify.html" target="_blank" rel="noopener" class="wk-mp-btn">View Extension</a>
					</div>

					<div class=" platform-card platform-wordpress">
						<div>
							<span class="wk-mp-platform-icon wk-mp-platform-icon-woocommerce"></span>
							<h4>WordPress<br/>WooComerce</h4>
						</div>
						<p>WordPress WooCommerce Marketplace Extension converts WooCommerce Store into the full featured Marketplace. After a quick installation, Seller has his own unique profile to sell goods.</p>
						<a href="https://store.webkul.com/Wordpress-Plugins.html" target="_blank" rel="noopener" class="wk-mp-btn">View Extension</a>
					</div>

					<div class=" platform-card platform-joomla">
						<div>
							<span class="wk-mp-platform-icon wk-mp-platform-icon-joomla"></span>
							<h4>Joomla Virtuemart</h4>
						</div>
						<p>Joomla Virtuemart Marketplace Extension converts Virtuemart Store into the full featured Marketplace. Joomla Virtuemart Marketplace Extension is fully compatible with Joomla 2.5 and Joomla 3.x.</p>
						<a href="https://store.webkul.com/Joomla-Extensions.html" target="_blank" rel="noopener" class="wk-mp-btn">View Extension</a>
					</div>

					<div class=" platform-card platform-odoo">
						<div>
							<span class="wk-mp-platform-icon wk-mp-platform-icon-odoo"></span>
							<h4>Odoo</h4>
						</div>
						<p>Odoo multi vendor marketplace module converts your odoo eCommerce into an efficient marketplace where admin has full control over the seller rights and permissions.</p>
						<a href="https://store.webkul.com/Odoo.html" target="_blank" rel="noopener" class="wk-mp-btn">View Extension</a>
					</div>

				</div>
			</div>
		</section>
	</div>

</section>
<?php
get_footer();

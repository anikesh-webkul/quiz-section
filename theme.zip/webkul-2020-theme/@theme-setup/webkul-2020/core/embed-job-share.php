<?php
global $wpdb;

$job_id    = get_query_var( 'job' );
$table     = $wpdb->prefix . 'open_positions';
$query_job = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE visibility='show' AND slug='%s'", $job_id ), ARRAY_A );

function filter_shared_job( $positions_bag, $job_id ) {

	$job_obj = array_values( array_filter( $positions_bag, function ( $item ) use ( $job_id ) {

		if ( trim( $item['position_name'] ) === $job_id || get_jobpost_slug_from_name( $item['position_name'] ) === $job_id ) {
			return $item;
		}
	} ) );
	return $job_obj;
}

if ( empty( $query_job ) ) {

	$positions_bag = $wpdb->get_results( "SELECT * FROM $table WHERE visibility='show'", ARRAY_A );
	$job_bag       = filter_shared_job( $positions_bag, $job_id );
	$job_bag       = $job_bag[0];

} else {
	$job_bag = $query_job[0];
}

if ( empty( $job_bag ) ) {
	if ( wp_redirect( get_permalink() ) ) {
		exit;
	}
}

$post_url = get_jobpost_permalink( $job_id );
?>
<style>
	* {
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
		box-sizing: border-box;
	}

	body {
		color: #333;
		padding: 15px;
		font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
	}

	p {
		color: #2c3145;
		font-weight: 600;
		margin: 20px 0 0 0;
		padding: 0;
		font-size: 18px;
		line-height: 1.3;
	}

	.name {
		color: #2149f3;
		font-size: 18px;
		margin-top: 0;
	}

	.desc {
		font-size: 16px;
		margin-top: 10px;
	}

	.details {
		margin-top: 20px;
	}

	.details span {
		color: #64687a;
		font-size: 18px;
		display: inline-block;
		margin: 0 25px 0 5px;
	}

	.details .process {
		display: block;
		margin-top: 10px;
	}

	.details .count:before,
	.details .ctc:before,
	.details .exp:before,
	.details .process:before {
		content: '';
		display: inline-block;
		background-image: url(../../../wp-content/themes/webkul-2018/images/webkul-main-sprite.svg);
		width: 19px;
		height: 19px;
		background-position-y: -160px;
		position: relative;
		top: 2px;
		left: -5px;
	}

	.details .count:after,
	.details .ctc:after,
	.details .exp:after,
	.details .process:after {
		content: attr(data-val);
		display: block;
		margin: 8px 20px;
		font-size: 16px;
		color: #2c3145;
	}

	.details .exp:before {
		background-position-x: 172px;
	}

	.details .count:before {
		background-position-x: 151px;
	}

	.details .ctc:before {
		background-position-x: 130px;
	}

	.details .process:before {
		background-position-x: 109px;
	}

	.rounds {
		margin: 8px 20px;
	}

	.rounds span {
		padding: 7px 10px 6px;
		background-color: #f2f2f2;
		font-size: 15px;
		color: #2c3145;
		margin: 5px 10px 5px 5px;
		border-radius: 4px;
	}

	.wk-button {
		text-decoration: none;
		font-size: 13px;
		padding: 8px 15px 9px;
		margin-left: 26px;
		font-weight: 700;
		display: inline-block;
		min-width: 100px;
		text-align: center;
		background-color: #2149f3;
		color: #fff;
		box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .27), 0 12px 26px 0 rgba(0, 0, 0, .2);
		border-radius: 4px;
		text-transform: uppercase;
	}

	hr {
		border: 0;
		border-top: 1px solid #ddd;
		margin: 15px 0 25px;
	}
</style>

<head>
	<meta name="viewport" content="width=device-width,user-scalable=yes,initial-scale=1,maximum-scale=5">
</head>
<div class="profile-slab">
	<p class="name"><?php echo esc_html( $job_bag['position_name'] ); ?></p>
	<p class="desc"><?php echo esc_html( $job_bag['position_detail'] ); ?></p>
	<div class="details">
		<span class="exp" data-val="<?php echo esc_attr( $job_bag['position_experience'] ); ?>">Experience</span>
		<span class="count" data-val="<?php echo esc_attr( $job_bag['openings'] ); ?>">Openings</span>
		<?php
		if ( '' !== $job_bag['expected_salary'] ) {
			?>
			<span class="ctc" data-val="<?php echo esc_attr( $job_bag['expected_salary'] ); ?>">CTC</span>
		<?php
	}
	?>
	<?php
	if ( '' !== $job_bag['interview_process'] ) {
		?>
		<span class="process">Interview Process</span>
		<div class="rounds">
			<?php
			$rounds = explode( ',' , $job_bag['interview_process'] );
			foreach ( $rounds as $round ) {
				echo '<span>' . esc_html( $round ) . '</span>';
			}
			?>
		</div>
	<?php
	}
	?>
		<div>
			<a href="<?php echo esc_url( $post_url ) . '?action=apply'; ?>" data-profile="<?php echo esc_attr( $job_bag['position_name'] ); ?>" class="wk-button open-form-btns" target="_blank" rel="nofollow noopener">Apply Now</a>
		</div>
	</div>
</div>

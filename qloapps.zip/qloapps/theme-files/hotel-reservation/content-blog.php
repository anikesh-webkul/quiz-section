<?php

$blog_filter = ( ! empty( $blog_filter = get_post_meta( get_the_ID(), 'qlo_filter' ) ) ) ? $blog_filter[0] : 'article';
$author_id = get_the_author_meta( 'ID' );
$prof_img  = get_the_author_meta( 'profile-image', $author_id );
$prof_img  = ( ! empty( $prof_img ) ) ? $prof_img : get_avatar_url( ( get_the_author_meta( 'user_email' ) ) );

?>
<!--Card-->
<div class="wk-story-card text-left">
	<a href="<?php echo the_permalink(); ?>">
		<div class="wk-story-cover hue-color-<?php echo esc_attr( $blog_filter ); ?>">
			<h3 title="<?php the_title(); ?>"><?php echo esc_html( responsive_clip_text( 50, get_the_title() ) ); ?></h3>
		</div>
	</a>
	<div class="wk-story-author">
		<a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>">
			<img src="<?php echo esc_url( $prof_img ); ?>" title="<?php the_author(); ?>">
		</a>
		<div class="wk-story-author-block">
			<a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>"><?php esc_html( the_author() ); ?></a>
			<span><?php echo get_the_date( 'j F Y' ); ?></span>
			<?php
			$views = getPostViews( get_the_ID() );
			$views = floor( $views / 100 );
			if ( $views >= 1 ) {
				?>
				<span><?php echo esc_html( $views . 'K views' ); ?></span>
				<?php
			}
			?>
		</div>
	</div>
</div>
<!--//Card-->

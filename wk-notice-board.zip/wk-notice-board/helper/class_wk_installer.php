<?php
if ( ! class_exists( 'Wk_notification_install' ) ) {

    class Wk_notification_install {

        public function create_notification_table() {
            global $wpdb;
            $charset_collate = $wpdb->get_charset_collate();
            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            $table_name = $wpdb->prefix . 'banner_list';
            if ( $wpdb->get_var( "show tables like '$table_name'" ) != $table_name ) {
                $sql = "CREATE TABLE $table_name (
                id                        mediumint(9)  NOT NULL AUTO_INCREMENT,
                title                     varchar(130)  NOT NULL,
  					  	banner_text               varchar(130)  NOT NULL,
                link_title                varchar(130)  NOT NULL,
  					  	link                      varchar(250)  NOT NULL,
                label_title               varchar(130)  NOT NULL,
                label_title_color         varchar(130)  NOT NULL,
                label_background_color    varchar(130)  NOT NULL,
                priority                  int(50)       NOT NULL,
                auto_disable              varchar(50)   NOT NULL,
               
                end_date                  varchar(50)   NOT NULL,
                status                    varchar(50)   NOT NULL,
                PRIMARY KEY (`id`)
               )$charset_collate;";
                dbDelta( $sql );
            }
        }
    }
}

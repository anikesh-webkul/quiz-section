<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();

$page_id     = get_the_id();
$has_header  = get_post_meta( $page_id, 'wk_page_has_header', true );
$has_infobox = get_post_meta( $page_id, 'wk_infobox_visible', true );
$all_press   = get_option( 'wktheme-page-press' );
$all_press   = ( '' === $all_press ) ? array() : $all_press;
$path        = wp_upload_dir()['baseurl'];

$opt_btn_attrs = maybe_unserialize( get_post_meta( $page_id, 'wk_opt_btn_attr', true ) );
?>

<?php
if ( '1' === $has_header ) {

	$layout      = get_post_meta( $page_id, 'wk_page_layout_view', true );
	$grid_class  = ( 'wide' === $layout ) ? 'wkgrid-wide' : 'wkgrid-squeezy';
	$has_bg_col  = ( 'wide' === $layout ) ? 'section-padding has-bgcol' : 'section-padding-0B';
	$tagline     = get_post_meta( $page_id, 'wk_banner_tagline', true );
	$feat_img    = get_the_post_thumbnail_url( $page_id, 'full' );
	?>

	<section class="wk-page-header <?php echo esc_attr( $has_bg_col ); ?>">
		<div class="<?php echo esc_attr( $grid_class ); ?>">
			<div class="page-tagline">
				<h1><?php echo $tagline; ?></h1>
				<?php
				if ( isset( $opt_btn_attrs['enable'] ) && '1' === $opt_btn_attrs['enable'] && ! empty( $opt_btn_attrs['link'] ) && ! empty( $opt_btn_attrs['label'] ) ) {

					$_link   = ( ! empty( $opt_btn_attrs['link'] ) ) ? $opt_btn_attrs['link'] : '';
					$_label  = ( ! empty( $opt_btn_attrs['label'] ) ) ? $opt_btn_attrs['label'] : '';
					$_rel    = ( ! empty( $opt_btn_attrs['rel'] ) ) ? ' rel=' . $opt_btn_attrs['rel'] : '';
					$_target = ( ! empty( $opt_btn_attrs['target'] ) ) ? ' target=_blank' : '';
					$_color  = ( ! empty( $opt_btn_attrs['color'] ) && 'prime' === $opt_btn_attrs['color'] ) ? 'wk-button' : 'wk-button ' . $opt_btn_attrs['color'];

					echo '<a class="' . esc_attr( $_color ) . '" href="' . esc_url( $_link ) . '"' . esc_attr( $_target . $_rel ) . '>' . esc_attr( $_label ) . '</a>';
				}
				?>
			</div>
			<div class="page-banner">
				<img src="<?php echo esc_url( $feat_img ); ?>" />
			</div>
			<?php echo ( 'wide' === $layout ) ? '' : '<hr/>'; ?>
		</div>
	</section>
	<?php
}
?>

<section class="wk-page-content section-padding-0B">
	<div class="wkgrid-squeezy">
		<?php
		while ( have_posts() ) {
			the_post();

			the_content();
		}
	?>
	</div>
</section>

<section class="wk-press-section section-padding-0T">
	<div class="wkgrid-squeezy">
		<!-- press slabs-->
		<?php
		if ( isset( $all_press['press'] ) ) {
			foreach ( $all_press['press']['items'] as $key ) {
				?>
				<div class="press-slab">
					<img src="<?php echo esc_url( $path . $key['logo'] ); ?>" title="<?php echo esc_attr( $key['name'] ); ?>" alt="<?php echo esc_attr( $key['name'] ); ?>" />
					<div class="name"><?php echo esc_html( $key['name'] . ' - ' . $key['desc'] ); ?></div>
					<a href="<?php echo esc_attr( $key['url'] ); ?>" class="press-link" title="<?php echo esc_attr( $key['title'] ); ?>"><?php echo esc_attr( $key['title'] ); ?></a>
				</div>
				<?php
			}
		}
		?>
		<!--// press slabs-->

		<?php
		if ( '1' === $has_infobox ) {

			$title      = get_post_meta( $page_id, 'wk_infobox_title', true );
			$content    = get_post_meta( $page_id, 'wk_infobox_content', true );
			$btn_label  = get_post_meta( $page_id, 'wk_infobox_btn_label', true );
			$btn_url    = get_post_meta( $page_id, 'wk_infobox_btn_url', true );
			?>
			<div class="wk-metainfo-box">
				<h2><?php echo esc_html( $title ); ?></h2>
				<p><?php echo wpautop( $content ); /* Do not ESC/strip this value; */?></p>
				<?php
				if ( '' !== $btn_label && '' !== $btn_url ) {
					echo '<a href="' . esc_url( $btn_url ) . '" class="wk-button">' . esc_html( $btn_label ) . '</a>';
				}
				?>
			</div>
			<?php
		}
		?>

	</div>
</section>


<?php
get_footer();

const _args = (argList => {
	let arg = {}, a, opt, thisOpt, curOpt;
	for (a = 0; a < argList.length; a++) {

		thisOpt = argList[a].trim();
		opt = thisOpt.replace(/^\-+/, '');

		if (opt === thisOpt) {
			// argument value
			if (curOpt) arg[curOpt] = opt;
			curOpt = null;
		} else {
			// argument name
			curOpt = opt;
			arg[curOpt] = true;
		}
	}
	return arg;
})(process.argv);

// Just Change theme folder Name in 'themeFolder';
themeFolder = 'webkul-2018';

if (_args['dest']) {
	themeFolder = _args['dest'];
}

const themePath = './wp-content/themes/' + themeFolder + '/';
const gulp         = require( 'gulp' );
const less         = require( 'gulp-less' );
const cleanCSS     = require( 'gulp-clean-css' );
const rename       = require( 'gulp-rename' );
const terser = require('gulp-terser');
// const browserSync = require('browser-sync').create();
// const reload = browserSync.reload;

/* Task to compile less */
const compileLess = () => {
	return gulp.src( themePath + 'assets/less/*.less' )
		.pipe( less() )
		.pipe( rename(function( path ){
			var name = path.basename.split( '-' )[0];
			path.basename = 'wk-' + name.replace( /@/g, '' );
		}))
		.pipe( gulp.dest( themePath + 'assets/build/css/' ) );
}

/*Minify CSS*/
throwPath = {}
throwPath.path = themePath + 'assets/dist/css/';
const minifyCss = () => {
	return gulp.src( themePath + 'assets/build/css/*.css' )
		.pipe( cleanCSS( { compatibility: 'ie8' } ) )
		.pipe( rename(function( path ) {
			if ( 'wk-front' === path.basename ) {
				path.basename = 'style';
			}
			path.basename += '.min';
		}))
		.pipe( gulp.dest( throwPath.path ) );
}

/*clone style.min from dist to root */
const copyMainCssToRoot = () => {
	return gulp.src( themePath + 'assets/dist/css/style.min.css' )
		.pipe( rename(function( path ) {
			path.basename = 'style';
		}))
		.pipe( gulp.dest( themePath ) );
}

/* Minify JS*/
const minifyJs = () => {
	return gulp.src( themePath + 'assets/build/js/**/*.js' )
		.pipe( terser() )
		.pipe( rename({
			suffix: '.min'
		}))
		.pipe( gulp.dest( themePath + 'assets/dist/js/' ) );
}


/*Watch JS*/
const watchJs = () => {
	gulp.watch( themePath + 'assets/build/js/**/*.js', minifyJs );
}

/*Watch LESS*/
const watchLess = () => {
	gulp.watch( themePath + 'assets/less/**/*.less' , compileLess );
}

/*Watch CSS*/
const watchCss = () => {
	gulp.watch( themePath + 'assets/build/css/*.css' , minifyCss );
}

/*Watch CSS MAIN*/
const watchCssMain = () => {
	gulp.watch( themePath + 'assets/dist/css/style.min.css' , copyMainCssToRoot );
}

/* Reload */
// const serve = () => {
// 	// Serve Files
// 	browserSync.init({
// 		server: {
// 			// baseDir: "./dist/"
// 			baseDir: "./wp-content/themes/webkul-2018/"
// 		},
// 		port: Math.ceil(Math.random() * 10000)
// 	});
// 	gulp.watch(themePath + 'assets/less/**/*.less').on("change", reload);
// 	gulp.watch(themePath + 'assets/build/js/**/*.js').on("change", reload);
// 	gulp.watch(themePath + '**/*.php').on("change", reload);
// };

const build = gulp.parallel(watchLess, watchCss, watchCssMain, watchJs);

/* Tasks when running `gulp` from terminal */
exports.compileLess = compileLess;
exports.minifyCss = minifyCss;
exports.copyMainCssToRoot = copyMainCssToRoot;
exports.minifyJs = minifyJs;
exports.watchLess = watchLess;
exports.watchCss = watchCss;
exports.watchCssMain = watchCssMain;
exports.watchJs = watchJs;
// exports.serve = serve;

gulp.task( 'default', build );

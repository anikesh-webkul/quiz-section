
<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();
?>
<section class="outer-wrapper">
    <div class="our-partner-header">
        <div class="container">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="to-be-partner">
                    <div class="col-md-8 text-center">
                        <h1>BECOME A PARTNER</h1>
                        <p class="head-p">QloApps provide their users a top-notch hotel booking experience. Complete user-friendly environment and its Simple access makes it more usable on QloApps, partners are a valuable asset, we aspire to have long-standing relationship with our partners. We dream to take our business to a next level with synchronised efforts with our partners</p>
                        <a href="<?php echo site_url().'/become-partner';?>" class="btn btn-bgcolor white become-partner">BECOME A PARTNER</a>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
    </div>
    <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="added-partner">
                        <p>OUR PARTNERS </p>
                    </div>
                </div>
            </div>
            <div class="row text-center">
            <?php


                $query_args = array('post_type'=>'our-partners','post_status'=>'publish','order'=>'ASC');

                $the_query = new WP_Query( $query_args );

                if ( $the_query->have_posts() ) :
                    while($the_query->have_posts() ) :$the_query-> the_post(); ?>

                        <div class="feature-detail-partner">
                            <div class="partner-logo">
                                <?php
                                    $url = get_post_meta($post->ID, 'partner-logo', true);

                                if ( !empty($url)) : ?>

                                    <img src="<?php echo $url;?>" class="img-responsive">

                                <?php endif;?>
                            </div>
                            <div class="partner-content">
                                <?php $abc = get_post_meta($post->ID, 'partner-url', true);?>
                                <h5><?php echo get_the_title();?></h5>
                                <span><a href="<?php  echo $abc; ?>" target="_blank"><?php echo $abc; ?></a></span>
                                <p class="text-justify"> <?php the_excerpt();?></p>
                                <?php
                                    $country_image = get_post_meta($post->ID, 'country-image', true);
                                ?>
                                <img src="<?php echo $country_image;?>" class="img-responsive">

                                <p><?php echo get_post_meta($post->ID, 'partner-country', true); ?></p>
                            </div>
                        </div>
                    <?php
                        endwhile;
                        endif;
                        ?>
            </div>
    </div>
    <div class="newsletter-wrapper">
        <div class="container">
            <div id="mc_embed_signup" class="subscribe-now">
              <form action="//qloapps.us8.list-manage.com/subscribe/post?u=a6022fbcc8eb59ebd26658e1c&amp;id=96917c5642" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                <div id="mc_embed_signup_scroll">
                  <h3 class="text-default text-center">Subscribe Our Newsletter <span>Get the Latest Updates About Our Product on Subscribing Here</span></h3>

                  <div class="mc-field-group">
                      <input type="email" placeholder="Enter Your Email Here" name="EMAIL" class="required email" id="mce-EMAIL">
                  </div>
                  <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_a6022fbcc8eb59ebd26658e1c_be6f4be20e" tabindex="-1" value=""></div>
                  <div class="clear">
                    <input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="white btn btn-bgcolor btn-subscribe">
                  </div>
                  <div id="mce-responses" class="clear">
                    <div class="response" id="mce-error-response" style="display:none"></div>
                    <div class="response" id="mce-success-response" style="display:none"></div>
                  </div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                </div>
              </form>
            </div>
        </div>
    </div>

</section>
<?php get_footer();?>

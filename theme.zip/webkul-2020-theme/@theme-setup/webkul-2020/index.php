<?php
/**
 * The main template file for HomePage
 * @link http://webkul.com
 * @package webkul
 * @subpackage webkul
 * @since webkul 1.0
 */

get_header();
?>

<div class="playground">
	<section class="wk-site-hero">
		<div class="wk-site-hero-content">
			<p>Top B2B/B2C eCommerce and Marketplace Experts</p>
			<h1 class="wk-site-tagline">We build B2B & B2C online marketplace store and apps</h1>
			<p>We help both B2B and B2C companies to scale their online business. Enterprises trust us for our cutting-edge marketplace, hyperlocal, and drop shipping solutions. In the last 10 years, we helped 80,000+ companies to scale their online business.</p>
		</div>
		<div class="wk-hero-box-wrap">
			<?php
			echo wk_webp( 'orphan/team-profile-megha.png', 'team-profile-megha', 'team-profile thumb-1' );
			echo wk_webp( 'orphan/team-profile-pulkit.png', 'team-profile-pulkit', 'team-profile thumb-2' );
			echo wk_webp( 'orphan/team-profile-priya.png', 'team-profile-priya', 'team-profile  thumb-3' );
			?>

			<div class="wk-hero-box">
				<div class="hello-txt">Hello 👋</div>
				<p class="wk-hero-box-title">Got questions?<br>Talk to our experts.</p>
				<a href="#contact" class="wk-button btn-light">Send a Message</a>
				<div class="p-x4">*The team typically replies in a few hours.</div>
			</div>
		</h4>
	</section>
</div>


<section id="wkmain-content" class="wk-customers-section section-padding-0B">
	<div class="wkgrid-wide text-center">
		<p class="title-mini">The world's top brands trust us</p>
		<div class="wk-window-to-toggle text-center wk-items-inlined">
			<?php
			echo wk_webp( 'customer/customer-logo-nokia.png', 'customer-logo-nokia', 'logo' );
			echo wk_webp( 'customer/customer-logo-un.png', 'customer-logo-un', 'logo' );
			echo wk_webp( 'customer/customer-logo-huawei.png', 'customer-logo-huawei', 'logo' );
			echo wk_webp( 'customer/customer-logo-canon.png', 'customer-logo-canon', 'logo' );
			echo wk_webp( 'customer/customer-logo-intel.png', 'customer-logo-intel', 'logo' );
			echo wk_webp( 'customer/customer-logo-tcs.png', 'customer-logo-tcs', 'logo' );
			echo wk_webp( 'customer/customer-logo-costco.png', 'customer-logo-costco', 'logo' );
			?>
		</div>
	</div>
</section>

<hr>

<section class="wk-services-section section-padding">
	<div class="wkgrid-wide">
		<div class="wk-section-head text-center section-margin-down">
			<h2>On-Demand Services</h2>
		</div>
		<?php
		$data = array(
			array(
				'i' => 'ecom',
				't' => 'Marketplace Development',
				'd' => 'We build B2B and B2C marketplace to help businesses scale.',
				'l' => 'https://webkul.com/ecommerce-marketplaces/',
			),
			array(
				'i' => 'cms',
				't' => 'PIM Development',
				'd' => 'We empower marketplaces with omnichannel product data intelligence.',
				'l' => 'https://webkul.com/product-information-manager/',
			),
			array(
				'i' => 'web',
				't' => 'ERP Development',
				'd' => 'We help businesses with on-demand ERP apps and tools development.',
				'l' => 'https://webkul.com/odoo-development/',
			),
			array(
				'i' => 'crm',
				't' => 'Custom CRM Development',
				'd' => 'We help businesses to capture leads and retrieve opportunities.',
				'l' => 'https://webkul.com/custom-crm-development/',
			),
			array(
				'i' => 'mobile',
				't' => 'Mobile App Development',
				'd' => 'We build native and cross-platform mobile apps to help retailers grow.',
				'l' => 'https://webkul.com/mobile-app-development/',
			),
			array(
				'i' => 'saas',
				't' => 'PWA Development',
				'd' => 'We make progressive web apps that deliver lightning-fast experience.',
				'l' => 'https://webkul.com/pwa-and-amp/',
			),
		);
		?>
		<div class="wk-section-grid">
			<?php
			foreach ( $data as $set ) {
				echo '<a href="' . $set['l'] . '" title="' . $set['t'] . '" class="wk-tile" gtm_track="Tapped ' . $set['t'] . '">
					<span class="icon ' . $set['i'] . '"></span>
					<h3 class="tile-title">' . $set['t'] . '</h3>
					<p class="p-x3">' . $set['d'] . '</p>
					<span tabindex="0" role="button" class="wk-button btn-dark">Read More</span>
				</a>';
			}
			?>
		</div>
	</div>
</section>

<section class="wk-virtual-try-on section-padding-0T">
	<div class="wkgrid-wide">
		<div class="try-on-wrapper">
			<video poster="https://cdnblog.webkul.com/blog/wp-content/uploads/2020/09/virtual-try-on-poster.jpg" loop muted autoplay nocontrols inline>
				<source src="https://cdnblog.webkul.com/blog/wp-content/uploads/2020/09/virtual-try-on.mp4" type="video/mp4">
				Your browser does not support the video tag.
			</video>
			<div class="try-on-content">
				<h2>Virtual Try-on</h2>
				<p class="try-on-text">Let your customers try their favorite products in immersive 3d.</p>
				<div>
					<a href="https://webkul.com/augmented-reality/" class="wk-button btn-light">Read More</a>&ensp;
					<a href="https://virtual.webkul.com/spects-tryon/" target="_blank" rel="noopener noreferrer" class="wk-button btn-dark">View in Browser</a>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="wk-technology-section">
	<div class="wkgrid-wide">
		<div class="wk-section-head text-center section-margin-down">
			<h2>Our Technologies</h2>
		</div>
		<div class="wk-section-grid">
			<?php
			$data = array(
				array(
					'i' => 'magento',
					't' => 'Magento',
					'l' => 'magento-development',
				),
				array(
					'i' => 'prestashop',
					't' => 'PrestaShop',
					'l' => 'prestashop-development',
				),
				array(
					'i' => 'woocommerce',
					't' => 'WooCommerce',
					'l' => 'woocommerce',
				),
				array(
					'i' => 'opencart',
					't' => 'OpenCart',
					'l' => 'opencart-development',
				),
				array(
					'i' => 'shopware',
					't' => 'Shopware',
					'l' => 'shopware',
				),
				array(
					'i' => 'cs-cart',
					't' => 'CS-Cart',
					'l' => 'cs-cart-development',
				),
				array(
					'i' => 'salesforce',
					't' => 'Salesforce',
					'l' => 'salesforce-consulting-services',
				),
				array(
					'i' => 'akeneo',
					't' => 'Akeneo',
					'l' => 'akeneo',
				),
				array(
					'i' => 'pimcore',
					't' => 'PimCore',
					'l' => 'pimcore',
				),
				array(
					'i' => 'odoo',
					't' => 'Odoo',
					'l' => 'odoo-development',
				),
				array(
					'i' => 'symfony',
					't' => 'Symfony',
					'l' => 'symfony',
				),
				array(
					'i' => 'laravel',
					't' => 'Laravel',
					'l' => 'laravel',
				),
			);

			foreach ( $data as $set ) {

				echo '<a href="' . site_url(). '/' . $set['l'] . '" class="p-x3 wk-tech-brick" gtm_track="Tapped Platform ' . $set['t'] . '">' . wk_webp( 'technology/technology-' . $set['i'] . '.png', $set['t'], '', true ) . '<p class="p-x3">' . $set['t'] . '</p></a>';
			}
			?>
		</div>
	</div>
</section>

<section class="wk-story-section section-padding">
	<div class="wkgrid-wide">
		<div class="wk-section-grid">
		<?php
		$data = array(
			array(
				'id'       => 'nokia',
				'cover'    => 'story/story-cover-nokia.jpg',
				'text'     => 'Find out how Webkul got a chance to work with Nokia, a global technology leader for developing custom web services RESTful APIs for Marketplace Multi Vendor Module for Magento 2.',
				'link'     => 'https://store.webkul.com/success-stories/nokia.html',
				'profile'  => 'story/story-profile-nokia.jpg',
				'name'     => 'Lucia Tudose',
				'location' => 'Finland',
			),
			array(
				'id'       => 'ironman',
				'cover'    => 'story/story-cover-ironman.jpg',
				'text'     => 'See how the world\'s largest sports participation platform, Ironman Triathlon is using Magento 2 Akeneo Connector on its official merchandise store for managing online catalog information.',
				'link'     => 'https://store.webkul.com/success-stories/ironman.html',
				'profile'  => 'story/story-profile-ironman.jpg',
				'name'     => 'Jordan Schinella',
				'location' => 'United States',
			),
			array(
				'id'       => 'itc',
				'cover'    => 'story/story-cover-itc.jpg',
				'text'     => 'Learn how Webkul teamed-up with ITC, a multilateral agency of WTO and United Nations for contributing to the global economic development of eCommerce marketplaces and small scale traders.',
				'link'     => 'https://store.webkul.com/success-stories/international-trade-centre.html',
				'profile'  => 'story/story-profile-itc.jpg',
				'name'     => 'Mohamed Es Fih',
				'location' => 'Geneva Area, Switzerland',
			),
			array(
				'id'       => 'huawei',
				'cover'    => 'story/story-cover-huawei.jpg',
				'text'     => 'We had lately a very good experience with Webkul Support and Development team! They were very helpful, supportive, and they did their best to satisfy our requests. Me and my team do highly appreciate their professionalism, dedication, and commitment.',
				'link'     => 'https://store.webkul.com/success-stories/huawei.html',
				'profile'  => 'story/story-profile-huawei.jpg',
				'name'     => 'Rami Alabbady',
				'location' => 'Jordan',
			),
			array(
				'id'       => 'samsung',
				'cover'    => 'story/story-cover-samsung.jpg',
				'text'     => 'Learn how Samsung FairDistribution verifies corporate accounts to offer exclusive deals and pricing under EPP (Employee Purchase Program). Enabling its employees and partner companies to shop from the official Samsung eStore.',
				'link'     => 'https://store.webkul.com/success-stories/samsung.html',
				'profile'  => 'story/story-profile-samsung.jpg',
				'name'     => 'Faruk Rahaman',
				'location' => 'Bangladesh',
			),
		);

		$template = '<div class="wk-story-box{{active_class}}">
			<div class="story-cover">{{cover_img}}</div>
			<div class="wk-story-content">
				<div class="wk-quote">
					<p>{{text}}</p>
					<a href="{{link}}" class="link" target="_blank" rel="noopener">Read full Story</a>
					<div class="wk-name-card">
						{{story_thumb}}
						<span class="name">{{name}}</span>
						<span class="location">{{location}}</span>
					</div>
				</div>
			</div>
		</div>';

		foreach ( $data as $idx => $datum ) {
			$active_class = ( 0 === $idx ) ? ' active' : '';

			echo strtr( $template, array(
				'{{active_class}}' => $active_class,
				'{{cover_img}}'    => wk_webp( $datum['cover'], 'story-cover-' . $datum['id'] ),
				'{{text}}'         => $datum['text'],
				'{{link}}'         => $datum['link'],
				'{{story_thumb}}'  => wk_webp( $datum['profile'], 'story-cover-' . $datum['id'], 'thumb' ),
				'{{name}}'         => $datum['name'],
				'{{location}}'     => $datum['location'],
			) );
			?>
			<?php
		}
		?>
		</div>
		<div class="wk-story-toggler">
			<span id="prev" class="story-dir-nav wk-button btn-ghost">Prev</span>
			<span id="next" class="story-dir-nav wk-button btn-dark">Next</span>
			<?php
			foreach ( $data as $idx => $datum ) {
				$active_class = ( 0 === $idx ) ? ' active' : '';
				echo '<div class="wk-story-nav ' . $active_class . '">';
				echo wk_Webp( 'story/story-logo-' . $datum['id'] . '.jpg', 'story-logo-nokia' );
				echo '</div>';
			}
			?>
		</div>
	</div>
</section>

<section class="wk-awards-section">
	<div class="wkgrid-wide">
		<div class="wk-section-head text-center section-margin-down">
			<h2>Awards</h2>
		</div>
		<div class="wk-section-grid">
			<a href="https://webkul.com/deloitte-award-winner-2019/" class="shaded-image-link">
				<?php echo wk_webp( 'award/award-deloitte.jpg', 'Deloitte Technology Fast 50 India' ); ?>
				<span data-label="5 times in a row" class="link-title">Deloitte Technology Fast 50 India</span>
			</a>
			<a href="https://webkul.com/blog/webkul-awarded-by-smart-ceo-for-startup-50/" class="shaded-image-link">
				<?php echo wk_webp( 'award/award-smartceo.jpg', 'Top Enterprise Venture by SmartCEO' ); ?>
				<span class="link-title">Top Enterprise Venture by SmartCEO</span>
			</a>
			<a href="https://webkul.com/magento-imagine-2019-award/" class="shaded-image-link">
				<?php echo wk_webp( 'award/award-magento-top-selling-extension.jpg', 'Magento Top Selling Extension Award' ); ?>
				<span data-label="2 times in a row" class="link-title">Magento Top Selling Extension Award</span>
			</a>
			<a href="https://webkul.com/magento-imagine-2019/" class="shaded-image-link">
				<?php echo wk_webp( 'award/award-magento-imagine.jpg', 'Magento Main Stage Commerce Sneaks' ); ?>
				<span data-label="2 times in a row" class="link-title">Magento Main Stage Commerce Sneaks</span>
			</a>
			<div class="award-lateral-view no-decor">
				<?php echo wk_webp( 'orphan/etrise-award.png', '#5 ETRise Rank 2020' ); ?>
				<div class="award-lateral-content">
					<h3><span class="col-accent">#5</span> ETRise Rank 2020</h3>
					<h2>India’s Top Performing MSMEs</h2>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="wk-badges-section section-padding">
	<div class="wkgrid-wide">
		<div class="wk-section-grid">
			<div class="wk-badge">
				<span class="badge-icon mg"></span>
				<p class=badge-label>Magento Commerce Certified Developer</p>
			</div>
			<div class="wk-badge">
				<span class="badge-icon ps"></span>
				<p class=badge-label>PrestaShop</br>Superhero Seller</p>
			</div>
			<div class="wk-badge">
				<span class="badge-icon sh"></span>
				<p class=badge-label>Shopify</br>Freelance Experts</p>
			</div>
		</div>
	</div>
</section>

<section class="wk-home-client section-padding-0T">
	<div class="wkgrid-wide">
		<div class="wk-section-grid">
		<?php
		$all_clients = get_option( 'wktheme-page-clients' );
		$all_clients = ( '' === $all_clients ) ? array() : $all_clients;
		$path        = wp_upload_dir()['baseurl'];
		if ( isset( $all_clients['client'] ) ) {
			$i = 0;
			$enabled_clients = array_filter( $all_clients['client']['items'], function( $client ) {
				return ( 'true' === $client['enable'] ) ? true : false;
			} );

			//Restrict only first two to be used
			$enabled_clients = array_slice( $enabled_clients, 0, 2 );

			foreach ( $enabled_clients as $key ) {
				$info = '<div class="wk-quote inline-left">
					<h2 class="">' . $key['saying_title'] . '</h2>
					<p>' . nl2br( $key['desc'] ) . '</p>
				</div>';
				$img = '<div class="inline-right">
					<div class="client-picture">
						<img src="' . $path . $key['image'] . '" alt="' . $key['name'] . '" />
					</div>
				</div>';
				if ( $i % 2 === 0 ) {
					echo '<div class="wk-inline-halves">';
					echo $info;
					echo $img;
					echo '</div>';
				} else {
					echo '<div class="wk-inline-halves">';
					echo $img;
					echo $info;
					echo '</div>';
				}
				$i++;
			}
		}
		?>
		</div>
	</div>
</section>

<section class="wk-partner-section">
	<div class="wkgrid-wide text-center">
		<div class="wk-section-head">
			<p class="title-mini">We are Partner with Top Ventures</p>
		</div>
		<div class="wk-section wk-items-inlined wk-window-to-toggle">
			<?php
			$items = array( 'adobe', 'paypal', 'prestashop', 'odoo', 'opencart', 'salesforce', 'algolia', 'stripe', 'payu', 'paytabs', 'cloudflare' );

			foreach ( $items as $item ) {
				echo wk_webp( 'partner/partner-logo-' . $item . '.png', $item );
			}
			?>
		</div>
		<div class="wk-section-link text-center">
			<a href="https://webkul.com/partners/" class="link">View All Partners</a>
		</div>
	</div>
</section>
<hr>

<section class="wk-innovation-videos-section section-padding">
	<div class="">
		<div class="wk-innovations-list">
			<div class="video-wrapper display-none">
				<span class="close"></span>
				<div class="video-frame">
					<div class="loader"></div>
					<div class="wkyt-video-frame-request" data-plyr-provider="youtube" data-plyr-embed-id=""></div>
				</div>
			</div>
			<div class="grd">
				<div class="brick">
					<h3 class="title">5 times</h3>
					<span class="mcom-logo"></span>
					<p class="tagline">Innovations Lab Winner</p>
				</div>
				<div class="wk-video">
					<div class="video-poster" data-video="https://youtu.be/UsBHcHdjwzU">
						<?php echo wk_webp( 'innovation/innovation-pwa-scan-and-go.jpg', 'PWA Scan and Go' ); ?>
						<span class="icon-play"></span>
					</div>
					<p class="video-name">PWA Scan and Go</p>
				</div>

				<div class="wk-video">
					<div class="video-poster" data-video="https://youtu.be/ajNidOluWK8">
						<?php echo wk_webp( 'innovation/innovation-ar-product-navigator.jpg', 'AR Product Navigator' ); ?>
						<span class="icon-play"></span>
					</div>
					<p class="video-name">AR Product Navigator</p>
				</div>
			</div>

			<div class="grd">

				<div class="wk-video">
					<div class="video-poster" data-video="https://youtu.be/xxKWP0EREqU">
						<?php echo wk_webp( 'innovation/innovation-ar-product-sizing.jpg', 'AR Product Sizing' ); ?>
						<span class="icon-play"></span>
					</div>
					<p class="video-name">AR Product Sizing</p>
				</div>
				<div class="wk-video">
					<div class="video-poster" data-video="https://youtu.be/ajNidOluWK8">
						<?php echo wk_webp( 'innovation/innovation-machine-learning-search.jpg', 'Machine Learning Search' ); ?>

						<span class="icon-play"></span>
					</div>
					<p class="video-name">Machine Learning Search</p>
				</div>
				<div class="wk-video">
					<div class="video-poster" data-video="https://youtu.be/jWXi1xoAb_A">
						<?php echo wk_webp( 'innovation/innovation-msi-based-pwa-pos.jpg', 'MSI PWA POS' ); ?>
						<span class="icon-play"></span>
					</div>
					<p class="video-name">MSI PWA POS</p>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="wkgrid-wide">
	<div class="wk-jumbo-ad">
		<div class="wkgrid-squeezy">
			<h2>Hire on-demand project developers and turn your idea into reality</h2>
			<a href="#contact" class="wk-button btn-white">Start a Project</a>
		</div>
	</div>
</section>
<?php

get_footer();

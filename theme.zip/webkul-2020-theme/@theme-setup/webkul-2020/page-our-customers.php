<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();
?>

<section class="wk-page-content">
	<div class="wk-component component--page-header customer-page-hero-section" _bgcolor="default">
		<div _wkgrid="wide">
			<div class="header-wrap header--view-alter">
				<div class="header-tagline">
					<h1>We globally help businesses to grow and scale.</h1>
					<div class="wp-block-button"><a class="wp-block-button__link has-primary-background-color has-background" href="https://webkul.com/top-locations/">Explore Locations</a></div>
				</div>
				<div class="header-img">
					<div class="wk-client-geo-wrap">
						<div class="customer-hero-paper">
							<div class="bg-blur"></div>
							<div class="brick ctr1c1">
								<div class="r1c1">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Mohammed Kettaneh" data-company="NAS"><br></span>
							</div>

							<div class="brick ctr1c2">
								<div class="r1c2">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Harry Glatz" data-company="Analog.de"><br></span>
							</div>

							<div class="brick ctr1c3">
								<div class="r1c3">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Steven Wilson" data-company="Shear Quantity"><br></span>
							</div>

							<div class="brick ctr1c4">
								<div class="r1c4">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Ton Schmitz" data-company="Xenos"><br></span>
							</div>

							<div class="brick ctr2c1">
								<div class="r2c1">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Alexander Gebhardt" data-company="Drezzer"><br></span>
							</div>

							<div class="brick ctr2c2">
								<div class="r2c2">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Alessandro Scavella" data-company="Cooder"><br></span>
							</div>

							<div class="brick ctr2c3">
								<div class="r2c3">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Cole Honeyman" data-company="Bam-Boo"><br></span>
							</div>

							<div class="brick ctr2c4">
								<div class="r2c4">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Sarah Parker " data-company="nu3.de"><br></span>
							</div>

							<div class="brick ctr3c1">
								<div class="r3c1">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Rami Alabbady" data-company="Huawei"><br></span>
							</div>

							<div class="brick ctr3c2">
								<div class="r3c2">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Stefan Riksten" data-company="Plastic Flessen"><br></span>
							</div>

							<div class="brick ctr3c3">
								<div class="r3c3">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Lucia Tudose" data-company="Nokia"><br></span>
							</div>

							<div class="brick ctr3c4">
								<div class="r3c4">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Mohamed Es Fih" data-company="ITC"><br></span>
							</div>

							<div class="brick ctr4c1">
								<div class="r4c1">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Sem Djeguede " data-company="Africa Baie"><br></span>
							</div>
							<div class="brick ctr4c2">
								<div class="r4c2">
									<span class="pic"></span>
									<span class="flg"></span>
								</div>
								<span class="dt" data-name="Cristiano-Longo " data-company="Shopsempre"><br></span>
							</div>
						</div>
						<img class="customer-hero-mobile" src="<?php echo get_template_directory_uri() . '/images/customer/customers-mobile.jpg'; ?>" alt="Our customers"/>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
	while ( have_posts() ) {
		the_post();

		the_content();
	}
	?>
	<script>
        var paper = document.querySelector(".customer-hero-paper");
        var bgBlur = document.querySelector(".bg-blur");
        if (paper) {
            paper.addEventListener("mouseover", (ev) => {
                var tempTarget = ev.target;
                if (tempTarget.closest(".brick") !== null && tempTarget.classList.contains("pic")) {
                    tempTarget.closest(".brick").classList.add("ctr-top");
                    bgBlur.classList.add("bg-blur-active");
                    ev.stopPropagation();
                }
            });
            paper.addEventListener("mouseout", (ev) => {
                var tempTarget = ev.target;
                if (tempTarget.classList.contains("pic") || tempTarget.classList.contains("flg") || tempTarget
                    .classList.contains("dt")) {

                    if (bgBlur.classList.contains("bg-blur-active")) {
                        bgBlur.classList.add("bg-blur-inactive");
                        bgBlur.addEventListener("animationend", function () {
                            bgBlur.classList.remove("bg-blur-active", "bg-blur-inactive");
                            if (tempTarget.closest(".brick").classList.contains("ctr-top")) {
                                tempTarget.closest(".brick").classList.remove("ctr-top");
                                ev.stopPropagation();
                            }
                        });
                    }
                }
            });
        }
    </script>
</section>

<?php
get_footer();
?>
<Script>
jQuery(document).ready(function() {
	var offset = 25;
	var singleItemWidth = 220;
	// var offset = Math.floor(jQuery('.block-icon-gallery-wrapper').width() / singleItemWidth);
	jQuery(".wk-toggle-load-items").find('.block-icon-gallery-widget').slice(0, offset).show();
	jQuery(".wk-toggle-load-button a").click(function (e) {
		offset = Math.floor( jQuery('.block-icon-gallery-wrapper').width() / singleItemWidth );
		e.preventDefault();
		jQuery(".block-icon-gallery-widget:hidden").slice(0, offset).show();
		if (jQuery(".block-icon-gallery-widget:hidden").length == 0) {
			jQuery(this).hide();
		}
	});
});
</script>
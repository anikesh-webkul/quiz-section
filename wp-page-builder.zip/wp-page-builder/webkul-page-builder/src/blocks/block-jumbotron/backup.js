/**
 * Register Custom Block Jumbotron
 */

registerBlockType( 'wk-blocks/jumbotron', {
    title : 'Jumbotron',
    icon : 'align-center',
    category: 'webkul',
    keywords: [
        'Jumbotron',
    ],
    example: {},

    attributes: {
        content: {
            selector: 'p',
            type:'array',
            source: 'children',
        },
        title: {
            type:'array',
            source: 'children',
            selector: 'h3',
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgURL: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
        },
        newWindow: {
            type:'boolean',
        },
        link: {
            type:'string',
        },
        button: {
            type:'string'
        },
        url: {
			type: 'string'
		},
       
    },
    edit : function( props ) {
        var content = props.attributes.content,
        title = props.attributes.title,
        imgURL = props.attributes.imgURL,
        imgALT = props.attributes.imgALT,
        imgID = props.attributes.imgID,
        newWindow = props.attributes.newWindow,
        link = props.attributes.link;
        button = props.attributes.button;

        const onChangeTitle = ( newTitle ) => {
            props.setAttributes( { title: newTitle } );
        }
        const onChangeContent = ( newContent ) => {
            props.setAttributes( { content: newContent } );
        }
        const onRemoveImage = () => {
			props.setAttributes( {
				imgURL: null,
                imgID: null,
                imgALT:null,
			} );
        };
        return el(
            Fragment,
            {},

            /**Sidebar Setting */
            el(
                InspectorControls,
                {},
                el(
                    PanelBody,
                    {
                        title:'Jumbotron Link Setting',
                        initial:true,
                    },
                    el(
                        PanelRow,
                        {},
                        el(
                            TextControl,
                            {
                                type:"string",
                                label:'ADD Button Link',
                                value:link,
                                onChange:(newLink) => {
                                    props.setAttributes({link:newLink});
                                }
                            }
                        )
                    ),
                    el(
                        PanelRow,
                        {},
                        el(
                            FormToggle,
                            {
                                checked:newWindow,
                                onChange:event =>  props.setAttributes({newWindow:event.target.checked})
                            }
                        ),
                        el(
                            'span',
                            {},
                            'Open in new Tab',
                        )
                    ),
                )
            ),
            /** //Sidebar Setting */

            el(
                'div',
                {
                    className:'wk-jumbotron-wrap',
                },

                el(
                    'div',
                    {
                        className:'wk-image-uploader',
                    },
                    el(
                        MediaUpload,
                        {
                            type: "image",
                            allowed: ALLOWED_MEDIA_TYPES,
                            value: imgID,
                            onSelect: img => props.setAttributes({
                                imgID: img.id,
                                imgURL: img.url,
                                imgALT:img.alt ? img.alt : img.title 
                            }),
                            render: ({ open }) => el(
                                Fragment,
                                null,
                                el(
                                    Button,
                                    {
                                        className: imgURL ? 'wk-change-image' : 'wk-add-image',
                                        onClick: open
                                    },
                                    ! imgURL ? wkUploadIcon : el( "img",
                                        {
                                            src: imgURL,
                                            alt: imgALT
                                        }
                                    )
                                ),
                                imgURL && el(
                                    Button,
                                    {
                                        className: "wk-remove-image",
                                        onClick: onRemoveImage
                                    },
                                    el(
                                        Dashicon,
                                        {
                                            icon: 'dismiss'
                                        }
                                    )
                                )
                            )
                        }
                    )
                    /** //MediaUpload End */
                    
                ),
                el(
                    'div',
                    {
                    },
                    el(
                        RichText,
                        {
                            key: 'editable',
                            tagName: 'h3',
                            value: title,
                            className:'wk-jumbotron-title',
                            onChange: onChangeTitle,
                            placeholder:'Jumbotron Title....'
                        },
                        
                    ),
                    el(
                        RichText,
                        {
                            key: 'editable',
                            tagName: 'p',
                            className:'wk-jumbotron-description',
                            onChange: onChangeContent,
                            value: content,
                            placeholder:'Jumbotron Description....'
                        }
                    ),
                    el(
                        PlainText,
                        {
                            key: 'editable',
                            tag:'div',
                            style:{width:'auto'},
                            value:button,
                            placeholder:'Jumbotron Button Text....',
                            onChange:newbutton => props.setAttributes({button:newbutton})
                        },
                    ),
                    el(
                        Dashicon,
                        {
                            icon:'admin-links',
                            style:{display:'block'}
                        }
                    ),
                )
                

            )
        );
        /** //WP Fragment End */
    },

    save:function(props) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className:'jumbotron-wrap',
                },
                (props.attributes.imgURL)&&
                el(
                    'div',
                    {
                        className:'jumbotron-image',
                    },
                    el(
                        'img',
                        {
                            src:props.attributes.imgURL,
                            alt:props.attributes.imgALT,
                        }
                    )
                ),
                el(
                    'div',
                    {
                        className:'jumbotron-content',
                    },
                    el(
                        RichText.Content,
                        {
                            tagName: 'h3',
                            value: props.attributes.title,
                            className:'title'
                        },
                    ),
                    el(
                        RichText.Content,
                        {
                            tagName: 'p',
                            value: props.attributes.content,
                        },
                    ),
                    el(
                        'a',
                        {
                            href:props.attributes.link,
                            target:(props.attributes.newWindow) ? '_blank' : false,
                            rel:(props.attributes.newWindow) ? 'noopener noreferrer' : false,
                            className:'wk-button'
                        },
                        props.attributes.button
                    )
                )

            )
        );
    }


} );
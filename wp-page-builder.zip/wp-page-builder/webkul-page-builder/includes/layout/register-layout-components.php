<?php
/**
 * Register layouts and sections for the Layout block.
 *
 * @package AtomicBlocks
 */
add_action( 'rest_api_init', 'wk_register_layout_endpoints' );

function wk_register_layout_endpoints() {

	/**
	 * Register the layouts GET endpoint.
	 * Returns all registered layouts.
	 */
	register_rest_route(
		'wk-page-layouts/v1',
		'layouts',
		[
			'methods'             => 'GET',
			'callback'            => 'wkp_register_components',
			'permission_callback' => function () {
				return current_user_can( 'edit_posts' );
			},
		]
	);

}

/**
 * Registers section and layout components.
 *
 * @since 2.0
 */
function wkp_register_components() {
	
	$result = array(
		array(
			'name' => 'Caption Icons Layout',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-caption-icons/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"wkTemplateLock":true,"className":"wk-component text-center block-caption-icons"} --> <div class="wk-component text-center block-caption-icons" _bgcolor="default"><div _wkgrid="wide"><!-- wp:heading {"align":"center","placeholder":"Caption Icon Section Heading","className":"block-title"} --> <h2 class="has-text-align-center block-title"></h2> <!-- /wp:heading --> <!-- wp:paragraph {"align":"center","placeholder":"Caption Icon Section Description","className":"block-desc"} --> <p class="has-text-align-center block-desc"></p> <!-- /wp:paragraph --> <!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/caption-icons","gridItem":"3","className":"caption-icons-pallete"} --> <div class="caption-icons-pallete view-variant--fall"><!-- wp:wk-blocks/caption-icons --> <div class="brick"><img class="caption-img"/><p class="wk-caption-title"></p><div class="caption wk-caption-info"></div></div> <!-- /wp:wk-blocks/caption-icons --> <!-- wp:wk-blocks/caption-icons --> <div class="brick"><img class="caption-img"/><p class="wk-caption-title"></p><div class="caption wk-caption-info"></div></div> <!-- /wp:wk-blocks/caption-icons --> <!-- wp:wk-blocks/caption-icons --> <div class="brick"><img class="caption-img"/><p class="wk-caption-title"></p><div class="caption wk-caption-info"></div></div> <!-- /wp:wk-blocks/caption-icons --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->',
		),
		array(
			'name' => 'Icon Gallery',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-image-gallery/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"className":"block-icon-gallery-section"} --> <div class="wk-component block-icon-gallery-section" _bgcolor="default"><div _wkgrid="wide"><!-- wp:heading {"align":"center"} --> <h2 class="has-text-align-center"></h2> <!-- /wp:heading --> <!-- wp:paragraph {"align":"center"} --> <p class="has-text-align-center"></p> <!-- /wp:paragraph --> <!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/icon-gallery", "className":"block-icon-gallery-wrapper"} --> <div class="block-icon-gallery-wrapper view-variant--fall"><!-- wp:wk-blocks/icon-gallery --> <div class="block-icon-gallery-widget"><img class="block-icon-gallery-image"/></div> <!-- /wp:wk-blocks/icon-gallery --> <!-- wp:wk-blocks/icon-gallery --> <div class="block-icon-gallery-widget"><img class="block-icon-gallery-image"/></div> <!-- /wp:wk-blocks/icon-gallery --> <!-- wp:wk-blocks/icon-gallery --> <div class="block-icon-gallery-widget"><img class="block-icon-gallery-image"/></div> <!-- /wp:wk-blocks/icon-gallery --> <!-- wp:wk-blocks/icon-gallery --> <div class="block-icon-gallery-widget"><img class="block-icon-gallery-image"/></div> <!-- /wp:wk-blocks/icon-gallery --> <!-- wp:wk-blocks/icon-gallery --> <div class="block-icon-gallery-widget"><img class="block-icon-gallery-image"/></div> <!-- /wp:wk-blocks/icon-gallery --> <!-- wp:wk-blocks/icon-gallery --> <div class="block-icon-gallery-widget"><img class="block-icon-gallery-image"/></div> <!-- /wp:wk-blocks/icon-gallery --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->',
		),
		array(
			'name' => 'Column Layout',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-column/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"className":""} --> <div class="wk-component block-column-layout" _bgcolor="default"><div _wkgrid="wide"><!-- wp:wk-blocks/block-wrapper {"className":""} --> <div class=" view-variant--fall"><!-- wp:wk-blocks/inline-column {"className":""} --> <div class="wkColumnGrid " style="grid-column-gap:30px;grid-row-gap:30px"><!-- wp:wk-blocks/inline-inner-column --> <div><!-- wp:heading --> <h2></h2> <!-- /wp:heading --> <!-- wp:paragraph --> <p></p> <!-- /wp:paragraph --> <!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/icon-gallery", "className":""} --> <div class=" view-variant--fall"></div> <!-- /wp:wk-blocks/block-wrapper --> <!-- wp:button --> <div class="wp-block-button"><a class="wp-block-button__link"></a></div> <!-- /wp:button --></div> <!-- /wp:wk-blocks/inline-inner-column --> <!-- wp:wk-blocks/inline-inner-column {"placeholder":"core/image"} --> <div><!-- wp:image --> <figure class="wp-block-image"><img alt=""/></figure> <!-- /wp:image --></div> <!-- /wp:wk-blocks/inline-inner-column --></div> <!-- /wp:wk-blocks/inline-column --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->',
		),
		array(
			'name' => 'Special Links Layout',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-special-links/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"wkTemplateLock":true,"className":"wk-component block-special-links"} --> <div class="wk-component block-special-links" _bgcolor="default"><div _wkgrid="wide"><!-- wp:heading {"align":"center","placeholder":"Special Links Section Heading","className":"block-title"} --> <h2 class="has-text-align-center block-title"></h2> <!-- /wp:heading --> <!-- wp:paragraph {"align":"center","placeholder":"Special Links Section Description","className":"block-desc"} --> <p class="has-text-align-center block-desc"></p> <!-- /wp:paragraph --> <!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/special-links","gridItem":"3","className":"special-link-pallete text-center"} --> <div class="special-link-pallete text-center view-variant--fall"><!-- wp:wk-blocks/special-links {"content":""} --> <div class="brick-wrap"><a class="wk-links-component"><div class="brick"></div></a></div> <!-- /wp:wk-blocks/special-links --> <!-- wp:wk-blocks/special-links {"content":""} --> <div class="brick-wrap"><a class="wk-links-component"><div class="brick"></div></a></div> <!-- /wp:wk-blocks/special-links --> <!-- wp:wk-blocks/special-links {"content":""} --> <div class="brick-wrap"><a class="wk-links-component"><div class="brick"></div></a></div> <!-- /wp:wk-blocks/special-links --> <!-- wp:wk-blocks/special-links {"content":""} --> <div class="brick-wrap"><a class="wk-links-component"><div class="brick"></div></a></div> <!-- /wp:wk-blocks/special-links --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Fancy Links Layout',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-fancy-links/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"wkTemplateLock":true,"className":"wk-component block-fancy-links"} --> <div class="wk-component block-fancy-links" _bgcolor="default"><div _wkgrid="wide"><!-- wp:heading {"align":"center","placeholder":"Fancy Links Section Heading","className":"block-title"} --> <h2 class="has-text-align-center block-title"></h2> <!-- /wp:heading --> <!-- wp:paragraph {"align":"center","placeholder":"Fancy Link Section Description","className":"block-desc"} --> <p class="has-text-align-center block-desc"></p> <!-- /wp:paragraph --> <!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/fancy-links","gridItem":"3","className":"wk-fancy-links"} --> <div class="wk-fancy-links view-variant--fall"><!-- wp:wk-blocks/fancy-links --> <a class="link-component"><img class="fancy-img"/><p class="fancy-title"></p></a> <!-- /wp:wk-blocks/fancy-links --> <!-- wp:wk-blocks/fancy-links --> <a class="link-component"><img class="fancy-img"/><p class="fancy-title"></p></a> <!-- /wp:wk-blocks/fancy-links --> <!-- wp:wk-blocks/fancy-links --> <a class="link-component"><img class="fancy-img"/><p class="fancy-title"></p></a> <!-- /wp:wk-blocks/fancy-links --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Jumbotron Layout',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-jumbotron/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"color":"#efefef","colorClass":"gray","gridLayout":"2","wkTemplateLock":true,"className":"wk-component block-jumbotron"} --> <div class="wk-component block-jumbotron"><div _wkgrid="wide"><div _bgcolor="gray"><!-- wp:wk-blocks/jumbotron {"alignment":false} --> <div class="block-jumbotron-wrap full-grid"><div class="jumbotron-content"><!-- wp:heading {"level":3,"className":"jumbotron-title"} --> <h3 class="jumbotron-title"></h3> <!-- /wp:heading --> <!-- wp:button {"backgroundColor":"primary","borderRadius":4} --> <div class="wp-block-button"><a class="wp-block-button__link has-background has-primary-background-color" style="border-radius:4px"></a></div> <!-- /wp:button --></div></div> <!-- /wp:wk-blocks/jumbotron --></div></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Success Story',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-success-story/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"wkTemplateLock":true,"className":"wk-success-story block-success-story"} --> <div class="wk-component wk-success-story block-success-story" _bgcolor="default"><div _wkgrid="wide"><!-- wp:heading {"align":"center","placeholder":"Success Story Section Heading","className":"block-title"} --> <h2 class="has-text-align-center block-title"></h2> <!-- /wp:heading --> <!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/success-story","gridItem":"3","className":"wrapper"} --> <div class="wrapper view-variant--fall"><!-- wp:wk-blocks/success-story --> <div class="story-block"><div class="story-image"><img/></div><div class="story-content"><div class="title"></div><div class="label"></div><p class="about"></p></div></div> <!-- /wp:wk-blocks/success-story --> <!-- wp:wk-blocks/success-story --> <div class="story-block"><div class="story-image"><img/></div><div class="story-content"><div class="title"></div><div class="label"></div><p class="about"></p></div></div> <!-- /wp:wk-blocks/success-story --> <!-- wp:wk-blocks/success-story {"newWindow":false,"linkWithBtn":false} --> <div class="story-block"><div class="story-image"><img/></div><div class="story-content"><div class="title"></div><div class="label"></div><p class="about"></p></div></div> <!-- /wp:wk-blocks/success-story --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Review Slider',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-review-slider/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"className":"wk-reviews-carousel wk-component block-review-slider","wkTemplateLock":true} --> <div class="wk-reviews-carousel wk-component block-review-slider" _bgcolor="default"><div _wkgrid="wide"><!-- wp:heading {"align":"center", "placeholder":"Review Slider Section Heading","className":"block-title"} --> <h2 class="has-text-align-center block-title"></h2> <!-- /wp:heading --> <!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/wk-no-block-allowed","className":"review-box"} --> <div class="review-box view-variant--fall"><!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/review-slider","className":"review-wrap review-wrap-quote","gridItem":"3"} --> <div class="review-wrap review-wrap-quote view-variant--fall"><!-- wp:wk-blocks/review-slider --> <div class="data"><p>Review for</p><p><a></a></p><p class="larger speak"></p><div class="customer-bio"><img class="pic"/><div class="info"><p></p><p></p><p></p></div></div></div> <!-- /wp:wk-blocks/review-slider --> <!-- wp:wk-blocks/review-slider --> <div class="data"><p>Review for</p><p><a></a></p><p class="larger speak"></p><div class="customer-bio"><img class="pic"/><div class="info"><p></p><p></p><p></p></div></div></div> <!-- /wp:wk-blocks/review-slider --> <!-- wp:wk-blocks/review-slider --> <div class="data"><p>Review for</p><p><a></a></p><p class="larger speak"></p><div class="customer-bio"><img class="pic"/><div class="info"><p></p><p></p><p></p></div></div></div> <!-- /wp:wk-blocks/review-slider --></div> <!-- /wp:wk-blocks/block-wrapper --> <!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/wk-no-block-allowed","className":"nav-reviews"} --> <div class="nav-reviews view-variant--fall"><!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/wk-no-block-allowed","className":"arrows prev"} --> <div class="arrows prev view-variant--fall"></div> <!-- /wp:wk-blocks/block-wrapper --> <!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/wk-no-block-allowed","className":"arrows next"} --> <div class="arrows next view-variant--fall"></div> <!-- /wp:wk-blocks/block-wrapper --></div> <!-- /wp:wk-blocks/block-wrapper --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Testimonial Layout',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-testimonial/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"color":"#efefef","colorClass":"gray","gridLayout":"2","wkTemplateLock":true,"className":"block-testimonial"} --> <div class="wk-component block-testimonial"><div _wkgrid="wide"><div _bgcolor="gray"><!-- wp:wk-blocks/testimonial --> <div class="wk-testimonial-wrap"><p></p><h5></h5><span></span></div> <!-- /wp:wk-blocks/testimonial --></div></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Header',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-page-header/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"wkTemplateLock":true,"className":"component\u002d\u002dpage-header"} --> <div class="wk-component component--page-header" _bgcolor="default"><div _wkgrid="wide"><!-- wp:wk-blocks/header --> <div class="header-wrap"><!-- wp:wk-blocks/inline-inner-column {"innerTemplate":"[[\u0022core/heading\u0022,{\u0022placeholder\u0022:\u0022Page Heading\u0022,\u0022level\u0022:1}],[\u0022core/heading\u0022,{\u0022placeholder\u0022:\u0022Page Sub Heading\u0022,\u0022level\u0022:4}],[\u0022core/paragraph\u0022,{\u0022placeholder\u0022:\u0022Page Description\u0022}],[\u0022core/button\u0022,{\u0022backgroundColor\u0022:\u0022primary\u0022,\u0022borderRadius\u0022:8}]]","className":"header-tagline"} --> <div class="header-tagline"><!-- wp:heading {"level":1,"placeholder":"Page Heading"} --> <h1></h1> <!-- /wp:heading --> <!-- wp:heading {"level":4,"placeholder":"Page Sub Heading"} --> <h4></h4> <!-- /wp:heading --> <!-- wp:paragraph {"placeholder":"Page Description"} --> <p></p> <!-- /wp:paragraph --> <!-- wp:button {"backgroundColor":"primary","borderRadius":8} --> <div class="wp-block-button"><a class="wp-block-button__link has-background has-primary-background-color" style="border-radius:8px"></a></div> <!-- /wp:button --></div> <!-- /wp:wk-blocks/inline-inner-column --></div> <!-- /wp:wk-blocks/header --></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Brand\'s Logo',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-brands-logo/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"wkTemplateLock":true,"className":"component--logo text-center"} --> <div class="wk-component component--logo text-center" _bgcolor="default"><div _wkgrid="wide"><!-- wp:wk-blocks/brands-logo --> <div class="title-mini">The world\'s top brands trust us</div><div class="wk-window-to-toggle wk-items-inlined"><div class="logo"><img class="logo-img" src="https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/samsung.png" alt="samsung"/></div><div class="logo"><img class="logo-img" src="https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/asus.png" alt="asus"/></div><div class="logo"><img class="logo-img" src="https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/BMW.png" alt="BMW"/></div><div class="logo"><img class="logo-img" src="https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/digiweb.png" alt="digiweb"/></div><div class="logo"><img class="logo-img" src="https://webkul.com/wp-content/plugins/webkul-page-builder/images/logo/tech-mahindra.png" alt="tm"/></div></div> <!-- /wp:wk-blocks/brands-logo --></div></div> <!-- /wp:wk-blocks/layout-container --> <!-- wp:separator --> <hr class="wp-block-separator"/> <!-- /wp:separator -->'
		),
		array(
			'name' => 'Badge',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-caption-icons/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"wkTemplateLock":true,"className":"block-badges-section"} --> <div class="block-badges-section wk-component" _bgcolor="default"><div _wkgrid="wide"><!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/wk-no-block-allowed","className":"block-badges-wrapper"} --> <div class="block-badges-wrapper view-variant--fall"><!-- wp:wk-blocks/badge --> <div class="wk-badges-section wk-section-grid"><div class="wk-badge"><span class="badge-icon mg"></span><span class="badge-label">Magento Commerce Certified Developer</span></div><div class="wk-badge"><span class="badge-icon ps"></span><span class="badge-label">PrestaShop Superhero Seller</span></div><div class="wk-badge"><span class="badge-icon sh"></span><span class="badge-label">Shopify Freelance Experts</span></div></div> <!-- /wp:wk-blocks/badge --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Cards',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-caption-icons/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"className":"block-cards-section"} --> <div class="wk-component block-cards-section" _bgcolor="default"><div _wkgrid="wide"><!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/card","gridItem":"4","className":"block-cards-wrapper"} --> <div class="block-cards-wrapper view-variant--fall"><!-- wp:wk-blocks/card --> <div class="block-card no-link" style="border-radius:8px"><img class="card-img" style="border-radius:8px"/><span class="link-title"><span class="card-label"></span></span></div> <!-- /wp:wk-blocks/card --> <!-- wp:wk-blocks/card --> <div class="block-card no-link" style="border-radius:8px"><img class="card-img" style="border-radius:8px"/><span class="link-title"><span class="card-label"></span></span></div> <!-- /wp:wk-blocks/card --> <!-- wp:wk-blocks/card --> <div class="block-card no-link" style="border-radius:8px"><img class="card-img" style="border-radius:8px"/><span class="link-title"><span class="card-label"></span></span></div> <!-- /wp:wk-blocks/card --> <!-- wp:wk-blocks/card --> <div class="block-card no-link" style="border-radius:8px"><img class="card-img" style="border-radius:8px"/><span class="link-title"><span class="card-label"></span></span></div> <!-- /wp:wk-blocks/card --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Fancy Lists',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-caption-icons/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"className":"block-fancy-list-section"} --> <div class="wk-component block-fancy-list-section" _bgcolor="default"><div _wkgrid="wide"><!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/fancy-list","gridItem":"4","className":""} --> <div class="block-fancy-list-wrapper view-variant--fall"><!-- wp:wk-blocks/fancy-list --> <div class="block-fancy-list no-link" style="border-radius:8px"><img class="fancy-list-img" style="border-radius:8px"/><!-- wp:list --> <ul><li></li></ul> <!-- /wp:list --></div> <!-- /wp:wk-blocks/fancy-list --> <!-- wp:wk-blocks/fancy-list --> <div class="block-fancy-list no-link" style="border-radius:8px"><img class="fancy-list-img" style="border-radius:8px"/><!-- wp:list --> <ul><li></li></ul> <!-- /wp:list --></div> <!-- /wp:wk-blocks/fancy-list --> <!-- wp:wk-blocks/fancy-list --> <div class="block-fancy-list no-link" style="border-radius:8px"><img class="fancy-list-img" style="border-radius:8px"/><!-- wp:list --> <ul><li></li></ul> <!-- /wp:list --></div> <!-- /wp:wk-blocks/fancy-list --> <!-- wp:wk-blocks/fancy-list --> <div class="block-fancy-list no-link" style="border-radius:8px"><img class="fancy-list-img" style="border-radius:8px"/><!-- wp:list --> <ul><li></li></ul> <!-- /wp:list --></div> <!-- /wp:wk-blocks/fancy-list --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->'
		),
		array(
			'name' => 'Badge New',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-caption-icons/example.png',
			//'content' => '<!-- wp:wk-blocks/layout-container {"wkTemplateLock":true,"className":"block-badges-section"} --> <div class="block-badges-section wk-component" _bgcolor="default"><div _wkgrid="wide"><!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/wk-no-block-allowed","className":"block-badges-wrapper"} --> <div class="block-badges-wrapper view-variant--fall"><!-- wp:wk-blocks/badge --> <div class="wk-badges-section wk-section-grid"><div class="wk-badge"><span class="badge-icon mg"></span><span class="badge-label">Magento Commerce Certified Developer</span></div><div class="wk-badge"><span class="badge-icon ps"></span><span class="badge-label">PrestaShop Superhero Seller</span></div><div class="wk-badge"><span class="badge-icon sh"></span><span class="badge-label">Shopify Freelance Experts</span></div></div> <!-- /wp:wk-blocks/badge --></div> <!-- /wp:wk-blocks/block-wrapper --></div></div> <!-- /wp:wk-blocks/layout-container -->'
			'content' =>'
			<!-- wp:wk-blocks/layout-container {"className":"block-badges-section"} -->
<div class="wk-component block-badges-section" _bgcolor="default"><div _wkgrid="wide"><!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/badgenew","gridItem":"3","className":"wk-section-grid block-badges-wrapper"} -->
<div class="wk-section-grid block-badges-wrapper view-variant--fall"><!-- wp:wk-blocks/badgenew -->
<div class="wk-badge no-link"><img class="badge-icon mg, wk-image-uploader"/><p class="badge-label" id="textbdge"></p></div>
<!-- /wp:wk-blocks/badgenew -->

<!-- wp:wk-blocks/badgenew -->
<div class="wk-badge no-link"><img class="badge-icon mg, wk-image-uploader"/><p class="badge-label" id="textbdge"></p></div>
<!-- /wp:wk-blocks/badgenew -->

<!-- wp:wk-blocks/badgenew -->
<div class="wk-badge no-link"><img class="badge-icon mg, wk-image-uploader"/><p class="badge-label" id="textbdge"></p></div>
<!-- /wp:wk-blocks/badgenew --></div>
<!-- /wp:wk-blocks/block-wrapper --></div></div>
<!-- /wp:wk-blocks/layout-container -->


			',
		
		
		),
		array(
			'name'=>'Technology',
			'image'=> WK_PAGE_BUILDER_URL . 'src/blocks/block-technology/example.png',
			'content'=>'<!-- wp:wk-blocks/layout-container {"gridField":"full","className":"wk-technology-section"} -->
			<div class="wk-component wk-technology-section" _bgcolor="default"><div _wkgrid="full"><!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/technology","gridItem":"6","className":"wk-section-grid"} -->
			<div class="wk-section-grid view-variant--fall"><!-- wp:wk-blocks/technology -->
			<div class="p-x3 wk-tech-brick no-link"><img class="technology-img"/><p class="p-x3"></p></div>
			<!-- /wp:wk-blocks/technology -->
			
			<!-- wp:wk-blocks/technology -->
			<div class="p-x3 wk-tech-brick no-link"><img class="technology-img"/><p class="p-x3"></p></div>
			<!-- /wp:wk-blocks/technology -->
			
			<!-- wp:wk-blocks/technology -->
			<div class="p-x3 wk-tech-brick no-link"><img class="technology-img"/><p class="p-x3"></p></div>
			<!-- /wp:wk-blocks/technology -->
			
			<!-- wp:wk-blocks/technology -->
			<div class="p-x3 wk-tech-brick no-link"><img class="technology-img"/><p class="p-x3"></p></div>
			<!-- /wp:wk-blocks/technology -->
			
			<!-- wp:wk-blocks/technology -->
			<div class="p-x3 wk-tech-brick no-link"><img class="technology-img"/><p class="p-x3"></p></div>
			<!-- /wp:wk-blocks/technology -->
			
			<!-- wp:wk-blocks/technology -->
			<div class="p-x3 wk-tech-brick no-link"><img class="technology-img"/><p class="p-x3"></p></div>
			<!-- /wp:wk-blocks/technology --></div>
			<!-- /wp:wk-blocks/block-wrapper --></div></div>
			<!-- /wp:wk-blocks/layout-container -->
			',
		),

		array(
			'name' => 'Link Bar',
			'image' => WK_PAGE_BUILDER_URL . 'src/blocks/block-linkBar/example.png',
			'content' => '<!-- wp:wk-blocks/layout-container {"gridField":"compact","className":"wk-link-bar"} -->
			<div class="wk-component wk-link-bar" _bgcolor="default"><div _wkgrid="compact"><!-- wp:wk-blocks/block-wrapper {"selectField":"wk-blocks/linkbar","className":"wk-link-group wkgrid-squeezy"} -->
			<div class="wk-link-group wkgrid-squeezy view-variant--fall"><!-- wp:wk-blocks/linkbar {"content":"","description":""} -->
			<div class="wk-link-block no-link" title=""><h4 class="wk-link-title"></h4><p class="wk-link-info"></p></div>
			<!-- /wp:wk-blocks/linkbar -->
			
			<!-- wp:wk-blocks/linkbar -->
			<div class="wk-link-block no-link"><h4 class="wk-link-title"></h4><p class="wk-link-info"></p></div>
			<!-- /wp:wk-blocks/linkbar -->
			
			<!-- wp:wk-blocks/linkbar {"content":"","description":""} -->
			<div class="wk-link-block no-link" title=""><h4 class="wk-link-title"></h4><p class="wk-link-info"></p></div>
			<!-- /wp:wk-blocks/linkbar --></div>
			<!-- /wp:wk-blocks/block-wrapper -->
			
			<!-- wp:paragraph -->
			<p></p>
			<!-- /wp:paragraph --></div></div>
			<!-- /wp:wk-blocks/layout-container -->
			'
		),
		

	);

	return $result;
}

<?php
/*
* @package webkul
* @subpackage webkul theme 2K2k
* @since webkul theme 3.0
*/

$all_countries = ['Abkhazia', 'Afghanistan','Aland','Albania','Algeria','American-Samoa','Andorra','Angola','Anguilla','Antarctica','Antigua-and-Barbuda','Argentina','Armenia','Aruba','Australia','Austria','Azerbaijan','Bahamas','Bahrain','Bangladesh','Barbados','Basque-Country','Belarus','Belgium','Belize','Benin','Bermuda','Bhutan','Bolivia','Bosnia-and-Herzegovina','Botswana','Brazil','British-Antarctic-Territory','British-Virgin-Islands','Brunei','Bulgaria','Burkina-Faso','Burundi','Cambodia','Cameroon','Canada','Canary-Islands','Cape-Verde','Cayman-Islands','Central-African-Republic','Chad','Chile','China','Christmas-Island','Cocos-Keeling-Islands','Colombia','Commonwealth','Comoros','Cook-Islands','Costa-Rica','Cote-dIvoire','Croatia','Cuba','Curacao','Cyprus','Czech-Republic','Democratic-Republic-of-the-Congo','Denmark','Djibouti','Dominica','Dominican-Republic','East-Timor','Ecuador','Egypt','El-Salvador','England','Equatorial-Guinea','Eritrea','Estonia','Ethiopia','European-Union','Falkland-Islands','Faroes','Fiji','Finland','France','French-Polynesia','French-Southern-Territories','Gabon','Gambia','Georgia','Germany','Ghana','Gibraltar','GoSquared','Greece','Greenland','Grenada','Guam','Guatemala','Guernsey','Guinea-Bissau','Guinea','Guyana','Haiti','Honduras','Hong-Kong','Hungary','Iceland','India','Indonesia','Iran','Iraq','Ireland','Isle-of-Man','Israel','Italy','Jamaica','Japan','Jersey','Jordan','Kazakhstan','Kenya','Kiribati','Kosovo','Kuwait','Kyrgyzstan','Laos','Latvia','Lebanon','Lesotho','Liberia','Libya','Liechtenstein','Lithuania','Luxembourg','Macau','Macedonia','Madagascar','Malawi','Malaysia','Maldives','Mali','Malta','Mars','Marshall-Islands','Martinique','Mauritania','Mauritius','Mayotte','Mexico','Micronesia','Moldova','Monaco','Mongolia','Montenegro','Montserrat','Morocco','Mozambique','Myanmar','NATO','Nagorno-Karabakh','Namibia','Nauru','Netherlands-Antilles','Netherlands','New-Caledonia','New-Zealand','Nicaragua','Niger','Nigeria','Niue','Norfolk-Island','North-Korea','Northern-Cyprus','Northern-Mariana-Islands','Norway','Olympics','Oman','Pakistan','Palau','Palestine','Panama','Papua-New-Guinea','Paraguay','Peru','Philippines','Pitcairn-Islands','Poland','Portugal','Puerto-Rico','Qatar','Red-Cross','Republic-of-the-Congo','Romania','Russia','Rwanda','Saint-Barthelemy','Saint-Helena','Saint-Kitts-and-Nevis','Saint-Lucia','Saint-Martin','Saint-Vincent-and-the-Grenadines','Samoa','San-Marino','Sao-Tome-and-Principe','Saudi-Arabia','Scotland','Senegal','Serbia','Seychelles','Sierra-Leone','Singapore','Slovakia','Slovenia','Solomon-Islands','Somalia','Somaliland','South-Africa','South-Georgia-and-the-South-Sandwich-Islands','South-Korea','South-Ossetia','South-Sudan','Spain','Sri-Lanka','Sudan','Suriname','Swaziland','Sweden','Syria','Taiwan','Tajikistan','Tanzania','Thailand','Togo','Tokelau','Tonga','Trinidad-and-Tobago','Tunisia','Turkey','Turkmenistan','Turks-and-Caicos-Islands','Tuvalu','US-Virgin-Islands','Uganda','Ukraine','United-Arab-Emirates','United-Kingdom','United-Nations','United-States','Unknown','Uruguay','Uzbekistan','Vanuatu','Venezuela','Vietnam','Wales','Wallis-And-Futuna','Western-Sahara','Yemen','Zambia','Zimbabwe','Nepal','Switzerland','Vatican-City'];

$top_countries = [
	[
		'name'  => 'United States',
		'color' => '#e72d2d',
		'id'    => 'United-States',
	],
	[
		'name'  => 'India',
		'color' => '#202190',
		'id'    => 'India',
	],
	[
		'name'  => 'United Kingdom',
		'color' => '#033399',
		'id'    => 'United-Kingdom',
	],
	[
		'name'  => 'Spain',
		'color' => '#ff8d19',
		'id'    => 'Spain',
	],
	[
		'name'  => 'France',
		'color' => '#e12a2a',
		'id'    => 'France',
	],
	[
		'name'  => 'Australia',
		'color' => '#ff9d00',
		'id'    => 'Australia',
	],
	[
		'name'  => 'Saudi Arabia',
		'color' => '#028b2e',
		'id'    => 'Saudi-Arabia',
	],
	[
		'name'  => 'Italy',
		'color' => '#db2c39',
		'id'    => 'Italy',
	],
	[
		'name'  => 'Netherlands',
		'color' => '#134094',
		'id'    => 'Netherlands',
	],
	[
		'name'  => 'United Arab Emirates',
		'color' => '#0e922d',
		'id'    => 'United-Arab-Emirates',
	],
	[
		'name'  => 'Germany',
		'color' => '#ff7920',
		'id'    => 'Germany',
	],
	[
		'name'  => 'Canada',
		'color' => '#ff1b1b',
		'id'    => 'Canada',
	],
	[
		'name'  => 'Brazil',
		'color' => '#ef9400',
		'id'    => 'Brazil',
	],
	[
		'name'  => 'Egypt',
		'color' => '#d52228',
		'id'    => 'Egypt',
	],
	[
		'name'  => 'Hong Kong',
		'color' => '#e03821',
		'id'    => 'Hong Kong',
	],
	[
		'name'  => 'Mexico',
		'color' => '#07784f',
		'id'    => 'Mexico',
	],
	[
		'name'  => 'Poland',
		'color' => '#c80220',
		'id'    => 'Poland',
	],
	[
		'name'  => 'Switzerland',
		'color' => '#e62908',
		'id'    => 'Switzerland',
	],
	[
		'name'  => 'Malaysia',
		'color' => '#d0bd00',
		'id'    => 'Malaysia',
	],
	[
		'name'  => 'Belgium',
		'color' => '#f42837',
		'id'    => 'Belgium',
	],
	[
		'name'  => 'Singapore',
		'color' => '#ed2939',
		'id'    => 'Singapore',
	],
	[
		'name'  => 'Austria',
		'color' => '#dc1828',
		'id'    => 'Austria',
	],
	[
		'name'  => 'South Africa',
		'color' => '#007742',
		'id'    => 'South Africa',
	],
	[
		'name'  => 'Romania',
		'color' => '#eaa400',
		'id'    => 'Romania',
	],
	[
		'name'  => 'Columbia',
		'color' => '#02338e',
		'id'    => 'Columbia',
	],
	[
		'name'  => 'Greece',
		'color' => '#000581',
		'id'    => 'Greece',
	],
	[
		'name'  => 'Turkey',
		'color' => '#db1b1b',
		'id'    => 'Turkey',
	],
	[
		'name'  => 'Chile',
		'color' => '#0439a6',
		'id'    => 'Chile',
	],
	[
		'name'  => 'Kuwait',
		'color' => '#009051',
		'id'    => 'Kuwait',
	],
	[
		'name'  => 'Thailand',
		'color' => '#03247d',
		'id'    => 'Thailand',
	],
];

$all_reviews      = maybe_unserialize( get_option( 'wkcr_review_data' ) );
$all_reviews      = ( '' === $all_reviews ) ? array() : $all_reviews;
$upload_path      = wp_upload_dir()['baseurl'];
$industry_list    = get_option( '__wkcr_industry_list' );
$industry_list    = empty( $industry_list ) ? array() : $industry_list;
$client_countries = array_unique( array_values( wp_list_pluck( $all_reviews, 'country' ) ) );

sort( $client_countries ); //sort will reindex the array

$all_reviews = array_filter( $all_reviews, function( $data ) {
	return ( 'checked' === $data['status'] ) ? true : false;
} );

function get_industry_name( $id ) {
	global $industry_list;
	$data_found = array_search( $id, array_column( $industry_list, 'id' ), true );
	return ( $data_found ) ? $industry_list[ $data_found ]['name'] : '';
}

function is_review_ready( $data ) {

	if ( 'checked' === $data['status']
	&& ! empty( $data['company_logo'] )
	&& ! empty( $data['review'] )
	&& ! empty( $data['name'] )
	&& ! empty( $data['country'] )
	&& ! empty( $data['industry'] )
	&& ! empty( $data['work'] )
	&& ( false === stripos( $data['work'], 'http' ) )
	) {
		return true;
	} else {
		return false;
	}
}


$country_pre_select = ( isset( $_GET['country'] ) && ! empty( $_GET['country'] ) ) ? $_GET['country'] : '';
$industry_pre_select = ( isset( $_GET['industry'] ) && ! empty( $_GET['industry'] ) ) ? $_GET['industry'] : 'All';

get_header();
?>

<section class="wk-page-content">
	<div class="wk-component component--page-header location-page-section" _bgcolor="default">
		<div _wkgrid="wide">
			<div class="header-wrap header--view-default">
				<div class="header-tagline">
					<h1>Top Selling Locations</h1>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="wk-top-locations section-padding-0B">
	<div class="wkgrid-wide">
		<div class="wk-section-grid location-wrapper">
			<?php
			foreach ( $top_countries as $country ) {
				echo '<div data-anchor="' . $country['id'] . '" class="location-block" style="background-color:' . $country['color'] . '"><span class="country-flag-lg ' . $country['id'] . '"></span>' . $country['name'] . '</div>';
			}
			?>
		</div>
	</div>
</section>
<section class="wk-page-content section-padding-0B">
<div class="wk-component " _bgcolor="default"><div _wkgrid="squeezy">
<h2>We work with top brands across the globe.</h2>
<p>Discover the reviews and insights of the inspiring Webkul customers, who turned their idea into living reality using Webkul plugins, apps and extensions..</p>
</div></div>
</section>


<section class="wk-global-review">
	<div class="wkgrid-wide">
		<div class="wk-glb-rvw-filter">
			<div class="wk-filter wk-filter-country" data-filter_group="country">
				<div class="feed-input-wrap">
					<span class="icon icon-search"></span>
					<input class="inpt-field inpt-field-search" type="text" id="inpt-filter-country" value="<?php echo $country_pre_select; ?>" placeholder="Search by Country" autocomplete="off" onfocus="this.setSelectionRange(this.value.length,this.value.length);"/>
					<span class="icon-close" id="inpt-filter-country-clear"></span>
				</div>
				<template id="tmpl-wkcrAutoSuggest"><li class="drpdwn-opt" data-filter_needle="{{id}}"><span class="country-flag-sm {{id}}"></span><span>{{name}}</span></li></template>
				<ul class="drpdwn-box" id="country-list"></ul>
			</div>
			<div class="wk-filter wk-filter-industry" data-filter_group="industry">
				<div class="feed-input-wrap">
					<div class="inpt-field inpt-field-select" id="inpt-filter-industry"><?php echo $industry_pre_select; ?></div>
					<span class="icon icon-arrow-dwn"></span>
				</div>
				<ul class="drpdwn-box" id="industry-list">
				<?php
				echo '<li class="drpdwn-opt" data-filter_needle="all">All</li>';
				foreach ( $industry_list as $item ) {
					echo '<li class="drpdwn-opt" data-filter_needle="' . $item['id'] . '">' . $item['name'] . '</li>';
				}
				?>
				</ul>
			</div>
		</div>
		<div class="wk-glb-rvw-list-outer">
			<div class="wk-loader-wrap on"><div class="wk-loader"></div></div>
			<div class="wk-glb-rvw-list">
			<?php
			foreach ( $all_reviews as $key => $item ) {

				if ( ! is_review_ready( $item ) ) {
					continue;
				}

				$country      = str_replace( '-', ' ', $item['country'] );

				$company_logo = empty( $item['company_logo'] ) ? '<br>' : '<img src="' . $upload_path . $item['company_logo'] . '" alt="' . $item['name'] . '" class="logo">';

				$client_img = empty( $item['pic'] ) ? 'https://webkul.com/wp-content/plugins/client-reviews/images/user.png' : $upload_path . $item['pic'];


				echo '<div class="wk-glb-rvw-box" data-id="' . $item['id'] . '" data-country="' . $item['country'] . '" data-industry="' . $item['industry']. '">
					<div class="loc"><span class="country-flag-sm ' . $item['country'] . '"></span>' . $country . '</div>' . $company_logo . ' 
					<p class="indus">' . get_industry_name( $item['industry'] ) . '</p>
					<div class="saying-box">
						<p class="saying">' . $item['review'] . '</p>
					</div>
					<div class="name-card">
						<img src="' . $client_img . '" alt="' . $item['name'] . '" class="thumb">
						<span class="name">' . $item['name'] . '</span>
						<span class="work">' . $item['work'] . '</span>
					</div>
				</div>';
			}
			?>
			</div>
		</div>
	</div>
</section>
<section class="wk-page-content section-top">
	<div class="wk-component block-jumbotron"><div _wkgrid="wide"><div _bgcolor="dark">
		<div class="block-jumbotron-wrap full-grid"><div class="jumbotron-content center">
		<h2 class="has-text-align-center jumbotron-title">Hire on-demand project developers and turn your idea into reality</h2>
		<div class="wp-block-button aligncenter"><a class="wp-block-button__link has-gray-background-color has-background" href="#contact">Become a Partner</a></div>
		</div></div>
		</div></div>
	</div>
</section>
<template id="tmplNoLocationFound">
	<div class="wk-no-data --exclude-item">
		<img src="<?php echo img_dir( 'orphan/no-data-found.png' ); ?>" alt="no-data-found">
		<h4 >Check back later</h4>
		<p>A large {{placeholder}} customer base trust us. We are in the process of adding them here. Meanwhile, you can check our top customers.</p>
		<a href="https://webkul.com/our-customers/" class="wk-button btn-dark">View Top Customers</a>
	</div>
</template>
<?php
echo '<script id="wkcrIndustryJson" type="application/json">' . wp_json_encode( $industry_list ) . '</script>';
echo '<script id="wkcrReviewJson" type="application/json">' . wp_json_encode( $all_reviews ) . '</script>';
echo '<script id="wkcrClientCountriesJson" type="application/json">' . wp_json_encode( $client_countries ) . '</script>';
echo '<script id="wkcrAllCountriesJson" type="application/json">' . wp_json_encode( $all_countries ) . '</script>';
?>
<style>
</style>
<?php
get_footer();

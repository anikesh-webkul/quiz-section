/**
 * wk-caption-title Tag h5 deprecated, we are using p tag instead of that
 */

wp.hooks.addFilter( 'blocks.registerBlockType', 'wk-blocks/deprecated/fancy-links', function(settings, name) {
    if ( name !== 'wk-blocks/fancy-links' ) {
        return settings;
    }
    settings.deprecated = [
        {
            attributes: settings.attributes,
 
            save: function( props ) {
                return el(
                    Fragment,
                    {},
                    el(
                        'a',
                        {
                            href:props.attributes.imgLink,
                            className:'link-component',
                            title:props.attributes.content,
                            target:(props.attributes.newContent) ? '_blank' : false,
                            rel:(props.attributes.newContent) ? 'noopener noreferrer' : false,
                        },
                        el(
                            'img',
                            {
                                src:props.attributes.imgSrc,
                                alt:props.attributes.imgALT,
                            },
                            
                        ),
                        el(
                            'h4',
                            {
                                value:props.attributes.content
                            },
                            props.attributes.content
                        )
                    )
                );
            },
        }
    ]

    return settings;

} );
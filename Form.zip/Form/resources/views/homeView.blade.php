<!DOCTYPE html>
<html>
<head>
    <title>Add Order</title>
    <style>

    #container{
        width:auto;
        height:450px;
        margin-left:15%;
        margin-right:15%;
        margin-top:5%;
        border:2px solid green;
    }

    label{
        font-size:1.5vw;
        margin-left:25%;
    }
    input{
        width:25%;
        height:30px;
        border:1px solid green;
        margin-left:25%;
    }

    button{
        width:10%;
        height:50px;
        border-radius:5px;
        margin-left:33%;
        font-size:1.2vw;
    }

    </style>
</head>
<body>

<div id="container">

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

    <form action="submit"  method="POST" >
    @csrf
        <br><br>
        <label>Form ID</label><br>
        <input type="number" name="form_id" placeholder="Enter form ID.."><br><br>

        <label>Name</label><br>
        <input type="text" name="name" placeholder="Enter Name.."><br><br>

        
     <a href="/createFormView"   <button type="submit" name="submit">Create Form</button></a>
    <form>

</div>

</body>
</html>
<?php 

               
               
?>
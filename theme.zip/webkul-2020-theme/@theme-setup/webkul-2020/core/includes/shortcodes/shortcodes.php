<?php

/*Shortcodes*/
add_shortcode( 'wk-caption-icon', 'wk_shortcode_caption_panel' );
add_shortcode( 'wk-caption-icons', 'wk_shortcode_caption_panel' );

add_shortcode( 'wk-image-gallery', 'wk_shortcode_gallery_panel' );

add_shortcode( 'wk-image-card', 'wk_shortcode_card_component' );
add_shortcode( 'wk-card-component', 'wk_shortcode_card_component' );

add_shortcode( 'wk-special-link', 'wk_shortcode_link_component' );
add_shortcode( 'wk-link-component', 'wk_shortcode_link_component' );


add_shortcode( 'wk-section', 'wk_shortcode_section_component' );
add_shortcode( 'wk-section-component', 'wk_shortcode_section_component' );

add_shortcode( 'wk-jumbotron', 'wk_shortcode_jumbotron_component' );
add_shortcode( 'wk-fancy-links', 'wk_shortcode_fancylink_component' );
add_shortcode( 'wk-carousels', 'wk_shortcode_carousel_component' );
add_shortcode( 'wk-success-story', 'wk_shortcode_success_story_component' );
/*//Shortcodes*/


/*Shortcodes Callbacks */
function wk_shortcode_success_story_component( $atts ) {

	if ( ! isset( $atts['for'] ) || empty( $atts['for'] ) ) {
		return '';
	}
	$pallete_id   = $atts['for'];
	$pallete_class = isset( $atts['class'] ) ? ' ' . $atts['class'] : false;
	$all_palletes = get_option( 'wktheme-success-story' );
	if ( ! isset( $all_palletes[ $pallete_id ] ) || empty( $all_palletes[ $pallete_id ]['items'][0]['title'] ) ) {
		return '';
	}

	$wkgrid_flag = ( isset( $atts['grid'] ) && 'false' === $atts['grid'] ) ? false : true;

	$data = $all_palletes[ $pallete_id ];

	$wk_meta_grid  = ( isset( $data['meta']['grid'] ) && ! empty( $data['meta']['grid'] ) ) ? $data['meta']['grid'] : 'squeezy';

	if ( $wkgrid_flag ) {
		$fragment  = '</div>';  //End the grid
		$fragment .= '<div class="wk-component wk-success-story' . $pallete_class . '" _grid="' . esc_attr( $wk_meta_grid ) . '"  _bgcolor="' . $data['meta']['bg'] . '">
		<div class="wkgrid-' . esc_attr( $wk_meta_grid ) . '">';
		$fragment .= ( ! empty( $data['meta']['title'] )  ) ? '<h2 class="title text-center">' . $data['meta']['title'] . '</h2>' : '';
		$fragment .= '<div class="wrapper text-center">';

		foreach ( $data['items'] as $item ) {

			$img = wk_get_img_html( @$item['icon'], '', array('title' => $item['title'] ) );

			$fragment .= '<div class="story-block tickle">
							<div class="story-image">
								<a target="_blank" rel="noopener" href="' . $item['url'] . '" title="' . $item['title'] . '">
									' . $img . '
								</a>
							</div>
							<div class="story-content">
								<div class="title">' . $item['title'] . '</div>
								<p class="about">' . $item['about'] . '</p>
								<a target="_blank" rel="noopener" class="read-more" href="' . $item['url'] . '" title="' . $item['title'] . '">Read More <span>&#8250;</span></a>
							</div>
				</div>';
		}

		$fragment .= '</div></div></div><div class="wkgrid-squeezy">';  //Start the grid again atlast

	} else {
		$fragment  = '<div class="wk-success-story' . $pallete_class . '">';
		$fragment .= ( ! empty( $data['meta']['title'] )  ) ? '<h2 class="title text-center">' . $data['meta']['title'] . '</h2>' : '';
		$fragment .= '<div class="wrapper">';

		foreach ( $data['items'] as $item ) {

			$img = wk_get_img_html( @$item['icon'] );
			
			$fragment .= '<a href="' . $item['url'] . '" title="' . $item['label'] . '" class="link-component">
			' . $img . '
			<h4>' . $item['label'] . '</h4></a>';
		}
		$fragment .= '</div></div>';  //Start the grid again atlast
	}

	return $fragment;
}




function wk_shortcode_carousel_component( $atts ) {

	if ( ! isset( $atts['for'] ) || empty( $atts['for'] ) ) {
		return '';
	}

	$pallete_id   = $atts['for'];
	$pallete_class = isset( $atts['class'] ) ? ' ' . $atts['class'] : false;
	$all_palletes = get_option( 'wktheme-carousels' );

	if ( ! isset( $all_palletes[ $pallete_id ] ) || empty( $all_palletes[ $pallete_id ]['items'][0]['linkLabel'] ) ) {
		return '';
	}

	$data     = $all_palletes[ $pallete_id ];

	$wk_meta_grid  = ( isset( $data['meta']['grid'] ) && ! empty( $data['meta']['grid'] ) ) ? $data['meta']['grid'] : 'squeezy';

	$fragment = '</div>'; //End the Grid
	$fragment .= '<div class="wk-reviews-carousel wk-component' . $pallete_class . '" _grid="' . esc_attr( $wk_meta_grid ) . '" _bgcolor="' . esc_attr( $data['meta']['bg'] ) . '"><div class="wkgrid-' . esc_attr( $wk_meta_grid ) . '">';
	$fragment .= ( ! empty( $data['meta']['title'] )  ) ? '<h2 class="title text-center">' . $data['meta']['title'] . '</h2>' : '';
	$fragment .= '<div class="review-box"><div class="review-wrap"><span class="qoute"></span>';
	foreach ( $data['items'] as $item ) {
		$img = file_exists( wp_upload_dir()['basedir'] . $item['iconUrl'] ) ? wp_upload_dir()['baseurl'] . $item['iconUrl'] : $item['iconUrl'];
		$fragment .= '<div class="data">
			<p>Review for</p>
			<p><a target="_blank" rel="noopener" href="' . esc_url( $item['linkUrl'] ) . '" title="' . esc_html( $item['linkLabel'] ) . '">' . esc_html( $item['linkLabel'] ) . '</a></p>
			<p class="larger speak">' . esc_html( $item['review'] ) . '</p>
			<div class="customer-bio">
				<img class="pic" src="' . esc_attr( $img ) . '" alt="' . esc_attr( $item['name'] ) . '">
				<div class="info">
					<p>' . esc_attr( $item['name'] ) . '</p>
					<p>' . esc_attr( $item['work'] ) . '</p>
					<p>' . esc_attr( $item['location'] ) . '</p>
				</div>
			</div>
		</div>';
	}

	$fragment .= '</div><span class="nav-reviews">
		<span class="arrows prev"></span>
		<span class="arrows next"></span>
	</span></div>';
	$fragment .= '</div></div><div class="wkgrid-squeezy">';  //Re-Start the grid atlast

	return $fragment;
}


function wk_shortcode_fancylink_component( $atts ) {

	if ( ! isset( $atts['for'] ) || empty( $atts['for'] ) ) {
		return '';
	}
	$pallete_id   = $atts['for'];
	$pallete_class = isset( $atts['class'] ) ? ' ' . $atts['class'] : false;
	$all_palletes = get_option( 'wktheme-fancy-links' );
	if ( ! isset( $all_palletes[ $pallete_id ] ) || empty( $all_palletes[ $pallete_id ]['items'][0]['label'] ) ) {
		return '';
	}

	$wkgrid_flag = ( isset( $atts['grid'] ) && 'false' === $atts['grid'] ) ? false : true;

	$data = $all_palletes[ $pallete_id ];

	$wk_meta_grid  = ( isset( $data['meta']['grid'] ) && ! empty( $data['meta']['grid'] ) ) ? $data['meta']['grid'] : 'squeezy';

	if ( $wkgrid_flag ) {
		$fragment  = '</div>';  //End the grid
		$fragment .= '<div class="wk-component wk-fancy-links no-sync' . $pallete_class . '" _grid="' . esc_attr( $wk_meta_grid ) . '"  _bgcolor="' . $data['meta']['bg'] . '">
		<div class="wkgrid-' . esc_attr( $wk_meta_grid ) . '">';
		$fragment .= ( ! empty( $data['meta']['title'] )  ) ? '<h2 class="title text-center">' . $data['meta']['title'] . '</h2>' : '';
		$fragment .= '<div class="wrapper">';

		foreach ( $data['items'] as $item ) {

			$img = wk_get_img_html( @$item['icon'] );

			$fragment .= '<a href="' . $item['url'] . '" title="' . $item['label'] . '" class="link-component">
			' . $img . '
			<h4>' . $item['label'] . '</h4></a>';
		}
		$fragment .= '</div></div></div><div class="wkgrid-squeezy">';  //Start the grid again atlast
	} else {
		$fragment  = '<div class="wk-fancy-links no-sync' . $pallete_class . '">';
		$fragment .= ( ! empty( $data['meta']['title'] )  ) ? '<h2 class="title text-center">' . $data['meta']['title'] . '</h2>' : '';
		$fragment .= '<div class="wrapper">';

		foreach ( $data['items'] as $item ) {
			
			$img = wk_get_img_html( @$item['icon'] );

			$fragment .= '<a href="' . $item['url'] . '" title="' . $item['label'] . '" class="link-component">
			' . $img . '
			<h4>' . $item['label'] . '</h4></a>';
		}
		$fragment .= '</div></div>';  //Start the grid again atlast
	}

	return $fragment;
}

//====> do_shortcode for caption-icons.
function wk_shortcode_caption_panel( $atts ) {
	$pallete_id   = $atts['for'];
	$pallete_class = isset( $atts['class'] ) ? ' ' . $atts['class'] : false;
	
	$all_palletes = get_option( 'wktheme-caption-icons' );
	if ( ! isset( $all_palletes[ $pallete_id ] ) || empty( $all_palletes[ $pallete_id ]['items'][0]['icon'] ) ) {
		return '';
	}

	$wkgrid_flag = ( isset( $atts['grid'] ) && 'false' === $atts['grid'] ) ? false : true;

	$data = $all_palletes[ $pallete_id ];
	$path = wp_upload_dir()['baseurl'];

	$wk_meta_title = isset( $data['meta']['title'] ) ? $data['meta']['title'] : '';
	$wk_meta_bg    = ( isset( $data['meta']['bg'] ) && ! empty( $data['meta']['bg'] ) ) ? $data['meta']['bg'] : 'default';
	$wk_meta_grid  = ( isset( $data['meta']['grid'] ) && ! empty( $data['meta']['grid'] ) ) ? $data['meta']['grid'] : 'squeezy';

	if ( $wkgrid_flag ) {
		$fragment  = '</div>'; // End the Grid
		$fragment .= '<div class="wk-component caption-icons-pallete text-center' . $pallete_class . '" _grid="' . esc_attr( $wk_meta_grid ) . '" _bgcolor="' . esc_attr( $wk_meta_bg ) . '"><div class="wkgrid-' . esc_attr( $wk_meta_grid ) . '">';
		if ( ! empty( $wk_meta_title ) ) {
			$fragment .= '<h2 class="title text-center">' . esc_html( $wk_meta_title ) . '</h2>';
		}
		foreach ( $data['items'] as $item ) {
			$caption = isset( $item['caption'] ) ? $item['caption'] : '';
			if ( isset( $item['icon'] ) && ! empty( $item['icon'] ) ) {
				
				$title = ( ! empty( $item['title'] ) ) ? '<h5>' . $item['title'] . '</h5>' : false;
				$title_class = ( $title ) ? 'tier' : false;

				$img_title = ( ! empty( $item['title'] ) ) ? $item['title'] : $caption;

				$img = wk_get_img_html( @$item['icon'], '', array('title'=> $img_title ) );

				$fragment .= '<div class="brick ' . $title_class . '">' . $img . $title . '<div class="caption">' . $caption . '</div></div>';
			}
		}
		$fragment .= '</div></div><div class="wkgrid-squeezy">'; //Start the Grid atlast

	} else {

		// When Shortcode inside shortcode. skip Grid and bgColor.
		$fragment = '<div class="caption-icons-pallete text-center' . $pallete_class . '"';
		if ( ! empty( $wk_meta_title ) ) {
			$fragment .= '<h2 class="title text-center">' . esc_html( $wk_meta_title ) . '</h2>';
		}
		foreach ( $data['items'] as $item ) {
			$caption = isset( $item['caption'] ) ? $item['caption'] : '';
			if ( isset( $item['icon'] ) && ! empty( $item['icon'] ) ) {

				$img = wk_get_img_html( @$item['icon'], '', array( 'title'=> $caption ) );

				$fragment .= '<div class="brick">' . $img . '<div class="caption">' . $caption . '</div></div>';
			}
		}
		$fragment .= '</div>';
	}
	return $fragment;
}

function wk_shortcode_gallery_panel( $atts ) {

	$pallete_id   = $atts['for'];
	$pallete_class = isset( $atts['class'] ) ? ' ' . $atts['class'] : false;
	$all_palletes = get_option( 'wktheme-image-gallery' );
	if ( ! isset( $all_palletes[ $pallete_id ] ) || empty( $all_palletes[ $pallete_id ]['items'][0]['icon'] ) ) {
		return '';
	}
	$data = $all_palletes[ $pallete_id ];
	if ( empty( $data['items'][0]['icon'] ) ) {
		return '';
	}

	$wk_meta_title = isset( $data['meta']['title'] ) ? $data['meta']['title'] : '';
	$wk_meta_bg    = ( isset( $data['meta']['bg'] ) && ! empty( $data['meta']['bg'] ) ) ? $data['meta']['bg'] : 'default';
	$wk_meta_grid  = ( isset( $data['meta']['grid'] ) && ! empty( $data['meta']['grid'] ) ) ? $data['meta']['grid'] : 'squeezy';

	$path      = wp_upload_dir()['baseurl'];
	// $fragment  = '</div>'; //End of Grid.
	$fragment  = ''; //End of Grid.
	$fragment .= '<div class="gallery-pallete wk-component text-center' . $pallete_class . '" _grid="'.esc_attr( $wk_meta_grid ).'" _bgcolor="' . esc_attr( $wk_meta_bg ) . '"><div class="wkgrid-' . esc_attr( $wk_meta_grid ) . '"><div class="inner-gallery">';

	if ( ! empty( $wk_meta_title ) ) {
		$fragment .= '<h2 class="title text-center">' . $wk_meta_title . '</h2>';
	}
	foreach ( $data['items'] as $item ) {

		$img = wk_get_img_html( @$item['icon'] );

		if ( isset( $item['link'] ) && ! empty( $item['link'] ) ) {

			$fragment .= '<div class="brick"><a href="' . esc_url( $item['link'] ) . '" target="_blank" rel="noopener">' . $img . '</a></div>';
		} else {
			$fragment .= '<div class="brick">' . $img . '</div>';
		}
	}
	// $fragment .= '</div></div></div><div class="wkgrid-squeezy">';
	$fragment .= '</div></div></div>';

	return $fragment;
}

function wk_shortcode_card_component( $atts ) {

	$pallete_id   = $atts['for'];
	$all_palletes = get_option( 'wktheme-card-component' );
	$data         = $all_palletes[ $pallete_id ];
	if ( empty( $data['items'][0]['image'] ) ) {
		return '';
	}

	$path     = wp_upload_dir()['baseurl'];
	$img_url  = $path . $data['items'][0]['image'];
	$content  = $data['items'][0]['content'];

	$fragment = '<div class="card-pallete">
			<div class="card-image">
				<img src="' . esc_url( $img_url ) . '"  />
			</div>
			<div class="card-content">
				<p>' . $content . '</p>
			</div>
	</div>';

	return $fragment;
}

function wk_shortcode_link_component( $atts ) {

	$pallete_id   = $atts['for'];
	$pallete_class = isset( $atts['class'] ) ? ' ' . $atts['class'] : false;
	$all_palletes = get_option( 'wktheme-link-component' );
	if ( ! isset( $all_palletes[ $pallete_id ] ) || empty( $all_palletes[ $pallete_id ]['items'][0]['label'] ) ) {
		return '';
	}
	$data = $all_palletes[ $pallete_id ];

	$wkgrid_flag = ( isset( $atts['grid'] ) && 'false' === $atts['grid'] ) ? false : true;

	$wk_meta_title = isset( $data['meta']['title'] ) ? $data['meta']['title'] : '';
	$wk_meta_bg    = ( isset( $data['meta']['bg'] ) && ! empty( $data['meta']['bg'] ) ) ? $data['meta']['bg'] : 'default';
	$wk_meta_grid  = ( isset( $data['meta']['grid'] ) && ! empty( $data['meta']['grid'] ) ) ? $data['meta']['grid'] : 'squeezy';

	if ( $wkgrid_flag ) {
		$fragment  = '</div>'; //End of Grid.
		$fragment .= '<div class="special-link-pallete wk-component' . $pallete_class . '" _grid="' . esc_attr( $wk_meta_grid ) . '" _bgcolor ="' . esc_attr( $wk_meta_bg ) . '"><div class="wkgrid-' . esc_attr( $wk_meta_grid ) . '"><div class="inner">';
		if ( ! empty( $wk_meta_title ) ) {
			$fragment .= '<h2 class="title text-center">' . $wk_meta_title . '</h2>';
		}
		foreach ( $data['items'] as $item ) {
			$fragment .= '<div class="brick-wrap"><a class="wk-links-component" href=' . $item['url'] . ' title="' . $item['label'] . '" target="_blank" rel="noopener"><div class="brick">' . nl2br( $item['label'] ) . '</div></a></div>';
		}
		$fragment .= '</div></div></div><div class="wkgrid-squeezy">';
	} else {
		$fragment = '<div class="special-link-pallete' . $pallete_class . '"><div class="inner">';
		foreach ( $data['items'] as $item ) {
			$fragment .= '<div class="brick-wrap"><a class="wk-links-component" href=' . $item['url'] . ' title="' . $item['label'] . '" target="_blank" rel="noopener"><div class="brick">' . nl2br( $item['label'] ) . '</div></a></div>';
		}
		$fragment .= '</div></div>';
	}


	return $fragment;
}



function wk_shortcode_section_component( $atts ) {

	$pallete_id    = $atts['for'];
	$pallete_class = isset( $atts['class'] ) ? ' ' . $atts['class'] : false;
	$all_palletes = get_option( 'wktheme-section-component' );
	$data         = $all_palletes[ $pallete_id ];
	if ( ! isset( $all_palletes[ $pallete_id ] ) || empty( $all_palletes[ $pallete_id ]['items'][0]['content'] ) ) {
		return '';
	}

	$content    = $data['items'][0]['content'];
	$contenttwo = $data['items'][0]['contenttwo'];

	$wk_meta_title = isset( $data['meta']['title'] ) ? $data['meta']['title'] : '';
	$wk_meta_bg    = ( isset( $data['meta']['bg'] ) && ! empty( $data['meta']['bg'] ) ) ? $data['meta']['bg'] : 'default';
	$wk_meta_grid  = ( isset( $data['meta']['grid'] ) && ! empty( $data['meta']['grid'] ) ) ? $data['meta']['grid'] : 'compact';
	global $shortcode_tags;

	$fragment  = '</div>'; //End of Grid.
	$fragment .= '<div class="wk-content-partition wk-component' . $pallete_class . '" _grid="' . esc_attr( $wk_meta_grid ) . '" _bgcolor ="' . esc_attr( $wk_meta_bg ) . '"><div class="wkgrid-' . esc_attr( $wk_meta_grid ) . '">';

	if ( ! empty( $wk_meta_title ) ) {
		$fragment .= '<h2 class="title text-center">' . $wk_meta_title . '</h2>';
	}
	foreach ( $data['items'] as $key => $section ) {
		if( strchr( $section['content'], '<img ' ) ) {

			$fragment .= '<div class="wk-content-wrap dir-rtl"><div class="part-one dir-ltr">' . do_shortcode( wk_inner_sc_modifier( wpautop( stripslashes( $section['contenttwo'] ) ) ) ) . '</div>
										<div class="part-two">' . do_shortcode( wk_inner_sc_modifier( wpautop( stripslashes( $section['content'] ) ) ) ) . '</div></div>';

		} else {
			
			$fragment .= '<div class="wk-content-wrap"><div class="part-one">' . do_shortcode( wk_inner_sc_modifier( wpautop( stripslashes( $section['content'] ) ) ) ) . '</div>
										<div class="part-two">' . do_shortcode( wk_inner_sc_modifier( wpautop( stripslashes( $section['contenttwo'] ) ) ) ) . '</div></div>';
		}
	}

	$fragment .= '</div></div><div class="wkgrid-squeezy">';

	return $fragment;
}

function wk_inner_sc_modifier( $content ) {
	return preg_replace_callback( '@\[([^<>&/\[\]\x00-\x20=]++)@', function( $matches ) {
		return $matches[0] . ' grid="false" ';
	}, $content );
}

function wk_shortcode_jumbotron_component( $atts ) {

	$pallete_id   = isset( $atts['for'] ) ? $atts['for'] : '';
	$pallete_class = isset( $atts['class'] ) ? ' ' . $atts['class'] : false;
	$all_palletes = get_option( 'wktheme-jumbotron' );

	if ( ! isset( $all_palletes[ $pallete_id ] ) || empty( $all_palletes[ $pallete_id ]['items'][0]['label'] ) ) {
		return '';
	}
	$data = $all_palletes[ $pallete_id ];

	$wkgrid_flag = ( isset( $atts['grid'] ) && 'false' === $atts['grid'] ) ? false : true;

	$wk_meta_title = isset( $data['meta']['title'] ) ? $data['meta']['title'] : '';
	$wk_meta_bg    = ( isset( $data['meta']['bg'] ) && ! empty( $data['meta']['bg'] ) ) ? $data['meta']['bg'] : 'default';
	$wk_meta_grid  = ( isset( $data['meta']['grid'] ) && ! empty( $data['meta']['grid'] ) ) ? $data['meta']['grid'] : 'squeezy';

	if ( $wkgrid_flag ) {
		$fragment  = '</div>';
		if ( $data['items'] ) {
			foreach ( $data['items'] as $item ) {
				
				$img = wk_get_img_html( @$item['image'] );

				$image = ( ! empty( $item['image'] ) ) ? '<div class="jumbotron-image">' . $img . '</div>' : false;

				$alter = ( ! empty( $image ) ) ? 'jumbotron-alter' : false;
				$fragment .= '<div class="wk-incontent-jumbotron wk-component ' . $alter . $pallete_class . '" _grid="' . esc_attr( $wk_meta_grid ) . '" _bgcolor ="' . esc_attr( $wk_meta_bg ) . '">
				<div class="wkgrid-' . esc_attr( $wk_meta_grid ) . '">
				<div class="jumbotron-wrap">' . $image . '
				<div class="jumbotron-content">
				<h2 class="title">' . $item['label'] . '</h2>
				<p class="larger">' . $item['description'] . '</p>
				<a href="' . $item['url'] . '" class="wk-button btn-dark"> ' . $item['btn_label'] . '</a>
				</div></div></div>
				</div>';
			}
		}
		$fragment .= '<div class="wkgrid-squeezy">';

	} else {
		$fragment = '';
		if ( $data['items'] ) {
			foreach ( $data['items'] as $item ) {
				$fragment .= '<div class="wk-incontent-jumbotron' . $pallete_class . '">
				<div class="jumbotron-content">
				<h2>' . $item['label'] . '</h2>
				<p class="larger">' . $item['description'] . '</p>
				<a href="' . $item['url'] . '" class="wk-button btn-dark"> ' . $item['btn_label'] . '</a>
				</div>
				</div>';
			}
		}
	}

	return $fragment;
}

/* //Shortcodes Callbacks */

registerBlockType( 'wk-blocks/caption-icons', {
    title : 'Caption Icons',
    icon : 'admin-page',
    category: 'webkul',
    keywords: [
        'Caption Icons',
    ],
    parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    example: {},

    attributes: {
        content: {
            type:'array',
            source: 'children',
            selector: '.wk-caption-info',
        },
        title: {
            type:'array',
            source: 'children',
            selector: '.wk-caption-title',
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgURL: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
		},

    },
    edit : function( props ) {
        var content = props.attributes.content,
        title = props.attributes.title,
        imgURL = props.attributes.imgURL,
        imgALT = props.attributes.imgALT,
        imgID = props.attributes.imgID;

        const onChangeTitle = ( newTitle ) => {
            props.setAttributes( { title: newTitle } );
        }
        const onChangeContent = ( newContent ) => {
            props.setAttributes( { content: newContent } );
        }
        const onRemoveImage = () => {
			props.setAttributes( {
				imgURL: null,
                imgID: null,
                imgALT:null,
			} );
        };
        return (
            el(
                'div',
                
                {
                    className:'brick text-center',
                },
                el(
                    'div',
                    {
                        className:'wk-image-uploader'
                    },
                    el(
                        MediaUpload,
                        {
                            buttonProps: {
                                className: 'change-image'
                            },
                            onSelect: img => props.setAttributes({
                                imgID: img.id,
                                imgURL: img.url,
                                imgALT:img.alt ? img.alt : img.title 
                            }),
                            allowed: ALLOWED_MEDIA_TYPES,
                            type: "image",
                            value: imgID,
                            render: ({ open }) => el(
                                Fragment,
                                null,
                                el(
                                    Button,
                                    {
                                        className: imgURL ? 'wk-change-image' : 'wk-add-image',
                                        onClick: open
                                    },
                                    ! imgURL ? wkUploadIcon : el( "img",
                                        {
                                            src: imgURL,
                                            alt: imgALT
                                        }
                                    )
                                ),
                                imgURL && el(
                                    Button,
                                    {
                                        className: "wk-remove-image",
                                        onClick: onRemoveImage
                                    },
                                    el(
                                        Dashicon,
                                        {
                                            icon: 'dismiss'
                                        }
                                    )
                                )
                            )
                        }
                    )

                ),
                
                el(
                    RichText,
                    {
                        key: 'editable',
                        tagName: 'p',
                        value: title,
                        className:'wk-caption-title',
                        onChange: onChangeTitle,
                        placeholder:'Caption Title',
                    },
                    
                ),
                el(
                    RichText,
                    {
                        key: 'editable',
                        tagName: 'div',
                        className:'wk-caption-info',
                        onChange: onChangeContent,
                        value: content,
                        placeholder:'Caption Description',
                    }
                )
            )
            // el(
            //     Fragment,
            //     null,
                
            // )
        );
    },
	save: function (props) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className: 'brick',
                },
                el(
                    'img',
                    {
                        src:props.attributes.imgURL,
                        alt:props.attributes.imgALT,
                        className:'caption-img'
                    }
                ),
                el(
                    'p',
                    {
                        className:'wk-caption-title'
                    },
                    props.attributes.title
                ),
                el(
                    'div',
                    {className:'caption wk-caption-info'},
                    props.attributes.content
                )
            )
        )
    }
} );
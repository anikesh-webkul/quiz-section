/**
 * wk-caption-title Tag h5 deprecated, we are using p tag instead of that
 */

wp.hooks.addFilter( 'blocks.registerBlockType', 'wk-blocks/deprecated/caption-icons', function(settings, name) {
    if ( name !== 'wk-blocks/caption-icons' ) {
        return settings;
    }
    
    settings.deprecated = [
        {
            attributes: settings.attributes,
 
            save: function( props ) {
                console.log(props)
                return el(
                    Fragment,
                    {},
                    el(
                        'div',
                        {
                            className:'brick tier',
                        },
                        el(
                            'img',
                            {
                                src:props.attributes.imgURL,
                                alt:props.attributes.imgALT,
                            }
                        ),
                        el(
                            'h5',
                            {
                                className:'wk-caption-title'
                            },
                            props.attributes.title
                        ),
                        el(
                            'div',
                            {className:'caption wk-caption-info'},
                            props.attributes.content
                        )
                    )
                );
            },
        }
    ]

    return settings;

} );
<?php
/**
*The template for displaying All Pages
*
*@package webkul
*@subpackage webkul theme 2K18
*@since webkul theme 2.0
*/

get_header();

$page_id     = get_the_id();
$layout      = get_post_meta( $page_id, 'wk_page_layout_view', true );
$grid_class  = ( 'wide' === $layout ) ? 'wkgrid-wide' : 'wkgrid-squeezy';
$has_bg_col  = ( 'wide' === $layout ) ? 'section-padding has-bgcol' : 'section-padding-0B';
$tagline     = get_post_meta( $page_id, 'wk_banner_tagline', true );
$feat_img    = get_the_post_thumbnail_url( $page_id, 'full' );
$has_infobox = get_post_meta( $page_id, 'wk_infobox_visible', true );
$has_header  = get_post_meta( $page_id, 'wk_page_has_header', true );

$opt_btn_attrs = maybe_unserialize( get_post_meta( $page_id, 'wk_opt_btn_attr', true ) );
?>

<?php
if ( '1' === $has_header ) {

	$layout      = get_post_meta( $page_id, 'wk_page_layout_view', true );
	$grid_class  = ( 'wide' === $layout ) ? 'wkgrid-wide' : 'wkgrid-squeezy';
	$has_bg_col  = ( 'wide' === $layout ) ? 'section-padding has-bgcol' : 'section-padding-0B';
	$tagline     = get_post_meta( $page_id, 'wk_banner_tagline', true );
	$feat_img    = get_the_post_thumbnail_url( $page_id, 'full' );
	?>

	<section class="wk-page-header <?php echo esc_attr( $has_bg_col ); ?> dir-rtl">
		<div class="<?php echo esc_attr( $grid_class ); ?>">
			<div class="page-banner">
				<img src="<?php echo esc_url( $feat_img ); ?>" />
			</div>
			<div class="page-tagline">
				<h1><?php echo $tagline; ?></h1>
				<?php
				if ( isset( $opt_btn_attrs['enable'] ) && '1' === $opt_btn_attrs['enable'] && ! empty( $opt_btn_attrs['link'] ) && ! empty( $opt_btn_attrs['label'] ) ) {

					$_link   = ( ! empty( $opt_btn_attrs['link'] ) ) ? $opt_btn_attrs['link'] : '';
					$_label  = ( ! empty( $opt_btn_attrs['label'] ) ) ? $opt_btn_attrs['label'] : '';
					$_rel    = ( ! empty( $opt_btn_attrs['rel'] ) ) ? ' rel=' . $opt_btn_attrs['rel'] : '';
					$_target = ( ! empty( $opt_btn_attrs['target'] ) ) ? ' target=_blank' : '';
					$_color  = ( ! empty( $opt_btn_attrs['color'] ) && 'prime' === $opt_btn_attrs['color'] ) ? 'wk-button' : 'wk-button ' . $opt_btn_attrs['color'];

					echo '<a class="' . esc_attr( $_color ) . '" href="' . esc_url( $_link ) . '"' . esc_attr( $_target . $_rel ) . '>' . esc_attr( $_label ) . '</a>';
				}
				?>
			</div>
			<?php echo ( 'wide' === $layout ) ? '' : '<hr/>'; ?>
		</div>
	</section>
	<?php
}

$head_img = get_template_directory_uri() . '/images/akeneo/headimg.png';
$content  = '<h1>Akeneo PIM Integration</h1><p>Akeneo centralizes your products in one place where you can easily manage, enrich your products and then distribute to various channels.</p>';
$videoimg = get_template_directory_uri() . '/images/akeneo/videobanner.png';
$videourl = 'https://cdn.uvdesk.com/uvdesk/bundles/webkuldefault/videos/akeneo-connector.mp4';
do_action('wk_altered_header', $head_img, $content, $videoimg, $videourl );

?>

<section class="wk-page-content section-padding">
	<div class="">
		<?php
		while ( have_posts() ) {
			the_post();

			the_content();
		}
		?>
	</div>
</section>

<?php
get_footer();

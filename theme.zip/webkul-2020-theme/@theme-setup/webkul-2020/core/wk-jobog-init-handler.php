<?php
/* CORE SNIPPET --- To check Image-Generator URL*/
add_action( 'init', function() {

	$uri       = $_SERVER['REQUEST_URI'];
	$uri_array = explode( '/', $uri );

	if ( in_array( 'jobs-ogimage', $uri_array, true ) ) {

		if ( isset( $_GET['ogid'] ) && ! empty( $_GET['ogid'] ) ) {
			wkjobsog_init_handler();
			exit;
			
		}
	}
});


function wkjobsog_init_handler() {
	//Require Image Gen Class
	require_once WKTHEME_CORE . 'class-wk-jobs-ogimage-generator.php';


	global $wpdb;
	$table_name = $wpdb->prefix . 'open_positions';

    $id = rawurldecode( strip_tags( wp_unslash( intval( base64_decode( $_GET['ogid'] ) ) ) ) );
    
	$data = $wpdb->get_results( "SELECT `position_name`, `seo` FROM $table_name WHERE id = '$id'", ARRAY_A );
	$data = isset( $data[0] ) ? $data[0] : array();

	$file = '';
	$seo  = isset( $data['seo'] ) ? maybe_unserialize( $data['seo'] ) : false;

    
	$string = isset( $seo['ogimg_template_name'] ) && ! empty( $seo['ogimg_template_name'] ) ? esc_html( $seo['ogimg_template_name'] ) : ( isset( $data['position_name'] ) ? $data['position_name'] : false );

	if( isset( $seo['og_image'] ) && ! empty( $seo['og_image'] ) ) {
		$dir = wp_upload_dir();
		$file = explode( $dir['baseurl'], $seo['og_image'] )[1];
		$file = $dir['basedir'] . $file;
	}


	new WK_Jobs_Ogimage_Generator( $string, $file );
}
/* //CORE SNIPPET --- To check Image-Generator URL*/

/* Super Initiator */
add_action( 'wp', function() {
	if( ! is_admin() && 'jobs' === get_query_var( 'pagename' ) && ! empty( get_query_var( 'job' ) ) ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'open_positions';

		$slug = get_query_var( 'job' );

		$data = $wpdb->get_results( "SELECT `id`, `position_name`, `seo`, `slug` FROM $table_name", ARRAY_A );

		$job = array_filter( $data, function( $dt ) use( $slug ) {
			return ( $slug == $dt['slug'] || $slug == get_jobpost_slug_from_name( $dt['position_name'] ) );
        } );

        $id  = ( ! empty( $job ) ) ? array_column( $job, 'id' )[0] : false;
		$seo = ( ! empty( $job ) ) ? maybe_unserialize( array_column( $job, 'seo' )[0] ) : false;

		if( ! isset( $seo['ogimg_template'] ) ) {
			return;
		}
		if( 'true' != $seo['ogimg_template'] ) {
			return;
		}
	
		// CHECKING IF YOAST IS NEARBY
		if ( defined( 'WPSEO_VERSION' ) ) {
	
			add_filter( 'wpseo_opengraph_image', function( $url_by_yoast ) use( $id ) {
	
				$og_url = esc_url( site_url() . '/jobs-ogimage/?ogid=' . rawurlencode( base64_encode( $id ) ) );
	
				return esc_url( $og_url ); //Return final OG URL
	
			}, 100);
	
			add_filter( 'wpseo_twitter_image', function( $url ) use( $id ) {
	
				$og_url = esc_url( site_url() . '/jobs-ogimage/?ogid=' . rawurlencode( base64_encode( $id ) ) );
	
				return esc_url( $og_url ); //Return final OG URL
			}, 100);
	
		}

	}

});
/* //Super Initiator */
<?php
get_header();
$mk_page_id = get_the_ID();


if( get_query_var( 'paged' ) ) {
    $paged =  get_query_var( 'paged' );
} else if ( get_query_var( 'page' ) ) {
    $paged =  get_query_var( 'page' );
} else {
    $paged=1;
 }

$search_value = ! empty( $_GET['add'] ) ? $_GET['add'] : '';

$query = new WP_Query( array(
    'post_type'      => 'add-ons',
    'posts_per_page' => 12, 
    'post_status'    => 'publish',
    'orderby'        => 'ID',
    'order'          => 'DESC', 
    's'              => $search_value,
    'paged'          => $paged 
    )
);
?>


<div class="our-partner-header">
        <div class="container text-center">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <h1>Add-Ons</h1>
                <p>Enhance your hotel booking website with QloApps add-ons. Each add-on will bring new functionality to your hotel booking website. So customize your website with them for a better hotel business.</p>
            </div>
            <div class="col-md-1"></div>
        </div>
</div>


<div class="hr_back_division">
    <div class="wkgrid-wide">

        <div class="hr_select_data">
        <form action="<?php echo esc_url( home_url( '/addons' ) ); ?>"  id="advanced-searchform" role="search" method="get">
                    <div class="search-bar">
                        <div class="qlo_addons_search_result">
                                <?php if(isset($_GET['add'])) { ?>                        
                            <p class='sub-heading'><strong><?php echo $query->found_posts; ?></strong><?php echo __(" Results found by your keyword", "hotel-reservation"); ?> "<strong><?php echo $search_value;  ?></strong>"</p>
                                <?php } ?>        
                        </div>
                        <div class="qlo_addons_search_result search-wrap" >                        
                            <input type="text" class="search-string" placeholder="<?php esc_html_e( 'Search' ) ?>" value="<?php echo get_search_query(); ?>" name="add" required />
                            <button type="submit" class="search-btn" value="submit"><i class="glyphicon glyphicon-search wk-search-btn" name="submit_btn_addons"></i></button>
                        </div>
                        <?php if( $query->found_posts == 0 ) { ?>
                            <div class="no-addons-found">"NO ADDONS FOUNDS"</div>
                            <?php } ?> 
                        </div>
                    </form>
                    <?php if ( $query->have_posts() ) { ?>
        </div>
    <div class="hr_select_data">

            <div class="qlo_addons_show">
        <?php while ( $query->have_posts() ) : $query->the_post();
            $addons__id = get_the_ID();
            $addons_field_value = get_post_meta($addons__id, "qlo_addons_extra_options", true);
        ?>
            <div class="qlo_addons_single_div">
                <div class="qlo_addons_feat_img">
                    <a href="<?php echo esc_url( $addons_field_value['qlo-buy-btn-link'] ); ?>" target="_blank" rel="noopener noreferrer">
                        <?php echo the_post_thumbnail( array(102, 102) ) ?>
                    </a>
                </div>
                
                
                <a href="<?php echo esc_url( $addons_field_value['qlo-buy-btn-link'] ); ?>" target="_blank" rel="noopener noreferrer">
                    <h4 class="qlo_addons_name_font"><?php the_title();?></h4>
                </a>


                <p class="qlo_addons_content_font"><?php echo has_excerpt( get_the_ID() ) ? esc_html( get_the_excerpt( get_the_ID() ) ) : esc_html( _wk_trim_post_content( get_the_ID(), 240, false ) ); ?></p>
                <div class="qlo_addons_prize_font">
                    <?php
                    $price = sprintf( '%0.2f', $addons_field_value['qlo-addons-prize'] );

                    if( 0.00 != $price ) {
                        echo "$ " . $price;
                    } else {
                        echo 'Free';
                    }
                     ?>
                </div>
                <a href="<?php echo esc_url( $addons_field_value['qlo-buy-btn-link'] ); ?>" target="_blank" rel="noopener noreferrer" class="qlo_addons_buy_btn">
                    <?php
                    if ( ! $addons_field_value['qlo-addons-prize'] == "" ) {
                        echo "BUY NOW";
                    } else { 
                        echo "Get ADD-ON";
                    }
                    ?>
                </a>
                </div>

        <?php endwhile; wp_reset_postdata(); ?>
    </div>

                <div class="qlo-addons-pagination-here">
                    <?php
                    //  hotelreservation_pagination($query->found_posts);
                    $qlo_count_total_addons = get_posts(
                        array(
                            'post_type'   =>  'add-ons',
                            'post_status' =>  'publish',
                        ));
                            $total_items = count($qlo_count_total_addons) + 1;
                            $prev_arrow = '&#8592;&nbsp;Previous &ensp;&ensp;&ensp;&ensp;';
                            $next_arrow = 'Next&nbsp;&#8594;';

                    		global $wp_query;

                    		if( $total_items > 0 ) {
                    			$total = $total_items/4;
                    		}
                    		else {
                    			$total = $query->max_num_pages;
                    		}
                        
                            $big = 9999999999999; // need an unlikely integer
                    		if( $total > 1 ) {
                    		  if( !$current_page = get_query_var('paged') )
                    			  $current_page = 1;
                    		  if( get_option('permalink_structure') ) {
                    			   $format = 'page/%#%/';
                    		  } else {
                    			   $format = '&paged=%#%';
                    		  }
                    			echo paginate_links(array(
                    				'base'               => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                    				'format'             => $format,
                    				'current'            => max( 1, get_query_var('paged') ),
                    				'total'              => ceil($total),
                    				'mid_size'           => 3,
                                    'after_page_number' => "&ensp;&ensp;&ensp;",
                                    'total'              => $query->max_num_pages,
                    				'prev_text'          => $prev_arrow,
                                    'next_text'          => $next_arrow,
                    			 ) );
                            }
                    ?>
                </div>
                <?php } ?>
    </div>
</div>
</div>
<?php get_footer(); ?>
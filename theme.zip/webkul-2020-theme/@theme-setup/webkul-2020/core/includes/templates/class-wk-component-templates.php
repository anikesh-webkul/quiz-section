<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Wk_Component_Templates' ) ) {

	class Wk_Component_Templates {

		public function __construct() {

			$this->$components = json_decode( get_option( 'wk_registered_components' ) );

		}

		public function get_template( $for ) {

			switch ( $for ) {

				case 'carousels':
					return '<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span><div class="wk-element-block">
					<div class="wk-review-carousel">
						<p><b>Review For ?</b></p>
						<input type="text" class="link-label" data-name="linkLabel" placeholder="Name of Product/Service" value="{{linkLabel}}"/>
						<input type="text" class="link-url" data-name="linkUrl" placeholder="Link" value="{{linkUrl}}"/>
						<div>
							<wk-i-upload size="small">
								<img class="thumb" src="{{iconUrl#esc_type=src}}" />
								<input type="hidden" class="thumb-url" data-type="img" value="{{iconUrl#esc_type=src}}" data-name="iconUrl" />
							</wk-i-upload>
							<textarea class="bubble review" data-name="review" placeholder="Review">{{review}}</textarea>
						</div>
						<table class="form-body">
							<tbody>
								<tr>
									<th>Name</th>
									<td><input type="text" class="name" data-name="name" value="{{name}}" placeholder="Name of the client"/></td>
								</tr>
								<tr>
									<th>Work details</th>
									<td><input type="text" class="work" data-name="work" value="{{work}}" placeholder="Work details"/></td>
								</tr>
								<tr>
									<th>Location</th>
									<td><input type="text" class="location" data-name="location" value="{{location}}" placeholder="Location"/></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>';

				case 'fancy-links':
					return '<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span><div class="wk-element-block">
								<div class>
									<wk-i-upload size="small">
										<img class="thumb" src="{{icon#esc_type=src}}"/>
										<input type="hidden" class="thumb-url" data-type="img" data-name="icon" value="{{icon#esc_type=src}}"/>
									</wk-i-upload>
									<label class="description"><p class="description">Link Brick Label (Not more than 2 lines )</p>
									<textarea class="link-label" data-name="label" placeholder="Link label...">{{label}}</textarea>
									</label>
								</div>
								<div>
									<label class="description"><p class="description">Link Brick URL</p>
										<input class="link-url" data-name="url" type="text" value="{{url}}" placeholder="Link source..." />
									</label>
								</div>
							</div>';

				case 'caption-icons':
					return '<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
									<div class="wk-element-block">
										<wk-i-upload size="full">
											<img class="thumb" src="{{icon#esc_type=src}}" />
											<input type="hidden" name="icon" data-name="icon" data-type="img" class="thumb-url" value="{{icon#esc_type=src}}" />
										</wk-i-upload>
										<div style="width:285px;">
											<input type="text" name="title" data-name="title" value="{{title}}" placeholder="Title...">
											<input type="text" name="caption" data-name="caption" value="{{caption}}" placeholder="Caption...">
										</div>
									</div>';

				case 'link-component' :
					return '<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
									<div class="wk-element-block">
										<div>
											<label class="description">
												<p class="description">Link Brick Label (Not more than 2 lines )</p>
												<textarea class="link-label" data-name="label" placeholder="Link label...">{{label}}</textarea>
											</label>
										</div>
										<div>
											<label class="description">
												<p class="description">Link Brick URL</p>
												<input class="link-url" data-name="url" type="text" value="{{url}}" placeholder="Link source...">
											</label>
										</div>
									</div>';

				case 'jumbotron':
					return '<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span><div class="wk-element-block">
										<div>
										<label><p class="description">Jumbotron Image (Image have different layout)</p>
										<wk-i-upload size="full">
											<img class="thumb" src="{{image#esc_type=src}}" />
											<input type="hidden" name="image" data-name="image" data-type="img" class="thumb-url" value="{{image#esc_type=src}}" />
										</wk-i-upload>
											<br />
											<label><p class="description">Jumbotron Title (Not more than 2 lines )</p>
												<input type="text" data-name="label" placeholder="Cover Title.." value="{{label}}">
											</label>
										</div>
										<div>
											<br />
											<label><p class="description">Description</p>
												<textarea class="cover-description" data-name="description" placeholder="Cover description...">{{description}}</textarea>
											</label>
										</div>
										<div>
											<br />
											<label>
												<p class="description">Jumbotron section Button</p>
												<input class="btn-label" type="text" data-name="btn_label" value="{{btn_label}}" placeholder="Button Label...">
											</label>
										</div>
										<div>
											<br />
											<label>
												<p class="description">Jumbotron section Redirect URL</p>
												<input data-name="url" class="link-url" type="text" value="{{url}}" placeholder="Link source...">
											</label>
										</div>
									</div>';

				case 'image-gallery':
					return '<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span><div class="wk-element-block">
										<wk-i-upload size="full">
											<img class="thumb" src="{{icon#esc_type=src}}" />
											<input type="hidden" name="icon" data-name="icon" data-type="img" class="thumb-url" value="{{icon#esc_type=src}}" />
										</wk-i-upload>
										<div>
											<input type="text" name="link" data-name="link" value="{{link}}" placeholder="Link ....">
										</div>
									</div>';
				case 'section-component':
					return '
					<span title="Rich Text / HTML Editor" class="wk-rich-editor-toggle" tabindex="0" data-editor="code">Visual Editor</span>
					<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
					<div class="wk-editor-wrap">
						<div class="wk-editor">
							<textarea rich-editor="true" class="" data-name="content">{{content}}</textarea>
						</div>
						<div class="wk-editor">
							<textarea rich-editor="true" class="" data-name="contenttwo">{{contenttwo}}</textarea>
						</div>
					</div><br />';

				case 'success-story':
					return '<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span><div class="wk-element-block">
						<div class>
							<wk-i-upload size="full">
								<img class="thumb" src="{{icon#esc_type=src}}"/>
								<input type="hidden" class="thumb-url" data-type="img" data-name="icon" value="{{icon#esc_type=src}}"/>
							</wk-i-upload>
						</div><br>
						<div>
							<label class="description"><p class="description">Title</p>
								<input type="text" name="title" data-name="title" value="{{title}}" placeholder="Title">
							</label>
						</div>
						<div>
							<label class="description"><p class="description">About</p>
								<textarea class="link-label" data-name="about" placeholder="About...">{{about}}</textarea>
							</label>
						</div>
						<div>
							<label class="description"><p class="description">URL</p>
								<input class="link-url" data-name="url" type="text" value="{{url}}" placeholder="URL..." />
							</label>
						</div>
					</div>';

				default:
					break;
			}
		}
	}
}

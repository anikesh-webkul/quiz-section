<?php

add_filter( 'wpseo_title', function( $title ) {
	global $wkseo_meetup;
	$wkseo_meetup['title'] = $title;
	return $title;
});

add_filter( 'wpseo_metadesc', function( $desc ) {
	global $wkseo_meetup;
	$wkseo_meetup['description'] = $desc;
	return $desc;
}, 100, 1);
add_filter( 'wpseo_opengraph_desc', function( $desc ) {
    global $wkseo_meetup;
    if( empty( $wkseo_meetup['description'] ) ) {
        $wkseo_meetup['description'] = $desc;
    }
	return $desc;
}, 100, 1);
add_filter( 'wpseo_opengraph_image', function( $img )  {
    global $wkseo_meetup;
	$wkseo_meetup['image'] = $img;
	return $img;
});


get_header();

date_default_timezone_set( 'Asia/kolkata' );
$meetup_id = get_the_ID();

$evt_page_data = ! empty( $evt_page_data = get_post_meta( $meetup_id, '__wk_meetup_page_data_', true  ) ) ? $evt_page_data : array();

$evt_data = ! empty( $evt_data = get_post_meta( $meetup_id, '__wk_meetup_data_', true  ) ) ? $evt_data : array();

$meetup_expire = ( date('Ymd', strtotime( $evt_data['start-date'] ) ) >  date('Ymd') );

$meetup_date = ! empty( $evt_data['start-date'] ) ? date( 'l, d F Y, h:i a', strtotime( $evt_data['start-date'] ) ) : false;

$d1 = date( 'D, d F, Y', strtotime( $evt_data['start-date'] ) );
$t1 = date( 'h:i a', strtotime( $evt_data['start-date'] ) );
$t2 = date( 'h:i a', strtotime( $evt_data['end-date'] ) );


$head      = ! empty( $evt_page_data['header'] ) ? $evt_page_data['header'] : array();
$spons     = ! empty( $evt_page_data['sponsors'] ) ? $evt_page_data['sponsors'] : array();
$speaks    = ! empty( $evt_page_data['speakers'] ) ? $evt_page_data['speakers'] : array();
$orgs      = ! empty( $evt_page_data['organizers'] ) ? $evt_page_data['organizers'] : array();
$suggn     = ! empty( $evt_page_data['suggestion'] ) ? $evt_page_data['suggestion'] : array();
$past_evt  = ! empty( $evt_page_data['past-event'] ) ? $evt_page_data['past-event'] : array();
$gallery   = ! empty( $evt_page_data['gallery'] ) ? $evt_page_data['gallery'] : array();
$highlight = ! empty( $evt_page_data['highlights'] ) ? $evt_page_data['highlights'] : array();
$images    = ! empty( $evt_page_data['images'] ) ? $evt_page_data['images'] : array();
$head_pos  = isset( $head['position'] ) ? $head['position'] : 'bottom';

$header_bgimg = ! empty( $head['image'] ) ? __wkimg_by_id( $head['image'], 'main' ) : false;
$header_bgcol = isset( $head['color'] ) ? $head['color'] : '#FFFFFF';


$head_style = ( $header_bgimg ) ? 'background-image:url(' . esc_url( $header_bgimg ) .')' : 'background-color:' . $header_bgcol;

$is_magento_meet = false;

if ( is_single( 'magento-meetup') ) {
	$meetup_expire = true;
	$is_magento_meet = true;
}
	// $meetup_expire = true;
?>


<section class="section-meetups-hero <?php echo ( ! $header_bgimg ) ? 'plain-header ' : false; echo 'header-' . $head_pos; ?>">
    <span class="heroes-bg wk-bg-lazify" data-src="<?php echo esc_url( $header_bgimg ); ?>" style="<?php echo $head_style; ?>"></span>
    <div class="wkgrid-wide">
        <div class="hero-wrapper">
            <div class="part-one">
                <div style="align-self:center">
                    <a href="<?php echo site_url( '/meetups/' ); ?>" class="back-link">All Meetups</a>
                </div>
                <div class="header-content">
                    <h1><?php echo ! empty( $head['title'] ) ? esc_html( $head['title'] ) : false; ?></h1>
                    <p><?php echo ! empty( $head['tagline'] ) ? esc_html( $head['tagline'] ) : false; ?></p>
                    <?php
                    if( ! empty( $meetup_date ) ) {
                        echo '<p class="meetup-date">' . $meetup_date . '</p>';
                    }
                    ?>
                    <div class="header-links-wrap">
                        <?php
                        if( ! empty( $head['booking-link'] ) ) {
                            ?>

                            <!-- <h5><?php echo ! empty( $head['booking-tagline'] ) ? esc_html( $head['booking-tagline'] ) : false; ?></h5> -->
                            <?php
                            if( $meetup_expire ) {
                                ?>
                                <a href="<?php echo ! empty( $head['booking-link'] ) ? esc_html( $head['booking-link'] ) : false; ?>" target="_blank" rel="noopener noreferrer" title="Grab Your Ticket Now !" class="meetup-btn meetup-reg"><?php echo ! empty( $head['booking-linklabel'] ) ? esc_html( $head['booking-linklabel'] ) : false; ?></a>
                                <?php
                            } else {
                                echo '<button type="button" class="meetup-btn meetup-reg closed">Past Event</button>';
                            }
                        }
                        if( isset( $images['link'] ) && ! empty( $images['link'] ) ) {
                            ?>
                            <a href="<?php echo esc_html( $images['link'] ); ?>" target="_blank" rel="noopener noreferrer" title="<?php echo $images['linklabel']; ?>" class="meetup-btn meetup-reg photos"><?php echo $images['linklabel']; ?></a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="part-two">
                <?php
                $featured_img = get_the_post_thumbnail_url( $meetup_id, 'large' );
                $wkseo_meetup[ 'image' ] = ! empty( $featured_img ) ? $featured_img : $wkseo_meetup[ 'image' ];
                ?>
                <img class="wk-lazify" data-src="<?php echo $featured_img; ?>" alt="Meetup Featured">
            </div>
        </div>
    </div>
</section>

<section class="section-meetup-speakers section-padding">
    <div class="wkgrid-wide grid-extended0">
        <div class="meetup-speaker-wrapper">
            
            <div class="speaker-part">
                <?php

                if( ! empty( $speaks['meta'] ) || ! empty( $speaks['registration']['link'] ) ) {
                    ?>
                    <h2>Speakers</h2>
                    <div class="speaker-wrap">
                        <?php
                        foreach( $speaks['meta'] as $speaker ) {
                            ?>
                            <div class="speaker">
                                <img class="wk-lazify" data-src="<?php echo ! empty( $speaker['image'] ) ? __wkimg_by_id( $speaker['image'], 'main' ) : false; ?>" <?php echo ! empty( $speaker['name'] ) ? 'alt="' . $speaker['name'] . '" title="' . $speaker['name'] . '"' : false; ?>>
                                    <div class="info">
                                        <h3><?php echo ! empty( $speaker['name'] ) ? $speaker['name'] : false; ?></h3>
                                        <h5><?php echo ! empty( $speaker['design'] ) ? $speaker['design'] : false; ?></h5>
                                        <div class="social-links">
                                            <?php
                                            foreach( $speaker['social'] as $key => $value ) {
                                                if( ! empty( $value ) ) {
                                                    echo '<a href="' . esc_url( $value ) . '" target="_blank" rel="noopener noreferrer" class="ssl-icon ' . esc_attr( $key ) . '"></a>';
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                            </div>
                            <?php
                        }
                        if( ! empty( $speaks['registration']['link'] ) && $meetup_expire ) {
                            ?>
                            <div class="register-speaker">
                                <div>
                                    <h3><?php echo ! empty( $speaks['registration']['title'] ) ? $speaks['registration']['title'] : false; ?></h3>
                                    <p><?php echo ! empty( $speaks['registration']['tagline'] ) ? $speaks['registration']['tagline'] : false; ?></p>
                                    <a href="<?php echo ! empty( $speaks['registration']['link'] ) ? esc_url( $speaks['registration']['link'] ) : false; ?>" class="meetup-btn" target="_blank" rel="noopener noreferrer"><?php echo ! empty( $speaks['registration']['linklabel'] ) ? esc_html( $speaks['registration']['linklabel'] ) : false; ?></a>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <?php
                }
                ?>
                <?php
                if( ! empty( $highlight['points'] ) ) {
                    ?>
                    <div class="highlight-points section-padding-0T">
                        <h2><?php echo $highlight['title']; ?></h2>
                        <ul>
                            <?php
                            foreach( $highlight['points'] as $ht ) {
                                echo '<li>' . esc_html( $ht ) . '</li>';
                            }
                            ?>
                        </ul>
                    </div>
                    <?php
                }
                ?>

                <div class="wk-page-content section-padding-0B">
                    <?php
                    while( have_posts() ) {
                        the_post();
                        the_content();
                    }
                    ?>
                </div>
            </div>

            
            <div class="organizer-part">
                <div class="organizer-wrap">
					<div>
						<h3>Date & Time</h3>
						<?php if( $is_magento_meet ) {
						?>
						<p class="coming-soon">Coming Soon...</p>
						<?php
						} else {
						?>
							<p><?php echo $d1; ?><br><?php echo $t1 . ' to ' . $t2; ?></p>
							<?php
								if( ! empty( $evt_data['location'] ) ) {
									$loc =  $evt_data['location']['street'] . ', ' . $evt_data['location']['city'] . ' ' . $evt_data['location']['state'] . '&nbsp;' . $evt_data['location']['pincode'] . '&nbsp;(' . $evt_data['location']['country'] . ')';
								} else {
									$loc = 'H-28 Sector 63, Noida, Uttar Pradesh 201301 (India)';
								}
								if( $meetup_expire ) {
									?>
									<a href='https://www.google.com/calendar/render?action=TEMPLATE&text=<?php echo ! empty( $head['title'] ) ? wp_kses_post( $head['title'] ) : false; ?>&dates=<?php echo date( 'Ymd\\THi00', strtotime( $evt_data['start-date'] ) ) ?>/<?php echo date( 'Ymd\\THi00', strtotime( $evt_data['end-date'] ) ) ?>&details=<?php echo ! empty( $head['tagline'] ) ? wp_kses_post( $head['tagline'] ) : false; ?>&location=<?php echo $loc; ?>&sf=true&output=xml' target="_blank" rel="noopener" class="wk-button open-form-btns">Add to Calendar</a>
									<?php
								}
								?>

						<?php
						}
					?>
					</div>
                    <div class="venue">
                        <h3>Venue</h3>
                        <p><b>Webkul Software</b><br>
                            <?php
                            if( ! empty( $evt_data['location'] ) ) {
                                echo $evt_data['location']['street'] . ', ' . $evt_data['location']['city'] . '<br>' . $evt_data['location']['state'] . '&nbsp;' . $evt_data['location']['pincode'] . '&nbsp;(' . $evt_data['location']['country'] . ')';
                            } else {
                                echo 'H-28 Sector 63, Noida,<br>Uttar Pradesh 201301 (India)';
                            }
                            ?>
                        </p>
                        <?php
                        if( ! empty( $evt_data['location']['map'] ) ) {
                            echo '<a href="' . $evt_data['location']['map'] . '" target="blank" rel="noopener noreferrer" class="venue-link">View on Map</a>';
                        }
                        ?>
                    </div>
                    <br>
                    <div>
                        <h3>Organizers</h3>
                        <div class="organizer-stack">
                            <?php
                            if( ! empty( $orgs ) ) {
                                foreach( $orgs as $org ) {
                                    if( ! empty( $org['image'] ) ) {
                                        echo '<div><img class="wk-lazify" data-src="' . __wkimg_by_id( $org['image'] ) . '" alt="' . $org['name'] . '">';
                                        echo '<p>' . $org['name'] . '</p></div>';

                                    }
                                }
                            }
                            ?>
                        </div>
    
                    </div>
                    <br>
                    <div>
                        <h3>Spread the word </h3>
                        <div class="meetup-social-links">
                            <?php
                            $hashtags = isset( $evt_data['social']['twitter'] ) ? $evt_data['social']['twitter'] : false;
                            ?>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode( get_the_permalink() ); ?>" target="_blank" rel="noopener noreferrer"><span class="mt-link facebook"></span></a>
                            <a href="https://twitter.com/share?url=<?php echo urlencode( get_the_permalink() ); ?>&text=<?php echo get_the_title() ?>&hashtags=<?php echo esc_html( $hashtags ); ?>" target="_blank" rel="noopener noreferrer"><span class="mt-link twitter"></span></a>
                            <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode(the_permalink()); ?>&amp;" target="_blank" rel="noopener noreferrer"><span class="mt-link linkedin"></span></a>
                            <?php
                            if( wp_is_mobile() ) {
                                ?>
                                <a href="whatsapp://send?text=<?php echo urlencode("Title:- " . get_the_title() . ",  Site Url:- " . get_permalink() );?>" target="_blank" rel="noopener noreferrer"><span class="mt-link whatsapp"></span></a>
                                <?php
                            }
                            ?>
                        </div>
                        <div class="copy-link">
                            <input type="text" disabled value="<?php echo get_the_permalink(); ?>">
                            <span>Copy</span>
                        </div>
                    </div>

                </div>
            </div>
            
        </div>
    </div>
</section>

<?php
if( ! empty( array_filter( $gallery ) ) && ! empty( $gallery['g1']['logo'] ) ) {
    ?>
    <section class="section-meetup-gallery">
        <div class="gallery-wrapper">
            <?php
            foreach( $gallery as $key => $value ) {
                echo '<div class="' . $key . '">
                        <img class="wk-lazify" data-src="' . __wkimg_by_id( $value['logo'], 'extra-large' ) . '" alt="' . $value['title'] . '" title="' . $value['title'] . '">
                    </div>';
            }
            ?>
        </div>
    </section>
    <?php
}


if( isset( $spons['meta'] ) && ! empty( array_filter( $spons['meta'] ) ) || isset( $spons['registration'] ) && ! empty( $spons['registration']['link'] )  ) {
    ?>
    <section class="section-meetup-sponsors section-padding">
        <div class="wkgrid-wide">
            <br>
            <h2>Sponsors</h2>
            <div class="sponsors-wrap">
                <?php
                if( isset( $spons['meta'] ) && ! empty( array_filter( $spons['meta'] ) ) ) {
                    foreach(  $spons['meta'] as $spon ) {
                        if( ! empty( $spon['logo'] ) ) {
                            echo '<a href="' . $spon['link'] . '" target="_blank" rel="noopenener noreferrer" title="">
                                    <img class="wk-lazify" data-src="' . __wkimg_by_id( $spon['logo'], 'medium' ) . '" alt="' . $spon['name'] . '" title="' . $spon['name'] . '">
                                </a>';
                        }
                    }
                }
                    ?>
            </div>
            <?php
            if( ! empty( $spons['registration']['link'] ) && ! empty( $spons['registration']['linklabel'] ) ) {
                $spon_reg_newtab = ( 'mailto' !== explode( ':', $spons['registration']['link'] )[0] ) ? 'target="_blank" rel="noopener noreferrer"' : false;

                echo '<a href="' . $spons['registration']['link'] . '" ' . $spon_reg_newtab . ' class="register-sponsor">
                        <p>' . $spons['registration']['linklabel'] . '&nbsp;
                        <span class="link"></span>
                        </p>
                    </a>';
            }
            ?>
            
        </div>
    </section>
    <?php
}

if( ! empty( array_filter( $past_evt['links'] ) ) ) {
    ?>
    <section class="section-past-events section-padding">
        <div class="wkgrid-wide">
            <div class="events-wrap">
                <div class="event-look">
                    <span class="paper-bg"></span>
                    <img class="wk-lazify" data-src="<?php echo ! empty( $past_evt['image'] ) ? __wkimg_by_id( $past_evt['image'], 'main' ) : false; ?>" alt="<?php echo ! empty( $past_evt['text'] ) ? $past_evt['text'] : false; ?>">
                </div>
                <div class="event-link">
                    <h2><?php echo ! empty( $past_evt['text'] ) ? $past_evt['text'] : false; ?></h2>
                    <p><?php echo ! empty( $past_evt['description'] ) ? $past_evt['description'] : false; ?></p>
                    <?php
                    foreach( $past_evt['links'] as $pe_links ) {
                        if( ! empty( $pe_links['link'] ) || ! empty( $pe_links['linklabel'] ) ) {
                            echo '<a href="' . $pe_links['link'] . '">' . $pe_links['linklabel'] . '</a>';
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>
    <?php
}

if( ! empty( $suggn['image'] ) ) {
    ?>
    <br><br>
    <section class="section-meetup-suggestion section-padding-0T">
        <div class="wkgrid-compact">
            <div class="suggestion-wrap">
                <div class="suggestion-link">
                    <h3>For any suggestion<br>drop us a line.</h3>
                    <p><?php echo ! empty( $suggn['text'] ) ? $suggn['text'] : false; ?></p>
                    <a href="<?php echo ! empty( $suggn['link'] ) ? $suggn['link'] : false; ?>" class="meetup-btn"><?php echo ! empty( $suggn['linklabel'] ) ? $suggn['linklabel'] : false; ?></a>
                </div>
                <div class="suggestion-look">
                    <img class="wk-lazify" data-src="<?php echo ! empty( $suggn['image'] ) ? __wkimg_by_id( $suggn['image'], 'main' ) : false; ?>" alt="<?php echo ! empty( $suggn['text'] ) ? $suggn['text'] : false; ?>">
                </div>
            </div>
        </div>
    </section>
    <?php
}

?>
<section class="wkgrid-wide">
	<div class="wk-jumbo-ad">
		<div class="wkgrid-squeezy">
			<h2>Check the other meetups at webkul for the developer, designer and merchants.</h2>
			<a href="https://webkul.com/meetups/" class="wk-button btn-white">View All Meetups</a>
		</div>
	</div>
</section>

<section class="meetup-apply-form-section" data-meetup="<?php echo get_the_title(); ?>">
	<div class="form-wrapper">
		<div class="form-head">
			<div class="form-container">
				<div class="back-link wkm-close-form">Back</div>
			</div>
		</div>
		<div class="form-body">
			<div class="form-container">
				<div class="form-group">
					<div id="wk-attendee-form" class="display-none">
						<h3>Become Attendee</h3>
						<?php
						// echo do_shortcode( '[contact-form-7 id="1909" title="Grow your business form"]' ); 
						echo do_shortcode( '[contact-form-7 id="23933" title="Meetup -  Become Attendee"]' ); 
						?>
					</div>
					<div id="wk-speaker-form" class="display-none">
						<h3>Become a Speaker</h3>
						<p>To offer the attendees of the Meetup a great agenda.We are again looking for an amazing line of speakers and interesting talks.</p>
						<?php
						// echo do_shortcode( '[contact-form-7 id="1919" title="Meetup-Become Speaker"]' ); 
						echo do_shortcode( '[contact-form-7 id="23931" title="Meetup - Become Speaker"]' );
						?>
					</div>				
				</div>

				<div class="form-response text-center display-none">
					<br>
					<img src="<?php echo get_template_directory_uri() . '/images/career/icon-success.jpg' ?>" alt="Submitted">
					<p>We appreciate your interest in joining us. We will be in touch.</p>
					<br>
					<span class="wk-button btn-dark wkm-close-form">Back</span>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
$evt_start_date = ! empty( $evt_data[ 'start-date' ] ) ? $evt_data[ 'start-date' ] : false;
$evt_end_date   = ! empty( $evt_data[ 'end-date' ] ) ? $evt_data[ 'end-date' ] : false;

add_action( 'webkul_footer', function() use( $evt_start_date, $evt_end_date, $evt_data ) {

	global $wkseo_meetup;
    ?>
    <script type="application/ld+json">
        {
            "@context": "http://schema.org",
            "@type": "Event",
            "name": "<?php echo $wkseo_meetup['title']; ?>",
            "url": "<?php echo get_the_permalink(); ?>",
            "description": "<?php echo $wkseo_meetup['description']; ?>",
            "startDate": "<?php echo $evt_start_date . ':00+05:30'; ?>",
            "endDate": "<?php echo $evt_end_date . ':00+05:30'; ?>",
            "location": {
                "@type": "Place",
                "name": "Webkul Software",
                "address": {
                    "@type": "PostalAddress",
                    "streetAddress": "<?php echo $evt_data['location']['street']; ?>",
                    "addressLocality": "<?php echo $evt_data['location']['city']; ?>",
                    "addressCountry": "<?php echo $evt_data['location']['country']; ?>"
                },
                "geo": {
                    "@type": "GeoCoordinates",
                    "latitude": <?php echo $evt_data['location']['lat']; ?>,
                    "longitude": <?php echo $evt_data['location']['lon']; ?>
                }
            },
            "image": "<?php echo $wkseo_meetup['image']; ?>",
            "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD",
                "validFrom": "<?php echo $evt_end_date . ':00+05:30'; ?>",
                "url": "<?php echo get_the_permalink(); ?>",
                "availability": "http://schema.org/InStock"
            },
            "performer": {
                "@type": "PerformingGroup",
                "name": "Webkul Software"
            },
            "organizer": {
                "@type": "Organization",
                "name": "Webkul Software",
                "url": "https://www.webkul.com/"
            }
        }
    </script>
    <?php

} );


get_footer();
?>
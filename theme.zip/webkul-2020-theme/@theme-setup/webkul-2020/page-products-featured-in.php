<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();

$page_id     = get_the_id();
$has_header  = get_post_meta( $page_id, 'wk_page_has_header', true );
$has_infobox = get_post_meta( $page_id, 'wk_infobox_visible', true );
$all_press   = get_option( 'wktheme-page-press' );
$all_press   = ( '' === $all_press ) ? array() : $all_press;
$path        = wp_upload_dir()['baseurl'];

$opt_btn_attrs = maybe_unserialize( get_post_meta( $page_id, 'wk_opt_btn_attr', true ) );
?>

<?php
if ( '1' === $has_header ) {

	$layout      = get_post_meta( $page_id, 'wk_page_layout_view', true );
	$grid_class  = ( 'wide' === $layout ) ? 'wkgrid-wide' : 'wkgrid-squeezy';
	$has_bg_col  = ( 'wide' === $layout ) ? 'section-padding has-bgcol' : 'section-padding-0B';
	$tagline     = get_post_meta( $page_id, 'wk_banner_tagline', true );
	$feat_img    = get_the_post_thumbnail_url( $page_id, 'full' );
	?>

	<section class="wk-page-header <?php echo esc_attr( $has_bg_col ); ?>">
		<div class="<?php echo esc_attr( $grid_class ); ?>">
			<div class="page-tagline">
				<h1><?php echo $tagline; ?></h1>
				<?php
				if ( isset( $opt_btn_attrs['enable'] ) && '1' === $opt_btn_attrs['enable'] && ! empty( $opt_btn_attrs['link'] ) && ! empty( $opt_btn_attrs['label'] ) ) {

					$_link   = ( ! empty( $opt_btn_attrs['link'] ) ) ? $opt_btn_attrs['link'] : '';
					$_label  = ( ! empty( $opt_btn_attrs['label'] ) ) ? $opt_btn_attrs['label'] : '';
					$_rel    = ( ! empty( $opt_btn_attrs['rel'] ) ) ? ' rel=' . $opt_btn_attrs['rel'] : '';
					$_target = ( ! empty( $opt_btn_attrs['target'] ) ) ? ' target=_blank' : '';
					$_color  = ( ! empty( $opt_btn_attrs['color'] ) && 'prime' === $opt_btn_attrs['color'] ) ? 'wk-button' : 'wk-button ' . $opt_btn_attrs['color'];

					echo '<a class="' . esc_attr( $_color ) . '" href="' . esc_url( $_link ) . '"' . esc_attr( $_target . $_rel ) . '>' . esc_attr( $_label ) . '</a>';
				}
				?>
			</div>
			<div class="page-banner">
				<img src="<?php echo esc_url( $feat_img ); ?>" />
			</div>
			<?php echo ( 'wide' === $layout ) ? '' : '<hr/>'; ?>
		</div>
	</section>
	<?php
}
?>

<section class="wk-page-content section-padding-0B">
	<div class="wkgrid-squeezy">
		<?php
		while ( have_posts() ) {
			the_post();

			the_content();
		}
	?>
	</div>
</section>

<section class="wk-featured-products-section section-padding-0T">
	<div class="wkgrid-wide text-center">

		<div class="project-content-box">
			<div class="header color-coolhue">
				<a href="https://webkul.github.io/coolhue/" target="_blank" rel="nofollow noopener"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/cool-hue.png' ); ?>"></a>
			</div>
			<div class="followers">
				<div class="follower-items">
					<a href="https://www.lifehacker.jp/2017/07/170702_coolhue.html" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/life-hacker.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="https://news.ycombinator.com/item?id=14580163" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/y-combinator.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="https://www.producthunt.com/posts/coolhue" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/product-hunt.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="http://coliss.com/articles/build-websites/operation/design/gradient-hue-and-swatches-coolhue.html" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/coliss.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="http://www.webdesignernews.com/comment/coolhue-coolest-gradient-hues-and-swatches" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/webdesigner-news.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="https://www.webdesignerdepot.com/2017/06/popular-design-news-of-the-week-june-19-2017-june-25-2017/" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/websdesigner-depot.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="https://speckyboy.com/weekly-news-for-designers-n-391/" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/speckyboy.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="https://freebiesbug.com/code-stuff/coolhue-css-color-gradients/" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/freebiesbug.png' ); ?>"> </a>
				</div>
			</div>
		</div>

		<div class="project-content-box">
			<div class="header color-csspin">
				<a href="https://webkul.github.io/csspin/" target="_blank" rel="nofollow noopener"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/css-pin.png' ); ?>"></a>
			</div>
			<div class="followers">
				<div class="follower-items">
					<a href="https://freebiesbug.com/code-stuff/csspin-10-css-spinners/" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/freebiesbug.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="http://coliss.com/articles/build-websites/operation/css/css-spinners-csspin.html" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/coliss.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="https://tutorialzine.com/2016/12/15-interesting-javascript-and-css-libraries-for-december-2016" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/tutorialzine.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="https://speckyboy.com/weekly-news-designers-n-362/" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/speckyboy.png' ); ?>"> </a>
				</div>
			</div>
		</div>

		<div class="project-content-box">
			<div class="header color-uvdesk">
				<a href="https://www.uvdesk.com/" target="_blank" rel="nofollow noopener"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/uvdesk.png' ); ?>">
				</a>
			</div>
			<div class="followers">
				<div class="follower-items">
					<a href="https://mixergy.com/interviews/webkul-with-vipin-sahu-2/" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/mixergy.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="https://www.techinasia.com/talk/lessons-educate-saas-app" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/techinasia.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="javascript:void(0)" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/symfony-logo.png' ); ?>"> </a>
				</div>
				<div class="follower-items">
					<a href="https://github.com/jashkenas/backbone/wiki/projects-and-companies-using-backbone#uvdesk--helpdesk-system" target="_blank" rel="nofollow noopener" rel="nofollow"><img class="project-image" src="<?php echo esc_url( get_template_directory_uri() . '/images/project-feature/backbone-js.png' ); ?>"> </a>
				</div>
			</div>
		</div>

		<?php
		if ( '1' === $has_infobox ) {

			$title      = get_post_meta( $page_id, 'wk_infobox_title', true );
			$content    = get_post_meta( $page_id, 'wk_infobox_content', true );
			$btn_label  = get_post_meta( $page_id, 'wk_infobox_btn_label', true );
			$btn_url    = get_post_meta( $page_id, 'wk_infobox_btn_url', true );
			?>
			<div class="wk-metainfo-box">
				<h2><?php echo esc_html( $title ); ?></h2>
				<p><?php echo wpautop( $content ); /* Do not ESC/strip this value; */?></p>
				<?php
				if ( '' !== $btn_label && '' !== $btn_url ) {
					echo '<a href="' . esc_url( $btn_url ) . '" class="wk-button">' . esc_html( $btn_label ) . '</a>';
				}
				?>
			</div>
			<?php
		}
		?>

	</div>
</section>


<?php
get_footer();

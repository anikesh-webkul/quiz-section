<?php
?>

<section id="contact-modal" modal="off">
	<div class="contact-modal-inner">
		<span id="modal-close"></span>
		<div class="contact-modal-info">
			<div class="wk-saying-block wk-quote">
				<div class="p-x3">Webkul developed customisation on Hyperlocal Marketplace for my website; completed in a timely manner.</div><br>
				<div class="p-x3">Good honest and diligent work ethic.</div>
				<div class="card">
					<?php echo wk_webp( 'orphan/stephen-wilson.png' );?>
					<div class="name">Stephen Wilson</div>
					<div class="p-x4">Head of Design & Conversion Clicksco</div>
				</div>
			</div>
			<div class="talk-to-sales">
				<span class="h5">Talk to Sales</span>
				<div class="item">
					<p class="icon usa p-x3">USA</p>
					<a href="tel:+19143531684">+1 914 353 1684</a>
				</div>
				<div class="item">
					<p class="icon ind p-x3">India</p>
					<a href="tel:+919870284067">+91 987 028 4067</a>
				</div>
				<div class="item">
					<p class="icon skype p-x3">Global</p>
					<a href="https://bit.ly/hello-webkul" target="_blank" rel="noopener" class="p-x3">Say Hello! on Skype</a>
				</div>
			</div>
		</div>
		<div class="contact-modal-form" view="form">
			<div class="contact-modal-form-inner">
				<p class="h4">Start a Project</p>
				<?php
					// Live Form
					echo do_shortcode( '[contact-form-7 id="21701" title="Contact Modal Popup"]' );

					//Local form
					// echo do_shortcode( '[contact-form-7 id="1304" title="Contact form 1"]' );

				?>
			</div>
			<div class="contact-modal-success">
				<img src="<?php echo img_dir( 'orphan/icon-success.svg' ); ?>" />
				<p class="h4">Message Sent!</p>
				<p class="p-x3">If you have more details or questions, you can reply to the received confirmation email.</p>
				<a href="<?php echo home_url(); ?>" class="wk-button btn-ghost">Back to Home</a>
			</div>
		</div>
	</div>
</section>
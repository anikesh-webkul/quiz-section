<!DOCTYPE html>
<html>
<head>
<title>Create Your Form</title>
<style>
.container{
    width:50%;
    border: 2px solid green;
    margin-right:auto;
    margin-left:auto;
    font-size:1.7vw;
}
#link{
    width:10%;
    margin-right:auto;
    margin-left:auto;
    font-size:15px;
}

#btn{
    width:20%;
    margin-right:auto;
    margin-left:auto;
    border:2px orange solid;
    height:50px;
    font-size:1.2vw;

}
#block2{
    display:none;
}
</style>
</head>
<body>


       
        <form action="" method="post">

        
        
        @foreach($data as $d)
        <div class="container">
        <h3> {{$d->q_name}}</h3><br>
           
            <input type="radio" name="choice" value="{{$d->opt1}}" required> <label for="opt1">{{$d->opt1}}</label><br>
            <input type="radio" name="choice" value="{{$d->opt2}}" required> <label for="opt2">{{$d->opt2}}</label><br>
            <input type="radio" name="choice" value="{{$d->opt3}}" required> <label for="opt3">{{$d->opt3}}</label><br>
            <input type="radio" name="choice" value="{{$d->opt4}}" required> <label for="opt4">{{$d->opt4}}</label><br>
          
          
        </div>
        @endforeach
        <center>
            <button id="btn">Submit Answer</button>
       </center>
       
        </form>>


       
            
                 
      
        

       
</body>
</html>
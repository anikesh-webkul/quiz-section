<?php
/*
Plugin Name: Webkul Post Version
Plugin URI: https://webkul.com
Description: Add blog post versions.
Version: 1.0.0
Author Name: Webkul
Author URI: https://webkul.com
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/* // Adding Meta boxes*/

add_action( 'add_meta_boxes', 'wkp_post_version' );

function wkp_post_version() {

	add_meta_box( 'wkp_add_post_version', 'Blog Version', 'wkp_add_post_versions', 'post', 'side', 'high' );

}

/* // Adding Meta boxes*/

/* // Adding Script*/

add_action( 'wp_enqueue_scripts', 'wkp_load_script_file' );

function wkp_load_script_file() {
	if ( is_single() ) {
		wp_enqueue_script( 'wkp-admin', plugin_dir_url( __FILE__ ) . 'assets/js/wk_admin.js', array(), '1.0.1', true );
		wp_localize_script( 'wkp-admin', 'wkpPostvar', array(
			'url'   => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'wkp_nonce' ),
		));

		wp_enqueue_style( 'wkp-style', plugin_dir_url( __FILE__ ) . 'assets/css/style.css', '1.0.1' );
	}
}
add_action( 'admin_enqueue_scripts', 'wkp_load_script_file_backend' );

function wkp_load_script_file_backend() {
	wp_enqueue_script( 'wkp-version-backend', plugin_dir_url( __FILE__ ) . 'assets/js/wkp_backend.js', array(), '1.0.0', true );
	wp_localize_script( 'wkp-version-backend', 'wkpVersionVar', array(
		'url'   => admin_url( 'admin-ajax.php' ),
		'nonce' => wp_create_nonce( 'wkp_version_nonce' ),
	));
}

/* // Adding Script*/

/* // Post version callback function*/

function wkp_add_post_versions() {

	wp_nonce_field( 'post_box_nonce', 'wkp_box_nonce' );
	$id           = get_the_ID();
	$version      = get_post_meta( $id, 'wkp_version', true );
	$frameversion = get_post_meta( $id, 'wkp_frameversion', true );

	// if ( isset( $_GET['wkp_revision'] ) && ! empty( $_GET['wkp_revision'] ) && is_user_logged_in() ) {
	//
	// 	$revision_id = esc_attr( $_GET['wkp_revision'] );
	//
	// 	$meta_value  = get_post_meta( $id, 'wkp-post-version' );
	//
	// 	foreach( $meta_value[0] as $key => $value ) {
	//
	// 		if ( $key == $revision_id ) {
	// 		$frameversion = explode('---', $value)[0];
	// 		$version      = explode('---', $value)[1];
	// 		}
	// 	}
	//
	// }

	// var_dump(get_post_meta( get_the_ID(), 'wkp-final-post-version' ));
	// echo "<br><br>";
	// var_dump(get_post_meta( get_the_ID(), 'wkp-post-version' ));
	wp_nonce_field( 'post_revision_nonce', 'wkp_revision_track_nonce' );
	global $post;
	$final_version = '';
	// $meta_value = get_post_meta( get_the_ID(), 'wkp-final-post-version' );
	$revisions  = wp_get_post_revisions( get_the_ID() );
	foreach( $revisions as $prop ) {
		$revisions = $prop->ID;
		break;
	}
	$version_data = get_post_meta( get_the_ID(), 'wkp-post-version', true );
	if ( $version_data ) {
		foreach( $version_data as $key => $value ) {
		  if ( $key == $revisions ) {

			  // var_dump($version_data);
			$data          = $version_data[ $revisions ];
			$data          = explode( '---', $data );
			$version_name  = $data[1];

		  }
		}
	}

	  ?>
	<input type="hidden" name="wkp_post_id" id="wkp_post_id" value="<?php echo get_the_ID();?>">

	<label for="version">Version:-</label><br>
	<input type="text" id="wkp_version" name="wkp_version" placeholder="Blog Version" value="<?php echo $version; ?>" ><br>
	<span>Add blog version</span><br /><br />

	<label for="wkp_frameversion">Framework Version:-</label>
	<input type="text" id="wkp_frameversion" name="wkp_frameversion" placeholder="Framework Version" value="<?php echo $frameversion; ?>" ><br>
	<span>Add framework version</span><br /><br />

	<label for="wkp_final_version"> Default Version</label><br>
	<input type="text" id="wkp_version_name" class="version_name" name="wkp_version_name" value="<?php if(!empty($version_name))echo $version_name; ?>" width="100%" placeholder="Current Blog Version" disabled><br />

	<?php



	  $meta_value = get_post_meta( get_the_ID(), "wkp-post-version" );
	  // if ( ! empty( $meta_value ) ) {
		//   echo '<h2 style="font-weight: 600;padding:8px 0px;">All Versions</h2>';
		// foreach( $meta_value[0] as $key => $value ) {
		// 	$version_name = explode( '---', $value )[1];
		// 	echo '<label for = "' . esc_attr( $version_name ) . '" value="' . esc_attr( $key ) . '">Version ' . $version_name . '</label><br>';
		// }
	  //
	  // }

	  if ( ! empty( $meta_value ) ) {
		?>
		<br />
		<h2 style="font-weight: 600;padding:8px 0px;">Restore Version</h2>
		<span> Select a version to restore in current version </span><br /><br />
		<?php
		$res_framework = '';
		foreach( $meta_value[0] as $key => $value ) {
			@$res_framework = explode('---', $value)[0];
		  	@$version_name  = explode('---', $value)[1];

		  ?>
			<input type="radio" version = "<?php echo esc_attr( $version_name ); ?>" framework = '<?php echo esc_attr( $res_framework ); ?>' id="<?php echo "restore-".$version_name; ?>" name="wkp_restore" value="<?php echo $key; ?>" />
			<label for = "<?php echo "restore-".$version_name; ?>"><?php echo "Version " . $version_name; ?></label><br>

		  <?php
		}
		echo '<p><span style="display:none" class="wkp-restore-require required">Please select restore version</span></p>';

		echo '<p><input type="submit" id="wkp_restoration" class="button button-primary" value="Restore" name="wkp_restoration" /><span class="wkp-loader spinner"></span></p>';
	}

}

/* // Post version callback function*/

/* // Save Post versions*/

add_action( 'save_post', 'save_version_meta', 10, 3 );

function save_version_meta( $post_id, $post, $update ) {

	if ( ! isset( $_POST['wkp_box_nonce'] ) ) {
	  return $post_id;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		die;
		return $post->ID;
	}

	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $_POST['wkp_box_nonce'], 'post_box_nonce' ) ) {
	  return $post_id;
	}

	$post_frameversion  = $_REQUEST['wkp_frameversion'];
	$version            = $_REQUEST['wkp_version'];
	$post_id            = $_REQUEST['wkp_post_id'];
	$revisions          = wp_get_post_revisions( $post_id );
	$check              = 0;

	foreach( $revisions as $revision ) {
	  $revisions = $revision->ID;
	  break;
	}

	// $finalversion  = ( isset( $_POST['wkp_final_version'] ) ) ? $_POST['wkp_final_version'] : '';
	$meta_value = get_post_meta( $post_id, 'wkp-post-version' );

	if ( ! empty( $version && ! isset( $_REQUEST['wkp_restoration'] ) ) ) {

		  if ( ! isset( $meta_value[0] ) ) {
			$data = array();
		  } else {
			  $data = $meta_value[0];

			  foreach( $data as $key => $value ) {

				$version_data = explode( '---', $value );

				if ( $version == $version_data[1] ) {

				  unset( $data[ $key ] );
				  $data[ $revisions ] = $post_frameversion . "---" . $version . "---";
				  update_post_meta( $post_id, 'wkp-post-version', $data );
				  $check += 1;

				}
			  }
		  }

		  if ( $check == '0' ) {

			if( ! wkp_revision_checking() ) {

			  $data[$revisions] = $post_frameversion . "---" . $version . "---";
			  update_post_meta( $post_id, 'wkp-post-version', $data );
			}
			else {
			  unset( $data[ $revisions ] );
			  update_post_meta( $post_id, 'wkp-post-version', $data );
			}
		  }
	}

	update_post_meta( $post_id, 'wkp_version', $version );
	update_post_meta( $post_id, 'wkp_frameversion', $post_frameversion );

}

/* // Save Post versions*/

/* // Checking post revision */

function wkp_revision_checking() {

	$post_id   = get_the_ID();
	$revisions = wp_get_post_revisions( $post_id );
	$final_arr = array();

	foreach( $revisions as $revision ){
	  $revisions = $revision->ID;
	  break;
	}

	$meta_value = get_post_meta( $post_id, 'wkp-post-version' );

	if ( is_array ( $meta_value ) ) {

	  foreach ( $meta_value as $arr ) {
		  foreach ( $arr as $key => $value ) {
				$final_arr[] = $key;
		  }
	  }
	}

	if ( in_array($revisions, $final_arr) )
		return true;
	else
		return false;
}

/* // Checking post revision */



/* // Save post revisions checking */

// function wkp_revision_check(){
//   $post_id   = get_the_ID();
//   $revisions = wp_get_post_revisions( $post_id );
//
//   foreach($revisions as $prop){
// 	$revisions = $prop->ID;
// 	break;
//   }
//
//   $meta_value = get_post_meta($post_id, "wkp-final-post-version");
//
//   if(is_array($meta_value)){
// 	foreach ($meta_value as $arr) {
// 		foreach ($arr as $key => $value) {
// 			  $final_arr[]=$key;
// 		}
// 	}
//   }
//   if(in_array($revisions,$final_arr))
// 	return true;
//   else
// 	return false;
// }

/* // Save post revisions checking */



// This functoin is currently disabled restore post is done by jquery ajax
/* // Restore post version revision */

// function wkp_saved_versions_updation( $post_id, $revision_id, $fields = null ){
//
//   // Check the user's permissions.
//   if(isset($_REQUEST['wkp_restore']) && isset($_REQUEST['wkp_restoration'])){
// 	$revision_id = $_REQUEST['wkp_restore'];
// 	$redirect    = add_query_arg( array( 'message' => 5, 'revision' => $revision_id ), get_edit_post_link( get_the_ID(), 'url' ) );
//
// 	if ( !$revision = wp_get_post_revision( $revision_id, ARRAY_A ) )
// 	  return $revision;
//
// 	if ( !is_array( $fields ) )
// 	  $fields = array_keys( _wp_post_revision_fields( $revision ) );
//
// 	$update = array();
// 	foreach ( array_intersect( array_keys( $revision ), $fields ) as $field ) {
// 	  $update[$field] = $revision[$field];
// 	}
//
// 	if ( !$update )
// 	  return false;
//
// 	$update['ID'] = $revision['post_parent'];
//
// 	$update = wp_slash( $update );
//
// 	remove_action( 'save_post', 'wkp_saved_versions_updation', 10, 3 );
//
// 	$post_id = wp_update_post( $update );
//
// 	if ( ! $post_id || is_wp_error( $post_id ) )
// 	return $post_id;
//
// 	add_action( 'save_post', 'wkp_saved_versions_updation', 10, 3 );
//
//
// 	wp_redirect( $redirect );
//
//
// 	exit;
//   }
//
// }
// add_action( 'save_post', 'wkp_saved_versions_updation', 10, 3 );

/* // Restore post version revision */


/* // Version tabs */

add_action( 'wkp_version_tab', 'wkp_version_list' );
function wkp_version_list() {
	$post_id      = get_the_ID();
	$version_data = get_post_meta( get_the_ID(), 'wkp-post-version', true );
	if ( ! empty( $version_data ) ) {
		$version_data = array_reverse( $version_data, true );
	}
	$wkp_get_framework = get_post_meta( $post_id, 'wkp-post-version' );
	$wkp_get_framework = ( isset( $wkp_get_framework[0] ) ) ? $wkp_get_framework : array();
	if ( ! empty( $version_data ) ) {
		?>
		<span href="#" class="wkp-dropdown wkp-demos">
		<span class="wkp-btn wkp-dropdown-label">Version</span>
		<ul class="wkp-dropdown-list wkp-post-versions">
			<?php
			$frameversion = '';
			foreach ( $version_data as $key => $value ) {
				$value        = explode( '---', $value );
				$version_name = 'Version ' . $value[1];
				$frameversion = $value[0];
			  ?>
			  <li data-value="<?php echo $key; ?>" data-version="<?php echo $value[1];?>" data-frameversion = "<?php echo esc_attr( $frameversion ); ?>" data-post-id="<?php echo $post_id; ?>" data-name="<?php echo $version_name;?>"><?php echo $version_name; ?></li>
			  <?php
			}
			?>
		</ul>
		</span>
	<?php
	}
}

/* // Version tabs */

/* //Version Data */

add_action( 'wp_ajax_wkp_post_data', 'wkp_post_data' );
add_action( 'wp_ajax_nopriv_wkp_post_data', 'wkp_post_data' );

function wkp_post_data() {

	  $nonce = $_POST['nonce'];

	  // Verify nonce field passed from javascript code

	 if ( ! wp_verify_nonce( $nonce, 'wkp_nonce' ) )
	  die ( 'Busted!');

	  $rev_cont = new WK_Blog_Content_Renderer;

	  $version_data = $_POST['wkp_version_data'];
	  $post_id      = $_POST['post_id'];

	  $data = wp_get_post_revisions( $post_id );

	  foreach($data as $revision => $value){
		if($revision == $version_data)
		$content = $value->post_content;
	  }

	  $rev_cont = new WK_Blog_Content_Renderer;
	  echo apply_filters( 'the_content', $rev_cont->revision_render_links( $content, $post_id ) );
	  // echo apply_filters( 'the_content', $content );
	  exit;
}

/* // Version Data */

/* // Post and Framework Version */

add_action( 'wkp_post_framework_detail', 'wkp_post_framework_details' );

function wkp_post_framework_details(){

	$post_id       = get_the_ID();
	$Frameversion  = '';
	$version       = '';

	// This code is run when someone copy heading url in select another version.
	if ( isset( $_GET['version'] ) && $_GET['version'] ) {

		$wkp_rev_id = $_GET['version'];
		if ( '/' === substr( $wkp_rev_id, -1 ) ) {
			$wkp_rev_id = substr( $wkp_rev_id, 0, -1 );
		}
		$wkp_frem_vers = get_post_meta( $post_id, 'wkp-post-version', true );
		$wkp_frem_vers = ( $wkp_frem_vers ) ? $wkp_frem_vers : array();
		foreach ( $wkp_frem_vers as $key => $value ) {
			if ( $key === (int) $wkp_rev_id ) {
				$data          = explode( '---', $value );
				@$Frameversion = $data[0];
				@$version      = $data[1];
			}
		}
	}
	$Frameversion  = ( empty( $Frameversion ) ) ? get_post_meta( $post_id, 'wkp_frameversion', true ) : $Frameversion ;
	$version       = ( empty( $version ) ) ? get_post_meta( $post_id, 'wkp_version', true ) : $version ;


	if( ! empty( $version ) ) {
	?>

	  <p class="wkp-current-version">Current Product Version - <rev><?php echo $version; ?></rev></p>
	  <!-- don't remove rev tag, it used in changing version via ajax -->

	<?php
	}
	if( ! empty( $Frameversion ) ) {
	?>

	  <p class="wkp-current-framework">Supported Framework Version - <rev><?php echo $Frameversion; ?></rev></p>
	  <!-- don't remove rev tag, it used in changing version via ajax -->

	<?php
	}

}

add_action( 'wp_ajax_wkp_revision_res', 'wkp_revision_res' );
add_action( 'wp_ajax_nopriv_wkp_revision_res', 'wkp_revision_res' );

function wkp_revision_res() {
	if ( isset( $_POST['nonce'] ) ) {
		if ( wp_verify_nonce( $_POST['nonce'], 'wkp_version_nonce' ) ) {
			$revision_id = $_POST['wkp_res_revision'];
			$post_ID     = $_POST['post_ID'];
			$revision    = wp_get_post_revisions( $post_ID );
			foreach ( $revision as $index => $value ) {

				if ( $index === (int) $revision_id ) {
					$res_content = $value->post_content;
				}
			}
			echo $res_content;
			exit;
		}
	}
}

<?php
get_header();
?>
<section class="service-banner">
  <div class="container">
    <div class="row text-center">
      <div class="col-md-2"></div>
      <div class="col-md-8">
        <h1>Services</h1>
        <p>We are here to help you and we are great at it. We offer services centered around only one goal</p>
        <p>" Establishment of your fruitful Hotel Business "</p>
      </div>
      <div class="col-md-2"></div>
    </div>
  </div>
</section>
<section class="service-content">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="service-type">
          <?php
                global $wp;
                $current_url = home_url(add_query_arg(array(), $wp->request));
                $option_link = ( ! empty(get_option('service_content'))) ? get_option('service_content'): array();
                foreach ($option_link as $option) {
                    $links = $option['name'];
                    $name = explode(" ", $links);
                    $type = $option['type'];
                    $url = $option['url'];
                    $set_url= $current_url."?".strtolower($name[0]);
                    ?>
                        <p class="service-<?php echo $name[0];?> tab" name="<?php echo $links?>"  id="<?php echo strtolower($name[0]);?>" type="<?php echo $type; ?>" url="<?php echo $url;?>" ><?php echo $links;?></p>
                    <?php
                }
                ?>
        </div>
      </div>
      <div class="col-md-9">
        <div class="row">
          <div class="loader">
            <div class="col-md-4">
              <div class="loader-brick text-center">
                <div class="load round"></div>
                <div class="load bar bold"></div>
                <div class="load bar"></div>
                <div class="load bar"></div>
                <div class="load bar"></div>
                <div class="load patch"></div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="loader-brick text-center">
                <div class="load round"></div>
                <div class="load bar bold"></div>
                <div class="load bar"></div>
                <div class="load bar"></div>
                <div class="load bar"></div>
                <div class="load patch"></div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="loader-brick text-center">
                <div class="load round"></div>
                <div class="load bar bold"></div>
                <div class="load bar"></div>
                <div class="load bar"></div>
                <div class="load bar"></div>
                <div class="load patch"></div>
              </div>
            </div>
          </div>
        <div class="wrapper" id="service_data">

      </div>
    </div>
    </div>

    </div>
  </div>
</section>
<?php get_footer();
?>

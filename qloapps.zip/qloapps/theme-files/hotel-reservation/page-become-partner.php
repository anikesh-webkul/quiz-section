<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */
get_header();
?>
<section class="outer-wrapper wk-partner-wrapper">

	<div class="wk-common-padding">

		<div class="container-fluid">

			<div class="row">

				<div class="col-md-1"></div>

				<div class="col-md-10 text-center">

					<h1>Why to become a partner</h1>

				</div>

				<div class="col-md-1"></div>

			</div>

			<div class="row text-center">

				<div class="col-md-4">

					<span class="partner-ico">

						<img src="<?php echo get_template_directory_uri().'/images/partner-list/brand-listing.png'?>">

					</span>

					<h3>Brand Listing</h3>
					<p>Your organisation will be listed on QloApps which will not only enhance the brand listing, but will also enhance your Customer trust value.</p>
				</div>

				<div class="col-md-4">

					<span class="partner-ico">

						<img src="<?php echo get_template_directory_uri().'/images/partner-list/pro-marketing.png'?>">

					</span>

					<h3>Pro Marketing</h3>
					<p> The brand promotion comes with great factors like Brand Trust. Whenever QloApps get promoted, QloApps partners gets promoted at a glance.</p>

				</div>

				<div class="col-md-4">

					<span class="partner-ico">

						<img src="<?php echo get_template_directory_uri().'/images/partner-list/instant-priority.png'?>">

					</span>

					<h3>Top Priority</h3>
					<p>QloApps always put all of its partners under top notch priority for different purposes. Partners are informed with the QloApps updates.</p>

				</div>

			</div>

		</div>

	</div>
	<div class="wk-common-padding">
	<div class="container">

			<div class="row">

			<div class="col-md-12">

				<h1 class="text-center">Become a partner</h1>

				<p class="text-center">Our Success is driven by the success of our partners. As a result we have a long standing relationship with all our partners across the globe. GO ahead and fill the form below to get yourself registered as an official QloApps partner</p>

			</div>

			</div>

			<div class="row">

				<div class="col-md-3"></div>

				<div class="col-md-6">

					<div class="partner-form">
						<?php echo do_shortcode( '[contact-form-7 id="4179" title="Become Partner"]' ); ?>
						<!-- <div id="uv_top_message" class="uv_load"><img src="https://cdn.uvdesk.com/bundles/webkuldefault/images/cssImages/loader.gif"></div>
						<script id="15b489c91316cf5b489c9131777" src="https://webkul.uvdesk.com/apps/form-builder/en/form/15b489c91316cf5b489c9131777?&info=0" async="async" > </script> -->

						<script>
						window.addEventListener( 'load', function(){
							var uvCheck=function(){
								if(document.getElementById("uv_reply")){
									document.getElementById("uv_reply").value="Became a partner";
								}else{ setTimeout(uvCheck,100); }
							};
							setTimeout(uvCheck,100);
						});
						</script>
					</div>

				</div>

				<div class="col-md-3"></div>


			</div>


			</div>

		</div>

</section>
<?php get_footer(); ?>

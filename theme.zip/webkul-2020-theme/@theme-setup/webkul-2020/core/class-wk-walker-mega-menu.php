<?php

class WK_Walker_Mega_Menu extends Walker_Nav_Menu {

	private $notice_board = '';

	public function start_lvl( &$output, $depth = 0, $args = array() ) {

		$output .= '<div class="wk-submenu-off"><ul class="wk-submenu-list"><span class="tip"></span>';
	}

	public function end_lvl( &$output, $depth = 0, $args = array() ) {
		$notices = '';
		if ( '' != $this->notice_board ) {
			$notices = $this->notice_board( $this->notice_board );
		}
		$text = 'Hire on-demand project developers and turn your idea into working reality.';
		if ( 'technologies' == $this->notice_board ) {
			$text = 'We can collaborate and develop on-demand softwares or tools as per your needs.';
		}
		if ( 'services' == $this->notice_board ) {
			$text = 'Do you need custom software or tool for your business? We can help you.';
		}
		$output .= '</ul><div class="wk-submenu-board">' . $notices . '</div><div class="wk-submenu-callout"><div class="callout-brick"><p>' . $text . '</p><a href="#contact" class="link">Start a Project</div></div>';
	}

	public function end_el( &$output, $item, $depth = 0, $args = array() ) {
		$output .= '';
	}
	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

		$classes = array();

		if ( ! empty( $item->classes ) ) {
			$classes = (array) $item->classes;
		}
		$class = '';
		$a_class = '';

		if ( in_array( 'menu-item-has-children', $classes, true ) ) {
			$a_class = 'wk-drop';
		}

		if ( $depth == 0 ) {
			preg_match( '/about|technologies|services/', implode( ',', $classes ), $matches );
			$this->notice_board = isset( $matches[0] ) ? $matches[0] : '';
		}

		$url = '';

		if( ! empty( $item->url ) ) {
			$url = $item->url;
		}

		$classes = implode( ' ', $classes );

		if ( $depth == 0 ) {

			$url    = ( '' === $url || '#!' === $url ) ? 'javascript:void(0);' : $url;
			$target = ( '' !== $item->target ) ? ' target="' . $item->target . '"' : '';
			$rel    = ( '' !== $item->xfn ) ? ' rel="' . $item->xfn . '"' : '';

			$output .= '<li class="' . $classes . '" ><a class="' . $a_class . '" href="' . $url . '" title="' . $item->title . '"' . $target . ' ' . $rel . '>' . $item->title . '</a>';

		} else {
			$target = ( '' !== $item->target ) ? ' target="' . $item->target . '"' : '';
			$rel    = ( '' !== $item->xfn ) ? ' rel="' . $item->xfn . '"' : '';
			$class  = empty( $item->classes[0] ) ? ' ' :  ' class="wk-menu-icon wk-menu-icon-' . $item->classes[0];

			$output .= '<li class="wk-menu-item-wrapper wk-menu-item"><a href="' . $url . '" title="' . $item->title . '"' . $rel . ' ' . $target . $class . '">' . $item->title . '</a></li>';
		}

	}

	private function notice_board( $name = 'about' ) {
		if ( 'about' === $name ) {
			$html = '<div class="card">' . wk_webp( 'orphan/nudge-magento-sneaks.png', '', '', true ) . '<div class="p-x4 txt-top">2 times in a row</div><div class="p-x3 txt-bottom">Adobe Magento Commerce Main Stage Sneaks</div></div>
			<div class="card">' . wk_webp( 'orphan/nudge-magento-innovations', '', '', true ) . '<div class="p-x4 txt-top">5 times in a row</div><div class="p-x3 txt-bottom">Adobe Magento Commerce Innovations Lab</div></div>
			<div class="card">' . wk_webp( 'orphan/nudge-deloitte', '', '', true ) . '<div class="p-x4 txt-top">5 times in a row</div><div class="p-x3 txt-bottom">Deloitte Technology Fast 50 India</div></div>
			<div class="card">' . wk_webp( 'orphan/nudge-smartceo', '', '', true ) . '<div class="p-x4 txt-top">Startup 50</div><div class="p-x3 txt-bottom">Top Enterprise Venture by SmartCEO</div></div>
			';
		}
		if ( 'technologies' === $name ) {

			$html = '<p>Leading Partners</p>' . wk_webp( 'orphan/nudge-partner-logos.png' );
		}
		if ( 'services' === $name ) {
			$html = '<div class="saying wk-quote"><div class="p-x3">Both the team and code are responsive. The team worked hard and politely on my little nerdy requests, bug fixing, and customizations.</div><div class="card">' . wk_webp( 'orphan/customer.png', '', '', true ) . '<div class="name txt-top">Dr. Mohamed Es Fih</div><div class="p-x4 txt-bottom">TeSolutions Advisor, ITC</div></div></div>
			<div><p>Top Clients</p>';
			$html .= wk_webp( 'orphan/nudge-customer-logos.png' ) . '</div>';
		}
		return $html;
	}
}

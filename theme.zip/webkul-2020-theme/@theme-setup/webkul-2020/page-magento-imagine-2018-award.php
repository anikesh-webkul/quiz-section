<html>
	<head>
		<meta name="viewport" content="width=device-width,user-scalable=yes,initial-scale=1,maximum-scale=5">
		<meta charset="UTF-8">
		<title><?php wp_title( '|', true, 'right' ); ?></title>
		<link rel="icon" type="image/x-icon" href="<?php echo esc_attr( get_bloginfo( 'template_url' ) ); ?>/images/favicon.ico"/>
		<link rel="apple-touch-icon" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-57.png' ); ?>" />
		<link rel="apple-touch-icon" sizes="72x72" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-72.png' ); ?>" />
		<link rel="apple-touch-icon" sizes="114x114" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-114.png' ); ?>" />
		<link rel="apple-touch-icon" sizes="144x144" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-144.png' ); ?>" />
		<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
		<link href="<?php echo esc_url( get_template_directory_uri() . '/assets/dist/css/wk-magentoaward.min.css' ); ?>" rel="stylesheet" type="text/css">

		<meta property="og:locale" content="en_US" />
		<meta property="og:type" content="website" />
		<meta property="og:title" content="Webkul Awarded as Magento Technology Partner" />
		<meta property="og:description" content="Webkul received the Magento Technology Partner at the annual Magento Imagine conference." />
		<meta property="og:url" content="https://webkul.com/magento-imagine-2018-award/" />
		<meta property="og:site_name" content="Webkul Software" />
		<meta property="og:image" content="https://webkul.com/blog/wp-content/uploads/2018/05/magento-imagine-2018-award.png" />
		<meta property="og:image:secure_url" content="https://webkul.com/blog/wp-content/uploads/2018/05/magento-imagine-2018-award.png" />
		<meta name="twitter:card" content="summary_large_image" />
		<meta name="twitter:description" content="Webkul received the Magento Technology Partner at the annual Magento Imagine conference." />
		<meta name="twitter:title" content="Webkul Awarded as Magento Technology Partner" />
		<meta name="twitter:site" content="@webkul" />
		<meta name="twitter:image" content="https://webkul.com/blog/wp-content/uploads/2018/05/magento-imagine-2018-award.png" />
	</head>
	<body>
		<div class="container">
			<div class="main">
				<div class="content">
					<img src="<?php echo esc_url( get_template_directory_uri() . '/images/magento-award/banner.png' ); ?>">
				</div>
			</div>
	<div class="moving">
		<div class="logo-wrap">
			<a class="back-up" href="https://www.webkul.com"><span>Back</span></a>
			<a href="https://webkul.com/" class="logo"></a>
			<div class="share-wrap"><span class="text">Share on</span>
				<a  onclick="window.open( this.href, 'targetWindow', 'toolbar=0,status=0,width=620,height=500'); return false;" href="http://www.facebook.com/sharer.php?u=https%3A//webkul.com/magento-imagine-2018-award&title=Technology Partner Winner Award&description=Imagine-2018 Technology Partner Winner Award" target="_blank">
					<?xml version="1.0" encoding="UTF-8"?>
					<svg width="30px" height="30px" viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
					   <g id="facebook" fill="#3b5999" stroke="none" fill-rule="evenodd">
						<path d="M11.511708,29.9999285 L11.511708,16.5819917 L7,16.5819917 L7,11.2499732 L11.511708,11.2499732 L11.511708,7.03123324 C11.511708,4.80467604 12.1367068,3.07616455 13.3867035,1.84569872 C14.6367002,0.615232905 16.2968531,0 18.3671604,0 C20.0468442,0 21.4140281,0.078124516 22.4687131,0.234374441 L22.4687131,4.98045687 L19.6562198,4.98045687 C18.6015348,4.98045687 17.8788806,5.21483131 17.4882563,5.68358019 C17.1757573,6.07420456 17.0195074,6.69920247 17.0195074,7.55857572 L17.0195074,11.2499732 L21.9999642,11.2499732 L21.2968409,16.5819917 L17.0195074,16.5819917 L17.0195074,29.9999285 L11.511708,29.9999285 Z" id="" fill-rule="nonzero"></path>
					</g>
				</svg>
				</a>
				<a  onclick="window.open('https://twitter.com/share?url=https%3A//webkul.com/magento-imagine-2018-award&amp;hashtags=Webkul&amp;related=webkul&amp;text=Imagine-2018 Technology Partner Winner Award @webkul', 'sharer', 'toolbar=0,status=0,width=620,height=500')" href="javascript:void(0);" target="_blank">
					<svg width="30px" height="30px" viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
						<g id="Artboard" stroke="none" stroke-width="1" fill="#55acee" fill-rule="evenodd">
							<g id="twitter" transform="translate(0.000000, 3.000000)" fill="#55acee" stroke="none">
								<path d="M26.8944671,6.09373547 C26.9335298,6.2499854 26.9530607,6.50389074 26.9530607,6.85545241 C26.9530607,9.6679457 26.2694683,12.3827827 24.9022844,14.9999642 C23.4960377,17.7733948 21.5233859,19.9804211 18.9843297,21.6210422 C16.2108991,23.456975 13.0273124,24.3749419 9.43357126,24.3749419 C5.99607916,24.3749419 2.851556,23.456975 0,21.6210422 C0.429686178,21.6601049 0.917966859,21.6796358 1.46484026,21.6796358 C4.31639626,21.6796358 6.87498331,20.8007317 9.14060321,19.0429233 C7.77341926,19.0429233 6.57225025,18.642534 5.53709617,17.8417543 C4.50194209,17.0409747 3.78905376,16.0351183 3.3984294,14.8241834 C3.78905376,14.8632461 4.16014633,14.882777 4.51170799,14.882777 C5.05858139,14.882777 5.60545568,14.8241834 6.15232908,14.7069962 C4.74608243,14.3944972 3.57421023,13.6718421 2.63671246,12.5390326 C1.6992147,11.4062231 1.23046582,10.1171637 1.23046582,8.67185432 L1.23046582,8.5546671 C2.08983907,9.06247869 3.00780503,9.33591494 3.9843655,9.37497765 C3.16405496,8.78904155 2.49999434,8.04685552 1.99218275,7.14842046 C1.48437116,6.2499854 1.23046582,5.26365903 1.23046582,4.18944314 C1.23046582,3.11522725 1.52343387,2.08983907 2.10936997,1.1132786 C3.63280384,3.02733683 5.49803347,4.5507707 7.70505975,5.6835802 C9.91208604,6.8163897 12.2655955,7.44138851 14.7655898,7.55857573 C14.6874653,7.08982685 14.6484026,6.62107796 14.6484026,6.15232908 C14.6484026,5.05858139 14.9218397,4.03319321 15.4687131,3.07616454 C16.0155865,2.11913587 16.7577725,1.36718394 17.6952703,0.820310544 C18.6327681,0.273437146 19.6483904,0 20.742138,0 C21.6405731,0 22.4706496,0.175780831 23.2323665,0.527342493 C23.9940834,0.878904155 24.6679099,1.34765304 25.253846,1.93358914 C26.6600927,1.66015199 27.968683,1.17187221 29.1796179,0.468748882 C28.710869,1.91405823 27.812434,3.04686774 26.4843119,3.86717828 C27.6561841,3.71092835 28.8280563,3.37889849 29.9999285,2.8710869 C29.1405552,4.12108363 28.105402,5.19530041 26.8944671,6.09373547 Z" id="">
								</path>
							</g>
						</g>
					</svg>
				</a>
			</div>
		</div>
		<h1 >2018 Magento Technology Partner Award<br>Winner</h1>
		<div class="shield"><img class="first-fold shield" src="<?php echo esc_url( get_template_directory_uri() . '/images/magento-award/shield.png' ); ?>"></div>
		<h3 class="px-30">Webkul Honored with Top Selling Extension Award at Imagine 2018</h3>
		<p>LAS VEGAS, NV – April 25, 2018 – Webkul - the hook for enterprise businesses, today received a Magento Technology Partner Award for the Top Selling Extension of 2017 at the annual Magento Imagine conference. Renowned as one of the eCommerce industry’s top events, Imagine brings together industry leaders who are paving the way for the future of B2C and B2C commerce. The Magento Technology Partners Awards recognizes the leading solution and technology partners that have delivered the greatest impact to the commerce industry over the past year.</p>
		<p>Webkul was recognized for highest sales of individual extensions on Marketplace.</p>

		<p class="quote">We are thrilled to be a 2017 Technology Partner Award Winner at Magento Imagine 2018 event. We are looking forward to innovating and taking ecommerce to the next level.</p>
		<p>-Webkul</p>

		<p>Our global ecosystem of partners is the backbone of Magento and helps us to provide the technology and solutions that empower thousands of merchants to deliver unparalleled experiences,” said Mark Lavelle, CEO at Magento Commerce. “Their commitment to innovation has taken the platform to new heights, and helped our joint customers drive growth, new business opportunities and connections with their customers. We are proud to honor their ingenuity and excellence.”</p>

		<p>The award was presented at the eighth annual Magento Imagine conference, which brings together more than 3,000 eCommerce experts from over 50 countries for three days of inspiration, knowledge sharing, industry insights, and customer panels. Participants can also explore the latest Magento product offerings that are transforming the digital commerce space.</p>

		<p>Webkul is the hook for enterprise businesses and helps enterprises to upscale easily with a wider range of ready to use and highly customisable eCommerce centric products.</p>

		<h3>Read more about the<br><a href="https://magento.com/blog/events/2018-partner-award-winners-magento-technology-partners" rel="nofollow noopener" target="_blank" class="mylink px-60">Magento  Partner Award Winners</a></h3>

		<h3 class="px-60-top">About</h3>
		<a href="https://webkul.com/" class="logo2"></a>
		<p>Webkul was founded in the year 2010 and Webkul is among one of the few 100% Self-Bootstrapped organizations.</p>

<p>Leveraging their technological expertise. Webkul creates world-class easy-to-use software and applications for enterprise businesses.</p>

		<h3 class="px-30">About Magento Commerce</h3>
		<p>Magento Commerce is the leading provider of cloud commerce innovation to merchants and brands across B2C and B2B industries, with more than $155 billion in gross merchandise volume transacted on the platform annually. In addition to its flagship digital commerce platform, Magento Commerce boasts a strong portfolio of cloud-based omnichannel solutions that empower merchants to successfully integrate digital and physical shopping experiences. Magento Commerce is the #1 provider to the Internet Retailer Top 1000, the B2B 300 and the Top 500 Guides for Europe and Latin America. Magento Commerce is supported by a vast global network of solution and technology partners, a highly active global developer community and the largest ecommerce marketplace for extensions available for download on the Magento Marketplace.More information can be found at <a rel="noopener nofollow" href="https://www.magento.com." target="_blank">www.magento.com</a>.</p>



		<div>
			<blockquote class="twitter-tweet" data-lang="en-gb"><p lang="en" dir="ltr">Congrats to <a href="https://twitter.com/hashtag/Magento?src=hash&amp;ref_src=twsrc%5Etfw">#Magento</a> Technology Partner <a href="https://twitter.com/webkul?ref_src=twsrc%5Etfw">@webkul</a> for creating the Top Selling Extension in 2017 <a href="https://t.co/3YkX6sW0Dm">https://t.co/3YkX6sW0Dm</a>  <a href="https://twitter.com/hashtag/MagentoImagine?src=hash&amp;ref_src=twsrc%5Etfw">#MagentoImagine</a> <a href="https://t.co/VcFuuCiIjh">pic.twitter.com/VcFuuCiIjh</a></p>&mdash; Magento (@magento) <a href="https://twitter.com/magento/status/989745473958260736?ref_src=twsrc%5Etfw">27 April 2018</a></blockquote>
			<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

		</div>

		<h3 class="first-fold">Follow us at</h3>
		<div class="full-cover">
		<a class="social" href="https://www.facebook.com/webkul" target="_blank"><?xml version="1.0" encoding="UTF-8"?>
			<?xml version="1.0" encoding="UTF-8"?>
			<svg width="30px" height="30px" viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
			   <g id="facebook" fill="#3b5999" stroke="none" fill-rule="evenodd">
				<path d="M11.511708,29.9999285 L11.511708,16.5819917 L7,16.5819917 L7,11.2499732 L11.511708,11.2499732 L11.511708,7.03123324 C11.511708,4.80467604 12.1367068,3.07616455 13.3867035,1.84569872 C14.6367002,0.615232905 16.2968531,0 18.3671604,0 C20.0468442,0 21.4140281,0.078124516 22.4687131,0.234374441 L22.4687131,4.98045687 L19.6562198,4.98045687 C18.6015348,4.98045687 17.8788806,5.21483131 17.4882563,5.68358019 C17.1757573,6.07420456 17.0195074,6.69920247 17.0195074,7.55857572 L17.0195074,11.2499732 L21.9999642,11.2499732 L21.2968409,16.5819917 L17.0195074,16.5819917 L17.0195074,29.9999285 L11.511708,29.9999285 Z" id="" fill-rule="nonzero"></path>
			</g>
		</svg>
		</a>

		<a class="social" href="https://in.linkedin.com/company/webkul" target="_blank">
			<?xml version="1.0" encoding="UTF-8"?>
<svg width="30px" height="30px" viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
	<g id="Artboard" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
		<g id="linkedin" transform="translate(2.000000, 1.000000)" fill="#0077B5" stroke="none" fill-rule="nonzero">
			<path d="M6.17965744,26.8749955 L0.730451682,26.8749955 L0.730451682,9.35550605 L6.17965744,9.35550605 L6.17965744,26.8749955 Z M3.48435137,6.95316803 C2.62497812,6.95316803 1.88279298,6.64066907 1.25779417,6.01567026 C0.632795367,5.39067145 0.32029641,4.64848632 0.32029641,3.78911307 C0.32029641,2.92973982 0.632795367,2.18755469 1.25779417,1.56255588 C1.88279298,0.937557071 2.62497812,0.625058115 3.48435137,0.625058115 C4.34372462,0.625058115 5.08590975,0.937557071 5.71090856,1.56255588 C6.33590737,2.18755469 6.64840632,2.92973982 6.64840632,3.78911307 C6.64840632,4.64848632 6.33590737,5.39067145 5.71090856,6.01567026 C5.08590975,6.64066907 4.34372462,6.95316803 3.48435137,6.95316803 Z M26.5702338,26.8749955 L21.1210281,26.8749955 L21.1210281,18.3203284 C21.1210281,16.9140818 21.0038408,15.8984595 20.7694664,15.2734607 C20.3397802,14.2187757 19.4999379,13.6914332 18.2499412,13.6914332 C16.9999444,13.6914332 16.1210403,14.1601821 15.6132287,15.0976799 C15.2226043,15.8008032 15.0272926,16.8359573 15.0272926,18.2031412 L15.0272926,26.8749955 L9.63668045,26.8749955 L9.63668045,9.35550605 L14.8515118,9.35550605 L14.8515118,11.7578441 L14.9101054,11.7578441 C15.3007297,10.9765962 15.9257277,10.3320665 16.7851009,9.82425493 C17.7225987,9.19925612 18.8163464,8.88675717 20.0663431,8.88675717 C22.6053992,8.88675717 24.3827393,9.68753681 25.3983616,11.2890952 C26.1796095,12.5781546 26.5702338,14.5703374 26.5702338,17.2656434 L26.5702338,26.8749955 Z" id=""></path>
		</g>
	</g>
</svg>
		</a>

		<a class="social" href="https://twitter.com/webkul" target="_blank">
				<svg width="30px" height="30px" viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
					<g id="Artboard" stroke="none" stroke-width="1" fill="#55acee" fill-rule="evenodd">
						<g id="twitter" transform="translate(0.000000, 3.000000)" fill="#55acee" stroke="none">
							<path d="M26.8944671,6.09373547 C26.9335298,6.2499854 26.9530607,6.50389074 26.9530607,6.85545241 C26.9530607,9.6679457 26.2694683,12.3827827 24.9022844,14.9999642 C23.4960377,17.7733948 21.5233859,19.9804211 18.9843297,21.6210422 C16.2108991,23.456975 13.0273124,24.3749419 9.43357126,24.3749419 C5.99607916,24.3749419 2.851556,23.456975 0,21.6210422 C0.429686178,21.6601049 0.917966859,21.6796358 1.46484026,21.6796358 C4.31639626,21.6796358 6.87498331,20.8007317 9.14060321,19.0429233 C7.77341926,19.0429233 6.57225025,18.642534 5.53709617,17.8417543 C4.50194209,17.0409747 3.78905376,16.0351183 3.3984294,14.8241834 C3.78905376,14.8632461 4.16014633,14.882777 4.51170799,14.882777 C5.05858139,14.882777 5.60545568,14.8241834 6.15232908,14.7069962 C4.74608243,14.3944972 3.57421023,13.6718421 2.63671246,12.5390326 C1.6992147,11.4062231 1.23046582,10.1171637 1.23046582,8.67185432 L1.23046582,8.5546671 C2.08983907,9.06247869 3.00780503,9.33591494 3.9843655,9.37497765 C3.16405496,8.78904155 2.49999434,8.04685552 1.99218275,7.14842046 C1.48437116,6.2499854 1.23046582,5.26365903 1.23046582,4.18944314 C1.23046582,3.11522725 1.52343387,2.08983907 2.10936997,1.1132786 C3.63280384,3.02733683 5.49803347,4.5507707 7.70505975,5.6835802 C9.91208604,6.8163897 12.2655955,7.44138851 14.7655898,7.55857573 C14.6874653,7.08982685 14.6484026,6.62107796 14.6484026,6.15232908 C14.6484026,5.05858139 14.9218397,4.03319321 15.4687131,3.07616454 C16.0155865,2.11913587 16.7577725,1.36718394 17.6952703,0.820310544 C18.6327681,0.273437146 19.6483904,0 20.742138,0 C21.6405731,0 22.4706496,0.175780831 23.2323665,0.527342493 C23.9940834,0.878904155 24.6679099,1.34765304 25.253846,1.93358914 C26.6600927,1.66015199 27.968683,1.17187221 29.1796179,0.468748882 C28.710869,1.91405823 27.812434,3.04686774 26.4843119,3.86717828 C27.6561841,3.71092835 28.8280563,3.37889849 29.9999285,2.8710869 C29.1405552,4.12108363 28.105402,5.19530041 26.8944671,6.09373547 Z" id=""></path>
						</g>
					</g>
				</svg>
		</a>
			</div>
		<a class="back" href="https://www.webkul.com"><h3>Back to Webkul</h3></a>
		<div class="first-fold"></div>
	</div>
			</div>
	</body>
</html>

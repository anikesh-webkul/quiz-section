<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/
get_header();

global $wpdb;
$table = $wpdb->prefix . 'team';

$team_bag = $wpdb->get_results( "SELECT id, emp_name, emp_designation, emp_team, emp_image FROM $table WHERE post_status='publish'", ARRAY_A );


function filter_team_in_groups( $team_bag, $grp ) {

	$re_build_data = array();
	$dumb_arr      = array();

	$members = array_values( array_filter( $team_bag, function( $person ) use ( $grp ) {
		if ( $grp === $person['emp_team'] ) {
			return $person;
		}
	}));

	//Ordering By emp_name
	foreach ( $members as $value ) {
		$dumb_arr[ $value['emp_name'] . '@' . $value['id'] ] = $value; //put Emp_name as keys
	}
	$keys = array_keys( $dumb_arr );   //get Emp_names
	asort( $keys );                    //Sort Emp_name Keys

	$re_build_data = array_values( array_map( function( $k ) use ( $dumb_arr, $re_build_data ) {
		return $dumb_arr[ $k ];
	}, $keys ) );

	return ( $re_build_data );   //return Ordered set of Team members
}
?>

<section class="team-page-header section-0T section-top">
	<div class="wkgrid-squeezy">
		<img class="team-banner img-responsive" src="<?php echo esc_url( get_template_directory_uri() . '/images/image-about-team.jpg' ); ?>" />
		<h1>We are <span class="col-odd">One,</span><br />We are <span class="col-main">Webkul.</span></h1>
		<p>We are 300+ highly focused people, working together on a mission to infinity. Technology and living on the edge is our first common passing.</p>
		<p>We scratch, innovate, live and play together.</p>
	</div>
</section>

<section class="wk-team-members-section section-padding-0T">
	<div class="wkgrid-squeezy">
		<h2 class="text-center">Meet the People</h2>
		<p>We are glad to see you here, meet the ironmen who are silently curating to solve the real world problems with their hardcore skills without any gimmicks.</p>
	</div>

	<div class="wkgrid-wide">
		<?php
		$for_italy_office = ''; //Group is Empty for Italy Office Employees
		$group_names      = [ 'Administratives', 'UI/UX Designers', 'Sales and Marketing', 'Tech Savvies', 'Engineers', 'Carers' ];
		$path             = wp_upload_dir()['baseurl'] . '/';

		foreach ( $group_names as $group ) {
			$filtered_team = filter_team_in_groups( $team_bag, $group );

			?>
			<div class="group-block">
				<h3 class="text-center"><?php echo esc_html( $group ); ?></h3>
				<div class="wk-section-grid">
				<?php
				foreach ( $filtered_team as $member ) {
					?>
					<div class="member-tile">
						<div class="surface lazify" data-src="<?php echo esc_url( $path . $member['emp_image'] ); ?>"></div>
						<div class="name"><?php echo esc_html( $member['emp_name'] ); ?></div>
						<div class="designation"><?php echo esc_html( $member['emp_designation'] ); ?></div>
					</div>
					<?php
				}
				?>
				</div>
			</div>
			<?php
			// if ( '' === $group ) {
			// 	echo '<div class="seperator text-center"><h2>India Office</h2></div>';
			// }
		}
		?>
	</div>
</section>
<section class="wk-page-content section-padding-0T">
	<div class="wkgrid-squeezy">
			<h2>Join Our Team</h2>
			<div class="card-pallete">
				<div class="card-image">
					<img class="team-banner img-responsive" src="<?php echo esc_url( get_template_directory_uri() . '/images/culture-image.jpg' ); ?>" />
				</div>
				<div class="card-content">
					<p>Want to experience
						<a href="https://webkul.com/blog/life-at-webkul/">Life at Webkul</a>?</p>
					<p>
						We love to work with the talented and hard-working people.
					</p>
					<p>
						Checkout the open positions to apply or drop an email to us.
					</p>
					<p>
						<a href="https://webkul.com/careers/" class="wk-button">View Openings</a>
					</p>
				</div>
			</div>
	</div>
</section>
<?php
get_footer();

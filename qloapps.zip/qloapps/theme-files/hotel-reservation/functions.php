<?php
/**
* The Hotel And Reservation functions template for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package Hotel&Reservation
 * @subpackage Hotel&Reservation
 * @since Hotel&Reservation 1.0
 */

 /*AMP LD-json image fix */
 add_filter( 'amp_post_template_metadata', 'amp_modify_json_metadata', 10, 1 );
 function amp_modify_json_metadata( $metadata ) {
	$metadata['publisher']['logo'] = array(

		'@type'  => 'ImageObject',
		'url'    => get_template_directory_uri() . '/images/logo.png',
		'height' => 60,
		'width'  => 60,
	);
	return $metadata;
 }
 /*//AMP LD-json image fix */

ob_start();

function hotelreservation_setup() {

	/*

	 * This theme styles the visual editor to resemble the theme style,

	 * specifically font, colors, icons, and column width.

	 */



	// Adds RSS feed links to <head> for posts and comments.

	add_theme_support( 'automatic-feed-links' );

// This theme styles the visual editor with editor-style.css to match the theme style.

	add_editor_style();


	/*

	 * Switches default core markup for search form, comment form,

	 * and comments to output valid HTML5.

	 */

	add_theme_support( 'html5', array(

		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'

	) );

	add_theme_support( 'post-formats', array(

		'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video'

	) );



/*

	 * This theme uses a custom image size for featured images, displayed on

	 * "standard" posts and pages.

	 */

  add_theme_support( 'post-thumbnails' );

	set_post_thumbnail_size( 360, 200, true );

  add_image_size( 'feat_img_size' ,1920, 445 ,true);


	// This theme uses its own gallery styles.

	add_filter( 'use_default_gallery_style', '__return_false' );

}

// add html in blog content PHP DOM
class WK_Blog_Content_Renderer {
	public static $navigate_links;
	function __construct() {
		add_filter( 'the_content', array( $this, 'render_link' ) );
		add_action( 'wp_footer', array( $this, 'navigation_template' ) );
		add_filter( 'return_show_toggler', array( $this, 'return_show_toggler') );
	}

	public function render_link( $content ) {
		if ( is_single() ) {

			if ( empty( $content ) )
			return;

			$post = new DOMDocument();

			// set error level
			$internalErrors = libxml_use_internal_errors(true);

			$post->loadHTML( mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' ) );

			// Restore error level
			libxml_use_internal_errors( $internalErrors );

			$seeker      = new DomXPath( $post );
			$title_nodes = $seeker->query( "//h1 | //h2 | //h3 | //h4 | //h5" );
			$classname   = 'wkqa-index-panel';
			$classname2   = 'index-title';
			$index_nodes = $seeker->query( "//*[contains(concat(' ', normalize-space(@class), ' '), ' $classname ') or contains(concat(' ', normalize-space(@class), ' '), ' $classname2 ')]" );

			if ( $title_nodes->length > 0 ) {

				foreach ( $title_nodes as $index => $node ) {
					if ( ! empty( $node->nodeValue ) ) {

						$node->setAttribute( 'data-link', get_permalink() . '#section-' . $index );
						$h_class = $node->getAttribute( 'class' );
						$node->setAttribute( 'class', 'wk-in-link ' . $h_class . '' );
						// $node->setAttribute( 'class', 'wk-in-link ' );
						$wrap    = $post->createElement( 'div' );
						$tooltip = $post->createElement( 'span' );

						$wrap->setAttribute( 'class', 'wk-link' );

						$tooltip->setAttribute( 'class', 'wk-tooltip' );
						$tooltip->setAttribute( 'data-tooltip', 'Click to copy' );
						$wrap->setAttribute( 'id', 'section-' . $index );
						$node->appendChild( $tooltip );

						$node->parentNode->replaceChild( $wrap, $node );
						$wrap->appendChild( $node );

						$firstSibling = $tooltip->parentNode->firstChild;
						$tooltip->parentNode->insertBefore( $tooltip, $firstSibling );
					}
				}

				if ( $index_nodes->length > 0 ) {
					$links = '';
					foreach ( $index_nodes as $index => $node ) {
						if ( ! empty( $node->nodeValue ) ) {

							if ( 'h1' === $node->nodeName || 'h2' === $node->nodeName ||'h3' === $node->nodeName ||'h4' === $node->nodeName ||'h5' === $node->nodeName ) {
								$parentID = $node->parentNode->getAttribute( 'id' );
								$links .= '<li><a class="nav-handlers" href=#' . $parentID . '>' . strip_shortcodes( $node->nodeValue ) . '</a></li>';
							} else {
								$node->setAttribute( 'id', 'panel-' . $index . '' );
								$links .= '<li><a class="nav-handlers" href=#panel-' . $index . '>' . strip_shortcodes( $node->nodeValue ) . '</a></li>';
							}
						}
					}
					self::$navigate_links = $links;
				}

				$show_toggler = 1;
				return $post->saveHTML();
			}


			return $content;
		} else {
			return $content;
		}
	}

	public function revision_render_links( $content, $post_id ) {
		if ( empty( $content ) )
		return;

		$post = new DOMDocument();

		// set error level
		$internalErrors = libxml_use_internal_errors(true);

		$post->loadHTML( mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' ) );

		// Restore error level
		libxml_use_internal_errors( $internalErrors );

		$seeker      = new DomXPath( $post );
		$title_nodes = $seeker->query( "//h1 | //h2 | //h3 | //h4 | //h5" );
		$classname   = 'wkqa-index-panel';
		$classname2   = 'index-title';
		$index_nodes = $seeker->query( "//*[contains(concat(' ', normalize-space(@class), ' '), ' $classname ') or contains(concat(' ', normalize-space(@class), ' '), ' $classname2 ')]" );

		if ( $title_nodes->length > 0 ) {

			foreach ( $title_nodes as $index => $node ) {
				if ( ! empty( $node->nodeValue ) ) {

					$node->setAttribute( 'data-link', get_permalink( $post_id ) . '#section-' . $index );
					$h_class = $node->getAttribute( 'class' );
					$node->setAttribute( 'class', 'wk-in-link ' . $h_class . '' );
					// $node->setAttribute( 'class', 'wk-in-link ' );
					$wrap    = $post->createElement( 'div' );
					$tooltip = $post->createElement( 'span' );

					$wrap->setAttribute( 'class', 'wk-link' );

					$tooltip->setAttribute( 'class', 'wk-tooltip' );
					$tooltip->setAttribute( 'data-tooltip', 'Click to copy' );
					$wrap->setAttribute( 'id', 'section-' . $index );
					$node->appendChild( $tooltip );

					$node->parentNode->replaceChild( $wrap, $node );
					$wrap->appendChild( $node );

					$firstSibling = $tooltip->parentNode->firstChild;
					$tooltip->parentNode->insertBefore( $tooltip, $firstSibling );
				}
			}

			if ( $index_nodes->length > 0 ) {
				$links = '';
				foreach ( $index_nodes as $index => $node ) {
					if ( ! empty( $node->nodeValue ) ) {

						if ( 'h1' === $node->nodeName || 'h2' === $node->nodeName ||'h3' === $node->nodeName ||'h4' === $node->nodeName ||'h5' === $node->nodeName ) {
							$parentID = $node->parentNode->getAttribute( 'id' );
							$links .= '<li><a class="nav-handlers" href=#' . $parentID . '>' . strip_shortcodes( $node->nodeValue ) . '</a></li>';
						} else {
							$node->setAttribute( 'id', 'panel-' . $index . '' );
							$links .= '<li><a class="nav-handlers" href=#panel-' . $index . '>' . strip_shortcodes( $node->nodeValue ) . '</a></li>';
						}
					}
				}
				self::$navigate_links = $links;
			}

			$show_toggler = 1;
			return $post->saveHTML();
		}


		return $content;
	}

	public function navigation_template() {
		$links = self::$navigate_links;
		if ( isset( $links ) && $links ) {

			$template = '<div class="wk-index-bar">
			<div class="wk-index-header">
			<div class="wk-index-title">Table of Content<span class="wk-index-bar-close">Hide Index</span></div>
			</div>
			<div class="wk-index-paper">
			<ul>' . $links . '</ul></div></div>';
			echo $template;
		}
	}


	function return_show_toggler( $post_id ) {

        $content_post = get_post( $post_id );
        $content      = $content_post->post_content;
        if ( empty( $content ) ) {
            return $content;
        }

        $post           = new DOMDocument();
        // set error level
        $internalErrors = libxml_use_internal_errors(true);
        $post->loadHTML( mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' ) );
        // Restore error level
        libxml_use_internal_errors( $internalErrors );

        $finder       = new DomXPath( $post );
		$classname   = 'wkqa-index-panel';
		$classname2   = 'index-title';
        $title_nodes = $finder->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' $classname ') or contains(concat(' ', normalize-space(@class), ' '), ' $classname2 ')]");
        $links        = '';

        foreach ( $title_nodes as $index => $node ) {
            $node->setAttribute( 'id', 'panel-' . $index );
            $links .= '<li><a class="nav-handlers" id=#panel-' . $index . '>' . strip_shortcodes( $node->nodeValue ) . '</a></li>';
        }
        if( $links ) {
            return 1;
        } else {
            return 0;
        }
    }

}


add_action( 'after_setup_theme', 'hotelreservation_setup' );


function hotelreservation_setup_wp_title( $title, $sep ) {

	global $paged, $page;



	if ( is_feed() )

		return $title;



	// Add the site name.

	$title .= get_bloginfo( 'name', 'display' );



	// Add the site description for the home/front page.

	$site_description = get_bloginfo( 'description', 'display' );

	if ( $site_description && ( is_home() || is_front_page() ) )

		$title = "$title $sep $site_description";



	// Add a page number if necessary.

	if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() )

		$title = "$title $sep " . sprintf( __( 'Page %s', 'Hotel&Reservation' ), max( $paged, $page ) );



	return $title;

}

add_filter( 'wp_title', 'hotelreservation_setup_wp_title', 10, 2 );


/**
 * Return the Google font stylesheet URL, if available.
 * The use of Source Sans Pro and Bitter by default is localized. For languages
 * that use characters not supported by the font, the font can be disabled.
 *
 * @since Webkul  Hotel & Reservation 1.0
 *
 * @return string Font stylesheet or empty string if disabled.
 */

// function hotelreservation_setup_fonts_url() {
//
//   $font_url = '';
//
//   /*
//
//    * Translators: If there are characters in your language that are not supported
//
//    * by Noto, translate this to 'off'. Do not translate into your own language.
//
//    */
//     $noto=_x( 'on', 'Noto Sans font: on or off', 'HotelReservation');
//
//     $pt_serif=_x( 'on', 'PT Serif font: on or off', 'HotelReservation');
//
//   if ( 'off' !== $noto || 'off' !== $pt_serif) {
//
//     if ( 'off' !== $noto )
//       $font_families[] = 'Noto Sans:400,700';
//
//     if ( 'off' !== $pt_serif )
//       $font_families[] = 'PT Serif:400,700';
//
//     $query_args = array(
//
//       'family' => urlencode( implode( '|', $font_families ) ),
//
//       'subset' => urlencode( 'latin,latin-ext' ),
//
//     );
//
//     $font_url = add_query_arg( $query_args, '//fonts.googleapis.com/css' );
//
//   }
//
//   return $font_url;
//
// }

function load_wp_media_files() {

  wp_enqueue_media();

   wp_enqueue_script( 'cloudkul-ajax-response', get_template_directory_uri() . "/assets/dist/js/back-end.min.js", array(), filemtime( get_template_directory() . '/assets/dist/js/back-end.min.js' ) );

}

add_action( 'admin_head', 'load_wp_media_files' );


 /**
 * Enqueue scripts and styles for the front end.
 *
 * @since Webkul HotelReservation 1.0
 */

 add_action( 'admin_enqueue_scripts', 'load_wp_files',10 );



 function load_wp_files() {

	wp_enqueue_media();

	wp_enqueue_script('script2', get_template_directory_uri() . '/assets/dist/js/add_details.min.js', array(), filemtime( get_template_directory() . '/assets/dist/js/add_details.min.js' ) );

	wp_enqueue_style( 'qa-backend-style', get_template_directory_uri() . '/assets/dist/css/qa-backend.min.css', array(), filemtime( get_template_directory() . '/assets/dist/css/qa-backend.min.css' ) );

	wp_localize_script( 'script2', 'wkthemeAjaxObj', array(
		'url'           => admin_url( 'admin-ajax.php' ),
		'nonce'         => wp_create_nonce( 'wktheme-admin-js-nonce' ),
		'assets_uri'    => get_template_directory_uri() . '/assets/',
	));

	wp_enqueue_style( 'webkulwidget-style', get_template_directory_uri() . '/assets/build/css/widget.css', array(), filemtime( get_template_directory() . '/assets/build/css/widget.css' ) );
	
 }


function hotelreservation_setup_scripts_styles() {

	// wp_deregister_script('jquery');
	// Add Source Sans Pro and Bitter fonts, used in the main stylesheet.

		wp_enqueue_script('hotelreservation_setup-jquery','https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js');

	// wp_enqueue_style( 'hotelreservation_setup-fonts', hotelreservation_setup_fonts_url(), array(), null );

	wp_enqueue_script( 'cloudkul-validate-js',"https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.14.0/jquery.validate.min.js");
	if (is_page('become-partner')) {
	  wp_enqueue_script( 'webkulMarketplace-recaptcha','https://www.google.com/recaptcha/api.js');
	}

		wp_enqueue_script('hotelreservation_setup-bootstrap-script','https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/js/bootstrap.min.js');

		wp_enqueue_style( 'hotelreservation-boostrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css');

	wp_enqueue_style('google-font-oxy', 'https://fonts.googleapis.com/css?family=Oxygen:300,400,500,700');

	wp_enqueue_style( 'webkultheme-style', get_stylesheet_uri(), array(), filemtime( get_template_directory() . '/style.css' ) );

	if ( is_single() ) {
		wp_enqueue_style( 'zoomerman-style', get_template_directory_uri() . '/assets/build/css/zoomerman.css', array(), '1.0.0' );

		wp_enqueue_script( 'zoomerman-script', get_template_directory_uri() . '/assets/build/js/zoomerman.js', '', '1.0', true);
	}


	wp_enqueue_script( 'hotelreservation_main_script', get_template_directory_uri() . '/assets/dist/js/main.min.js', '', filemtime( get_template_directory() . '/assets/dist/js/main.min.js' ), true);

	 wp_enqueue_script( 'qlo-ajax-response', get_template_directory_uri() . "/assets/dist/js/ajax-comments.min.js" );

	 wp_enqueue_script( 'qlo-smoothscroll', get_template_directory_uri() . "/assets/dist/js/smoothScroll.min.js", array(), filemtime( get_template_directory() . '/assets/dist/js/smoothScroll.min.js' ) );
	 wp_enqueue_style( 'dashicons' );

		//  wp_localize_script('hotelreservation_main_script', 'ajax_var', array(
		// 			 'url' => admin_url('admin-ajax.php'),
		// 			 'nonce' => wp_create_nonce('ajaxnonce')
		//  ));
		if(is_front_page() && is_home()){
			wp_enqueue_script('glider-js', 'https://cdnjs.cloudflare.com/ajax/libs/glider-js/1.7.3/glider.min.js', array(), '1', true);
			wp_enqueue_style( 'glider-css', 'https://cdnjs.cloudflare.com/ajax/libs/glider-js/1.7.3/glider.min.css', array(), '1.0.0' );
			
		}
		wp_enqueue_style('google-font-droid', 'https://fonts.googleapis.com/css?family=Droid+Serif:400,400i,700');
	}

	add_action( 'wp_enqueue_scripts', 'hotelreservation_setup_scripts_styles' );

  /*-------Register New Menu---------*/

function register_my_menu() {

  register_nav_menu('hotelreservation_main_menu',__( 'hotelreservation Main Menu' ));
  register_nav_menu('hotelreservation_sidebar_menu',__( 'hotelreservation Sidebar Menu' ));
  register_nav_menu('hotelreservation_products',__( 'Qlo Products' ));
  register_nav_menu('hotelreservation_addons',__( 'Add-Ons' ));
  register_nav_menu('hotelreservation_explore',__( 'Explore' ));
  register_nav_menu('hotelreservation_quicklinks',__( 'Quick Links' ));

}
add_action( 'init', 'register_my_menu' );


global $submenu_item_count;
global $curr_menu_as_parent;
$submenu_item_count = 0;
$curr_menu_as_parent = 0;

function qlo_mega_menu( $item_output, $item, $depth, $args )	 {

	// $rendered_menus = '';
	// if ( 1 === (int) $depth ) {
  //
	// 	global $submenu_item_count;
	// 	$submenu_item_count ++;
  //
	// 	// $locations = get_nav_menu_locations();
	// 	// $menu_id = $locations[ 'hotelreservation_main_menu' ];
	// 	// $menu_obj = wp_get_nav_menu_object( $menu_id );
	// 	// $menu_items = wp_get_nav_menu_items( $menu_obj->term_id );
  //
	// 	global $curr_menu_as_parent;
	// 	if ( $curr_menu_as_parent != $item->menu_item_parent ) {
  //
	// 		$curr_menu_as_parent = $item->menu_item_parent;
	// 		if( $item->description ){
	// 			$header = '<div class="submenu-header"></div>';
	// 			// $rendered_menus .= $header . $item_output . '<p class="description">'.$item->description.'</p>';
	// 			$item_output = '<li>marketplace</li><p class="description">'.$item->description.'</p>';
	// 		}
	// 	}	else{
	// 		$item_output .= '<p class="description">'.$item->description.'</p>';
	// 			// $rendered_menus = $item_output . '<p class="description">'.$item->description.'</p>';
	// 		}
  //
  //   //
	// 	// foreach ( $menu_items as $menu_li ) {
  //   //
	// 	// 	if ( $item->menu_item_parent === $menu_li->menu_item_parent ) {
	// 	// 		// console_log( $curr_menu_as_parent . ' == ' . $submenu_item_count . ' -- ' . ' true');
  //   //
	// 	// 	}
	// 	// }
	// }

	if( $item->description ){
		$item_output .= '<p class="description">'.$item->description.'</p>';
	}

	return $item_output;
}
add_filter( 'walker_nav_menu_start_el', 'qlo_mega_menu', 10, 4 );


// /*ajax for helpful article-YES or NO */
//
// add_action('wp_ajax_nopriv_post_like', 'post_like');
// add_action('wp_ajax_post_like', 'post_like');
// add_action('wp_ajax_nopriv_post_dislike', 'post_dislike');
// add_action('wp_ajax_post_dislike', 'post_dislike');
//
// function post_like(){
//   $nonce = $_POST['nonce'];
//   if ( ! wp_verify_nonce( $nonce, 'ajaxnonce' ) )
//         die ( 'Busted!');
//   if(isset($_POST['post_like'])){
// 		$post_id = $_POST['post_id'];
//     $meta_count = get_post_meta($post_id, "votes_count", true);
//     update_post_meta($post_id, "votes_count", ++$meta_count);
//       echo $meta_count;
//   }
//   else
//     echo "already";
//   exit;
// }
//
// function post_dislike(){
//     $nonce = $_POST['nonce'];
//     if ( ! wp_verify_nonce( $nonce, 'ajaxnonce' ) )
//         die ( 'Busted!');
//   if(isset($_POST['post_dislike'])){
//      $post_id = $_POST['post_id'];
//      $meta_count = get_post_meta($post_id, "votes_dislikecount", true);
//      update_post_meta($post_id, "votes_dislikecount", ++$meta_count);
//      echo $meta_count;
//   }
//   else
// 	echo "already";
//   exit;
// }
/* //ajax for helpful article-YES or NO */


/*--- Include Core Functions File---*/
require_once( dirname( __FILE__ ) . '/core/core-functions.php' );
/*--- //Include Core Functions File---*/

add_action('admin_init', 'add_custom_options');

function add_custom_options(){
	add_option('latest_version_value', '');
	add_option('latest_file_id', '');
	add_option('download_statistics', '');
	add_option('total_downloads', 0);

	add_option('gold_main_price', 249);
	add_option('gold_offer_price', '');
	add_option('platinum_main_price', 329);
	add_option('platinum_offer_price', '');
	add_option('platinum_offer_price', '');
	add_option('qlo_monthly_price', 25);

}

add_action('admin_menu' , function(){
	$hook = add_menu_page( __("Download Stats"), __("Download Stats"), "publish_posts", "download_stats",  "list_download_stats", "dashicons-download", 3 );
		add_action( "load-$hook", 'add_stats_options' );
} );

/* SCREEN OPTIONS */
function add_stats_options(){
	$option = 'per_page';
	$args = array(
		   'label' => 'Stats Per Page',
		   'default' => 10,
		   'option' => 'stats_per_page'
		   );
	add_screen_option( $option, $args );
}


add_filter('set-screen-option',  'set_stats_options', 10, 3);

function set_stats_options($status, $option, $value) {
			return $value;
}
/* //SCREEN OPTIONS */



function list_download_stats(){

				?>
				<div class="wrap">
						<h1>QLO Marketplace Download Stats<a><span class="dashicons dashicons-chart-bar" style="font-size: 50px;margin-top: -20px;margin-left: 12px;"></span></a></h1>
				</div>
				<div>
						<h4>Total Downloads : <?php echo get_option('total_downloads');?></h4>
				</div>

				<?php
				$obj = new stats_listing_class;
				$obj->prepare_items();
				$obj->display();
}


// DOWNLOAD STATS WP_LIST_TABLE
if( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class stats_listing_class extends WP_List_Table{

		public function __construct(){

			parent::__construct( array(
				'singular'  => 'downloadStat',
				'plural'    => 'downloadStats',
				'ajax'      => false,
			   ) );
		}

		private $stats_list;

		public function no_items() {
			_e( 'No Downloads yet, Sorry!' );
		}

		public function column_default( $item, $column_name ) {
				switch( $column_name ) {
					case 'ip':
						case 'user_name':
					case 'user_email':
						case 'download_count':
								return $item[ $column_name ];
						default:
								return print_r( $item, true );
				}
		}

		public function get_columns() {

				return $columns= array(
						  'ip'							=>	__('IP Address'),
						'user_name'				=>	__('Name'),
						  'user_email'			=>	__('Email ID'),
						  'download_count'	=>	__('Downloads'),
					 );
	  }

	  public function get_sortable_columns() {

				return $sortable = array(
								'user_name'				=>	array('user_name', false),
								'download_count'	=>	array('download_count', false),
						);
		}

		public function usort_reorder_data( $a, $b ) {

				$orderby  =   ( ! empty( $_GET['orderby'] ) ) ? $_GET['orderby'] : 'user_name';
			$order    =   ( ! empty($_GET['order'] ) ) ? $_GET['order'] : 'desc';
			$result   =   strcmp( $a[$orderby], $b[$orderby] );

				return ( $order === 'asc' ) ? $result : -$result;
		}

		public function prepare_items(){

				$columns  = $this->get_columns();
				$sortable = $this->get_sortable_columns();
				$hidden   = array();

				$this->_column_headers = array( $columns, $hidden, $sortable );
				$data = $this->fetch_stats();

		usort( $data, array( &$this, 'usort_reorder_data' ) );
		$per_page = $this->get_items_per_page('stats_per_page');
		$current_page  = $this->get_pagenum();
		$total_items   = count($data);
				$this->set_pagination_args( array(
			  'total_items'  =>  $total_items,
			  'per_page'     =>  $per_page
		  ) );
		$data = array_slice($data,( ($current_page-1)*$per_page ), $per_page);

		$this->items = $data;
		}

		private function fetch_stats(){

			 $this->stats_list = get_option('download_statistics');
	   return $this->stats_list;
		}
}
//  end of DOWNLOAD STATS WP_LIST_TABLE


/* downlaod ajax */
add_action('wp_ajax_nopriv_download', 'download_file_fn');
add_action('wp_ajax_download', 'download_file_fn');

function download_file_fn(){
		$nonce = $_POST['nonce'];
		if ( ! wp_verify_nonce( $nonce, 'ajaxnonce' ) )
					die ( 'Busted!');

		$name  = ( isset($_POST['name'] )) ? $_POST['name'] : '';
	  $email = ( isset($_POST['email'] )) ? $_POST['email'] : '';
		$ip=( !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];

		$stats_list = ( !empty(get_option('download_statistics')) ) ? get_option('download_statistics') : array();
		$tot_dwnld  =  get_option('total_downloads');

		$new_data = array(
						'ip'              =>   $ip,
						'user_name'       =>   $name,
						'user_email'      =>   $email,
						'download_count'  =>   1
			);
		if( empty($stats_list[0]) ){  /* it will run only when first entry is being made */
			unset($stats_list[0]);
					array_unshift($stats_list, $new_data);
		}
		elseif( false !== $key = array_search( $ip, array_column($stats_list, 'ip') ) ) {
					++$stats_list[$key]['download_count'];
		}
		else
					array_push($stats_list, $new_data);

		update_option('download_statistics', $stats_list);
		update_option('total_downloads', ++$tot_dwnld);

	  echo wp_get_attachment_url( get_option('latest_file_id') );
	  exit;
}
/* // end of downlaod ajax */

// add_action('wp_ajax_nopriv_get_client_ip', 'get_client_ip');
// add_action('wp_ajax_get_client_ip', 'get_client_ip');
//
// function get_client_ip(){
//   $ip = isset( $_POST['ip_add'] ) ? $_POST['ip_add'] : '';
//   add_option('client_ip_address',$ip);
//   exit;
// }

/* Submit payu money*/
add_action('wp_ajax_nopriv_in_download_file', 'in_download_file');
add_action('wp_ajax_in_download_file', 'in_download_file');

function in_download_file(){

	$nonce = $_POST['nonce'];
	if ( ! wp_verify_nonce( $nonce, 'ajaxnonce' ) )
		die ( 'Busted!');
		// e5iIg1jwi8 Test
		// KWTTMZ1q Live
	$SALT = "KWTTMZ1q";
	$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
	foreach($_POST as $key => $value) {

		$posted[$key] = $value;

	}

	if(empty($posted['hash']) && sizeof($posted) > 0) {

	  if(
			  empty($posted['key'])
			  || empty($posted['txnid'])
			  || empty($posted['amount'])
			  || empty($posted['firstname'])
			  || empty($posted['email'])
			  || empty($posted['productinfo'])
			  || empty($posted['surl'])
			  || empty($posted['furl'])
			  || empty($posted['service_provider'])
	  ) {

		$hash = 'error';

	  } else {

			$hashVarsSeq = explode('|', $hashSequence);
		$hash_string = '';
			foreach($hashVarsSeq as $hash_var) {
			$hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
			$hash_string .= '|';
		  }

		$hash_string .= $SALT;

		$hash = strtolower(hash('sha512', $hash_string));

	  }

	}

	echo $hash;
	exit;
}

// Admin area Upload zip
add_action('wp_dashboard_setup', 'upload_marketplace_zip_file');

function upload_marketplace_zip_file() {
	global $wp_meta_boxes;
	add_meta_box('marketplace_uploader',__( 'Upload new version of Qlo Marketplace' ),'mp_upload_form_ui','dashboard','normal','high');

		add_meta_box('cloud_hosting_pricing',__( 'Cloud Hosting Plan Pricing' ),'mp_cloud_hosting_plan_price','dashboard','normal','high');
}
function mp_cloud_hosting_plan_price(){

	if ( isset( $_POST['cloud_plan_pricing'], $_POST['gold_price'], $_POST['platinum_price'] )
				&& wp_verify_nonce( $_POST['cloud_plan_pricing'], 'action_set_price' )
		) {
				 update_option( 'gold_main_price', $_POST['gold_price'] );
				 update_option( 'gold_offer_price', $_POST['gold_price_off'] );
				 update_option( 'platinum_main_price', $_POST['platinum_price'] );
				 update_option( 'platinum_offer_price', $_POST['platinum_price_off'] );
				 update_option( 'qlo_monthly_price', $_POST['qlo_monthly_price'] );
		 }

	else{
		// The security check failed.
	}

	$g_m = get_option('gold_main_price');
	$g_o = get_option('gold_offer_price');
	$p_m = get_option('platinum_main_price');
	$p_o = get_option('platinum_offer_price');
	$monthly_price = get_option('qlo_monthly_price');

	?>
	<div class='inside'>

		<form id="featured_upload" method="post" action="">
			<label for="monthly-price">Monthly Subscription Price : </label><br>
			<input type="text" id="monthly-price" placeholder="Monthly Subscription Price" name="qlo_monthly_price" value="<?php echo $monthly_price; ?>" required><br><br>
			<label for="gold-plan"> Gold Plan : </label><br>
			<input type="text" id="gold-plan" placeholder="Main Price" name="gold_price" value="<?php echo $g_m ?>" required>
			<input type="text" id="gold-plan-offer" placeholder="Offer Price" name="gold_price_off" value="<?php echo $g_o ?>">
			<br><br>
			<label for="platinum-plan"> Platinum Plan : </label></br>
			<input type="text" id="platinum-plan" placeholder="Main Price" name="platinum_price" required value="<?php echo $p_m ?>">
			<input type="text" id="platinum-plan-offer" placeholder="Offer Price" name="platinum_price_off" value="<?php echo $p_o ?>">

			<?php wp_nonce_field( 'action_set_price', 'cloud_plan_pricing' ); ?>

			<input class="button button-primary" id="" name="" type="submit" value="Save Options" />
		</form>
	</div>
	<?php
}


function mp_upload_form_ui($post) {
	if ( isset( $_POST['marketplace_upload_nonce'], $_POST['qlomp_version'], $_FILES['qlomp_zip_file'] )
				&& wp_verify_nonce( $_POST['marketplace_upload_nonce'], 'action_upload_zip' )
		) {

					require_once( ABSPATH . 'wp-admin/includes/image.php' );
					require_once( ABSPATH . 'wp-admin/includes/file.php' );
					require_once( ABSPATH . 'wp-admin/includes/media.php' );

					$attachment_id = media_handle_upload( 'qlomp_zip_file', 0 );

					if( is_wp_error( $attachment_id ) ){
					}
					else{
						 $latest_version = $_POST['qlomp_version'];
						 $prev_file = get_option('latest_file_id');
						 wp_delete_attachment($prev_file);
						 update_option('latest_version_value', $latest_version);
						 update_option('latest_file_id', $attachment_id);
					}
		}

	else{
		// The security check failed.
	}
	?>
	<div class='inside'>

			<strong>Current Version : <a href="<?php echo wp_get_attachment_url(get_option('latest_file_id'));?>"><?php echo get_option('latest_version_value')?></a></strong>
			<br><br>

			<form id="featured_upload" method="post" action="" enctype="multipart/form-data">
				<input type="text" placeholder="Update Version" name="qlomp_version" required>
				<input type="file" name="qlomp_zip_file" value="file" required multiple="false" />
				<?php wp_nonce_field( 'action_upload_zip', 'marketplace_upload_nonce' ); ?>
				<input class="button button-primary" id="submit_zip_upload" name="submit_zip_upload" type="submit" value="Upload" />
			</form>
	</div>
	<?php
}
// end of Admin area Upload zip

function call_common_mp_ad_section(){
	?>
	<div class="marketplace-ad-banner">
			<div class="container">
				<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-10 text-center">
						<p class="para-1">Now get quick support &amp; assistance from experts &amp; other community members at <a href="https://forums.qloapps.com/" rel="noopener" target="_blank"><span>qloapps forum</span></a></p>
					</div>
					<div class="col-md-1"></div>
				</div>
			</div>
		</div>
	<?php
}


function display_banner_section(){
?>
<section class="home-banner-wrapper">
	  <div class="container">
		<div class="row">
		  <div class="col-md-12 text-center">
			<div class="home-banner-cover">
				<div class="home-banner-head-wrapper">
					<h1 class="white">Free Open Source Hotel Reservation & Online Booking System</h1>
					<p class="white">Take your Hotel Business Online with the help of QloApps</p>
					<a class="white btn btn-view-demo uc" href="<?php echo get_template_directory_uri().'/vdch.php'?>" title="View Demo" target="_blank">View Demo</a>
					<a class="white btn btn-download-ext btn-bgcolor uc" href="<?php echo get_template_directory_uri().'/cbch.php'?>" title="Download" target="_blank" rel="nofollow">Download</a>
					<a class="fo-logo-link" title="Qloapps review on financesonline.com" href="https://reviews.financesonline.com/p/qloapps/" alt="financesonline.com" rel="nofollow" target="_blank"><img style="margin:10px; padding: 10px; width: 215px" src="https://financesonline.com/seal/seal.png"></a>
				</div>
			</div>
		  </div>
		</div>
	  </div>
  </section>
<?php
}

function display_about_section(){
?>
<section class="wk-about-section wk-common-padding" id="about">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h3 class="text-center">About QloApps - Hotel Booking Engine</h3>
			</div>
			<div class="col-md-1"></div>
			<div class="col-md-10">
				<p class="text-center head-detail">QloApps is an Open Source software which launches a multilingual Hotel Booking Website within a matter of few minutes that too for Free. QloApps allows you to take and manage both on-desk and online hotel booking. It consist all the features which are required to take your hotel business to its pinnacle.</p>
			</div>
			<div class="col-md-1"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<img src="<?php echo get_template_directory_uri().'/images/mock-up.png'?>" class="img-responsive">
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</section>
<?php
}

function display_cloud_hosting_section(){

		$monthly_price = (get_option('qlo_monthly_price')!='') ? get_option('qlo_monthly_price') : '25';
	?>
  <section class="wk-cloud-section">
	  <article class="hosting section-padding">
		  <div class="container">
			<div class="row">
			  <div class="col-md-12">
				<h2 class="text-center space-0">Cloud Hosting</h2>
			  </div>
			  <div class="col-md-2"></div>
			  <div class="col-md-8">
				<p class="text-center head-detail">Host your QloApps hotel website on world's best Cloud Infrastructure Provider AWS (Amazon Web Services) and <span>get 1 Year Free Hosting </span> services Under AWS free tier plan. You also have the option to host your hotel website on GCP (Google Cloud Platform)
			  </div>
			  <div class="col-md-2"></div>
			</div>
			<div class="row text-center">
			  <div class="col-md-4 col-sm-6">
				<div class="image-wrapper">
				   <div class="cloud-bg cloud-bg-1"></div>
				  <p>Better Performance</p>
				</div>
			  </div>
			  <div class="col-md-4 col-sm-6">
				<div class="image-wrapper">
				  <div class="cloud-bg cloud-bg-2"></div>
				  <p>Secure System for your hotel booking website</p>
				</div>
			  </div>
			  <div class="col-md-4 col-sm-6">
				<div class="image-wrapper">
				  <div class="cloud-bg cloud-bg-3"></div>
				  <p>Increase number of bookings with faster service</p>
				</div>
			  </div>
			</div>
			<div class="row">
			  <div class="col-md-12 text-center">
				<a href="cloud-hosting" class="white-button uc">Host Your Website Now</a>
			  </div>
			</div>
		  </div>
	</article>
</section>
	<?php
}

function display_feature_section(){
	?>
		<section class="wk-feature-section section-padding text-center">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h3 class="space-0">Features</h3>
					<p class="mid-para">QloApps has all the features that will increase the efficiency and effectiveness of your Hotel Business. With many alluring features for both the Admin and User, QloApps will guarantee the success of the hotel booking website. </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 text-center">
					<a href="features" class="btn-download-ext rmargin-10 uc">View More Features</a>
          <a href="JavaScript:void(0)" class="sugg-btn white btn-bgcolor btn-download-ext uc">Suggest Any Feature</a>
				</div>
			</div>
			<div class="row text-center">
				<br><br><br>
				<div class="qa-addon-grid">
				<?php
					$query_args = array('post_type'=>'features','post_status'=>'publish','order'=>'ASC', 'showposts'=>'6');

						$the_query = new WP_Query( $query_args );

						if ( $the_query->have_posts() ) :

								while($the_query->have_posts() ) :$the_query-> the_post();

									?>
									<div class="image-wrapper">
										<div class="border-circle">
											<?php
												$url = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()));

											if ( !empty($url)) : ?>

											<img src="<?php echo $url;?>" class="img-responsive">

											<?php endif;?>
										</div>
										<h4><?php echo get_the_title();?></h4>
										<p class="head-detail"> <?php the_excerpt();?></p>
									</div>
									<!-- <div class="feature_icon_wrap">
										</div> -->
									<?php

								endwhile;

						endif;
				?>
				</div>
			</div>
		</div>
		</section>
	<?php
}


function display_feature_suggestion_form(){
  ?>
  <section class="section-padding fearure-suggestions">
  	<div class="container">
  		<div class="row">
  			<div class="col-md-12">
  				<div class="fearure-containt">
  					<span class="form-close">
  						<img src="<?php echo get_template_directory_uri() . '/images/Close-icon.png';?>">
  					</span>
  					<h1 class="text-center">Feature Suggestion</h1>
  					<p class="text-center">Our aim is to help our users to attain what they desire. So we like to hear it from you. Please suggest a feature which you feel should be there in QloApps.</p>

            <?php echo do_shortcode( '[contact-form-7 id="4178" title="Feature Suggestion"]' ); ?>

  					<!-- <div id="uv_top_message" class="uv_load">
  						<img src="https://cdn.uvdesk.com/bundles/webkuldefault/images/cssImages/loader.gif">
  					</div>

  					<script id="15b923310630175b923310630c7" src="https://webkul.uvdesk.com/apps/form-builder/en/form/15b923310630175b923310630c7?removePlaceholders=1&info=0" async="async" > </script> -->

  				</div>
  			</div>
  		</div>
  	</div>
  </section>

  <?php
}

function wk_become_partner_section(){
  ?>
  <section class="wk-become-partner-section section-padding text-center">
	  <div class="container">
		<h3>Our Partners</h3>
		<p class="mid-para">A single effort may fail but a collective effort is the guarantee of success. Your contribution can be of great significance. Our partnership should aim the mutual benefits and the benefit of the community. So let us make the Hospitality Industry great together.</p>
		<a href="<?php echo site_url() . '/become-partner'; ?>" class="btn btn-bgcolor white normal-btn-style">BECOME A PARTNER</a>
	</div>
  </section>
  <?php
}

function display_teaser_video_section(){
  ?>




<section class="home-wk-teaser-video-section wk-common-padding" id="how-it-works">
  <div class="container">
	<div class="row">
	  <div class="col-md-2"></div>
	  <div class="col-md-8">
		<h2 class="text-center white">Watch How your Online Booking &amp; Reservation Store Can be Established</h2>
	  </div>
	  <div class="col-md-2"></div>
	</div>
	<div class="row">
	  <div class="col-md-12">
		<div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModal" aria-hidden="true">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-body">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<div>
				  <video id="modal-video-player" controls="" poster="<?php echo get_template_directory_uri() . '/images/poster-image.jpg'; ?>" preload="1">
					<source src="https://cdn.uvdesk.com/qloapps/qloapps.mp4" type="video/mp4">
				  </video>
				</div>
			  </div>
			</div>
		  </div>
		</div>
		<div class="text-center">
		  <a href="#" class="open-video" data-toggle="modal" data-target="#videoModal" data-thevideo="https://www.youtube.com/embed/LyVmg-NhEX0" title="video teaser">
			<img src="<?php echo get_template_directory_uri().'/images/home-icon-play.png'?>" class="home-icon-play img-responsive">
		</a>
		</div>
		<p class="white text-center">Watch Our Teaser Video</p>
	  </div>
	</div>
  </div>
</section>
<?php
}

function wk_add_story_section(){
  ?>
<section class="wk-add-story-section wk-common-padding text-center">
  <div class="container">
	<div class="row">
	  <div class="col-md-12">
		<h3>Share Your Success Story</h3>
	  </div>
	  <div class="col-md-2"></div>
	  <div class="col-md-8">
		<p class="head-detail">Unicorn crucifix tumblr intelligentsia, readymade kogi stumptown microdosing. Semiotic jean shorts street art YOLO jianbing single origin</p>
	<a href="<?php echo site_url() . '/register-success-story'; ?>" class="btn btn-bgcolor white normal-btn-style">Add Your Story</a>
	  </div>
	  <div class="col-md-2"></div>
	</div>
  </div>
</section>
  <?php
}

function display_contact_section( $string = NULL){
  ?>
  <section class="wk_contact_us_section wk-common-padding">
	<div class="container">
	  <div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6 text-center">
			<p class="contact-us-p"><?php echo $string;?></p>
			<a href="<?php echo site_url() ?>/contact" class="contact-us-btn">Contact Us</a>
		</div>
		<div class="col-md-3"></div>
	  </div>
	</div>
  </section>
  <?php
}
/**
 * Register our sidebars and widgetized areas.
 */

function sidebar_widget() {



  register_sidebar( array(

	'name'          => 'Hotel Reservation Main Sidebar',

	'id'            => 'hotel_main_sidebar',

	'before_widget' => '<div>',

	'description' => __( 'An optional custom widget area for your site', 'hotel_sidebar' ),

	'after_widget'  => '</div>',

	'before_title'  => '<h2 class="rounded">',

	'after_title'   => '</h2>',

  ) );



  register_sidebar( array(

	'name'          => 'Hotel Reservation Single Page Sidebar',

	'id'            => 'hotel_singlesidebar',

	'before_widget' => '<div>',

	'description' => __( 'An optional custom widget area for your site provides best facility', 'hotel_sidebar1' ),

	'after_widget'  => '</div>',

	'before_title'  => '<h2 class="rounded">',

	'after_title'   => '</h2>',

  ) );

}

add_action( 'widgets_init', 'sidebar_widget' );

function create_custom_post_type() {

  $labels = array(
    'name'                  => _x( 'Features', 'features', 'hotelreservation' ),
    'singular_name'         => _x( 'Features', 'features', 'hotelreservation' ),
    'menu_name'             => __( 'Features', 'hotelreservation' ),
    'name_admin_bar'        => __( 'Features', 'hotelreservation' ),
  );

  $args = array(
    'labels'             => $labels,
    'description'        => __( 'Adding For Features.', 'HotelReservation' ),
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'features','with_front' => false),
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => true,
    'menu_position'      => 5,
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
  );

  $partner_labels = array(
    'name'                  => _x( 'Partners', 'partners', 'hotelreservation' ),
    'singular_name'         => _x( 'Partners', 'partners', 'hotelreservation' ),
    'menu_name'             => __( 'Partners', 'hotelreservation' ),
    'name_admin_bar'        => __( 'Partners', 'hotelreservation' ),
  );

  $partner_arg = array(
    'labels'             => $partner_labels,
    'description'        => __( 'Adding Partners.', 'HotelReservation' ),
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'our-partners','with_front' => false),
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => true,
    'menu_position'      => 5,
    'menu_icon'          => 'dashicons-groups',
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
  );


  $story_labels = array(
    'name'                  => _x( 'Success Stories', 'success stories', 'hotelreservation' ),
    'singular_name'         => _x( 'Success Stories', 'success stories', 'hotelreservation' ),
    'menu_name'             => __( 'Success Stories', 'hotelreservation' ),
    'name_admin_bar'        => __( 'Success Stories', 'hotelreservation' ),
    );

    $story_arg = array(
    'labels'             => $story_labels,
    'description'        => __( 'Adding Success Stories.', 'HotelReservation' ),
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'success-stories','with_front' => false),
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => true,
    'menu_position'      => 5,
    'menu_icon'          => 'dashicons-feedback',
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
    );

    register_post_type( 'features', $args );
    register_post_type( 'our-partners', $partner_arg );
    register_post_type( 'success-stories', $story_arg );
    // register_post_type( 'webinar', $webinar_arg );
 }

add_action('init','create_custom_post_type');


//making the meta box (Note: meta box != custom meta field)
function wpse_add_custom_meta_box() {
   add_meta_box(
	   'mockup_img',       // $id
	   'Mock Up Image',                  // $title
	   'mockup_image_show',  // $callback
	   'features',                 // $page
	   'side',                  // $context
	   'high'                     // $priority
   );
  $posttype_name = ( get_post_type() === 'success-stories' ) ? 'Customer Details' : 'Partner Details';
	add_meta_box(
	   'partner_desc',       // $id
	   $posttype_name,                  // $title
	   'partner_description',  // $callback
	   array('our-partners','success-stories'),                 // $page
	   'side',                  // $context
	   'high'                     // $priority
   );
  add_meta_box(
	   'customer_review',       // $id
	   'Customer Review',                  // $title
	   'customer_review',  // $callback
	   'success-stories'                // $page
	);
	add_meta_box( 'sm_meta', __( 'Featured Posts' ), 'sm_meta_callback', 'post' );
	add_meta_box( 'wk_post_links', __( 'Post page links' ), 'wk_post_links', 'post', 'side','high' );
	
	add_meta_box( 'qlo_blog_filters', __( 'Blog Group' ), 'wkqlo_blog_filters', 'post', 'side', 'high' );

	add_meta_box( "qa-addons-ext-opts", "Addons Extra Option", "qa_addons_opts_cb", "add-ons", "side", "high");
}
add_action('add_meta_boxes', 'wpse_add_custom_meta_box');


include_once(get_template_directory().'/widget/popular-tags.php');
include_once(get_template_directory().'/widget/popular_posts.php');
include_once(get_template_directory().'/widget/subscribe_newsletter.php');
include_once(get_template_directory().'/widget/wk-search.php');

//showing custom form fields
add_action( 'current_screen', function(){
	
	if ( 'edit' === get_current_screen()->base ) {
		
		if ( isset( $_GET['patch_action'] ) && 'resolve_filters' === $_GET['patch_action'] )  {

			$args = array(
				'fields'         => 'ids',
				'posts_per_page' => '50',
				'meta_query'     => array(
					'relation'       => 'OR',
						array(
						'key'     => 'qlo_filter',
						'compare' => 'NOT EXISTS',
						'value'   => '' // This is ignored, but is necessary...
					),
				)
			);

			$all_ids = new WP_Query( $args );

			foreach( $all_ids->posts as $id ) {
				update_post_meta( $id, 'qlo_filter', 'article' );
			}
			
			echo '<center><br><br><p>"action" => "resolve_fitlers" ----> COMPLETED</p><br>';
			echo '<p>Total Posts in a batch = ' . $all_ids->post_count . '</p><br><br>';
			echo '<p><b>Redirecting in <span id="timer">5</span> seconds.</b></p></center>';

			wp_reset_postdata();
			?>
			<script>
			window.onload = function() {
				i = 5;
				area = document.getElementById('timer');
				timer = setInterval( function() {
					i--;
					area.innerText = i;
					if ( 0 === i ) {
						window.location.href = "<?php echo admin_url('edit.php'); ?>";
					}
				}, 1000 );
			};
			</script>
			<?php
			die();
		}
	}
});

function wkqlo_blog_filters( $post ) {

	wp_nonce_field( 'wkqlo_filters','wkqlo_filters_nonce' );

	$filter = get_post_meta( $post->ID, 'qlo_filter', true );
	?>
	<label>
		<input required type='radio' name="qlo_filter" value="article" <?php checked( $filter, 'article'); ?>>
		<strong>Article</strong>
	</label><br><br>
	<label>
		<input required type='radio' name="qlo_filter" value="doc" <?php checked( $filter, 'doc' ); ?>>
		<strong>Doc</strong>
	</label><br><br>
<?php
}


function mockup_image_show() {
	global $post;

	// Use nonce for verification to secure data sending
	wp_nonce_field( basename( __FILE__ ), 'wpse_our_nonce' );
	$mockup_image=get_post_meta(get_the_id(),'mockup-image',true);
	$dir=wp_upload_dir();
	$mockup_img=$dir['baseurl'].'/'.$mockup_image;
	?>

	<!-- my custom value input -->
	<img src="<?php if(!empty($mockup_image))echo $mockup_img?>" alt="<?php echo get_the_title();?>" class="mock-up-url" width="250"><br>
	<input type="text" class="mockup_image" place name="mokup-image" value="<?php if(!empty($mockup_image))echo $mockup_img?>" width="100%"><br><br>
	<button class="button button-primary upload-mock-up">Upload Mock Up</button>
	<?php
}

//showing partner details
function partner_description() {
	global $post;

	// Use nonce for verification to secure data sending
	wp_nonce_field( basename( __FILE__ ), 'wpse_our_nonce' );

	$partner_url=get_post_meta(get_the_id(), 'partner-url','true');

	$dir=wp_upload_dir();
	$partner_logo=get_post_meta(get_the_id(),'partner-logo',true);
	$partner_logo_l=$partner_logo;

	$country_image=get_post_meta(get_the_id(),'country-image',true);
	$country_img=$country_image;

	$country_name=get_post_meta(get_the_id(), 'partner-country','true');
  $customer_name = get_post_meta( get_the_id(), 'customer-name','true' );
  $customer_image = get_post_meta( get_the_id(), 'customer-image','true' );
  $customer_image = ( ! empty( $customer_image ) ) ? wp_upload_dir()['baseurl'] . $customer_image : '';
  $customer_desig = get_post_meta( get_the_id(), 'customer-designation','true' );

	?>

	<!-- my custom value input -->
  <?php
  if( get_post_type() === 'success-stories'){
	?>

	<label for="customer-name"><?php _e( 'Name:' ); ?></label><br>
	<input type="text" class="customer_name" name="customer-name" value="<?php if(!empty($customer_name))echo $customer_name; ?>" width="100%"><br /><br />

	<label for="customer-image"><?php _e( 'Upload Image:' ); ?></label><br>
	<img src="<?php if( ! empty( $customer_image ) ) echo $customer_image; ?>" alt="<?php echo get_the_title();?>" class="customer-image-url" width="250"><br /><br />
	<button class="button button-primary customer-image">Upload Image</button>
	<input type="hidden" class="customer_image" name="customer-image" value="<?php if(!empty($customer_image))echo $customer_image; ?>" width="100%"><br><br>

	<label for="customer-designation"><?php _e( 'Designation:' ); ?></label><br>
	<input type="text" class="customer_desig" name="customer-designation" value="<?php if(!empty($customer_desig))echo $customer_desig; ?>" width="100%"><br /><br />

	<?php
  }
  ?>
	<label for="partner-url"><?php _e( 'Url:' ); ?></label><br>
	<input type="text" class="partner_url" place name="partner-url" value="<?php if(!empty($partner_url))echo $partner_url ?>" width="100%"><br><br>

  <label for="partner-log"><?php _e( 'Upload Logo' ); ?></label><br>
	<img src="<?php if(!empty($partner_logo))echo $partner_logo_l?>" alt="<?php echo get_the_title();?>" class="logo-url" width="250"><br>
	<button class="button button-primary partner-logo">Upload Logo</button>
	<input type="hidden" class="partner_logo" place name="partner-log" value="<?php if(!empty($partner_logo))echo $partner_logo_l?>" width="100%"><br><br>

  <label for="country-image"><?php _e( 'Upload Country Flag' ); ?></label><br>
	<img src="<?php if(!empty($country_image))echo $country_img?>" alt="<?php echo get_the_title();?>" class="country-url" width="auto"><br>
	<button class="button button-primary country-image">Upload Flag</button><br><br>
	<input type="hidden" class="country_image" place name="country-image" value="<?php if(!empty($country_image))echo $country_img?>" width="100%">

	<label for="partner-country"><?php _e( 'Country Name:' ); ?></label><br>
	<input type="text" class="partner_country" place name="partner-country" value="<?php if(!empty($country_name))echo $country_name ?>" width="100%">
	<?php
}

function customer_review(){
  wp_nonce_field( basename( __FILE__ ), 'wpse_our_nonce' );
  $customer_review = get_post_meta( get_the_id(), 'customer-review','true' );
  ?>
  <textarea rows="3" cols="40" name="customer-review" id="customer_review" style="width:100%;"><?php echo ( ! empty( $customer_review ) ) ? $customer_review : ''; ?></textarea>

  <?php
}
function wpse_save_meta_fields( $post_id ) {

  // verify nonce
  if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
	  return 'nonce not verified';

  // check autosave
  if ( wp_is_post_autosave( $post_id ) )
	  return 'autosave';

  //check post revision
  if ( wp_is_post_revision( $post_id ) )
	  return 'revision';

  // check permissions
  if ( 'features' == $_POST['features'] ) {
	  if ( ! current_user_can( 'edit_page', $post_id ) )
		  return 'cannot edit page';
	  } elseif ( ! current_user_can( 'edit_post', $post_id ) ) {
		  return 'cannot edit post';
  }

	  $dir=wp_upload_dir();
	  $partner_logo = $_POST['partner-log'];
	  $country_image = $_POST['country-image'];

	  $partner_url = $_POST['partner-url'];
	  update_post_meta($post_id,'partner-url',$partner_url);

		$partner_country = $_POST['partner-country'];
		update_post_meta($post_id,'partner-country',$partner_country);

	if( get_post_type() === 'success-stories' ){

	  $customer_name = $_POST['customer-name'];
	  update_post_meta( $post_id,'customer-name',$customer_name );

	  $customer_image = $_POST['customer-image'];
	  $customer_image = str_replace(wp_upload_dir()['baseurl'],"",$customer_image);
	  update_post_meta( $post_id,'customer-image',$customer_image );

	  $customer_desig = $_POST['customer-designation'];
	  update_post_meta($post_id,'customer-designation',$customer_desig);

	}

	$customer_review = $_POST['customer-review'];
	update_post_meta($post_id,'customer-review',$customer_review);

	  update_post_meta($post_id,'partner-logo',$partner_logo);
	  update_post_meta($post_id,'country-image',$country_image);


  //so our basic checking is done, now we can grab what we've passed from our newly created form
   $dir=wp_upload_dir();
  $mockup_image = $_POST['mokup-image'];
   $mockup_img=str_replace($dir['baseurl'],"",$mockup_image);
  update_post_meta($post_id,'mockup-image',$mockup_img);

}
add_action( 'save_post', 'wpse_save_meta_fields' );
add_action( 'new_to_publish', 'wpse_save_meta_fields' );

/* custom comments */

function hotelReservation_comment($comment, $args, $depth) {

   $GLOBALS['comment'] = $comment;

$status = wp_get_comment_status( $comment->comment_ID );

if ( $status == "approved" ) {
	?>
   <!--Custom Response-->

		  <div class="custom-response-container" id='comment-<?php comment_ID();?>'>

  <!--Genric-->

							<div class="generic clearfix">

								<!--Pic-->

								<div class="generic-pic">

									<img src="<?php echo wk_get_avatar(get_avatar( get_avatar( get_the_author_meta( 'ID' )))); ?>" alt="<?php echo comment_author();?>" title="<?php echo comment_author();?>">

								</div>

								<!--Pic-->

								<!--Details-->

								<div class="generic-details">

									<h5 class="text-capitalize"><?php echo comment_author();?></h5>

									<span><?php echo human_time_diff( get_comment_time( 'U'),current_time('timestamp') );?> ago</span>

									<!--Comment-->

								   <?php comment_text() ?>

									<!--Comment-->

								</div>

								<!--Details-->


							</div>

							<!--Generic-->
							<div class="horizontal-line1 margin-top-15"></div>
							<div class="horizontal-line2 margin-bottom-15"></div>

							</div>

			<!--Custom Response-->

		  <!--Seprator--><span class="seprator"></span><!--Seprator-->
<?php
		}

	}

function wk_get_avatar($get_avatar){

	preg_match("/src='(.*?)'/i", $get_avatar, $matches);

	return $matches[1];

}

add_filter( 'avatar_defaults', 'hotelReservationavatar' );


	function hotelReservationavatar($avatar_defaults) {

	$myavatar = 'https://s.gravatar.com/avatar/91d231e9101d39a5f6e4dfc3d3ac1bab?s=80';

	$avatar_defaults[$myavatar] = "hotelReservation avtar";

	return $avatar_defaults;

	}


/**
 * Blogs navigation menus
 *
 * @param [string] $blog_type
 * @return HTML
 */
function blog_navbar( $blog_type = null ) {
	?>
	<section class="blog-navigation-section">
		<div class="container">
			<div class="blog-nav-grid">
				<div class="blog-filters">
					<!-- Responsive Blog Menu Toggle -->
					<ul class="dropbtn"><li></li><li></li><li></li></ul>
					<!--// Responsive Blog Menu Toggle -->
					
					<!-- Responsive Blog Menu -->
					<div id="blogDropdown" class="dropdown-content">
						<ul>
							<li><a class="<?php if ( isset( $blog_type ) && $blog_type == 'all' ) echo 'item-active'; ?>" href="<?php echo get_site_url().'/blog/'; ?>">All Blogs</a></li>

							<li><a class="<?php if ( isset( $blog_type ) && $blog_type == 'popular' ) echo 'item-active'; ?>" href="<?php echo get_site_url() . '/blog/popular/'; ?>">Most Viewed</a></li>

							<li><a class="<?php if ( isset( $blog_type ) && $blog_type == 'recent' ) echo 'item-active'; ?>" href="<?php echo get_site_url() . '/blog/recent/'; ?>">Recent</a></li>
							
							<li><a class="<?php if ( isset( $blog_type ) && $blog_type == 'articles' ) echo 'item-active'; ?>" href="<?php echo get_site_url() . '/blog/articles/'; ?>">Articles</a></li>

							<li><a class="<?php if( isset( $blog_type ) && $blog_type == 'docs' ) echo 'item-active'; ?>" href="<?php echo get_site_url().'/blog/docs/'; ?>">Docs</a></li>

						</ul>
					</div>
					<!--// Responsive Blog Menu -->


					<!-- Blog Menu -->
					<ul class="main-filter">
						<li><a class="<?php if ( isset( $blog_type ) && $blog_type == 'all' ) echo 'item-active'; ?>" href="<?php echo get_site_url().'/blog/'; ?>">All Blogs</a></li>

						<li><a class="<?php if ( isset( $blog_type ) && $blog_type == 'popular' ) echo 'item-active'; ?>" href="<?php echo get_site_url() . '/blog/popular/'; ?>">Most Viewed</a></li>

						<li><a class="<?php if ( isset( $blog_type ) && $blog_type == 'recent' ) echo 'item-active'; ?>" href="<?php echo get_site_url() . '/blog/recent/'; ?>">Recent</a></li>
						
						<li><a class="<?php if ( isset( $blog_type ) && $blog_type == 'articles' ) echo 'item-active'; ?>" href="<?php echo get_site_url() . '/blog/articles/'; ?>">Articles</a></li>

						<li><a class="<?php if( isset( $blog_type ) && $blog_type == 'docs' ) echo 'item-active'; ?>" href="<?php echo get_site_url().'/blog/docs/'; ?>">Docs</a></li>

					</ul>
					<!--// Blog Menu -->

				</div>
				<div class="blog-navbar-actions">
					<span class="icon-action reading-list-count no-after" data-count="0">
						<a class="icon-action-reading-list" href="<?php echo esc_url( home_url( 'reading-list' ) ); ?>"></a>
					</span>
					<div class="blog-search-subscribe-btn">
						<?php get_search_form(); ?>
					</div>
				</div>
			</div>
			<!-- <div class="row">
				<div class="col-md-7 col-sm-6 col-xs-2">
				</div>
				<div class="col-md-5 col-sm-6 col-xs-10 text-right">
				</div>
			</div> -->
		</div>
	</section>
	<?php
}



//


// Modify excerpt And Its Length

function hotelreservation_excerpt_more($more)
{
	global $post;
	if($post->post_type == 'our-partners')
	  return ' <a class="main-color" title="read more" href="'. get_permalink() . '"> More Info...</a>';
	elseif( get_post_meta($post->ID, 'meta-featured-post', true) ){
			if( get_post_meta($post->ID, 'meta-featured-post', true) ==='yes')
				 return;
	}
	return ' <a class="main-color" title="Read more" href="'. get_permalink() . '">[...]</a>';
}


add_filter('excerpt_more', 'hotelreservation_excerpt_more');

function new_excerpt_length($length) {

  global $post;
  if ($post->post_type == 'post'){
	if( get_post_meta($post->ID, 'meta-featured-post', true) ){
	  if( get_post_meta($post->ID, 'meta-featured-post', true) ==='yes')
		 return 25;
	}
	return 13;
  }
  elseif ($post->post_type == 'our-partners')
	return 22;
  else
	return 14;

}
add_filter('excerpt_length', 'new_excerpt_length');

function get_excerpt($limit, $source = null){
	  global $post;
	if($source == "content" ? ($excerpt = get_the_content()) : ($excerpt = get_the_excerpt()));
	$excerpt = preg_replace(" (\[.*?\])",'',$excerpt);
	$excerpt = strip_shortcodes($excerpt);
	$excerpt = strip_tags($excerpt);
	$excerpt = substr($excerpt, 0, $limit);
	$excerpt = substr($excerpt, 0, strripos($excerpt, " "));
	$excerpt = trim(preg_replace( '/\s+/', ' ', $excerpt));
	$excerpt = $excerpt.' <a href="'.get_permalink($post->ID).'">[...]</a>';
	return $excerpt;
}

// Most Popular Posts

function getPostViews($postID){
	$count_key = 'post_views_count';
	$count = get_post_meta($postID, $count_key, true);
	if($count==''){
		delete_post_meta($postID, $count_key);
		add_post_meta($postID, $count_key, '0');
		return "0 View";
	}
	return $count.'Views';
}


function setPostViews($postID) {
	$count_key = 'post_views_count';
	$count = get_post_meta($postID, $count_key, true);
	if($count==''){
		$count = 0;
		delete_post_meta($postID, $count_key);
		add_post_meta($postID, $count_key, '0');
	}else{
		$count++;
		update_post_meta($postID, $count_key, $count);
	}
}


function get_pagenumber_args() {

	if ( get_query_var( 'paged' ) ) {
		$paged =  get_query_var( 'paged' );
	} else if( get_query_var( 'page' ) ) {
		$paged =  get_query_var('page');
	} else {
		$paged = 1;
	}
	return $paged;
}

function hotelreservation_pagination($tot_post) {

		$prev_arrow = '&#8592;';
		$next_arrow = '&#8594;';

		global $wp_query;

		if( $tot_post > 0 ){
			$total = $tot_post/get_option('posts_per_page');
		}
		else{
			$total = $wp_query->max_num_pages;
		}

		$big = 9999999999999; // need an unlikely integer
		if( $total > 1 )  {
		  if( !$current_page = get_query_var('paged') )
			 $current_page = 1;
		  if( get_option('permalink_structure') ) {
			   $format = 'page/%#%/';
		  } else {
			   $format = '&paged=%#%';
		  }
			echo paginate_links(array(
				'base'          => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
				'format'        => $format,
				'current'       => max( 1, get_query_var('paged') ),
				'total'         => ceil($total),
				'mid_size'      => 3,
				'type'          => 'list',
				'prev_text'     => $prev_arrow,
				'next_text'     => $next_arrow,
			 ) );
		}
}

function sm_meta_callback( $post ) {
		$featured = get_post_meta( $post->ID );
		?>
		<p>
		<div class="sm-row-content">
			<label for="meta-checkbox">
				<input type="checkbox" name="meta-featured-post" id="meta-checkbox" value="yes" <?php if ( isset ( $featured['meta-featured-post'] ) ) checked( $featured['meta-featured-post'][0], 'yes' ); ?> />
				<?php _e( 'Featured this post', 'sm-textdomain' )?>
				<?php wp_nonce_field( 'theme_meta_box_nonce', 'sm_nonce' ); ?>
			</label>
		</div>
		</p>
		<?php
}


add_action( 'save_post', 'sm_meta_save' );
function sm_meta_save( $post_id ) {
			global $wpdb;
		// Checks save status
		$is_autosave = wp_is_post_autosave( $post_id );
		$is_revision = wp_is_post_revision( $post_id );
		$is_valid_nonce = ( isset( $_POST[ 'sm_nonce' ] ) && wp_verify_nonce( $_POST[ 'sm_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
		// Exits script depending on save status
		if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
			return;
		}
		// Checks for input and saves
		if( isset( $_POST[ 'meta-featured-post' ] ) ) {
			update_post_meta( $post_id, 'meta-featured-post', 'yes' );
		} else {
			update_post_meta( $post_id, 'meta-featured-post', 'no' );
		}
		$query_args = get_posts( array(
				'numberposts' => -1
			)
		);
		foreach ($query_args as $key => $value) {
			if ( isset( $_POST[ 'meta-featured-post' ] ) && $value->ID != $post_id ) {
					update_post_meta( $value->ID, 'meta-featured-post', 'no' );
			}
		}
}

function author_initials(){

					$alpha_col_swatches = array(
						'A' => '#00BCD4', 'B' => '#3F51B5', 'C' => '#8BC34A',
						'D' => '#009688', 'E' => '#4CAF50', 'F' => '#512DA8',
						'G' => '#F57C00', 'H' => '#9E9E9E', 'I' => '#7C4DFF',
						'J' => '#FF5722', 'K' => '#E67E22', 'L' => '#34495E',
						'M' => '#9B59B6', 'N' => '#3498DB', 'O' => '#1ABC9C',
						'P' => '#795548', 'Q' => '#95A5A6', 'R' => '#2980B9',
						'S' => '#FBC02D', 'T' => '#FF9800', 'U' => '#8E44AD',
						'V' => '#E74C3C', 'W' => '#FF4081', 'X' => '#778485',
						'Y' => '#2C3E50', 'Z' => '#0C594A', 'num' => '#EF6C98'
					);
			  $author = get_the_author_meta('user_nicename', get_post(get_the_ID())->post_author);
		  $letters = explode(" ", $author);
		  $initials = ( count($letters) == 1) ? $letters[0][0] : $letters[0][0].$letters[1][0];
					$initials = strtoupper($initials);
					$alpha_col = ( ctype_alpha($initials[0]) )  ?  $alpha_col_swatches[$initials[0]]  : $alpha_col_swatches['num'] ;
		  return $initials.'-'.$alpha_col;
}

function get_icon_name_time_info(){


	  $name_icon =explode('-', author_initials() );
			$author_ID = get_the_author_meta('ID', get_post(get_the_ID())->post_author);
	  ?>
	  <span style="background-color: <?php echo $name_icon[1]; ?>" class="name-icon"><?php echo $name_icon[0];?></span>
	  <span class="name-date">
		  <span class="author-name"><a href="<?php echo get_author_posts_url($author_ID); ?>"><?php echo get_the_author_meta('display_name', get_post(get_the_ID())->post_author); ?></a></span>
		  <time class="post-time" datetime="<?php echo get_the_date(the_Date());?>"><?php echo get_the_date(the_Date()); ?> </time>
	  </span>
	<?php
}

function display_post_content_info(){

  $id = get_the_ID();
  ?>
	  <div class="icon-bar-wrapper">
		  <?php get_icon_name_time_info(); ?>
		  <span class="views-likes">
			  <?php $total_views=get_post_meta(get_the_ID(),'post_views_count',true);
								?>
								<span class="total-views"><span class="glyphicon glyphicon-eye-open"></span>(<?php echo $total_views;?>)</span>
								<span class="draft-love-wrap">
									<?php echo getPostLikeLink(get_the_ID());?>
								</span>
		  </span>
	  </div>

<?php
}


add_action('wp_ajax_nopriv_post-like', 'post_like');
add_action('wp_ajax_post-like', 'post_like');

$timebeforerevote = 1440; // = 2 hours

function post_like(){

   $nonce = $_POST['nonce'];
	if ( ! wp_verify_nonce( $nonce, 'ajaxnonce' ) )
		die ( 'Busted!');

  if(isset($_POST['post_like'])){

	if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}

	$ip=explode(',', $ip);
	$post_id = $_POST['post_id'];
	$meta_IP = get_post_meta($post_id, "voted_IP");
	if(!isset($meta_IP[0]))
		 $voted_IP = array();
	else{
		 $voted_IP = $meta_IP[0];
	}
	$meta_count = get_post_meta($post_id, "votes_count", true);

	if(!hasAlreadyVoted($post_id)){

	  $voted_IP[$ip[0]] = time();
	  update_post_meta($post_id, "voted_IP", $voted_IP);
	  update_post_meta($post_id, "votes_count", ++$meta_count);
	  echo $meta_count;
	}
	else{
	  unset($voted_IP[$ip[0]]);
	  update_post_meta($post_id, "voted_IP", $voted_IP);
	  update_post_meta($post_id, "votes_count", --$meta_count);
	  echo "already ".$meta_count;
	  die;
	}
  }
  exit;
}

function hasAlreadyVoted($post_id) {

 $meta_IP = get_post_meta($post_id, "voted_IP");
 $final_arr=array();
 $check_ip=array();

 if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
   $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
 }
 else {
  $ip = $_SERVER['REMOTE_ADDR'];
 }

	$ip=explode(',', $ip);
  if(is_array($meta_IP)){

		foreach ($meta_IP as $arr) {

			foreach ($arr as $key => $value) {
				  $final_arr[]=$key;
			  }
		  }
   }

  if(in_array($ip[0],$final_arr))
	return true;
  else
	return false;
}

function getPostLikeLink($post_id) {

	$vote_count = get_post_meta($post_id, "votes_count", true);
	if($vote_count==''){
		$vote_count=0;
	}
	$output = '';

	if(hasAlreadyVoted($post_id)){

		if($vote_count>1){
		  $text= $vote_count.' Likes';
		}
		elseif($vote_count==1){
		  $text= $vote_count.' Like';
		}

		$output .= '<a href="#" data-post_id="'.$post_id.'" class="post-like">
						  <svg class="animated-svg alreadyactive" xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 14 12">
							<path id="icon-love"  d="M7.023,2.142A3.854,3.854,0,0,0,3.763-.005C1.3-.005,0,2.094,0,4.194c0,3.486,7.023,7.811,7.023,7.811s6.982-4.284,6.982-7.811c0-2.142-1.338-4.2-3.721-4.2A3.634,3.634,0,0,0,7.023,2.142Z"/>
						  </svg>
						  <span  title="'.__('Liked').'"class="draft-love alreadyvoted">'.$text.'</span>
					</a>';
	}

	else{
					if($vote_count>1){
						 $text= $vote_count.' Likes';
					 }
					 elseif($vote_count==1){
						 $text= $vote_count.' Like';
					 }
					else {
						$text = '  Like It ?';
					}
			$output .= '<a href="#" data-post_id="'.$post_id.'" class="post-like">
							<svg class="animated-svg" xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 14 12">
							  <path id="icon-love"  d="M7.023,2.142A3.854,3.854,0,0,0,3.763-.005C1.3-.005,0,2.094,0,4.194c0,3.486,7.023,7.811,7.023,7.811s6.982-4.284,6.982-7.811c0-2.142-1.338-4.2-3.721-4.2A3.634,3.634,0,0,0,7.023,2.142Z"/>
							</svg>
							<span  title="'.__('Like').'"class="draft-love">'.$text.'</span>
						</a>';
	}

	return $output;
}

function get_banner_image_thumbnail($image_id)

{
   if(wp_get_attachment_url(get_post_thumbnail_id($image_id)))

	{
		return wp_get_attachment_url(get_post_thumbnail_id($image_id));

	}
	else

	{
	   // return get_template_directory_uri().'/images/defult-banner.png';

		return '';

	}
}

/**
 * Template tag to show featured image on AMP
 * @param string $size the post thumbnail size
 */
function isa_amp_featured_img( $size = 'medium' ) {

	global $post;

	if ( has_post_thumbnail( $post->ID ) ) {

		$thumb_id = get_post_thumbnail_id( $post->ID );
		$img = wp_get_attachment_image_src( $thumb_id, $size );
		$img_src = $img[0];
		$w = $img[1];
		$h = $img[2];

		$alt = get_post_meta($post->ID, '_wp_attachment_image_alt', true);

		if(empty($alt)) {
			$attachment = get_post( $thumb_id );
			$alt = trim(strip_tags( $attachment->post_title ) );
		} ?>
		<amp-img id="feat-img" src="<?php echo esc_url( $img_src ); ?>" <?php
			if ( $img_srcset = wp_get_attachment_image_srcset( $thumb_id, $size ) ) {
				?> srcset="<?php echo esc_attr( $img_srcset ); ?>" <?php
			}
			?> alt="<?php echo esc_attr( $alt ); ?>" width="<?php echo $w; ?>" height="<?php echo $h; ?>">
		</amp-img>
		<?php
	}
}
 /**
 * Make AMP use your custom single.php.
 */
// function my_amp_set_custom_template( $file, $type, $post ) {
//     if ( 'single' === $type ) {
//         $file =  get_stylesheet_directory() . '/amp/single.php';
//     }
//     return $file;
// }
// add_filter( 'amp_post_template_file', 'my_amp_set_custom_template', 10, 3 );


add_action( 'wp_enqueue_scripts', 'menu_wdscript' );
function menu_wdscript() {
  wp_localize_script( 'hotelreservation_main_script', 'hotelreservation_main_script', array(
    'url'   => admin_url( 'admin-ajax.php' ),
    'nonce' => wp_create_nonce('ajaxnonce'),
  ) );
}

function home_page_cover_svg_code(){
	?>
	<svg id="Banner" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1920" height="900" viewBox="0 0 1920 900">
		<metadata><?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>
	<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c138 79.159824, 2016/09/14-01:09:01        ">
		 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
				<rdf:Description rdf:about=""/>
		 </rdf:RDF>
	</x:xmpmeta>





















	<?xpacket end="w"?></metadata>
	<defs>
			<style>
				.cls-1, .cls-113, .cls-124, .cls-130, .cls-138, .cls-145, .cls-15, .cls-153, .cls-155, .cls-157, .cls-159, .cls-161, .cls-163, .cls-174, .cls-187, .cls-189, .cls-191, .cls-193, .cls-194, .cls-203, .cls-23, .cls-31, .cls-40, .cls-42, .cls-44, .cls-46, .cls-48, .cls-5, .cls-51, .cls-62, .cls-73, .cls-75, .cls-77, .cls-79, .cls-80, .cls-9, .cls-94 {
					fill: #fff;
				}

				.cls-1 {
					filter: url(#filter);
				}

				.cls-2 {
					fill: #2091f5;
				}

				.cls-115, .cls-12, .cls-123, .cls-127, .cls-136, .cls-137, .cls-173, .cls-180, .cls-2, .cls-203, .cls-21, .cls-22, .cls-25, .cls-4, .cls-61, .cls-68, .cls-7, .cls-72, .cls-87, .cls-88, .cls-89, .cls-90, .cls-91, .cls-92, .cls-93 {
					fill-rule: evenodd;
				}

				.cls-2, .cls-3 {
					opacity: 0.2;
				}

				.cls-11, .cls-122, .cls-126, .cls-39, .cls-4 {
					fill: #3392e3;
				}

				.cls-10, .cls-102, .cls-114, .cls-125, .cls-128, .cls-129, .cls-13, .cls-131, .cls-132, .cls-133, .cls-134, .cls-135, .cls-136, .cls-139, .cls-14, .cls-140, .cls-141, .cls-142, .cls-143, .cls-144, .cls-146, .cls-147, .cls-148, .cls-149, .cls-150, .cls-151, .cls-152, .cls-154, .cls-156, .cls-158, .cls-16, .cls-160, .cls-162, .cls-164, .cls-165, .cls-166, .cls-167, .cls-168, .cls-17, .cls-170, .cls-171, .cls-172, .cls-175, .cls-176, .cls-177, .cls-178, .cls-18, .cls-180, .cls-182, .cls-183, .cls-184, .cls-185, .cls-188, .cls-19, .cls-190, .cls-192, .cls-195, .cls-20, .cls-21, .cls-24, .cls-25, .cls-26, .cls-27, .cls-28, .cls-29, .cls-30, .cls-32, .cls-33, .cls-34, .cls-35, .cls-36, .cls-37, .cls-38, .cls-41, .cls-43, .cls-45, .cls-47, .cls-49, .cls-50, .cls-52, .cls-53, .cls-54, .cls-55, .cls-56, .cls-58, .cls-59, .cls-6, .cls-60, .cls-63, .cls-64, .cls-65, .cls-66, .cls-68, .cls-70, .cls-71, .cls-74, .cls-76, .cls-78, .cls-81, .cls-95 {
					fill: #7cc0fa;
				}

				.cls-100, .cls-101, .cls-103, .cls-104, .cls-105, .cls-106, .cls-107, .cls-108, .cls-109, .cls-110, .cls-111, .cls-112, .cls-115, .cls-116, .cls-117, .cls-118, .cls-119, .cls-12, .cls-120, .cls-121, .cls-123, .cls-127, .cls-173, .cls-198, .cls-199, .cls-200, .cls-201, .cls-202, .cls-61, .cls-7, .cls-8, .cls-84, .cls-85, .cls-86, .cls-96, .cls-97, .cls-98, .cls-99 {
					fill: #9bd1ff;
				}

				.cls-10, .cls-100, .cls-101, .cls-102, .cls-103, .cls-104, .cls-105, .cls-106, .cls-107, .cls-108, .cls-109, .cls-11, .cls-110, .cls-111, .cls-112, .cls-113, .cls-114, .cls-115, .cls-116, .cls-117, .cls-118, .cls-119, .cls-12, .cls-120, .cls-121, .cls-122, .cls-123, .cls-124, .cls-125, .cls-126, .cls-127, .cls-128, .cls-129, .cls-13, .cls-130, .cls-131, .cls-132, .cls-133, .cls-134, .cls-135, .cls-136, .cls-137, .cls-138, .cls-139, .cls-14, .cls-140, .cls-141, .cls-142, .cls-143, .cls-144, .cls-145, .cls-146, .cls-147, .cls-148, .cls-149, .cls-15, .cls-150, .cls-151, .cls-152, .cls-153, .cls-154, .cls-155, .cls-156, .cls-157, .cls-158, .cls-159, .cls-16, .cls-160, .cls-161, .cls-162, .cls-163, .cls-164, .cls-165, .cls-166, .cls-167, .cls-168, .cls-169, .cls-17, .cls-170, .cls-171, .cls-172, .cls-173, .cls-174, .cls-175, .cls-176, .cls-177, .cls-178, .cls-179, .cls-18, .cls-180, .cls-181, .cls-182, .cls-183, .cls-184, .cls-185, .cls-186, .cls-187, .cls-188, .cls-189, .cls-19, .cls-190, .cls-191, .cls-192, .cls-193, .cls-194, .cls-195, .cls-196, .cls-197, .cls-198, .cls-199, .cls-20, .cls-200, .cls-201, .cls-202, .cls-21, .cls-22, .cls-23, .cls-24, .cls-25, .cls-26, .cls-27, .cls-28, .cls-29, .cls-30, .cls-31, .cls-32, .cls-33, .cls-34, .cls-35, .cls-36, .cls-37, .cls-38, .cls-40, .cls-41, .cls-42, .cls-43, .cls-44, .cls-45, .cls-46, .cls-47, .cls-48, .cls-49, .cls-50, .cls-51, .cls-52, .cls-53, .cls-54, .cls-55, .cls-56, .cls-57, .cls-58, .cls-59, .cls-60, .cls-61, .cls-62, .cls-63, .cls-64, .cls-65, .cls-66, .cls-67, .cls-68, .cls-69, .cls-7, .cls-70, .cls-71, .cls-73, .cls-74, .cls-75, .cls-76, .cls-77, .cls-78, .cls-79, .cls-8, .cls-80, .cls-81, .cls-82, .cls-83, .cls-84, .cls-85, .cls-86, .cls-87, .cls-88, .cls-89, .cls-9, .cls-90, .cls-91, .cls-92, .cls-93, .cls-94, .cls-95, .cls-96, .cls-97, .cls-98, .cls-99 {
					stroke: #3392e3;
					stroke-width: 4px;
				}

				.cls-10, .cls-100, .cls-101, .cls-102, .cls-103, .cls-104, .cls-105, .cls-106, .cls-107, .cls-108, .cls-109, .cls-11, .cls-110, .cls-111, .cls-112, .cls-113, .cls-114, .cls-115, .cls-116, .cls-117, .cls-118, .cls-119, .cls-12, .cls-120, .cls-121, .cls-122, .cls-123, .cls-124, .cls-125, .cls-126, .cls-127, .cls-128, .cls-129, .cls-13, .cls-130, .cls-131, .cls-132, .cls-133, .cls-134, .cls-135, .cls-136, .cls-137, .cls-138, .cls-139, .cls-14, .cls-140, .cls-141, .cls-142, .cls-143, .cls-144, .cls-145, .cls-146, .cls-147, .cls-148, .cls-149, .cls-15, .cls-150, .cls-151, .cls-152, .cls-153, .cls-154, .cls-155, .cls-156, .cls-157, .cls-158, .cls-159, .cls-16, .cls-160, .cls-161, .cls-162, .cls-163, .cls-164, .cls-165, .cls-166, .cls-167, .cls-168, .cls-169, .cls-17, .cls-170, .cls-171, .cls-172, .cls-173, .cls-174, .cls-175, .cls-176, .cls-177, .cls-178, .cls-179, .cls-18, .cls-180, .cls-181, .cls-182, .cls-183, .cls-184, .cls-185, .cls-186, .cls-187, .cls-188, .cls-189, .cls-19, .cls-190, .cls-191, .cls-192, .cls-193, .cls-194, .cls-195, .cls-196, .cls-197, .cls-198, .cls-199, .cls-20, .cls-200, .cls-201, .cls-202, .cls-21, .cls-22, .cls-23, .cls-24, .cls-25, .cls-26, .cls-27, .cls-28, .cls-29, .cls-30, .cls-31, .cls-32, .cls-33, .cls-34, .cls-35, .cls-36, .cls-37, .cls-38, .cls-40, .cls-41, .cls-42, .cls-43, .cls-44, .cls-45, .cls-46, .cls-47, .cls-48, .cls-49, .cls-50, .cls-51, .cls-52, .cls-53, .cls-54, .cls-55, .cls-56, .cls-57, .cls-58, .cls-59, .cls-60, .cls-61, .cls-62, .cls-63, .cls-64, .cls-65, .cls-66, .cls-67, .cls-68, .cls-69, .cls-7, .cls-70, .cls-71, .cls-73, .cls-74, .cls-75, .cls-76, .cls-77, .cls-78, .cls-79, .cls-8, .cls-80, .cls-81, .cls-82, .cls-83, .cls-84, .cls-85, .cls-86, .cls-88, .cls-89, .cls-9, .cls-90, .cls-91, .cls-92, .cls-93, .cls-94, .cls-95, .cls-96, .cls-97, .cls-98, .cls-99 {
					stroke-linejoin: round;
				}

				.cls-7 {
					filter: url(#filter-2);
				}

				.cls-8 {
					filter: url(#filter-3);
				}

				.cls-9 {
					filter: url(#filter-4);
				}

				.cls-10 {
					filter: url(#filter-5);
				}

				.cls-11 {
					filter: url(#filter-6);
				}

				.cls-12 {
					filter: url(#filter-7);
				}

				.cls-13 {
					filter: url(#filter-8);
				}

				.cls-14 {
					filter: url(#filter-9);
				}

				.cls-15 {
					filter: url(#filter-10);
				}

				.cls-16 {
					filter: url(#filter-11);
				}

				.cls-17 {
					filter: url(#filter-12);
				}

				.cls-18 {
					filter: url(#filter-13);
				}

				.cls-19 {
					filter: url(#filter-14);
				}

				.cls-20 {
					filter: url(#filter-15);
				}

				.cls-21 {
					filter: url(#filter-16);
				}

				.cls-137, .cls-169, .cls-179, .cls-181, .cls-186, .cls-22, .cls-57, .cls-67, .cls-69 {
					fill: #f2f2f2;
				}

				.cls-22 {
					filter: url(#filter-17);
				}

				.cls-23 {
					filter: url(#filter-18);
				}

				.cls-24 {
					filter: url(#filter-19);
				}

				.cls-26 {
					filter: url(#filter-20);
				}

				.cls-27 {
					filter: url(#filter-21);
				}

				.cls-28 {
					filter: url(#filter-22);
				}

				.cls-29 {
					filter: url(#filter-23);
				}

				.cls-30 {
					filter: url(#filter-24);
				}

				.cls-31 {
					filter: url(#filter-25);
				}

				.cls-32 {
					filter: url(#filter-26);
				}

				.cls-33 {
					filter: url(#filter-27);
				}

				.cls-34 {
					filter: url(#filter-28);
				}

				.cls-35 {
					filter: url(#filter-29);
				}

				.cls-36 {
					filter: url(#filter-30);
				}

				.cls-37 {
					filter: url(#filter-31);
				}

				.cls-38 {
					filter: url(#filter-32);
				}

				.cls-40 {
					filter: url(#filter-33);
				}

				.cls-41 {
					filter: url(#filter-34);
				}

				.cls-42 {
					filter: url(#filter-35);
				}

				.cls-43 {
					filter: url(#filter-36);
				}

				.cls-44 {
					filter: url(#filter-37);
				}

				.cls-45 {
					filter: url(#filter-38);
				}

				.cls-46 {
					filter: url(#filter-39);
				}

				.cls-47 {
					filter: url(#filter-40);
				}

				.cls-48 {
					filter: url(#filter-41);
				}

				.cls-50 {
					filter: url(#filter-42);
				}

				.cls-51 {
					filter: url(#filter-43);
				}

				.cls-52 {
					filter: url(#filter-44);
				}

				.cls-53 {
					filter: url(#filter-45);
				}

				.cls-54 {
					filter: url(#filter-46);
				}

				.cls-55 {
					filter: url(#filter-47);
				}

				.cls-56 {
					filter: url(#filter-48);
				}

				.cls-57 {
					filter: url(#filter-49);
				}

				.cls-58 {
					filter: url(#filter-50);
				}

				.cls-59 {
					filter: url(#filter-51);
				}

				.cls-60 {
					filter: url(#filter-52);
				}

				.cls-61 {
					filter: url(#filter-53);
				}

				.cls-62 {
					filter: url(#filter-54);
				}

				.cls-63 {
					filter: url(#filter-55);
				}

				.cls-64 {
					filter: url(#filter-56);
				}

				.cls-65 {
					filter: url(#filter-57);
				}

				.cls-66 {
					filter: url(#filter-58);
				}

				.cls-67 {
					filter: url(#filter-59);
				}

				.cls-68 {
					filter: url(#filter-60);
				}

				.cls-69 {
					filter: url(#filter-61);
				}

				.cls-70 {
					filter: url(#filter-62);
				}

				.cls-71 {
					filter: url(#filter-63);
				}

				.cls-72 {
					fill: #2a98f7;
				}

				.cls-73 {
					filter: url(#filter-64);
				}

				.cls-74 {
					filter: url(#filter-65);
				}

				.cls-75 {
					filter: url(#filter-66);
				}

				.cls-76 {
					filter: url(#filter-67);
				}

				.cls-77 {
					filter: url(#filter-68);
				}

				.cls-78 {
					filter: url(#filter-69);
				}

				.cls-79 {
					filter: url(#filter-70);
				}

				.cls-80 {
					filter: url(#filter-71);
				}

				.cls-81 {
					filter: url(#filter-72);
				}

				.cls-196, .cls-197, .cls-82, .cls-83, .cls-88, .cls-89, .cls-90, .cls-91, .cls-92, .cls-93 {
					fill: #e8e8ee;
				}

				.cls-82 {
					filter: url(#filter-73);
				}

				.cls-83 {
					filter: url(#filter-74);
				}

				.cls-84 {
					filter: url(#filter-75);
				}

				.cls-85 {
					filter: url(#filter-76);
				}

				.cls-86 {
					filter: url(#filter-77);
				}

				.cls-87 {
					fill: none;
				}

				.cls-88 {
					filter: url(#filter-78);
				}

				.cls-89 {
					filter: url(#filter-79);
				}

				.cls-90 {
					filter: url(#filter-80);
				}

				.cls-91 {
					filter: url(#filter-81);
				}

				.cls-92 {
					filter: url(#filter-82);
				}

				.cls-93 {
					filter: url(#filter-83);
				}

				.cls-95 {
					filter: url(#filter-84);
				}

				.cls-96 {
					filter: url(#filter-85);
				}

				.cls-97 {
					filter: url(#filter-86);
				}

				.cls-98 {
					filter: url(#filter-87);
				}

				.cls-99 {
					filter: url(#filter-88);
				}

				.cls-100 {
					filter: url(#filter-89);
				}

				.cls-101 {
					filter: url(#filter-90);
				}

				.cls-102 {
					filter: url(#filter-91);
				}

				.cls-103 {
					filter: url(#filter-92);
				}

				.cls-104 {
					filter: url(#filter-93);
				}

				.cls-105 {
					filter: url(#filter-94);
				}

				.cls-106 {
					filter: url(#filter-95);
				}

				.cls-107 {
					filter: url(#filter-96);
				}

				.cls-108 {
					filter: url(#filter-97);
				}

				.cls-110 {
					filter: url(#filter-98);
				}

				.cls-111 {
					filter: url(#filter-99);
				}

				.cls-112 {
					filter: url(#filter-100);
				}

				.cls-113 {
					filter: url(#filter-101);
				}

				.cls-114 {
					filter: url(#filter-102);
				}

				.cls-115 {
					filter: url(#filter-103);
				}

				.cls-116 {
					filter: url(#filter-104);
				}

				.cls-117 {
					filter: url(#filter-105);
				}

				.cls-118 {
					filter: url(#filter-106);
				}

				.cls-119 {
					filter: url(#filter-107);
				}

				.cls-120 {
					filter: url(#filter-108);
				}

				.cls-121 {
					filter: url(#filter-109);
				}

				.cls-122 {
					filter: url(#filter-110);
				}

				.cls-123 {
					filter: url(#filter-111);
				}

				.cls-124 {
					filter: url(#filter-112);
				}

				.cls-125 {
					filter: url(#filter-113);
				}

				.cls-126 {
					filter: url(#filter-114);
				}

				.cls-127 {
					filter: url(#filter-115);
				}

				.cls-128 {
					filter: url(#filter-116);
				}

				.cls-129 {
					filter: url(#filter-117);
				}

				.cls-130 {
					filter: url(#filter-118);
				}

				.cls-131 {
					filter: url(#filter-119);
				}

				.cls-132 {
					filter: url(#filter-120);
				}

				.cls-133 {
					filter: url(#filter-121);
				}

				.cls-134 {
					filter: url(#filter-122);
				}

				.cls-135 {
					filter: url(#filter-123);
				}

				.cls-136 {
					filter: url(#filter-124);
				}

				.cls-137 {
					filter: url(#filter-125);
				}

				.cls-138 {
					filter: url(#filter-126);
				}

				.cls-139 {
					filter: url(#filter-127);
				}

				.cls-140 {
					filter: url(#filter-128);
				}

				.cls-141 {
					filter: url(#filter-129);
				}

				.cls-142 {
					filter: url(#filter-130);
				}

				.cls-143 {
					filter: url(#filter-131);
				}

				.cls-144 {
					filter: url(#filter-132);
				}

				.cls-145 {
					filter: url(#filter-133);
				}

				.cls-146 {
					filter: url(#filter-134);
				}

				.cls-147 {
					filter: url(#filter-135);
				}

				.cls-148 {
					filter: url(#filter-136);
				}

				.cls-149 {
					filter: url(#filter-137);
				}

				.cls-150 {
					filter: url(#filter-138);
				}

				.cls-151 {
					filter: url(#filter-139);
				}

				.cls-152 {
					filter: url(#filter-140);
				}

				.cls-153 {
					filter: url(#filter-141);
				}

				.cls-154 {
					filter: url(#filter-142);
				}

				.cls-155 {
					filter: url(#filter-143);
				}

				.cls-156 {
					filter: url(#filter-144);
				}

				.cls-157 {
					filter: url(#filter-145);
				}

				.cls-158 {
					filter: url(#filter-146);
				}

				.cls-159 {
					filter: url(#filter-147);
				}

				.cls-160 {
					filter: url(#filter-148);
				}

				.cls-161 {
					filter: url(#filter-149);
				}

				.cls-162 {
					filter: url(#filter-150);
				}

				.cls-163 {
					filter: url(#filter-151);
				}

				.cls-164 {
					filter: url(#filter-152);
				}

				.cls-165 {
					filter: url(#filter-153);
				}

				.cls-166 {
					filter: url(#filter-154);
				}

				.cls-167 {
					filter: url(#filter-155);
				}

				.cls-168 {
					filter: url(#filter-156);
				}

				.cls-169 {
					filter: url(#filter-157);
				}

				.cls-170 {
					filter: url(#filter-158);
				}

				.cls-171 {
					filter: url(#filter-159);
				}

				.cls-172 {
					filter: url(#filter-160);
				}

				.cls-173 {
					filter: url(#filter-161);
				}

				.cls-174 {
					filter: url(#filter-162);
				}

				.cls-175 {
					filter: url(#filter-163);
				}

				.cls-176 {
					filter: url(#filter-164);
				}

				.cls-177 {
					filter: url(#filter-165);
				}

				.cls-178 {
					filter: url(#filter-166);
				}

				.cls-179 {
					filter: url(#filter-167);
				}

				.cls-180 {
					filter: url(#filter-168);
				}

				.cls-181 {
					filter: url(#filter-169);
				}

				.cls-182 {
					filter: url(#filter-170);
				}

				.cls-183 {
					filter: url(#filter-171);
				}

				.cls-184 {
					filter: url(#filter-172);
				}

				.cls-185 {
					filter: url(#filter-173);
				}

				.cls-186 {
					filter: url(#filter-174);
				}

				.cls-187 {
					filter: url(#filter-175);
				}

				.cls-188 {
					filter: url(#filter-176);
				}

				.cls-189 {
					filter: url(#filter-177);
				}

				.cls-190 {
					filter: url(#filter-178);
				}

				.cls-191 {
					filter: url(#filter-179);
				}

				.cls-192 {
					filter: url(#filter-180);
				}

				.cls-193 {
					filter: url(#filter-181);
				}

				.cls-194 {
					filter: url(#filter-182);
				}

				.cls-195 {
					filter: url(#filter-183);
				}

				.cls-196 {
					filter: url(#filter-184);
				}

				.cls-197 {
					filter: url(#filter-185);
				}

				.cls-198 {
					filter: url(#filter-186);
				}

				.cls-199 {
					filter: url(#filter-187);
				}

				.cls-200 {
					filter: url(#filter-188);
				}

				.cls-201 {
					filter: url(#filter-189);
				}

				.cls-202 {
					filter: url(#filter-190);
				}
			</style>
			<filter id="filter" x="-2" y="-1" width="1925" height="905" filterUnits="userSpaceOnUse">
				<feOffset result="offset" dy="1" in="SourceAlpha"/>
				<feGaussianBlur result="blur" stdDeviation="1.732"/>
				<feFlood result="flood" flood-opacity="0.08"/>
				<feComposite result="composite" operator="in" in2="blur"/>
				<feBlend result="blend" in="SourceGraphic"/>
				<feImage preserveAspectRatio="none" x="0" y="0" width="1920" height="900" result="image" xlink:href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMTkyMCIgaGVpZ2h0PSI5MDAiIHZpZXdCb3g9IjAgMCAxOTIwIDkwMCI+CiAgPGRlZnM+CiAgICA8c3R5bGU+CiAgICAgIC5jbHMtMSB7CiAgICAgICAgZmlsbDogdXJsKCNsaW5lYXItZ3JhZGllbnQpOwogICAgICB9CiAgICA8L3N0eWxlPgogICAgPGxpbmVhckdyYWRpZW50IGlkPSJsaW5lYXItZ3JhZGllbnQiIHgxPSIxNDQyLjU2NiIgeTE9IjkwMCIgeDI9IjQ3Ny40MzQiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgICAgPHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjNmNiYmZmIi8+CiAgICAgIDxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzFlOTdmZSIvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICA8L2RlZnM+CiAgPHJlY3QgY2xhc3M9ImNscy0xIiB3aWR0aD0iMTkyMCIgaGVpZ2h0PSI5MDAiLz4KPC9zdmc+Cg=="/>
				<feComposite result="composite-2" operator="in" in2="SourceGraphic"/>
				<feBlend result="blend-2" in2="blend"/>
				<feGaussianBlur result="blur-2" in="SourceAlpha"/>
				<feFlood result="flood-2" flood-color="#3392e3"/>
				<feComposite result="composite-3" operator="out" in2="blur-2"/>
				<feOffset result="offset-2" dy="-7"/>
				<feComposite result="composite-4" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend-3" in2="blend-2"/>
			</filter>
			<filter id="filter-2" x="1821.75" y="810.469" width="25.44" height="53.656" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-3" x="1871.16" y="766.719" width="26.81" height="36.687" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-4" x="1288.94" y="790.719" width="125.47" height="105.875" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-5" x="1280.5" y="772.344" width="142.38" height="25.437" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-6" x="1335.5" y="861.281" width="32.41" height="35.313" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-7" x="1325.62" y="850" width="52.16" height="22.594" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-8" x="1363.69" y="811.875" width="35.25" height="25.437" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-9" x="1304.47" y="854.25" width="16.91" height="25.406" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-10" x="1391.84" y="666.469" width="320.04" height="231.531" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-11" x="1568.09" y="694.688" width="40.88" height="49.406" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-12" x="1507.47" y="694.688" width="40.87" height="49.406" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-13" x="1445.44" y="694.688" width="40.87" height="49.406" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-14" x="1568.09" y="833.031" width="40.88" height="49.438" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-15" x="1507.47" y="833.031" width="40.87" height="49.438" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-16" x="1359.44" y="600.125" width="352.44" height="83.281" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-17" x="1359.44" y="754" width="352.44" height="69.188" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-18" x="1626" y="578" width="171" height="319" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-19" x="1620" y="563" width="183" height="18" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-20" x="1722" y="613" width="48" height="59" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-21" x="1654" y="613" width="48" height="59" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-22" x="1654" y="683" width="48" height="59" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-23" x="1721.72" y="754" width="47.94" height="59.281" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-24" x="1654.06" y="824.594" width="47.94" height="59.312" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-25" x="743" y="541" width="171" height="356" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-26" x="830.812" y="595.875" width="49.344" height="70.594" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-27" x="768.781" y="595.875" width="49.344" height="70.594" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-28" x="830.812" y="686.219" width="49.344" height="70.625" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-29" x="768.781" y="686.219" width="49.344" height="70.625" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-30" x="830.812" y="773.75" width="49.344" height="70.625" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-31" x="768.781" y="773.75" width="49.344" height="70.625" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-32" x="743" y="541" width="171" height="24" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-33" x="868.875" y="466" width="205.815" height="430.594" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-34" x="869" y="466" width="206" height="28" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-35" x="997" y="546" width="42" height="76" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-36" x="997" y="569" width="42" height="54" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-37" x="908" y="546" width="42" height="76" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-38" x="908" y="582" width="42" height="41" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-39" x="997" y="651" width="42" height="76" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-40" x="997" y="669" width="42" height="58" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-41" x="908" y="651" width="42" height="76" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-42" x="923.844" y="770.938" width="50.75" height="88.937" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-43" x="403.688" y="497.062" width="132.5" height="399.532" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-44" x="475.562" y="554.938" width="36.657" height="55.062" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-45" x="427.625" y="554.938" width="36.687" height="55.062" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-46" x="475.562" y="631.188" width="36.657" height="55.031" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-47" x="427.625" y="631.188" width="36.687" height="55.031" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-48" x="475.562" y="707.438" width="36.657" height="55.031" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-49" x="427.625" y="707.438" width="36.687" height="55.031" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-50" x="475.562" y="783.625" width="36.657" height="55.094" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-51" x="427.625" y="783.625" width="36.687" height="55.094" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-52" x="393.781" y="497.062" width="152.281" height="28.219" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-53" x="381.156" y="802" width="28.156" height="59.312" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-54" x="475.562" y="607.156" width="203" height="289.438" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-55" x="609.5" y="670.719" width="39.469" height="53.625" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-56" x="555.906" y="670.719" width="39.469" height="53.625" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-57" x="502.375" y="670.719" width="39.437" height="53.625" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-58" x="609.5" y="744.094" width="39.469" height="53.687" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-59" x="502.375" y="841.531" width="146.594" height="53.657" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-60" x="490.938" y="823.188" width="169.437" height="39.593" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-61" x="555.906" y="744.094" width="39.469" height="53.687" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-62" x="502.375" y="744.094" width="39.437" height="53.687" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-63" x="469.938" y="598.719" width="215.656" height="38.093" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-64" x="87.906" y="612.812" width="160.688" height="283.782" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-65" x="79.438" y="612.812" width="177.625" height="29.657" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-66" x="185.156" y="677.781" width="35.25" height="59.281" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-67" x="185.156" y="693.281" width="35.25" height="43.781" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-68" x="116.094" y="677.781" width="35.25" height="59.281" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-69" x="116.094" y="713.062" width="35.25" height="24" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-70" x="185.156" y="765.281" width="35.25" height="59.313" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-71" x="116.094" y="765.281" width="35.25" height="59.313" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-72" x="116.094" y="783.625" width="35.25" height="40.969" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-73" x="687" y="693.281" width="19.75" height="31.063" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-74" x="672.938" y="693.281" width="19.718" height="31.063" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-75" x="1207.19" y="799.188" width="74.72" height="74.812" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-76" x="708.156" y="799.188" width="74.719" height="74.812" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-77" x="264.094" y="799.188" width="74.75" height="74.812" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-78" x="2429.41" y="759.656" width="29.59" height="16.938" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-79" x="2546.41" y="759.656" width="29.59" height="16.938" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-80" x="1097.25" y="759.656" width="29.59" height="16.938" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-81" x="1214.25" y="759.656" width="29.59" height="16.938" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-82" x="295.125" y="759.656" width="29.594" height="16.938" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-83" x="412.125" y="759.656" width="29.594" height="16.938" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-84" x="98" y="682" width="139" height="21" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-85" x="118" y="722" width="28" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-86" x="154" y="722" width="28" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-87" x="118" y="776" width="28" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-88" x="154" y="776" width="28" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-89" x="118" y="830" width="28" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-90" x="154" y="830" width="28" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-91" x="184" y="634" width="170" height="26" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-92" x="208" y="683" width="34" height="51" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-93" x="252" y="683" width="34" height="51" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-94" x="296" y="683" width="34" height="51" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-95" x="208" y="749" width="34" height="51" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-96" x="252" y="749" width="34" height="51" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-97" x="296" y="749" width="34" height="51" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-98" x="267" y="819" width="29" height="57" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-99" x="303" y="834" width="27" height="27" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-100" x="208" y="834" width="27" height="27" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-101" x="403" y="695" width="90" height="202" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-102" x="399" y="678" width="98" height="21" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-103" x="489" y="836" width="18.031" height="38" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-104" x="424" y="723" width="19" height="26" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-105" x="424" y="764" width="19" height="26" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-106" x="424" y="805" width="19" height="26" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-107" x="453" y="723" width="19" height="26" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-108" x="453" y="764" width="19" height="26" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-109" x="453" y="805" width="19" height="26" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-110" x="432" y="862" width="33" height="35" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-111" x="422.25" y="851" width="52.031" height="22.031" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-112" x="796" y="822" width="89" height="75" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-113" x="790" y="809" width="101" height="18" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-114" x="829" y="872" width="23" height="25" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-115" x="822" y="864" width="37" height="16" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-116" x="807" y="837" width="25" height="18" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-117" x="862" y="867" width="12" height="18" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-118" x="585" y="734" width="227" height="164" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-119" x="658" y="754" width="29" height="35" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-120" x="701" y="754" width="29" height="35" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-121" x="745" y="754" width="29" height="35" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-122" x="658" y="852" width="29" height="35" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-123" x="701" y="852" width="29" height="35" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-124" x="585" y="687" width="250" height="59" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-125" x="585" y="796" width="250" height="49" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-126" x="525" y="671" width="121" height="226" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-127" x="520" y="661" width="130" height="13" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-128" x="544" y="696" width="34" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-129" x="592" y="696" width="34" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-130" x="592" y="746" width="34" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-131" x="544" y="796" width="34" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-132" x="592" y="846" width="34" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-133" x="1151" y="645" width="121" height="252" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-134" x="1175" y="684" width="35" height="50" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-135" x="1219" y="684" width="35" height="50" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-136" x="1175" y="748" width="35" height="50" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-137" x="1219" y="748" width="35" height="50" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-138" x="1175" y="810" width="35" height="50" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-139" x="1219" y="810" width="35" height="50" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-140" x="1151" y="645" width="121" height="17" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-141" x="1037" y="592" width="146" height="305" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-142" x="1037" y="592" width="146" height="20" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-143" x="1062" y="649" width="30" height="54" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-144" x="1062" y="665" width="30" height="38" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-145" x="1125" y="649" width="30" height="54" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-146" x="1125" y="674" width="30" height="29" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-147" x="1062" y="723" width="30" height="54" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-148" x="1062" y="736" width="30" height="41" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-149" x="1125" y="723" width="30" height="54" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-150" x="1108" y="808" width="36" height="63" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-151" x="1419" y="614" width="94" height="283" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-152" x="1436" y="655" width="26" height="39" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-153" x="1470" y="655" width="26" height="39" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-154" x="1436" y="709" width="26" height="39" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-155" x="1470" y="709" width="26" height="39" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-156" x="1436" y="763" width="26" height="39" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-157" x="1470" y="763" width="26" height="39" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-158" x="1436" y="817" width="26" height="39" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-159" x="1470" y="817" width="26" height="39" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-160" x="1412" y="614" width="108" height="20" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-161" x="1509" y="830" width="19.97" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-162" x="1318" y="692" width="144" height="205" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-163" x="1339" y="737" width="28" height="38" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-164" x="1377" y="737" width="28" height="38" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-165" x="1415" y="737" width="28" height="38" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-166" x="1339" y="789" width="28" height="38" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-167" x="1339" y="858" width="104" height="38" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-168" x="1330.91" y="845" width="120.21" height="28.031" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-169" x="1377" y="789" width="28" height="38" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-170" x="1415" y="789" width="28" height="38" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-171" x="1313" y="686" width="153" height="27" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-172" x="1755" y="829" width="33" height="44" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-173" x="1800" y="829" width="33" height="44" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-174" x="1845" y="829" width="33" height="44" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-175" x="1623" y="696" width="114" height="201" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-176" x="1617" y="696" width="126" height="21" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-177" x="1643" y="742" width="25" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-178" x="1643" y="753" width="25" height="31" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-179" x="1692" y="742" width="25" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-180" x="1692" y="767" width="25" height="17" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-181" x="1643" y="804" width="25" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-182" x="1692" y="804" width="25" height="42" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-183" x="1692" y="817" width="25" height="29" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-184" x="1294" y="753" width="14" height="22" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-185" x="1304" y="753" width="14" height="22" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-186" x="52" y="828" width="53" height="53" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-187" x="335" y="828" width="53" height="53" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-188" x="890" y="828" width="53" height="53" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-189" x="1244" y="828" width="53" height="53" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
			<filter id="filter-190" x="1559" y="828" width="53" height="53" filterUnits="userSpaceOnUse">
				<feGaussianBlur result="blur" stdDeviation="2" in="SourceAlpha"/>
				<feFlood result="flood" flood-color="#fff"/>
				<feComposite result="composite" operator="out" in2="blur"/>
				<feOffset result="offset" dy="3"/>
				<feComposite result="composite-2" operator="in" in2="SourceAlpha"/>
				<feBlend result="blend" in2="SourceGraphic"/>
			</filter>
		</defs>
		<rect id="BG" class="cls-1" width="1920" height="900"/>
		<path id="buildings" class="cls-2" d="M1920,897H1764v-2h-83v1H1536v-2H1383v2H870V145h97V446h211V317h193V155h185V268h125v51h95V423h144V897ZM715,896H615v2H352V821H272v74H67V329h70V255H291V380h61V228H615v97h94V138H830V895H715v1Z"/>
		<g id="Back_Buildings" data-name="Back Buildings" class="cls-3">
			<g id="_3" data-name="3">
				<path class="cls-4" d="M1842,896V618a5,5,0,0,1,5-5h73V896h-78Zm74-279h-70V893h70V617Z"/>
				<rect class="cls-5" x="1846" y="617" width="74" height="276"/>
				<path id="Rectangle_550_copy" data-name="Rectangle 550 copy" class="cls-4" d="M1841,617a5,5,0,0,1-5-5V592a5,5,0,0,1,5-5h79v30h-79Zm75-26h-76v22h76V591Z"/>
				<rect class="cls-6" x="1840" y="591" width="80" height="22"/>
				<g style="fill: #9bd1ff; filter: url(#filter-2)">
					<path id="path-14" class="cls-7" d="M1847.19,810.471s-13.72,23.739-22.91,39.635c-8.67,15.12,7.79,14.012,7.79,14.012h15.12V810.471Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#path-14" style="stroke: #3392e3; filter: none; fill: none"/>
				<g>
					<path id="Rectangle_551_copy_3" data-name="Rectangle 551 copy 3" class="cls-4" d="M1895.5,688h-22a2.5,2.5,0,0,1-2.5-2.5v-32a2.5,2.5,0,0,1,2.5-2.5h22a2.5,2.5,0,0,1,2.5,2.5v32A2.5,2.5,0,0,1,1895.5,688Zm-1.5-33h-19v29h19V655Z"/>
					<rect class="cls-6" x="1875" y="655" width="19" height="29"/>
					<rect id="Rectangle_510_copy" data-name="Rectangle 510 copy" class="cls-5" x="1875" y="655" width="19" height="3"/>
				</g>
				<g id="Group_12_copy" data-name="Group 12 copy">
					<path id="Rectangle_551_copy_3-2" data-name="Rectangle 551 copy 3" class="cls-4" d="M1895.5,746h-22a2.5,2.5,0,0,1-2.5-2.5v-32a2.5,2.5,0,0,1,2.5-2.5h22a2.5,2.5,0,0,1,2.5,2.5v32A2.5,2.5,0,0,1,1895.5,746Zm-1.5-33h-19v29h19V713Z"/>
					<rect class="cls-6" x="1875" y="713" width="19" height="29"/>
					<rect id="Rectangle_510_copy-2" data-name="Rectangle 510 copy" class="cls-5" x="1875" y="713" width="19" height="3"/>
				</g>
				<g id="Group_12_copy_2" data-name="Group 12 copy 2">
					<path id="Rectangle_551_copy_3-3" data-name="Rectangle 551 copy 3" class="cls-4" d="M1920,688h-5.5a2.5,2.5,0,0,1-2.5-2.5v-32a2.5,2.5,0,0,1,2.5-2.5h5.5v37Zm0-33h-4v29h4V655Z"/>
					<rect class="cls-6" x="1916" y="655" width="4" height="29"/>
					<rect id="Rectangle_510_copy-3" data-name="Rectangle 510 copy" class="cls-5" x="1916" y="655" width="4" height="3"/>
				</g>
				<g id="Group_12_copy_3" data-name="Group 12 copy 3">
					<path id="Rectangle_551_copy_3-4" data-name="Rectangle 551 copy 3" class="cls-4" d="M1920,746h-5.5a2.5,2.5,0,0,1-2.5-2.5v-32a2.5,2.5,0,0,1,2.5-2.5h5.5v37Zm0-33h-4v29h4V713Z"/>
					<rect class="cls-6" x="1916" y="713" width="4" height="29"/>
					<rect id="Rectangle_510_copy-4" data-name="Rectangle 510 copy" class="cls-5" x="1916" y="713" width="4" height="3"/>
				</g>
				<g style="fill: #9bd1ff; filter: url(#filter-3)">
					<rect id="Rectangle_551_copy_3-5" data-name="Rectangle 551 copy 3" class="cls-8" x="1871.16" y="766.719" width="26.81" height="36.687" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_551_copy_3-5" style="stroke: #3392e3; filter: none; fill: none"/>
			</g>
			<g id="_4" data-name="4">
				<g style="fill: #fff; filter: url(#filter-4)">
					<rect id="rect-52" class="cls-9" x="1288.94" y="790.719" width="125.47" height="105.875" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-52" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-5)">
					<rect id="Rectangle_585_copy" data-name="Rectangle 585 copy" class="cls-10" x="1280.5" y="772.344" width="142.38" height="25.437" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_585_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #3392e3; filter: url(#filter-6)">
					<rect id="Rectangle_551_copy_4" data-name="Rectangle 551 copy 4" class="cls-11" x="1335.5" y="861.281" width="32.41" height="35.313" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_551_copy_4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-7)">
					<path id="Rectangle_559_copy_2" data-name="Rectangle 559 copy 2" class="cls-12" d="M1338.92,850s-7.45,10.5-12.2,17.178c-3.8,6,3.38,5.412,3.38,5.412h43.4s7,0.511,3.09-4.831c-4.71-6.635-12.61-17.759-12.61-17.759h-25.06Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_559_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-8)">
					<rect id="rect-51" class="cls-13" x="1363.69" y="811.875" width="35.25" height="25.437" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-51" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-9)">
					<rect id="Rectangle_589_copy" data-name="Rectangle 589 copy" class="cls-14" x="1304.47" y="854.25" width="16.91" height="25.406" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_589_copy" style="stroke: #3392e3; filter: none; fill: none"/>
			</g>
			<g id="_5" data-name="5">
				<g id="back">
					<g style="fill: #fff; filter: url(#filter-10)">
						<rect id="rect-50" class="cls-15" x="1391.84" y="666.469" width="320.04" height="231.531" rx="5" ry="5" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-50" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-11)">
						<rect id="rect-49" class="cls-16" x="1568.09" y="694.688" width="40.88" height="49.406" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-49" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-12)">
						<rect id="Rectangle_576_copy" data-name="Rectangle 576 copy" class="cls-17" x="1507.47" y="694.688" width="40.87" height="49.406" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_576_copy" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-13)">
						<rect id="Rectangle_576_copy_2" data-name="Rectangle 576 copy 2" class="cls-18" x="1445.44" y="694.688" width="40.87" height="49.406" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_576_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-14)">
						<rect id="Rectangle_576_copy_3" data-name="Rectangle 576 copy 3" class="cls-19" x="1568.09" y="833.031" width="40.88" height="49.438" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_576_copy_3" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-15)">
						<rect id="Rectangle_576_copy_3-2" data-name="Rectangle 576 copy 3" class="cls-20" x="1507.47" y="833.031" width="40.87" height="49.438" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_576_copy_3-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-16)">
						<path id="Rectangle_573_copy" data-name="Rectangle 573 copy" class="cls-21" d="M1704.81,600.118H1394.68a7.057,7.057,0,0,0-7.05,7.059l-28.19,69.176a7.057,7.057,0,0,0,7.05,7.059h338.32a7.05,7.05,0,0,0,7.05-7.059V607.177A7.05,7.05,0,0,0,1704.81,600.118Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_573_copy" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #f2f2f2; filter: url(#filter-17)">
						<path id="Rectangle_573_copy_2" data-name="Rectangle 573 copy 2" class="cls-22" d="M1704.81,754H1389.04a7.057,7.057,0,0,0-7.05,7.059l-22.55,55.059a7.056,7.056,0,0,0,7.05,7.058h338.32a7.05,7.05,0,0,0,7.05-7.058V761.059A7.05,7.05,0,0,0,1704.81,754Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_573_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
				<g id="front">
					<g style="fill: #fff; filter: url(#filter-18)">
						<path id="path-13" class="cls-23" d="M1626,578h171a0,0,0,0,1,0,0V892a5,5,0,0,1-5,5H1631a5,5,0,0,1-5-5V578A0,0,0,0,1,1626,578Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#path-13" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-19)">
						<rect id="rect-48" class="cls-24" x="1620" y="563" width="183" height="18" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-48" style="stroke: #3392e3; filter: none; fill: none"/>
					<path id="Rectangle_563_copy" data-name="Rectangle 563 copy" class="cls-25" d="M1703.09,501.189C1680.71,519.181,1620.01,568,1620.01,568h182.98l-83.54-66.8S1712.14,491.756,1703.09,501.189Z"/>
					<g style="fill: #7cc0fa; filter: url(#filter-20)">
						<rect id="rect-47" class="cls-26" x="1722" y="613" width="48" height="59" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-47" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-21)">
						<rect id="Rectangle_566_copy" data-name="Rectangle 566 copy" class="cls-27" x="1654" y="613" width="48" height="59" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_566_copy" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-22)">
						<rect id="Rectangle_566_copy_2" data-name="Rectangle 566 copy 2" class="cls-28" x="1654" y="683" width="48" height="59" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_566_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-23)">
						<rect id="Rectangle_566_copy_3" data-name="Rectangle 566 copy 3" class="cls-29" x="1721.72" y="754" width="47.94" height="59.281" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_566_copy_3" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-24)">
						<rect id="Rectangle_566_copy_3-2" data-name="Rectangle 566 copy 3" class="cls-30" x="1654.06" y="824.594" width="47.94" height="59.312" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_566_copy_3-2" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
			</g>
			<g id="_6" data-name="6">
				<g style="fill: #fff; filter: url(#filter-25)">
					<rect id="rect-46" class="cls-31" x="743" y="541" width="171" height="356" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-46" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-26)">
					<rect id="rect-45" class="cls-32" x="830.812" y="595.875" width="49.344" height="70.594" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-45" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-27)">
					<rect id="Rectangle_655_copy" data-name="Rectangle 655 copy" class="cls-33" x="768.781" y="595.875" width="49.344" height="70.594" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-28)">
					<rect id="Rectangle_655_copy_2" data-name="Rectangle 655 copy 2" class="cls-34" x="830.812" y="686.219" width="49.344" height="70.625" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-29)">
					<rect id="Rectangle_655_copy_2-2" data-name="Rectangle 655 copy 2" class="cls-35" x="768.781" y="686.219" width="49.344" height="70.625" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy_2-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-30)">
					<rect id="Rectangle_655_copy_3" data-name="Rectangle 655 copy 3" class="cls-36" x="830.812" y="773.75" width="49.344" height="70.625" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy_3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-31)">
					<rect id="Rectangle_655_copy_3-2" data-name="Rectangle 655 copy 3" class="cls-37" x="768.781" y="773.75" width="49.344" height="70.625" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy_3-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-32)">
					<rect id="Rectangle_620_copy" data-name="Rectangle 620 copy" class="cls-38" x="743" y="541" width="171" height="24" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_620_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				<rect class="cls-39" x="732" y="563" width="193" height="4"/>
			</g>
			<g id="_7" data-name="7">
				<g style="fill: #fff; filter: url(#filter-33)">
					<rect id="rect-44" class="cls-40" x="868.875" y="466" width="205.815" height="430.594" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-44" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-34)">
					<rect id="Rectangle_620_copy-2" data-name="Rectangle 620 copy" class="cls-41" x="869" y="466" width="206" height="28" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_620_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<rect class="cls-39" x="855" y="492" width="234" height="6"/>
				<g id="windows">
					<g>
						<g style="fill: #fff; filter: url(#filter-35)">
							<rect id="rect-43" class="cls-42" x="997" y="546" width="42" height="76" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-43" style="stroke: #3392e3; filter: none; fill: none"/>
						<g style="fill: #7cc0fa; filter: url(#filter-36)">
							<rect id="Rectangle_619_copy" data-name="Rectangle 619 copy" class="cls-43" x="997" y="569" width="42" height="54" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#Rectangle_619_copy" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="986" y="621" width="61" height="4" rx="2" ry="2"/>
					</g>
					<g id="Group_10_copy" data-name="Group 10 copy">
						<g style="fill: #fff; filter: url(#filter-37)">
							<rect id="rect-42" class="cls-44" x="908" y="546" width="42" height="76" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-42" style="stroke: #3392e3; filter: none; fill: none"/>
						<g style="fill: #7cc0fa; filter: url(#filter-38)">
							<rect id="Rectangle_619_copy-2" data-name="Rectangle 619 copy" class="cls-45" x="908" y="582" width="42" height="41" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#Rectangle_619_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="897" y="621" width="61" height="4" rx="2" ry="2"/>
					</g>
					<g id="Group_10_copy_2" data-name="Group 10 copy 2">
						<g style="fill: #fff; filter: url(#filter-39)">
							<rect id="rect-41" class="cls-46" x="997" y="651" width="42" height="76" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-41" style="stroke: #3392e3; filter: none; fill: none"/>
						<g style="fill: #7cc0fa; filter: url(#filter-40)">
							<rect id="Rectangle_619_copy-3" data-name="Rectangle 619 copy" class="cls-47" x="997" y="669" width="42" height="58" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#Rectangle_619_copy-3" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="986" y="725" width="61" height="4" rx="2" ry="2"/>
					</g>
					<g id="Group_10_copy_2-2" data-name="Group 10 copy 2">
						<g style="fill: #fff; filter: url(#filter-41)">
							<rect id="rect-40" class="cls-48" x="908" y="651" width="42" height="76" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-40" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="897" y="725" width="61" height="4" rx="2" ry="2"/>
					</g>
				</g>
				<g id="doors">
					<path class="cls-49" d="M968.969,770.938h46.721a4,4,0,0,1,4,4v80.937a4,4,0,0,1-4,4H968.969a0,0,0,0,1,0,0V770.938A0,0,0,0,1,968.969,770.938Z"/>
					<ellipse class="cls-39" cx="984.454" cy="816.11" rx="4.234" ry="4.235"/>
					<g style="fill: #7cc0fa; filter: url(#filter-42)">
						<path id="Rectangle_639_copy" data-name="Rectangle 639 copy" class="cls-50" d="M927.844,770.938h46.75a0,0,0,0,1,0,0v88.937a0,0,0,0,1,0,0h-46.75a4,4,0,0,1-4-4V774.938A4,4,0,0,1,927.844,770.938Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_639_copy" style="stroke: #3392e3; filter: none; fill: none"/>
					<circle id="Ellipse_640_copy" data-name="Ellipse 640 copy" class="cls-39" cx="959.094" cy="816.11" r="4.25"/>
				</g>
				<g id="stairs">
					<rect class="cls-39" x="911.156" y="864.125" width="118.434" height="5.625" rx="2" ry="2"/>
					<rect id="Rectangle_645_copy" data-name="Rectangle 645 copy" class="cls-39" x="895.625" y="874" width="149.465" height="5.656" rx="2" ry="2"/>
				</g>
			</g>
			<g id="_8" data-name="8">
				<g style="fill: #fff; filter: url(#filter-43)">
					<path id="Rectangle_668_copy" data-name="Rectangle 668 copy" class="cls-51" d="M408.688,497.062h122.5a5,5,0,0,1,5,5V896.594a0,0,0,0,1,0,0h-132.5a0,0,0,0,1,0,0V502.062A5,5,0,0,1,408.688,497.062Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_668_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-44)">
					<rect id="rect-39" class="cls-52" x="475.562" y="554.938" width="36.657" height="55.062" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-39" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-45)">
					<rect id="Rectangle_690_copy" data-name="Rectangle 690 copy" class="cls-53" x="427.625" y="554.938" width="36.687" height="55.062" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-46)">
					<rect id="Rectangle_690_copy_2" data-name="Rectangle 690 copy 2" class="cls-54" x="475.562" y="631.188" width="36.657" height="55.031" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-47)">
					<rect id="Rectangle_690_copy_2-2" data-name="Rectangle 690 copy 2" class="cls-55" x="427.625" y="631.188" width="36.687" height="55.031" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_2-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-48)">
					<rect id="Rectangle_690_copy_3" data-name="Rectangle 690 copy 3" class="cls-56" x="475.562" y="707.438" width="36.657" height="55.031" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #f2f2f2; filter: url(#filter-49)">
					<rect id="Rectangle_690_copy_3-2" data-name="Rectangle 690 copy 3" class="cls-57" x="427.625" y="707.438" width="36.687" height="55.031" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_3-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-50)">
					<rect id="Rectangle_690_copy_4" data-name="Rectangle 690 copy 4" class="cls-58" x="475.562" y="783.625" width="36.657" height="55.094" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-51)">
					<rect id="Rectangle_690_copy_4-2" data-name="Rectangle 690 copy 4" class="cls-59" x="427.625" y="783.625" width="36.687" height="55.094" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_4-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-52)">
					<rect id="Rectangle_668_copy_3" data-name="Rectangle 668 copy 3" class="cls-60" x="393.781" y="497.062" width="152.281" height="28.219" rx="5" ry="5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_668_copy_3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-53)">
					<path id="Rectangle_559_copy_3" data-name="Rectangle 559 copy 3" class="cls-61" d="M409.311,802l-25.377,43.807c-9.607,16.712,8.632,15.487,8.632,15.487h16.745V802Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_559_copy_3" style="stroke: #3392e3; filter: none; fill: none"/>
			</g>
			<g id="_9" data-name="9">
				<g style="fill: #fff; filter: url(#filter-54)">
					<path id="path-12" class="cls-62" d="M480.562,607.156h193a5,5,0,0,1,5,5V896.594a0,0,0,0,1,0,0h-203a0,0,0,0,1,0,0V612.156A5,5,0,0,1,480.562,607.156Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#path-12" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-55)">
					<rect id="rect-38" class="cls-63" x="609.5" y="670.719" width="39.469" height="53.625" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-38" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-56)">
					<rect id="Rectangle_671_copy" data-name="Rectangle 671 copy" class="cls-64" x="555.906" y="670.719" width="39.469" height="53.625" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-57)">
					<rect id="Rectangle_671_copy_2" data-name="Rectangle 671 copy 2" class="cls-65" x="502.375" y="670.719" width="39.437" height="53.625" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-58)">
					<rect id="Rectangle_671_copy_3" data-name="Rectangle 671 copy 3" class="cls-66" x="609.5" y="744.094" width="39.469" height="53.687" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #f2f2f2; filter: url(#filter-59)">
					<rect id="Rectangle_671_copy_4" data-name="Rectangle 671 copy 4" class="cls-67" x="502.375" y="841.531" width="146.594" height="53.657" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-60)">
					<path id="Rectangle_671_copy_5" data-name="Rectangle 671 copy 5" class="cls-68" d="M648.958,823.176H502.35s-5.921,16.6-10.089,28.29c-5.129,12.728,6.18,11.24,6.18,11.24H654.176s8.492,1.388,5.572-9.272C655.581,841.75,648.958,823.176,648.958,823.176Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_5" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #f2f2f2; filter: url(#filter-61)">
					<rect id="Rectangle_671_copy_3-2" data-name="Rectangle 671 copy 3" class="cls-69" x="555.906" y="744.094" width="39.469" height="53.687" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_3-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-62)">
					<rect id="Rectangle_671_copy_3-3" data-name="Rectangle 671 copy 3" class="cls-70" x="502.375" y="744.094" width="39.437" height="53.687" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_3-3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-63)">
					<rect id="Rectangle_668_copy_2" data-name="Rectangle 668 copy 2" class="cls-71" x="469.938" y="598.719" width="215.656" height="38.093" rx="5" ry="5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_668_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
			</g>
			<g id="_10" data-name="10">
				<path class="cls-72" d="M61,863H18a2,2,0,0,1-2-2V803a2,2,0,0,1,2-2H61a2,2,0,0,1,2,2v58A2,2,0,0,1,61,863Zm-2-58H20v54H59V805Z"/>
				<rect id="Rectangle_745_copy_4" data-name="Rectangle 745 copy 4" class="cls-6" x="20" y="805" width="39" height="54"/>
				<rect id="Rectangle_745_copy_5" data-name="Rectangle 745 copy 5" class="cls-5" x="20" y="805" width="39" height="3"/>
				<g>
					<path id="Rectangle_735_copy_2" data-name="Rectangle 735 copy 2" class="cls-4" d="M4,771V893H111.87v3.939H0V767.118H111.87V771H4Z"/>
					<path id="Rectangle_735_copy" data-name="Rectangle 735 copy" class="cls-4" d="M4,676v91H111.87v3.939H0V672.118H111.87V676H4Z"/>
					<rect id="Rectangle_735_copy_5" data-name="Rectangle 735 copy 5" class="cls-5" y="771" width="116" height="122"/>
					<rect id="Rectangle_735_copy_3" data-name="Rectangle 735 copy 3" class="cls-6" y="676" width="116" height="91"/>
					<rect id="Rectangle_735_copy_4" data-name="Rectangle 735 copy 4" class="cls-5" y="676" width="116" height="4"/>
				</g>
				<g style="fill: #fff; filter: url(#filter-64)">
					<path id="path-11" class="cls-73" d="M92.906,612.812H243.594a5,5,0,0,1,5,5V896.594a0,0,0,0,1,0,0H87.906a0,0,0,0,1,0,0V617.812a5,5,0,0,1,5-5Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#path-11" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-65)">
					<rect id="Rectangle_712_copy" data-name="Rectangle 712 copy" class="cls-74" x="79.438" y="612.812" width="177.625" height="29.657" rx="5" ry="5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_712_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				<g id="Group_10_copy_3" data-name="Group 10 copy 3">
					<g style="fill: #fff; filter: url(#filter-66)">
						<rect id="rect-37" class="cls-75" x="185.156" y="677.781" width="35.25" height="59.281" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-37" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-67)">
						<rect id="Rectangle_619_copy-4" data-name="Rectangle 619 copy" class="cls-76" x="185.156" y="693.281" width="35.25" height="43.781" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_619_copy-4" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="173.906" y="731.406" width="53.532" height="5.656" rx="2" ry="2"/>
				</g>
				<g id="Group_10_copy_4" data-name="Group 10 copy 4">
					<g style="fill: #fff; filter: url(#filter-68)">
						<rect id="rect-36" class="cls-77" x="116.094" y="677.781" width="35.25" height="59.281" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-36" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-69)">
						<rect id="Rectangle_619_copy-5" data-name="Rectangle 619 copy" class="cls-78" x="116.094" y="713.062" width="35.25" height="24" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_619_copy-5" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="104.844" y="731.406" width="53.531" height="5.656" rx="2" ry="2"/>
				</g>
				<g id="Group_10_copy_5" data-name="Group 10 copy 5">
					<g style="fill: #fff; filter: url(#filter-70)">
						<rect id="rect-35" class="cls-79" x="185.156" y="765.281" width="35.25" height="59.313" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-35" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="173.906" y="818.938" width="53.532" height="5.656" rx="2" ry="2"/>
				</g>
				<g id="Group_10_copy_5-2" data-name="Group 10 copy 5">
					<g style="fill: #fff; filter: url(#filter-71)">
						<rect id="rect-34" class="cls-80" x="116.094" y="765.281" width="35.25" height="59.313" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-34" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-72)">
						<rect id="Rectangle_619_copy-6" data-name="Rectangle 619 copy" class="cls-81" x="116.094" y="783.625" width="35.25" height="40.969" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_619_copy-6" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="104.844" y="818.938" width="53.531" height="5.656" rx="2" ry="2"/>
				</g>
			</g>
			<g id="path">
				<g id="_1" data-name="1">
					<g style="fill: #e8e8ee; filter: url(#filter-73)">
						<path id="Rectangle_706_copy_3" data-name="Rectangle 706 copy 3" class="cls-82" d="M687,693.281h15.75a4,4,0,0,1,4,4v23.063a4,4,0,0,1-4,4H687a0,0,0,0,1,0,0V693.281A0,0,0,0,1,687,693.281Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_706_copy_3" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #e8e8ee; filter: url(#filter-74)">
						<rect id="Rectangle_706_copy_4" data-name="Rectangle 706 copy 4" class="cls-83" x="672.938" y="693.281" width="19.718" height="31.063" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_706_copy_4" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
			</g>
			<g id="front-tree">
				<g id="_3-2" data-name="3">
					<g style="fill: #9bd1ff; filter: url(#filter-75)">
						<ellipse id="ellipse-3" class="cls-84" cx="1244.55" cy="836.594" rx="37.36" ry="37.406" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#ellipse-3" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="1243.84" y="840.125" width="1.41" height="22.563" rx="0.5" ry="0.5"/>
					<path id="Rectangle_536_copy" data-name="Rectangle 536 copy" class="cls-4" d="M1228.57,845.946a0.723,0.723,0,0,0,0,1.034l15.47,15.5a0.73,0.73,0,0,0,1.03-1.034l-15.47-15.5A0.727,0.727,0,0,0,1228.57,845.946Z"/>
					<path id="Rectangle_536_copy_2" data-name="Rectangle 536 copy 2" class="cls-4" d="M1260.53,845.946a0.723,0.723,0,0,1,0,1.034l-15.47,15.5a0.73,0.73,0,0,1-1.03-1.034l15.47-15.5A0.727,0.727,0,0,1,1260.53,845.946Z"/>
					<path class="cls-39" d="M1243.53,859.875h2.03a2.5,2.5,0,0,1,2.5,2.5v28.563a0,0,0,0,1,0,0h-7.03a0,0,0,0,1,0,0V862.375A2.5,2.5,0,0,1,1243.53,859.875Z"/>
				</g>
				<g id="_4-2" data-name="4">
					<g style="fill: #9bd1ff; filter: url(#filter-76)">
						<ellipse id="ellipse-2" class="cls-85" cx="745.515" cy="836.594" rx="37.36" ry="37.406" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#ellipse-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="744.812" y="840.125" width="1.407" height="22.563" rx="0.5" ry="0.5"/>
					<path id="Rectangle_536_copy-2" data-name="Rectangle 536 copy" class="cls-4" d="M729.537,845.946a0.732,0.732,0,0,0,0,1.034l15.476,15.5a0.73,0.73,0,0,0,1.032-1.034l-15.476-15.5A0.73,0.73,0,0,0,729.537,845.946Z"/>
					<path id="Rectangle_536_copy_2-2" data-name="Rectangle 536 copy 2" class="cls-4" d="M761.506,845.946a0.734,0.734,0,0,1,0,1.034l-15.476,15.5A0.73,0.73,0,0,1,745,861.445l15.476-15.5A0.73,0.73,0,0,1,761.506,845.946Z"/>
					<path class="cls-39" d="M744.5,859.875h2.031a2.5,2.5,0,0,1,2.5,2.5v28.563a0,0,0,0,1,0,0H742a0,0,0,0,1,0,0V862.375A2.5,2.5,0,0,1,744.5,859.875Z"/>
				</g>
				<g id="_5-2" data-name="5">
					<g style="fill: #9bd1ff; filter: url(#filter-77)">
						<ellipse id="ellipse" class="cls-86" cx="301.469" cy="836.594" rx="37.375" ry="37.406" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#ellipse" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="300.781" y="840.125" width="1.407" height="22.563" rx="0.5" ry="0.5"/>
					<path id="Rectangle_536_copy-3" data-name="Rectangle 536 copy" class="cls-4" d="M285.485,845.946a0.734,0.734,0,0,0,0,1.034l15.476,15.5a0.73,0.73,0,0,0,1.032-1.034l-15.476-15.5A0.73,0.73,0,0,0,285.485,845.946Z"/>
					<path id="Rectangle_536_copy_2-3" data-name="Rectangle 536 copy 2" class="cls-4" d="M317.454,845.946a0.732,0.732,0,0,1,0,1.034l-15.476,15.5a0.73,0.73,0,0,1-1.032-1.034l15.476-15.5A0.73,0.73,0,0,1,317.454,845.946Z"/>
					<path class="cls-39" d="M300.469,859.875H302.5a2.5,2.5,0,0,1,2.5,2.5v28.563a0,0,0,0,1,0,0h-7.031a0,0,0,0,1,0,0V862.375A2.5,2.5,0,0,1,300.469,859.875Z"/>
				</g>
			</g>
			<g id="street-lights">
				<g id="_1-2" data-name="1">
					<path class="cls-87" d="M2505.52,896.588V770.941c-2.93-46.028-68.9-30.343-67.67,0"/>
					<path id="Shape_600_copy" data-name="Shape 600 copy" class="cls-87" d="M2505.52,896.588V770.941c2.31-38.063,52.92-29.336,53.56-2.823"/>
					<g style="fill: #e8e8ee; filter: url(#filter-78)">
						<path id="path-10" class="cls-88" d="M2444.19,759.647c-7.66,0-14.8,6.321-14.8,14.118v2.823H2459v-2.823C2459,765.968,2451.86,759.647,2444.19,759.647Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#path-10" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #e8e8ee; filter: url(#filter-79)">
						<path id="Rectangle_602_copy" data-name="Rectangle 602 copy" class="cls-89" d="M2561.2,759.647c-7.67,0-14.8,6.321-14.8,14.118v2.823H2576v-2.823C2576,765.968,2568.86,759.647,2561.2,759.647Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_602_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
				<g id="_2" data-name="2">
					<path class="cls-87" d="M1173.36,896.588V770.941c-2.92-46.028-68.89-30.343-67.66,0"/>
					<path id="Shape_600_copy-2" data-name="Shape 600 copy" class="cls-87" d="M1173.36,896.588V770.941c2.32-38.063,52.92-29.336,53.57-2.823"/>
					<g style="fill: #e8e8ee; filter: url(#filter-80)">
						<path id="path-9" class="cls-90" d="M1112.04,759.647c-7.66,0-14.8,6.321-14.8,14.118v2.823h29.6v-2.823C1126.84,765.968,1119.7,759.647,1112.04,759.647Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#path-9" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #e8e8ee; filter: url(#filter-81)">
						<path id="Rectangle_602_copy-2" data-name="Rectangle 602 copy" class="cls-91" d="M1229.04,759.647c-7.66,0-14.8,6.321-14.8,14.118v2.823h29.61v-2.823C1243.85,765.968,1236.71,759.647,1229.04,759.647Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_602_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
				<g id="_3-3" data-name="3">
					<path class="cls-87" d="M371.249,896.588V770.941c-2.922-46.028-68.891-30.343-67.665,0"/>
					<path id="Shape_600_copy-3" data-name="Shape 600 copy" class="cls-87" d="M371.249,896.588V770.941c2.318-38.063,52.923-29.336,53.568-2.823"/>
					<g style="fill: #e8e8ee; filter: url(#filter-82)">
						<path id="path-8" class="cls-92" d="M309.928,759.647c-7.664,0-14.8,6.321-14.8,14.118v2.823h29.6v-2.823C324.73,765.968,317.592,759.647,309.928,759.647Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#path-8" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #e8e8ee; filter: url(#filter-83)">
						<path id="Rectangle_602_copy-3" data-name="Rectangle 602 copy" class="cls-93" d="M426.932,759.647c-7.664,0-14.8,6.321-14.8,14.118v2.823h29.6v-2.823C441.734,765.968,434.6,759.647,426.932,759.647Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_602_copy-3" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
			</g>
		</g>
		<g id="Front_Buildings" data-name="Front Buildings">
			<g id="_1-3" data-name="1">
				<path id="bg-2" data-name="bg" class="cls-94" d="M106,700H228a5,5,0,0,1,5,5V897a0,0,0,0,1,0,0H101a0,0,0,0,1,0,0V705A5,5,0,0,1,106,700Z"/>
				<g style="fill: #7cc0fa; filter: url(#filter-84)">
					<rect id="roof" class="cls-95" x="98" y="682" width="139" height="21" rx="8" ry="8" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#roof" style="stroke: #3392e3; filter: none; fill: none"/>
				<g id="r-1">
					<g>
						<g style="fill: #9bd1ff; filter: url(#filter-85)">
							<rect id="rect-33" class="cls-96" x="118" y="722" width="28" height="42" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-33" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="120" y="751" width="24" height="3"/>
					</g>
					<g id="Group_6_copy" data-name="Group 6 copy">
						<g style="fill: #9bd1ff; filter: url(#filter-86)">
							<rect id="rect-32" class="cls-97" x="154" y="722" width="28" height="42" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-32" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="156" y="751" width="24" height="3"/>
					</g>
				</g>
				<g id="r-2">
					<g>
						<g style="fill: #9bd1ff; filter: url(#filter-87)">
							<rect id="rect-31" class="cls-98" x="118" y="776" width="28" height="42" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-31" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="120" y="805" width="24" height="3"/>
					</g>
					<g id="Group_6_copy-2" data-name="Group 6 copy">
						<g style="fill: #9bd1ff; filter: url(#filter-88)">
							<rect id="rect-30" class="cls-99" x="154" y="776" width="28" height="42" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-30" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="156" y="805" width="24" height="3"/>
					</g>
				</g>
				<g id="r-3">
					<g>
						<g style="fill: #9bd1ff; filter: url(#filter-89)">
							<rect id="rect-29" class="cls-100" x="118" y="830" width="28" height="42" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-29" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="120" y="859" width="24" height="3"/>
					</g>
					<g id="Group_6_copy-3" data-name="Group 6 copy">
						<g style="fill: #9bd1ff; filter: url(#filter-90)">
							<rect id="rect-28" class="cls-101" x="154" y="830" width="28" height="42" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-28" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="156" y="859" width="24" height="3"/>
					</g>
				</g>
			</g>
			<g id="_2-2" data-name="2">
				<path id="bg-3" data-name="bg" class="cls-94" d="M193,656H345a5,5,0,0,1,5,5V897a0,0,0,0,1,0,0H188a0,0,0,0,1,0,0V661A5,5,0,0,1,193,656Z"/>
				<g style="fill: #7cc0fa; filter: url(#filter-91)">
					<rect id="roof-2" data-name="roof" class="cls-102" x="184" y="634" width="170" height="26" rx="8" ry="8" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#roof-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g id="r-1-2" data-name="r-1">
					<g>
						<g style="fill: #9bd1ff; filter: url(#filter-92)">
							<rect id="rect-27" class="cls-103" x="208" y="683" width="34" height="51" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-27" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="210" y="718" width="30" height="3"/>
					</g>
					<g id="Group_6_copy-4" data-name="Group 6 copy">
						<g style="fill: #9bd1ff; filter: url(#filter-93)">
							<rect id="rect-26" class="cls-104" x="252" y="683" width="34" height="51" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-26" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="254" y="718" width="30" height="3"/>
					</g>
					<g id="Group_6_copy_2" data-name="Group 6 copy 2">
						<g style="fill: #9bd1ff; filter: url(#filter-94)">
							<rect id="rect-25" class="cls-105" x="296" y="683" width="34" height="51" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-25" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="298" y="718" width="30" height="3"/>
					</g>
				</g>
				<g id="r-2-2" data-name="r-2">
					<g>
						<g style="fill: #9bd1ff; filter: url(#filter-95)">
							<rect id="rect-24" class="cls-106" x="208" y="749" width="34" height="51" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-24" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="210" y="784" width="30" height="3"/>
					</g>
					<g id="Group_6_copy-5" data-name="Group 6 copy">
						<g style="fill: #9bd1ff; filter: url(#filter-96)">
							<rect id="rect-23" class="cls-107" x="252" y="749" width="34" height="51" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-23" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="254" y="784" width="30" height="3"/>
					</g>
					<g id="Group_6_copy_2-2" data-name="Group 6 copy 2">
						<g style="fill: #9bd1ff; filter: url(#filter-97)">
							<rect id="rect-22" class="cls-108" x="296" y="749" width="34" height="51" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-22" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="298" y="784" width="30" height="3"/>
					</g>
				</g>
				<g id="doors-2" data-name="doors">
					<g>
						<path class="cls-109" d="M246,819h25a0,0,0,0,1,0,0v57a0,0,0,0,1,0,0H246a4,4,0,0,1-4-4V823A4,4,0,0,1,246,819Z"/>
						<circle class="cls-39" cx="262" cy="847" r="3"/>
					</g>
					<g>
						<g style="fill: #9bd1ff; filter: url(#filter-98)">
							<path id="Rectangle_63_copy" data-name="Rectangle 63 copy" class="cls-110" d="M267,819h25a4,4,0,0,1,4,4v49a4,4,0,0,1-4,4H267a0,0,0,0,1,0,0V819A0,0,0,0,1,267,819Z" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#Rectangle_63_copy" style="stroke: #3392e3; filter: none; fill: none"/>
						<circle id="Ellipse_2_copy" data-name="Ellipse 2 copy" class="cls-39" cx="276" cy="847" r="3"/>
					</g>
				</g>
				<g id="stairs-2" data-name="stairs">
					<rect class="cls-39" x="234" y="878" width="70" height="4" rx="2" ry="2"/>
					<rect id="Rectangle_64_copy" data-name="Rectangle 64 copy" class="cls-39" x="225" y="884" width="88" height="4" rx="2" ry="2"/>
				</g>
				<g id="windows-2" data-name="windows">
					<g style="fill: #9bd1ff; filter: url(#filter-99)">
						<rect id="r" class="cls-111" x="303" y="834" width="27" height="27" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#r" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #9bd1ff; filter: url(#filter-100)">
						<rect id="l" class="cls-112" x="208" y="834" width="27" height="27" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#l" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
			</g>
			<g id="_3-4" data-name="3">
				<g style="fill: #fff; filter: url(#filter-101)">
					<path id="path-7" class="cls-113" d="M408,695h80a5,5,0,0,1,5,5V897a0,0,0,0,1,0,0H403a0,0,0,0,1,0,0V700A5,5,0,0,1,408,695Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#path-7" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-102)">
					<rect id="Rectangle_550_copy-2" data-name="Rectangle 550 copy" class="cls-114" x="399" y="678" width="98" height="21" rx="5" ry="5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_550_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-103)">
					<path id="path-6" class="cls-115" d="M489,836s9.735,16.816,16.254,28.075c6.153,10.71-5.529,9.925-5.529,9.925H489V836Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#path-6" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-104)">
					<rect id="rect-21" class="cls-116" x="424" y="723" width="19" height="26" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-21" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-105)">
					<rect id="Rectangle_551_copy" data-name="Rectangle 551 copy" class="cls-117" x="424" y="764" width="19" height="26" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_551_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-106)">
					<rect id="Rectangle_551_copy_2" data-name="Rectangle 551 copy 2" class="cls-118" x="424" y="805" width="19" height="26" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_551_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-107)">
					<rect id="Rectangle_551_copy_3-6" data-name="Rectangle 551 copy 3" class="cls-119" x="453" y="723" width="19" height="26" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_551_copy_3-6" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-108)">
					<rect id="Rectangle_551_copy_3-7" data-name="Rectangle 551 copy 3" class="cls-120" x="453" y="764" width="19" height="26" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_551_copy_3-7" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-109)">
					<rect id="Rectangle_551_copy_3-8" data-name="Rectangle 551 copy 3" class="cls-121" x="453" y="805" width="19" height="26" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_551_copy_3-8" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #3392e3; filter: url(#filter-110)">
					<rect id="Rectangle_551_copy_3-9" data-name="Rectangle 551 copy 3" class="cls-122" x="432" y="862" width="33" height="35" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_551_copy_3-9" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-111)">
					<path id="Rectangle_559_copy" data-name="Rectangle 559 copy" class="cls-123" d="M461,851s7.433,10.221,12.167,16.729C476.959,873.568,469.8,873,469.8,873H426.5s-6.978.5-3.083-4.7L436,851h25Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_559_copy" style="stroke: #3392e3; filter: none; fill: none"/>
			</g>
			<g id="_4-3" data-name="4">
				<g style="fill: #fff; filter: url(#filter-112)">
					<rect id="rect-20" class="cls-124" x="796" y="822" width="89" height="75" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-20" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-113)">
					<rect id="Rectangle_585_copy-2" data-name="Rectangle 585 copy" class="cls-125" x="790" y="809" width="101" height="18" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_585_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #3392e3; filter: url(#filter-114)">
					<rect id="Rectangle_551_copy_4-2" data-name="Rectangle 551 copy 4" class="cls-126" x="829" y="872" width="23" height="25" rx="2.5" ry="2.5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_551_copy_4-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-115)">
					<path id="Rectangle_559_copy_2-2" data-name="Rectangle 559 copy 2" class="cls-127" d="M849.556,864s5.285,7.434,8.652,12.168c2.7,4.247-2.391,3.833-2.391,3.833H825.025s-4.962.362-2.192-3.421L831.778,864h17.778Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_559_copy_2-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-116)">
					<rect id="rect-19" class="cls-128" x="807" y="837" width="25" height="18" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-19" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-117)">
					<rect id="Rectangle_589_copy-2" data-name="Rectangle 589 copy" class="cls-129" x="862" y="867" width="12" height="18" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_589_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
			</g>
			<g id="_5-3" data-name="5">
				<g id="back-2" data-name="back">
					<g style="fill: #fff; filter: url(#filter-118)">
						<rect id="rect-18" class="cls-130" x="585" y="734" width="227" height="164" rx="5" ry="5" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-18" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-119)">
						<rect id="rect-17" class="cls-131" x="658" y="754" width="29" height="35" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-17" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-120)">
						<rect id="Rectangle_576_copy-2" data-name="Rectangle 576 copy" class="cls-132" x="701" y="754" width="29" height="35" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_576_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-121)">
						<rect id="Rectangle_576_copy_2-2" data-name="Rectangle 576 copy 2" class="cls-133" x="745" y="754" width="29" height="35" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_576_copy_2-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-122)">
						<rect id="Rectangle_576_copy_3-3" data-name="Rectangle 576 copy 3" class="cls-134" x="658" y="852" width="29" height="35" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_576_copy_3-3" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-123)">
						<rect id="Rectangle_576_copy_3-4" data-name="Rectangle 576 copy 3" class="cls-135" x="701" y="852" width="29" height="35" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_576_copy_3-4" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-124)">
						<path id="Rectangle_573_copy-2" data-name="Rectangle 573 copy" class="cls-136" d="M590,687H810a5,5,0,0,1,5,5l20,49a5,5,0,0,1-5,5H590a5,5,0,0,1-5-5V692A5,5,0,0,1,590,687Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_573_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #f2f2f2; filter: url(#filter-125)">
						<path id="Rectangle_573_copy_2-2" data-name="Rectangle 573 copy 2" class="cls-137" d="M590,796H814a5,5,0,0,1,5,5l16,39a5,5,0,0,1-5,5H590a5,5,0,0,1-5-5V801A5,5,0,0,1,590,796Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_573_copy_2-2" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
				<g id="front-2" data-name="front">
					<g style="fill: #fff; filter: url(#filter-126)">
						<path id="path-5" class="cls-138" d="M525,671H646a0,0,0,0,1,0,0V892a5,5,0,0,1-5,5H530a5,5,0,0,1-5-5V671A0,0,0,0,1,525,671Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#path-5" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-127)">
						<rect id="rect-16" class="cls-139" x="520" y="661" width="130" height="13" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-16" style="stroke: #3392e3; filter: none; fill: none"/>
					<path id="Rectangle_563_copy-2" data-name="Rectangle 563 copy" class="cls-25" d="M590.979,616.953L650,664.005H520l59.357-47.048S584.546,610.309,590.979,616.953Z"/>
					<g style="fill: #7cc0fa; filter: url(#filter-128)">
						<rect id="rect-15" class="cls-140" x="544" y="696" width="34" height="42" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-15" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-129)">
						<rect id="Rectangle_566_copy-2" data-name="Rectangle 566 copy" class="cls-141" x="592" y="696" width="34" height="42" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_566_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-130)">
						<rect id="Rectangle_566_copy_2-2" data-name="Rectangle 566 copy 2" class="cls-142" x="592" y="746" width="34" height="42" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_566_copy_2-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-131)">
						<rect id="Rectangle_566_copy_3-3" data-name="Rectangle 566 copy 3" class="cls-143" x="544" y="796" width="34" height="42" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_566_copy_3-3" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-132)">
						<rect id="Rectangle_566_copy_3-4" data-name="Rectangle 566 copy 3" class="cls-144" x="592" y="846" width="34" height="42" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_566_copy_3-4" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
			</g>
			<g id="_6-2" data-name="6">
				<g style="fill: #fff; filter: url(#filter-133)">
					<rect id="rect-14" class="cls-145" x="1151" y="645" width="121" height="252" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-14" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-134)">
					<rect id="rect-13" class="cls-146" x="1175" y="684" width="35" height="50" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-13" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-135)">
					<rect id="Rectangle_655_copy-2" data-name="Rectangle 655 copy" class="cls-147" x="1219" y="684" width="35" height="50" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-136)">
					<rect id="Rectangle_655_copy_2-3" data-name="Rectangle 655 copy 2" class="cls-148" x="1175" y="748" width="35" height="50" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy_2-3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-137)">
					<rect id="Rectangle_655_copy_2-4" data-name="Rectangle 655 copy 2" class="cls-149" x="1219" y="748" width="35" height="50" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy_2-4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-138)">
					<rect id="Rectangle_655_copy_3-3" data-name="Rectangle 655 copy 3" class="cls-150" x="1175" y="810" width="35" height="50" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy_3-3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-139)">
					<rect id="Rectangle_655_copy_3-4" data-name="Rectangle 655 copy 3" class="cls-151" x="1219" y="810" width="35" height="50" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_655_copy_3-4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-140)">
					<rect id="Rectangle_620_copy-3" data-name="Rectangle 620 copy" class="cls-152" x="1151" y="645" width="121" height="17" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_620_copy-3" style="stroke: #3392e3; filter: none; fill: none"/>
				<rect class="cls-39" x="1143" y="661" width="137" height="3"/>
			</g>
			<g id="_7-2" data-name="7">
				<g style="fill: #fff; filter: url(#filter-141)">
					<rect id="rect-12" class="cls-153" x="1037" y="592" width="146" height="305" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-12" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-142)">
					<rect id="Rectangle_620_copy-4" data-name="Rectangle 620 copy" class="cls-154" x="1037" y="592" width="146" height="20" rx="4" ry="4" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_620_copy-4" style="stroke: #3392e3; filter: none; fill: none"/>
				<rect class="cls-39" x="1027" y="610" width="166" height="4"/>
				<g id="windows-3" data-name="windows">
					<g>
						<g style="fill: #fff; filter: url(#filter-143)">
							<rect id="rect-11" class="cls-155" x="1062" y="649" width="30" height="54" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-11" style="stroke: #3392e3; filter: none; fill: none"/>
						<g style="fill: #7cc0fa; filter: url(#filter-144)">
							<rect id="Rectangle_619_copy-7" data-name="Rectangle 619 copy" class="cls-156" x="1062" y="665" width="30" height="38" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#Rectangle_619_copy-7" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="1057" y="701" width="43" height="4" rx="2" ry="2"/>
					</g>
					<g id="Group_10_copy-2" data-name="Group 10 copy">
						<g style="fill: #fff; filter: url(#filter-145)">
							<rect id="rect-10" class="cls-157" x="1125" y="649" width="30" height="54" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-10" style="stroke: #3392e3; filter: none; fill: none"/>
						<g style="fill: #7cc0fa; filter: url(#filter-146)">
							<rect id="Rectangle_619_copy-8" data-name="Rectangle 619 copy" class="cls-158" x="1125" y="674" width="30" height="29" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#Rectangle_619_copy-8" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="1120" y="701" width="43" height="4" rx="2" ry="2"/>
					</g>
					<g id="Group_10_copy_2-3" data-name="Group 10 copy 2">
						<g style="fill: #fff; filter: url(#filter-147)">
							<rect id="rect-9" class="cls-159" x="1062" y="723" width="30" height="54" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-9" style="stroke: #3392e3; filter: none; fill: none"/>
						<g style="fill: #7cc0fa; filter: url(#filter-148)">
							<rect id="Rectangle_619_copy-9" data-name="Rectangle 619 copy" class="cls-160" x="1062" y="736" width="30" height="41" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#Rectangle_619_copy-9" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="1057" y="775" width="43" height="4" rx="2" ry="2"/>
					</g>
					<g id="Group_10_copy_2-4" data-name="Group 10 copy 2">
						<g style="fill: #fff; filter: url(#filter-149)">
							<rect id="rect-8" class="cls-161" x="1125" y="723" width="30" height="54" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
						</g>
						<use xlink:href="#rect-8" style="stroke: #3392e3; filter: none; fill: none"/>
						<rect class="cls-39" x="1120" y="775" width="43" height="4" rx="2" ry="2"/>
					</g>
				</g>
				<g id="doors-3" data-name="doors">
					<path class="cls-49" d="M1080,808h32a0,0,0,0,1,0,0v63a0,0,0,0,1,0,0h-32a4,4,0,0,1-4-4V812A4,4,0,0,1,1080,808Z"/>
					<circle class="cls-39" cx="1101" cy="840" r="3"/>
					<g style="fill: #7cc0fa; filter: url(#filter-150)">
						<path id="Rectangle_639_copy-2" data-name="Rectangle 639 copy" class="cls-162" d="M1108,808h32a4,4,0,0,1,4,4v55a4,4,0,0,1-4,4h-32a0,0,0,0,1,0,0V808A0,0,0,0,1,1108,808Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_639_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<circle id="Ellipse_640_copy-2" data-name="Ellipse 640 copy" class="cls-39" cx="1119" cy="840" r="3"/>
				</g>
				<g id="stairs-3" data-name="stairs">
					<rect class="cls-39" x="1069" y="877" width="84" height="4" rx="2" ry="2"/>
					<rect id="Rectangle_645_copy-2" data-name="Rectangle 645 copy" class="cls-39" x="1058" y="884" width="106" height="4" rx="2" ry="2"/>
				</g>
			</g>
			<g id="_8-2" data-name="8">
				<g style="fill: #fff; filter: url(#filter-151)">
					<path id="Rectangle_668_copy-2" data-name="Rectangle 668 copy" class="cls-163" d="M1424,614h84a5,5,0,0,1,5,5V897a0,0,0,0,1,0,0h-94a0,0,0,0,1,0,0V619A5,5,0,0,1,1424,614Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_668_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-152)">
					<rect id="rect-7" class="cls-164" x="1436" y="655" width="26" height="39" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-7" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-153)">
					<rect id="Rectangle_690_copy-2" data-name="Rectangle 690 copy" class="cls-165" x="1470" y="655" width="26" height="39" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-154)">
					<rect id="Rectangle_690_copy_2-3" data-name="Rectangle 690 copy 2" class="cls-166" x="1436" y="709" width="26" height="39" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_2-3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-155)">
					<rect id="Rectangle_690_copy_2-4" data-name="Rectangle 690 copy 2" class="cls-167" x="1470" y="709" width="26" height="39" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_2-4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-156)">
					<rect id="Rectangle_690_copy_3-3" data-name="Rectangle 690 copy 3" class="cls-168" x="1436" y="763" width="26" height="39" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_3-3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #f2f2f2; filter: url(#filter-157)">
					<rect id="Rectangle_690_copy_3-4" data-name="Rectangle 690 copy 3" class="cls-169" x="1470" y="763" width="26" height="39" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_3-4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-158)">
					<rect id="Rectangle_690_copy_4-3" data-name="Rectangle 690 copy 4" class="cls-170" x="1436" y="817" width="26" height="39" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_4-3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-159)">
					<rect id="Rectangle_690_copy_4-4" data-name="Rectangle 690 copy 4" class="cls-171" x="1470" y="817" width="26" height="39" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_690_copy_4-4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-160)">
					<rect id="Rectangle_668_copy_3-2" data-name="Rectangle 668 copy 3" class="cls-172" x="1412" y="614" width="108" height="20" rx="5" ry="5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_668_copy_3-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #9bd1ff; filter: url(#filter-161)">
					<path id="Rectangle_559_copy_3-2" data-name="Rectangle 559 copy 3" class="cls-173" d="M1509,830s10.78,18.586,18,31.03c6.82,11.837-6.12,10.97-6.12,10.97H1509V830Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_559_copy_3-2" style="stroke: #3392e3; filter: none; fill: none"/>
			</g>
			<g id="_9-2" data-name="9">
				<g style="fill: #fff; filter: url(#filter-162)">
					<path id="path-4" class="cls-174" d="M1323,692h134a5,5,0,0,1,5,5V897a0,0,0,0,1,0,0H1318a0,0,0,0,1,0,0V697A5,5,0,0,1,1323,692Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#path-4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-163)">
					<rect id="rect-6" class="cls-175" x="1339" y="737" width="28" height="38" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-6" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-164)">
					<rect id="Rectangle_671_copy-2" data-name="Rectangle 671 copy" class="cls-176" x="1377" y="737" width="28" height="38" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-165)">
					<rect id="Rectangle_671_copy_2-2" data-name="Rectangle 671 copy 2" class="cls-177" x="1415" y="737" width="28" height="38" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_2-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-166)">
					<rect id="Rectangle_671_copy_3-4" data-name="Rectangle 671 copy 3" class="cls-178" x="1339" y="789" width="28" height="38" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_3-4" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #f2f2f2; filter: url(#filter-167)">
					<rect id="Rectangle_671_copy_4-2" data-name="Rectangle 671 copy 4" class="cls-179" x="1339" y="858" width="104" height="38" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_4-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-168)">
					<path id="Rectangle_671_copy_5-2" data-name="Rectangle 671 copy 5" class="cls-180" d="M1339,845h104s4.2,11.761,7.16,20.039c3.64,9.015-4.39,7.961-4.39,7.961H1335.3s-6.03.983-3.95-6.568C1334.3,858.156,1339,845,1339,845Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_5-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #f2f2f2; filter: url(#filter-169)">
					<rect id="Rectangle_671_copy_3-5" data-name="Rectangle 671 copy 3" class="cls-181" x="1377" y="789" width="28" height="38" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_3-5" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-170)">
					<rect id="Rectangle_671_copy_3-6" data-name="Rectangle 671 copy 3" class="cls-182" x="1415" y="789" width="28" height="38" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_671_copy_3-6" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-171)">
					<rect id="Rectangle_668_copy_2-2" data-name="Rectangle 668 copy 2" class="cls-183" x="1313" y="686" width="153" height="27" rx="5" ry="5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_668_copy_2-2" style="stroke: #3392e3; filter: none; fill: none"/>
			</g>
			<g id="_10-2" data-name="10">
				<path class="cls-4" d="M1720,897V768h200V897H1720Zm196-129H1720V893h196V768Z"/>
				<rect class="cls-5" x="1737" y="808" width="183" height="85"/>
				<g style="fill: #7cc0fa; filter: url(#filter-172)">
					<rect id="rect-5" class="cls-184" x="1755" y="829" width="33" height="44" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#rect-5" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-173)">
					<rect id="Rectangle_745_copy" data-name="Rectangle 745 copy" class="cls-185" x="1800" y="829" width="33" height="44" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_745_copy" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #f2f2f2; filter: url(#filter-174)">
					<rect id="Rectangle_745_copy_2" data-name="Rectangle 745 copy 2" class="cls-186" x="1845" y="829" width="33" height="44" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_745_copy_2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g>
					<path id="Rectangle_735_copy-2" data-name="Rectangle 735 copy" class="cls-4" d="M1720,808V738h200v70H1720Zm196-66H1720v62h196V742Z"/>
					<rect class="cls-6" x="1737" y="742" width="183" height="62"/>
					<rect id="Rectangle_526_copy" data-name="Rectangle 526 copy" class="cls-5" x="1737" y="742" width="183" height="3"/>
				</g>
				<g style="fill: #fff; filter: url(#filter-175)">
					<path id="path-3" class="cls-187" d="M1628,696h104a5,5,0,0,1,5,5V897a0,0,0,0,1,0,0H1623a0,0,0,0,1,0,0V701A5,5,0,0,1,1628,696Z" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#path-3" style="stroke: #3392e3; filter: none; fill: none"/>
				<g style="fill: #7cc0fa; filter: url(#filter-176)">
					<rect id="Rectangle_712_copy-2" data-name="Rectangle 712 copy" class="cls-188" x="1617" y="696" width="126" height="21" rx="5" ry="5" style="stroke: inherit; filter: none; fill: inherit"/>
				</g>
				<use xlink:href="#Rectangle_712_copy-2" style="stroke: #3392e3; filter: none; fill: none"/>
				<g id="Group_10_copy_3-2" data-name="Group 10 copy 3">
					<g style="fill: #fff; filter: url(#filter-177)">
						<rect id="rect-4" class="cls-189" x="1643" y="742" width="25" height="42" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-4" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-178)">
						<rect id="Rectangle_619_copy-10" data-name="Rectangle 619 copy" class="cls-190" x="1643" y="753" width="25" height="31" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_619_copy-10" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="1638" y="782" width="38" height="4" rx="2" ry="2"/>
				</g>
				<g id="Group_10_copy_4-2" data-name="Group 10 copy 4">
					<g style="fill: #fff; filter: url(#filter-179)">
						<rect id="rect-3" class="cls-191" x="1692" y="742" width="25" height="42" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-3" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-180)">
						<rect id="Rectangle_619_copy-11" data-name="Rectangle 619 copy" class="cls-192" x="1692" y="767" width="25" height="17" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_619_copy-11" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="1687" y="782" width="38" height="4" rx="2" ry="2"/>
				</g>
				<g id="Group_10_copy_5-3" data-name="Group 10 copy 5">
					<g style="fill: #fff; filter: url(#filter-181)">
						<rect id="rect-2" class="cls-193" x="1643" y="804" width="25" height="42" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="1638" y="844" width="38" height="4" rx="2" ry="2"/>
				</g>
				<g id="Group_10_copy_5-4" data-name="Group 10 copy 5">
					<g style="fill: #fff; filter: url(#filter-182)">
						<rect id="rect" class="cls-194" x="1692" y="804" width="25" height="42" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#rect" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #7cc0fa; filter: url(#filter-183)">
						<rect id="Rectangle_619_copy-12" data-name="Rectangle 619 copy" class="cls-195" x="1692" y="817" width="25" height="29" rx="2" ry="2" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_619_copy-12" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="1687" y="844" width="38" height="4" rx="2" ry="2"/>
				</g>
			</g>
			<g id="path-2" data-name="path">
				<g id="_1-4" data-name="1">
					<g style="fill: #e8e8ee; filter: url(#filter-184)">
						<path id="Rectangle_706_copy_3-2" data-name="Rectangle 706 copy 3" class="cls-196" d="M1298,753h10a0,0,0,0,1,0,0v22a0,0,0,0,1,0,0h-10a4,4,0,0,1-4-4V757A4,4,0,0,1,1298,753Z" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_706_copy_3-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<g style="fill: #e8e8ee; filter: url(#filter-185)">
						<rect id="Rectangle_706_copy_4-2" data-name="Rectangle 706 copy 4" class="cls-197" x="1304" y="753" width="14" height="22" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#Rectangle_706_copy_4-2" style="stroke: #3392e3; filter: none; fill: none"/>
				</g>
			</g>
			<g id="front-tree-2" data-name="front-tree">
				<g id="_1-5" data-name="1">
					<g style="fill: #9bd1ff; filter: url(#filter-186)">
						<circle id="circle-5" class="cls-198" cx="78.5" cy="854.5" r="26.5" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#circle-5" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="78" y="857" width="1" height="16" rx="0.5" ry="0.5"/>
					<path id="Rectangle_536_copy-4" data-name="Rectangle 536 copy" class="cls-4" d="M89.839,861.129a0.518,0.518,0,0,1,0,.732L78.861,872.839a0.518,0.518,0,0,1-.732-0.732l10.978-10.978A0.518,0.518,0,0,1,89.839,861.129Z"/>
					<path id="Rectangle_536_copy_2-4" data-name="Rectangle 536 copy 2" class="cls-4" d="M67.161,861.129a0.518,0.518,0,0,0,0,.732l10.978,10.978a0.518,0.518,0,0,0,.732-0.732L67.893,861.129A0.518,0.518,0,0,0,67.161,861.129Z"/>
					<path class="cls-39" d="M78.5,871h0a2.5,2.5,0,0,1,2.5,2.5V893a0,0,0,0,1,0,0H76a0,0,0,0,1,0,0V873.5A2.5,2.5,0,0,1,78.5,871Z"/>
				</g>
				<g id="_2-3" data-name="2">
					<g style="fill: #9bd1ff; filter: url(#filter-187)">
						<circle id="circle-4" class="cls-199" cx="361.5" cy="854.5" r="26.5" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#circle-4" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="361" y="857" width="1" height="16" rx="0.5" ry="0.5"/>
					<path id="Rectangle_536_copy-5" data-name="Rectangle 536 copy" class="cls-4" d="M372.839,861.129a0.518,0.518,0,0,1,0,.732l-10.978,10.978a0.518,0.518,0,0,1-.732-0.732l10.978-10.978A0.518,0.518,0,0,1,372.839,861.129Z"/>
					<path id="Rectangle_536_copy_2-5" data-name="Rectangle 536 copy 2" class="cls-4" d="M350.161,861.129a0.518,0.518,0,0,0,0,.732l10.978,10.978a0.518,0.518,0,0,0,.732-0.732l-10.978-10.978A0.518,0.518,0,0,0,350.161,861.129Z"/>
					<path class="cls-39" d="M361.5,871h0a2.5,2.5,0,0,1,2.5,2.5V893a0,0,0,0,1,0,0h-5a0,0,0,0,1,0,0V873.5A2.5,2.5,0,0,1,361.5,871Z"/>
				</g>
				<g id="_3-5" data-name="3">
					<g style="fill: #9bd1ff; filter: url(#filter-188)">
						<circle id="circle-3" class="cls-200" cx="916.5" cy="854.5" r="26.5" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#circle-3" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="916" y="857" width="1" height="16" rx="0.5" ry="0.5"/>
					<path id="Rectangle_536_copy-6" data-name="Rectangle 536 copy" class="cls-4" d="M927.839,861.129a0.518,0.518,0,0,1,0,.732l-10.978,10.978a0.518,0.518,0,0,1-.732-0.732l10.978-10.978A0.518,0.518,0,0,1,927.839,861.129Z"/>
					<path id="Rectangle_536_copy_2-6" data-name="Rectangle 536 copy 2" class="cls-4" d="M905.161,861.129a0.518,0.518,0,0,0,0,.732l10.978,10.978a0.518,0.518,0,0,0,.732-0.732l-10.978-10.978A0.518,0.518,0,0,0,905.161,861.129Z"/>
					<path class="cls-39" d="M916.5,871h0a2.5,2.5,0,0,1,2.5,2.5V893a0,0,0,0,1,0,0h-5a0,0,0,0,1,0,0V873.5A2.5,2.5,0,0,1,916.5,871Z"/>
				</g>
				<g id="_4-4" data-name="4">
					<g style="fill: #9bd1ff; filter: url(#filter-189)">
						<circle id="circle-2" class="cls-201" cx="1270.5" cy="854.5" r="26.5" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#circle-2" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="1270" y="857" width="1" height="16" rx="0.5" ry="0.5"/>
					<path id="Rectangle_536_copy-7" data-name="Rectangle 536 copy" class="cls-4" d="M1281.84,861.129a0.522,0.522,0,0,1,0,.732l-10.98,10.978a0.515,0.515,0,0,1-.73,0,0.522,0.522,0,0,1,0-.732l10.98-10.978A0.515,0.515,0,0,1,1281.84,861.129Z"/>
					<path id="Rectangle_536_copy_2-7" data-name="Rectangle 536 copy 2" class="cls-4" d="M1259.16,861.129a0.522,0.522,0,0,0,0,.732l10.98,10.978a0.515,0.515,0,0,0,.73,0,0.522,0.522,0,0,0,0-.732l-10.98-10.978A0.515,0.515,0,0,0,1259.16,861.129Z"/>
					<path class="cls-39" d="M1270.5,871h0a2.5,2.5,0,0,1,2.5,2.5V893a0,0,0,0,1,0,0h-5a0,0,0,0,1,0,0V873.5A2.5,2.5,0,0,1,1270.5,871Z"/>
				</g>
				<g id="_5-4" data-name="5">
					<g style="fill: #9bd1ff; filter: url(#filter-190)">
						<circle id="circle" class="cls-202" cx="1585.5" cy="854.5" r="26.5" style="stroke: inherit; filter: none; fill: inherit"/>
					</g>
					<use xlink:href="#circle" style="stroke: #3392e3; filter: none; fill: none"/>
					<rect class="cls-39" x="1585" y="857" width="1" height="16" rx="0.5" ry="0.5"/>
					<path id="Rectangle_536_copy-8" data-name="Rectangle 536 copy" class="cls-4" d="M1596.84,861.129a0.522,0.522,0,0,1,0,.732l-10.98,10.978a0.515,0.515,0,0,1-.73,0,0.522,0.522,0,0,1,0-.732l10.98-10.978A0.515,0.515,0,0,1,1596.84,861.129Z"/>
					<path id="Rectangle_536_copy_2-8" data-name="Rectangle 536 copy 2" class="cls-4" d="M1574.16,861.129a0.522,0.522,0,0,0,0,.732l10.98,10.978a0.515,0.515,0,0,0,.73,0,0.522,0.522,0,0,0,0-.732l-10.98-10.978A0.515,0.515,0,0,0,1574.16,861.129Z"/>
					<path class="cls-39" d="M1585.5,871h0a2.5,2.5,0,0,1,2.5,2.5V893a0,0,0,0,1,0,0h-5a0,0,0,0,1,0,0V873.5A2.5,2.5,0,0,1,1585.5,871Z"/>
				</g>
			</g>
			<g id="street-lights-2" data-name="street-lights">
				<g id="_1-6" data-name="1">
					<path class="cls-87" d="M22,897V808c2.073-32.6,48.87-21.493,48,0"/>
					<path id="Shape_600_copy-4" data-name="Shape 600 copy" class="cls-87" d="M22,897V808c-0.9-14.684-11.042-19.659-21-18"/>
					<path id="Rectangle_602_copy_3" data-name="Rectangle 602 copy 3" class="cls-4" d="M55,811v-1c0-5.523,5.063-10,10.5-10S76,804.477,76,810v1H55Zm16-3.667c0-1.841-2.652-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808H71v-0.667Z"/>
					<path id="Rectangle_602_copy_3-2" data-name="Rectangle 602 copy 3" class="cls-203" d="M71,807.333c0-1.841-2.652-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808H71v-0.667Z"/>
				</g>
				<g id="_2-4" data-name="2">
					<path class="cls-87" d="M967,897V808c2.073-32.6,48.87-21.493,48,0"/>
					<path id="Shape_600_copy-5" data-name="Shape 600 copy" class="cls-87" d="M967,897V808c-1.51-24.752-31.889-21.57-37.212-6.352"/>
					<path id="Rectangle_602_copy-4" data-name="Rectangle 602 copy" class="cls-4" d="M917,811v-1c0-5.523,5.063-10,10.5-10s10.5,4.477,10.5,10v1H917Zm16-3.667c0-1.841-2.652-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808h11v-0.667Z"/>
					<path id="Rectangle_602_copy_2" data-name="Rectangle 602 copy 2" class="cls-203" d="M933,807.333c0-1.841-2.652-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808h11v-0.667Z"/>
					<path id="Rectangle_602_copy_3-3" data-name="Rectangle 602 copy 3" class="cls-4" d="M1000,811v-1c0-5.523,5.06-10,10.5-10s10.5,4.477,10.5,10v1h-21Zm16-3.667c0-1.841-2.65-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808h11v-0.667Z"/>
					<path id="Rectangle_602_copy_3-4" data-name="Rectangle 602 copy 3" class="cls-203" d="M1016,807.333c0-1.841-2.65-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808h11v-0.667Z"/>
				</g>
				<g id="_3-6" data-name="3">
					<path class="cls-87" d="M1536,897V808c2.07-32.6,48.87-21.493,48,0"/>
					<path id="Shape_600_copy-6" data-name="Shape 600 copy" class="cls-87" d="M1536,897V808c-1.51-24.752-31.89-21.57-37.21-6.352"/>
					<path id="Rectangle_602_copy-5" data-name="Rectangle 602 copy" class="cls-4" d="M1486,811v-1c0-5.523,5.06-10,10.5-10s10.5,4.477,10.5,10v1h-21Zm16-3.667c0-1.841-2.65-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808h11v-0.667Z"/>
					<path id="Rectangle_602_copy_2-2" data-name="Rectangle 602 copy 2" class="cls-203" d="M1502,807.333c0-1.841-2.65-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808h11v-0.667Z"/>
					<path id="Rectangle_602_copy_3-5" data-name="Rectangle 602 copy 3" class="cls-4" d="M1569,811v-1c0-5.523,5.06-10,10.5-10s10.5,4.477,10.5,10v1h-21Zm16-3.667c0-1.841-2.65-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808h11v-0.667Z"/>
					<path id="Rectangle_602_copy_3-6" data-name="Rectangle 602 copy 3" class="cls-203" d="M1585,807.333c0-1.841-2.65-3.333-5.5-3.333s-5.5,1.492-5.5,3.333V808h11v-0.667Z"/>
				</g>
			</g>
		</g>
	</svg>
	<?php
}


/*----custom console function---
	Pass multiple comma seperated data, For example,
	console_log( DATA1, DATA2, DATA3, ... );
*/
function console_log() {
  $data = func_get_args();
  $log  = "<script>console.log( 'PHP debugger: ";
  $log .= '\n\n';
  for ($i=0; $i < count($data); $i++) {
	$log .= json_encode( print_r($data[$i], true) );
	$log .= '\n';
  }
  $log .= "' );</script>";
  echo $log;
}

function responsive_clip_text( $limit, $string ) {

	if( strlen($string) < 50 ){
	   return $string;
	}
	$string  = substr( $string, 0, $limit );
	$string  = substr( $string, 0, strripos( $string, " " ) );
	$string  = trim( preg_replace( '/\s+/', ' ', $string ) );
	$string .= '...';
	return $string;
}

/*------Add Extra Field In User Profile Page--------*/
add_action( 'show_user_profile', 'extra_user_profile_fields' );
add_action( 'edit_user_profile', 'extra_user_profile_fields' );

function extra_user_profile_fields( $user ) { ?>
<h3 class="heading"><?php _e("Edit your author profile", "qloapps"); ?></h3>

<table class="form-table">
	<tr>
		<th>
			<label for="gender"><?php _e("Gender", "qloapps"); ?></label></th>
		<td>
			<input type="radio" name="gender" id="gender" value="male" class="regular-text" <?php if(esc_attr( get_the_author_meta( 'gender', $user->ID ) )=='male') echo 'checked' ?> /><?php echo __(" Male", "qloapps"); ?>
			<input type="radio" name="gender" id="gender" value="female" class="regular-text" <?php if(esc_attr( get_the_author_meta( 'gender', $user->ID ) )=='female') echo 'checked' ?> /><?php echo __(" Female", "qloapps"); ?><br />

			<span class="description"><?php _e("Please select your Gender.", "qloapps"); ?></span>
		</td>
	</tr>
	<tr>
		<th>
			<label for="designation"><?php _e("Designation at Webkul", "qloapps"); ?></label></th>
		<td>
			<input type="text" name="designation" id="designation" value="<?php echo esc_attr( get_the_author_meta( 'designation', $user->ID ) ); ?>" class="regular-text" /><br />
			<span class="description"><?php _e("Please enter your Designation.", "qloapps"); ?></span>
		</td>
	</tr>
	<tr>
		<th>
			<label for="twitter_url"><?php _e("Twitter Profile URL", "qloapps"); ?></label>
		</th>
		<td>
			<input type="text" name="twitter_url" id="twitter_url" value="<?php echo esc_attr( get_the_author_meta( 'twitter_url', $user->ID ) ); ?>" class="regular-text" /><br />
			<span class="description"><?php _e("Please enter your Twitter Profile URL.", "qloapps"); ?></span>
		</td>
	</tr>
	<tr>
		<th>
			<label for="fb_url"><?php _e("Facebook Profile URL"); ?></label>
		</th>
		<td>
			<input type="text" name="fb_url" id="fb_url" value="<?php echo esc_attr( get_the_author_meta( 'fb_url', $user->ID ) ); ?>" class="regular-text" /><br />
			<span class="description"><?php _e("Please enter your Facebook Profile URL.", "qloapps"); ?></span>
		</td>
	</tr>
	<tr>
		<th>
			<label for="profile-image"><?php _e("Upload Image for your profile", "qloapps"); ?></label>
		</th>
		<td class="prof-img">
			<img src="<?php echo esc_attr( get_the_author_meta( 'profile-image', $user->ID ) ); ?>" alt="Upload Your Image for Your profile" class="image-url">
			<br><input type="text" name="profile-image" id="profile-image" value="<?php echo esc_attr( get_the_author_meta( 'profile-image', $user->ID ) ); ?>" class="regular-text" /><br />
			<br><button class="button button-primary" id="upload-image"><?php echo __("Upload Image", "qloapps"); ?></button>
			<br><br><span class="description"><?php _e("Please Scale or Crop your image to 100&times;100 [px].", "qloapps"); ?></span>
			<span><?php echo __("Don't know how to edit? Just do in two steps -", "qloapps"); ?></span><br><br>
			<a style="background-color:#1E9137;border-radius:5px;color:#fff;text-decoration:none;padding:3px 10px;" href="https://goo.gl/z8vqzX"><?php echo __("Step 1", "qloapps"); ?></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a style="background-color:#1E9137;border-radius:5px;color:#fff;text-decoration:none;padding:3px 10px;" href="https://goo.gl/uBFsI5"><?php echo __("Step 2", "qloapps"); ?></a>
		</td>
	</tr>
</table>
<?php }

add_action( 'personal_options_update', 'save_extra_user_profile_fields' );
add_action( 'edit_user_profile_update', 'save_extra_user_profile_fields' );

function save_extra_user_profile_fields( $user_id ) {
	if ( !current_user_can( 'edit_user', $user_id ) ) { return false; }

		if(!empty($_POST['fb_url'])){

			update_user_meta( $user_id, 'fb_url', $_POST['fb_url'] );

		}

		if(!empty($_POST['gender'])){

			update_user_meta( $user_id, 'gender', $_POST['gender'] );

		}

		if(!empty($_POST['twitter_url'])){

			update_user_meta( $user_id, 'twitter_url', $_POST['twitter_url'] );

		}

		if(!empty($_POST['designation'])){

			update_user_meta( $user_id, 'designation', $_POST['designation'] );

		}

		if(!empty($_POST['profile-image'])){

			update_user_meta( $user_id, 'profile-image', $_POST['profile-image'] );

		}
}


/* get data for page Services */
add_action('wp_ajax_nopriv_get_service_data','get_service_data');
add_action('wp_ajax_get_service_data','get_service_data');

	function get_service_data(){
		if( isset( $_POST['val'] ) ){
			$type=$_POST['val'];
			if($type=="audit"){
				$type= "Audit and Optimization";
			}
		}else{
			$type = 'support';
		}
		global $wpdb;
		$count=100;
		$upload_dir = wp_upload_dir();
		$upload_dir = $upload_dir['baseurl'];
		$table_name= $wpdb->prefix . "service_table";
		$support = $wpdb->get_results( "SELECT * FROM $table_name WHERE type ='$type' ", 'ARRAY_A' );
		foreach($support as $result){
			$result_content=html_entity_decode($result['content']);
			$excerpt_count = strlen($result_content);
			if($excerpt_count>$count){
				$excerpt = strip_tags($result_content);
			  $excerpt = substr($excerpt, 0, $count);
			  $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
				$excerpt = $excerpt . "...";

			}
			else{
				$excerpt=$result_content;
			}

			?>
			<div class="col-md-4">
				<div class="service-data text-center">
					<img src="<?php echo "$upload_dir/".$result['image'];?>" width='100' height='100'>
			<h1><?php echo $result['title'];?></h1>
			<p><?php echo $excerpt;?></p>
			<p class="service-price"><?php echo "$ ". $result['price'];?></p>
			<a class="service-buy-link" href="<?php echo $result['buynow'];?>">BUY NOW</a>
			</div>
		</div>
			<?php
		}
		die;
	}

function wk_post_links( $post ) {
	wp_nonce_field( 'wk_post_links', 'wk_post_links_nonce' );
	$post_links      = get_post_meta( $post->ID, 'wkpl-post-link', true );
	$store_link      = ( isset( $post_links['store_link'] ) ) ? $post_links['store_link'] : '';
	$store_label     = ( isset( $post_links['store_label'] ) ) ? $post_links['store_label'] : '';
	$demo_label_array = ( isset( $post_links['demo_label'] ) ) ? $post_links['demo_label'] : array();
	$demo_link_array = ( isset( $post_links['demo_link'] ) ) ? $post_links['demo_link'] : array();
	?>
	<div>
		<label> Store Label :- <br>
			<input type = "text" name = "wkpl-store-label" value = "<?php echo $store_label; ?>" />
		</label><br>
		<label> Store Link :- <br>
			<input type = "text" name = "wkpl-store-link" value = "<?php echo $store_link; ?>" />
		</label>
		<div class="wkpl-link-panel">
			<?php
			foreach ( $demo_link_array as $key => $demo_link ) {
				?>
				<div>
					<label> Demo Label :- <br>
						<input type = "text" name = "wkpl-demo-label[]" value = "<?php echo esc_html( $demo_label_array[ $key ] ); ?>" />
					</label>
					<label> Demo Link :- <br>
						<input type = "text" name = "wkpl-demo-link[]" value = "<?php echo esc_html( $demo_link ); ?>" required />
					</label>
					<p><button class="button button-primary wkpl-delete">Delete</button></p>
				</div>
				<?php
			}
			if ( 0 == count( $demo_link_array ) && 0 == count( $demo_label_array ) ) {
				?>
				<div>
					<label> Demo Label :- <br>
						<input type = "text" name = "wkpl-demo-label[]" value = "" />
					</label>
					<label> Demo Link :- <br>
						<input type = "text" name = "wkpl-demo-link[]" value = "" />
					</label>
				</div>
				<?php
			}
			?>
		</div>
		<p><button id="wkpl-add" class="button" >Add More</button></p>
	</div>
	<?php
}

add_action( 'save_post', 'wkqlo_post_metabox_save' );

function wkqlo_post_metabox_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return $post_id;
	}

	if ( ! current_user_can( 'edit_page', $post_id ) ) {
		return $post_id;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'post' == $_POST['post_type'] ) {

		if ( isset( $_POST['wk_post_links_nonce'] ) ) {
	
			// Verify that the nonce is valid.
			if ( ! wp_verify_nonce( $_POST['wk_post_links_nonce'], 'wk_post_links' ) ) {
			  return $post_id;
			}
		
			$store_link  = $_POST['wkpl-store-link'];
			$store_label = $_POST['wkpl-store-label'];
			$demo_link   = ( isset( $_POST['wkpl-demo-link'] ) ) ? $_POST['wkpl-demo-link']: array();
			$demo_label  = ( isset( $_POST['wkpl-demo-label'] ) ) ? $_POST['wkpl-demo-label']: array();
		
			$post_link   = array();
			$post_link['store_label'] = $store_label;
			$post_link['store_link'] = $store_link;
			foreach ($demo_link as $key => $value) {
				$post_link['demo_label'][$key] = $demo_label[$key];
				$post_link['demo_link'][$key]  = $value;
			}

			if( ! empty( get_post_meta( $post_id, 'wkpl-post-link' ) ) ) {
				update_post_meta( $post_id, 'wkpl-post-link', $post_link );
			} elseif ( ! empty( $post_link['store_link'] ) > 0 || count( array_filter( $post_link['demo_link'] ) ) > 0  ) {
				update_post_meta( $post_id, 'wkpl-post-link', $post_link );
			}
		}

		if ( isset( $_POST['wkqlo_filters_nonce'] ) ) {

			if ( ! wp_verify_nonce( $_POST['wkqlo_filters_nonce'], 'wkqlo_filters' ) ) {
				return $post_id;
			}

			$filter = isset( $_POST['qlo_filter'] ) ? $_POST['qlo_filter'] : 'doc';
			update_post_meta( $post_id, 'qlo_filter', $filter );
		}
		
	}

}


//Add Tinymce
add_action( 'admin_head', 'add_wkqa_tmce_btn' );
function add_wkqa_tmce_btn() {

	global $post;
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	// check if WYSIWYG is enabled
	if ( 'true' === get_user_option( 'rich_editing' ) ) {
		if ( isset( $post->post_type ) || isset( $_GET['page'] ) ) {

			if ( ( ! is_null( $post ) && 'post' === $post->post_type ) ) {
				add_filter( 'mce_external_plugins', 'add_wkqa_plugin_script' );
				add_filter( 'mce_buttons_3', 'register_wkqa_button' );
			}
		}
	}
}

// register the index panel button
function register_wkqa_button( $buttons ) {

	array_push( $buttons, 'wkqa_plank_indexpanel', 'wkqa_plank_imgleft', 'wkqa_plank_imgright' );
	return $buttons;
}

// Declare script for new Video buttonk
function add_wkqa_plugin_script( $plugin_array ) {
	$plugin_array['wkqa_mce_button'] = get_template_directory_uri() . '/assets/build/js/wkqa-tinymce.js';
	return $plugin_array;
}

add_action( 'admin_init', 'wkqa_editor_style' );
function wkqa_editor_style() {
	add_editor_style( get_template_directory_uri() . '/assets/build/css/admin-tinymce.css' );
}
//** end Tinymce



// ====> Register Webinar Menu
add_action( 'admin_menu', 'register_wk_webinar_menu' );
function register_wk_webinar_menu() {

  add_menu_page( 'Qlo Webinar', 'Qlo Webinar', 'edit_posts', 'webinar', 'wk_webinar_list_menu_callback', 'dashicons-money', 10 );

  $hook = add_submenu_page( 'webinar', 'Webinars List', 'Webinars List', 'edit_posts', 'webinar', 'wk_webinar_list_menu_callback' );

  add_submenu_page( 'webinar', 'Add Webinar', 'Add New', 'edit_posts', 'add_webinar', 'wk_add_webinar_callback' );

  add_action( 'load-' . $hook, 'webinar_menu_page_screen_option' );

}

function webinar_menu_page_screen_option() {
	$screen = get_current_screen();
	// get out of here if we are not on our settings page
	if ( ! is_object( $screen ) || $screen->id != 'toplevel_page_webinar' )
		return;

	$args = array(

		'label'   => 'Webinar ',
		'default' => 10,
		'option'  => 'qa_webinar_per_page',
	);
	add_screen_option( 'per_page', $args );
}

function wk_add_webinar_callback() {

  if( isset( $_POST['qa-submit'] ) ) {

    if( 'update' === $_POST['qa-submit'] && 'webinar' === get_post_type( $_GET['post'] ) ) {

      $wn_data = array(
        'ID'           => $_GET['post'],
        'post_title'   => sanitize_text_field( $_REQUEST['wn-title'] ),
        'post_excerpt' => sanitize_textarea_field( $_REQUEST['wn-excerpt'] ),
        'post_content' => $_REQUEST['wn-content'],
        'post_name'    => sanitize_title_with_dashes( $_REQUEST['wn-slug'] ),
      );

      $wn_status = wp_update_post( $wn_data );
      update_post_meta( $_GET['post'], 'webinar-book-link', $_REQUEST['wn-book-link'] );
      update_post_meta( $_GET['post'], 'webinar-date', str_replace( 'T', ' ', $_REQUEST['wn-date'] ) );
      if( $wn_status ) {
        ?>
        <div class="notice notice-success is-dismissible">
        	<p>
            <strong>Webinar Updated Successfully.</strong>
            <a href="<?php echo esc_url( admin_url() . 'admin.php?page=webinar' ) ?>"> View All</a>
          </p>
        	<button type="button" class="notice-dismiss">
        		<span class="screen-reader-text">Dismiss this notice.</span>
        	</button>
        </div>
        <?php
      }

    } else if( 'add' === $_POST['qa-submit'] ) {
      $wn_data = array(
        'post_title'   => sanitize_text_field( $_REQUEST['wn-title'] ),
        'post_excerpt' => sanitize_textarea_field( $_REQUEST['wn-excerpt'] ),
        'post_author'  => get_current_user_id(),
        'post_content' => $_REQUEST['wn-content'],
        'post_status'  => 'publish',
        'post_type'    => 'webinar',
        'post_name'    => sanitize_title_with_dashes( $_REQUEST['wn-slug'] ),
      );
      $wn_status = wp_insert_post( $wn_data );
      update_post_meta( $wn_status, 'webinar-book-link', $_REQUEST['wn-book-link'] );
      update_post_meta( $wn_status, 'webinar-date', str_replace( 'T', ' ', $_REQUEST['wn-date'] ) );
      if( $wn_status ) {
        ?>
        <div class="notice notice-success is-dismissible">
          <p>
            <strong>Webinar Added Successfully.</strong>
            <a href="<?php echo esc_url( admin_url() . 'admin.php?page=webinar' ) ?>"> View Here</a>
          </p>
          <button type="button" class="notice-dismiss">
            <span class="screen-reader-text">Dismiss this notice.</span>
          </button>
        </div>
        <?php
      }
    }
  }
  $post_id = $wn_title = $wn_excerpt = $wn_content = $wn_book = $wn_date = $wn_slug ='';
  if( isset( $_GET['post'] ) && ! empty( $_GET['post'] )  ) {
    $post_id = (int) $_GET['post'];
    if( get_post_type( $post_id ) && 'webinar' === get_post_type( $post_id ) ) {
      $wn_data    = get_post( $post_id );
      $wn_title   = $wn_data->post_title;
      $wn_excerpt = $wn_data->post_excerpt;
      $wn_content = $wn_data->post_content;
      $wn_slug    = $wn_data->post_name;
      $wn_book    = get_post_meta( $post_id, 'webinar-book-link', true );
      $wn_date    = get_post_meta( $post_id, 'webinar-date', true );
      $wn_date    = str_replace( ' ', 'T', trim( $wn_date ) );
    }
  }
  ?>
  <div class="qlo-webinar">
    <h1><?php echo ( ! empty( $_GET['post'] ) ) ? 'Edit' : 'Add'; ?> Webinar</h1>
    <div>
      <form method="POST">
        <div class="qa-column">
          <label>
            Title
            <input type="text" id="wn-title" name="wn-title" value="<?php echo esc_html( $wn_title ); ?>" required placeholder="title">
          </label>
        </div>

        <div class="qa-column">
          <label>
            Slug
            <br />
            <div class="qa-divider">
              <input type="text" name="wn-slug-prefix" value="<?php echo esc_url( site_url() . '/webinar/#'  ); ?>" disabled placeholder="Slug">
            </div>
            <div class="qa-divider">
              <input type="text" name="wn-slug" id="wn-slug" value="<?php echo esc_attr( $wn_slug ); ?>" required placeholder="">
            </div>
            <?php
            if( ! empty( $wn_slug ) ) {
              ?>
              <br />
              <br />
              <a href="<?php echo esc_url( site_url() . '/webinar/#' . $wn_slug ); ?>" target="_blank" rel="noreferrer noopener"><?php echo esc_url( site_url() . '/webinar/#' . $wn_slug ); ?></a>
              <?php
            }
            ?>
          </label>
        </div>

        <div class="qa-column">
          <label>
            Excerpt
            <textarea name="wn-excerpt" rows="4" placeholder="Short Description" required><?php echo esc_html( $wn_excerpt ); ?></textarea>
          </label>
        </div>
        <div class="qa-column">
          <label>
            Webinar Date
            <input type="datetime-local" id="date" name="wn-date" value="<?php echo $wn_date; ?>" placeholder='dd/mm/yyyy hh:mm' required />
            <span class="description">Eg:- 26/01/2019 23:40</span>
          </label>
        </div>
        <div class="qa-column">
          <label>
            Webinar Book Link
            <input type="text" name="wn-book-link" placeholder="Book link" value="<?php echo $wn_book;  ?>" />
          </label>
        </div>
        <div class="qa-column">
          <?php
          wp_editor( $wn_content, 'wn-content' );
          ?>
        </div>
        <div class="qa-column">
          <button type="submit" name="qa-submit" value="<?php echo ( ! empty( $_GET['post'] ) ) ? 'update' : 'add'?>" class="button button-primary"><?php echo ( ! empty( $_GET['post'] ) ) ? 'Update Webinar' : 'Add Webinar'?></buttun>
        </div>
      </form>
    </div>
  </div>
  <?php
}

function wk_webinar_list_menu_callback() {

  require_once( dirname( __FILE__ ) . '/core/class-wk-webinar-list.php' );
  if( isset( $_POST['qawn-submit'] ) ) {
    $wn_tagline      = $_POST['wn-tagline'];
    $wn_booking_link = $_POST['wn-booking-link'];
    update_option( 'qa-webinar-tagline', $wn_tagline );
    update_option( 'qa-webinar-booking-link', $wn_booking_link );
  }
  $wn_tagline      = get_option( 'qa-webinar-tagline' );
  $wn_booking_link = get_option( 'qa-webinar-booking-link' );
  ?>
  <div style="margin-top:30px">
    <form method="post">
      <fieldset class="qa-fieldset" style="width:50%">
        <legend><b>Webinar Listing Page</b></legend>
        <div>
          <label>
            <b>Webinar Listing Tag Line</b>
            <br />
            <textarea style="width:100%" name="wn-tagline"><?php echo $wn_tagline; ?></textarea>
          </label>
        </div>

        <div>
          <label>
            <b>Webinar Book Link</b>
            <br />
            <input style="width:100%" type="text" name="wn-booking-link" value="<?php echo esc_url( $wn_booking_link ); ?>" placeholder="Booking Link">
          </label>
        </div>
        <br />
        <input type="submit" name="qawn-submit" value="SAVE" Class="button button-primary">
      </fieldset>
    </form>
  </div>
  <?php
}
// <==== Register Webinar Menu

add_filter( 'qa_moon_section', function( $args = array() ){
  ?>
  <section class="section-padding qa-moon-section">
    <div class="text-center wk-grid-lg">
      <h1><?php echo ( isset( $args['title'] ) ) ? esc_html( $args['title'] ) : false; ?></h1>
      <p><?php echo ( isset( $args['content'] ) ) ? esc_html( $args['content'] ) : false; ?></p>
      <?php
      if( ! empty( $args['link_url'] ) ) {
        $new_tab = ( isset( $args['new_tab'] ) && 'true' === $args['new_tab'] ) ? 'target="_blank" rel="noopener noreferrer"' : false;
        echo '<a class="btn btn-bgcolor white" href="' . esc_url( $args['link_url'] ) . '" ' . $new_tab . '>'. esc_html( $args['link_label'] ) .'</a>';
      }
      ?>
    </div>
  </section>

  <?php
}, 10, 1 );

add_action( 'wp_ajax_nopriv_getWebinarPopUpPage', 'getWebinarPopUpPage' );
add_action( 'wp_ajax_getWebinarPopUpPage', 'getWebinarPopUpPage' );

function getWebinarPopUpPage() {
  $nonce = $_POST['nonce'];
  // check_ajax_referer( 'ajaxnonce', 'nonce' );
  // check_ajax_referer( 'ajaxnonce', 'nonce' );
  // if ( ! wp_verify_nonce( $nonce, 'ajaxnonce' ) )
  //   die ( 'Busted!');

  $slug = sanitize_title_with_dashes($_POST['slug']);
  $post = get_page_by_path( $slug, OBJECT, 'webinar' );
  if( $post ) {

    date_default_timezone_set('Asia/Kolkata');
    $current_dt = date('Y-m-d H:i');
    $webinar_date = get_post_meta( $post->ID, 'webinar-date', true );
    $flag = ( strtotime( $current_dt ) <  strtotime( $webinar_date ) ) ? '1' : '0';
    $book_link = get_post_meta( $post->ID, 'webinar-book-link', true );
    $booking_date = date( 'd-M-Y | h:iA', strtotime( $webinar_date ) );

    $response = array(
      'title'   => $post->ID,
      'content' => apply_filters( 'the_content', $post->post_content ),
      'link'    => esc_url( $book_link ),
      'date'    => $booking_date . ' (IST)',
      'flag'    => $flag,
    );
  } else {
    $response = '0';
  }
  echo json_encode( $response );
  die;
}

function qlo_addons_PTCB() {

    $labels = array(
        'name'                  => _x( 'addons', 'Post Type General Name', 'hotel-reservation' ),
        'singular_name'         => _x( 'addonss', 'Post Type Singular Name', 'hotel-reservation' ),
        'menu_name'             => __( 'Qlo Addons', 'hotel-reservation' ),
        'parent_item_colon'     => __( 'Parent Qlo Addons', 'hotel-reservation' ),
        'all_items'             => __( 'All Qlo Addons', 'hotel-reservation' ),
        'view_item'             => __( 'View Qlo Addons', 'hotel-reservation' ),
        'add_new_item'          => __( 'Add New Qlo Addons', 'hotel-reservation' ),
        'add_new'               => __( 'Add New', 'hotel-reservation' ),
        'edit_item'             => __( 'Edit Qlo Addons', 'hotel-reservation' ),
        'update_item'           => __( 'Update Qlo Addons', 'hotel-reservation' ),
        'search_items'          => __( 'Search Qlo Addons', 'hotel-reservation' ),
        'not_found'             => __( 'Not Found', 'hotel-reservation' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'hotel-reservation' ),
		'set_featured_image'    => 'Set Add-on Logo',
		'remove_featured_image' => 'Remove Add-on Logo',
		'use_featured_image'    => 'Use Add-on Logo',
		'featured_image'        => 'Add-on logo'
    );
     
// Set other options for Custom Post Type
     
    $args = array(
        'description'         => __( 'Qlo Addons description', 'hotel-reservation' ),
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'editor','year', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', ),
        /* A hierarchical CPT is like Pages and can have
        * Parent and child items. A non-hierarchical CPT
        * is like Posts.
        */ 
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => false,
        'show_in_admin_bar'   => false,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-pressthis',            
        'can_export'          => true,
        'has_archive'         => false,
        'exclude_from_search' => false,
        'publicly_queryable'  => false,
        'capability_type'     => 'post',
        'rewrite'             => '',           
    );
     
    register_post_type( 'add-ons', $args );
 
}
   add_action( 'init', 'qlo_addons_PTCB', 0 );


function qa_addons_opts_cb( $post ) {
	
	wp_nonce_field( "qa_addon_opts", "qa_addon_opts_nonce" );
	
	$ads_opts = get_post_meta($post->ID, "qlo_addons_extra_options", true );
	$ads_opts = is_array( $ads_opts ) ? $ads_opts : array();

	$qa_featured_addon = get_post_meta( $post->ID, 'qa_featured_addon', true );
	?>
	
	<b>Buy Addon Link</b>
	<p><input name="qlo_addons_option[qlo-buy-btn-link]" type="text" placeholder="button URL" value="<?php echo isset( $ads_opts['qlo-buy-btn-link'] )  ? esc_url( $ads_opts['qlo-buy-btn-link'] ) : false;  ?>"></p>
	<hr>
    <b>Addon Price : </b>
	<p><input name="qlo_addons_option[qlo-addons-prize]" placeholder="Addons prize" type="text" value="<?php echo isset( $ads_opts['qlo-addons-prize'] )  ? esc_html( $ads_opts['qlo-addons-prize'] ) : false;  ?>">
	
	<hr>
	<b>Addon Logo ( Black & white) </b>
	<br><b>* For Homepage </b><br><br>
	<?php
	$addon_logo =  ! empty( $ads_opts['logo'] ) ? wp_get_attachment_image_src( (int) $ads_opts['logo'] )[0] : false;
	?>
	<div class="">
		<img src="<?php echo esc_url( $addon_logo ); ?>" class="_wk_uploader _uploader_src opac-72" onerror="this.onerror=null;this.src='<?php echo get_template_directory_uri() . '/images/upload.png'; ?>'" style="width:80px;height:80px;" title="Click to Upload Addon Logo">
		
		<input type="hidden" class="_wk_uploader_id" name="qlo_addons_option[logo]" value="<?php echo ! empty( $ads_opts['logo'] ) ? $ads_opts['logo'] : false; ?>">
	</div>

	<br><hr><br>
	<label>
		<input type="checkbox" <?php ! empty( $qa_featured_addon ) ? checked( 'true', $qa_featured_addon ) : false; ?> name="qa_featured_addon" value="true">&nbsp;
		<strong>Is Featured Addon ?</strong>
	</label>
	<p class="description">(* Featured Addon will be show on homepage. )</p>


<?php
}

// Add the custom columns to the Addons post type:
add_filter( 'manage_add-ons_posts_columns', function( $columns ) {
	$columns['featured_addon'] = 'Featured Add-on';
	return $columns;

} );

// Add the data to the custom columns for the Addons post type:
add_action( 'manage_add-ons_posts_custom_column' , function( $column, $post_id  ) {
	switch ( $column ) {
		case 'featured_addon' :
			$qa_featured_addon = get_post_meta( $post_id, 'qa_featured_addon', true );;
			echo ! empty( $qa_featured_addon ) ? '<span class="dashicons dashicons-star-filled" style="color: yellow; text-shadow: 1px 1px 1px #7e8000;"></span>' : '—';
			break;
	}
}, 10, 2 );


function qa_addon_save_opts( $post_id, $post ) {
    if( $post->post_type !== 'add-ons' ) {
		return;
	}
	if( ! isset( $_POST['qa_addon_opts_nonce'] ) ) {
		return;
	}
	if( ! wp_verify_nonce( $_POST['qa_addon_opts_nonce'], 'qa_addon_opts' ) ) {
		return;
	}
		
	$qa_opts = isset( $_POST['qlo_addons_option'] ) ? $_POST['qlo_addons_option'] : array();
	$qa_opts['qlo-buy-btn-link'] = sanitize_text_field($qa_opts['qlo-buy-btn-link']);
	$qa_opts['qlo-addons-prize'] = sanitize_text_field($qa_opts['qlo-addons-prize']);

	update_post_meta( $post_id, "qlo_addons_extra_options", $qa_opts );

	update_post_meta( $post_id, 'qa_featured_addon', $_POST['qa_featured_addon'] );

}
add_action("save_post", "qa_addon_save_opts", 100, 2);


function _wk_trim_post_content( $post_id, $content_len = 150, $dots = true ) {
	if ( ! $post_id ) {
		return false;
	}
	$content = get_post( $post_id );
	$content = wpautop( $content->post_content );
	$content = substr( $content, strpos( $content, '<p>' ), strpos( $content, '</p>' ) );
	$content = wp_strip_all_tags( $content );
	$content = substr( $content, 0, $content_len );
	$content = substr( $content, 0, strripos( $content, ' ' ) );
	
	if( $dots )
	$content = $content . '...';
	// $text    = wp_trim_words( $content, 20 );
	return $content;
}

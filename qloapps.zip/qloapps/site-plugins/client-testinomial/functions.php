<?php
/*
Plugin Name: Client Testimonial
Plugin URI: https://webkul.com
Description: A plugin for Adding Testimonial for our Webkul Products from clients
Author: webkul
Author URI: http://webkul.com
Text Domain: Webkul
*/


defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
define( 'WKCR_DIR', plugin_dir_url( __FILE__ ) );
define( 'WKCR_PLUGIN_FILE', __FILE__ );


add_action( 'admin_enqueue_scripts', function() {

	wp_enqueue_script( 'jquery-ui-sortable' );
	if ( isset( $_GET['page'] ) && 'wk_client_testimonial' === $_GET['page'] ) {
		wp_enqueue_script( 'wkcr-backend-js', WKCR_DIR . '/assets/dist/js/wkcr-backend.min.js', array(), '5.4.2' );
		wp_enqueue_style( 'wkcr-backend-css', WKCR_DIR . '/assets/dist/css/wkcr-backend.min.css', array(), '5.4.2' );
		wp_localize_script( 'wkcr-backend-js', 'wkCRInfoOBJ', array(
			'url'           => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'wkcr-admin-js-nonce' ),
			'wp_upload_dir' => wp_upload_dir()['baseurl'],
		));

		wp_enqueue_style( 'select2_css', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css' );
		wp_enqueue_script( 'select2_js', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js' );
		wp_enqueue_media();
	}

}, 10 );

/*-------//Enqueue Assets---------*/


// Adding Menu
add_action( 'admin_menu', function() {
	add_menu_page( 'Client Testimonial', 'Client Testimonial', 'edit_posts', 'wk_client_testimonial', '_client_add_testimonial_menu_page', 'dashicons-id-alt', 10 );
});

function _client_add_testimonial_menu_page() {

	$all_testimonial  = maybe_unserialize( get_option( 'wkct-client-testimonial-data' ) );
	$all_testimonial  = ( '' == $all_testimonial ) ? array() : $all_testimonial;
	$path             = wp_upload_dir()['baseurl'];
	
	$tc = count( $all_testimonial );
	
	$featured = array_filter( $all_testimonial, function( $ttl ) {
		return ( isset( $ttl['featured'] ) & ! empty( $ttl['featured'] ) ) ? true : false;
	} );
	$fc = count( $featured );
	$countries = get_option( 'wk_country_list' );
	?>
	<div class="wrap">
		<p style="float:right">
			Total Count : <b><?php echo $tc ?></b><br/>
			Featured Count : <b><?php echo $fc ?></b>
		</p>
		<h1>Client Testimonial</h1>
		<hr /><br />

		<div class="mk-save-reviews-wrapper">
			<div style="display:none;" class="notice notice-success is-dismissible">
				<p><strong>Testimonial were successfully Updated.</strong></p>
			</div>
			<div style="display:none;" class="notice notice-error is-dismissible">
				<p><strong>Something Went Wrong! Please Try Again.</strong></p>
			</div>
			<div class="wk-save-rw">
				<button id="save-reviews" class="button button-primary">Update Order</button>
				<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>"/>
				<!-- <button id="enable-reviews" class="button button-primary update-reviews">Enable Reviews</button>
				<button id="disable-reviews" class="button button-primary update-reviews">Disable Reviews</button> -->
			</div>
			<span class="description mk-review-des">Drag and Drop to Sort Testimonial</span>
			<div class="review-blocks-container">
				<button class="wk-add-block page-title-action aria-button-if-js" role="button">
					<span class="dashicons dashicons-plus-alt"></span> Add
				</button>
			</div>
		</div>
		<span class="dashicons dashicons-star-filled" style="color:#0882ff"></span> <i>Featured testimonial will shows on homepage.</i>

		<template id="wk-review-template">
				<div class="wk-element-block width-45" id="mk_review_{{count_id}}" data-id="mk_review_{{count_id}}">
					<span title="Remove" class="wk-review-remove-block dashicons dashicons-dismiss"></span>
					<p><b>Client testimonial</b></p>
					<div >
						<div class="img-wrap">
							<img src="" />
							<input type="hidden" class="img-url" value=""/>
						</div>
						<textarea class="bubble review" placeholder="Testinomial"></textarea>
					</div>
					<input type="hidden" name="mk-id" class="mk-review-id" value="mk_review_{{count_id}}">
					<input type="hidden" name="mk-order" class="mk-review-order" value="{{count}}">
					<table class="form-body">
						<tbody>

							<tr>
								<th><label for="testimonial-status">Status</label></th>
								<td>
								<label class="mk-review-status">
									<input type="checkbox" id="testimonial-status" class="status" name="status" value="enable" checked>
									<span class="slider enable"></span>
								</label>
								</td>
							</tr>
							<tr>
								<th>Name</th>
								<td><input type="text" class="name" value="" placeholder="Name of the client"/></td>
							</tr>
							<tr>
								<th>Ratings</th>
								<td class="mk-rating">
									<?php

									for ( $i = 5; $i >= 1; $i-- ) {
										?>
										<input class="mk-rating-input" name="stars{{count}}" id="stars{{count}}<?php echo $i;?>" type="radio"  value ='<?php echo $i;?>' ><label class="mk-rating-stars" for="stars{{count}}<?php echo $i;?>" ></label>
										<?php
									}
									?>
									<!-- <input type="checkbox" value =''> -->
								</td>
							</tr>
							<tr>
								<th>Designation</th>
								<td><input type="text" class="design" value="" placeholder="Client Designation and Company"/></td>
							</tr>
							

							<tr>
								<th>Country</th>
								<td>
									<select class="country mk_testinomial_country_list">
										<?php
										if( ! empty( $countries ) && is_array( $countries ) ) {
											foreach( $countries as $code => $name ) {
												echo "<option value='$code' data-img='https://restcountries.eu/data/" . strtolower( $code ) . ".svg'>$name</option>";
											}
										}
										?>
									</select>
								</td>
							</tr>
							<tr style="position: absolute; visibility: hidden;">
								<th>website</th>
								<td><input type="text" class="work" value="" placeholder="Client Website"/></td>
							</tr>
							<tr style="position: absolute; visibility: hidden;">
								<th>Video Link</th>
								<td>
									<hr>
									<input type="text" class="video" value="" placeholder="Video Link"/>
									<p><label>
										<input type="checkbox" class="video_status">&nbsp;
										Tick checkbox to show video on homepage.
									</label></p>
									<hr>
								</td>
							</tr>
							<tr>
								<th>Featured<br>&ensp;</th>
								<td>
								<label class="mk-review-status">
									<input type="checkbox" class="featured" name="featured" value="on" id="featured-testimonial">
									<span class="slider enable"></span>
								</label>
								<p class="description">*Tick featured, to show on Homepage.</p>
								</td>
							</tr>
						</tbody>
					</table>
					<button class="mk-update-review button button-primary button-large" id="mk_review_{{count_id}}" >Save</button>
					<img style="display:none;" class="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>"/>
				</div>
		</template>
		<br /><br />
		<div id="wk-handle-client-reviews">
			<div class="wk-review-sortable">
			<?php
			if ( $all_testimonial ) {
				$order   = array();
				$c_order = 0;
				foreach ( $all_testimonial as $key => $row ) {
					if( isset( $row['order'] ) ) {
						$c_order = 1;
						$order[ $key ] = $row['order'];
					}
				}
				if ( $c_order ) {
					array_multisort( $order, SORT_DESC, $all_testimonial );
				}
				$count = 0;
				$data_len = count( $all_testimonial );
				$first_set = 0;
				foreach ( $all_testimonial as $key ) {
					$r_id  = 'mk_review_' . $count;
					$order = $data_len;
					$count ++;

					if ( isset( $key['id'] ) && ! empty( $key['id'] ) ) {
						$r_id = $key['id'];
					}
					if ( isset( $key['order'] ) && ! empty( $key['order'] ) ) {
						$order = $key['order'];
					} else {
						$first_set = true;
					}
					$key['order'] = $order;
					$key['id'] = $r_id;
					$data_all[$r_id] = $key;
					$status = isset( $key['status'] ) ? $key['status']:'checked';
					$mk_status = $status == 'checked' ? 'enable' : 'disable';
					$img_url = isset($key['imgUrl']) ? $path . $key['imgUrl']: WKCR_DIR . 'images/user-placeholder.png';
					$featured = isset( $key['featured'] ) ? $key['featured'] : false;
					$place_holder = WKCR_DIR . 'images/user-placeholder.png';
					$video_status = isset( $key['video_status'] ) ? $key['video_status'] : false;
					$country_code = isset( $key['country_code'] ) ? $key['country_code'] : false;
					$country_name = isset( $key['country_name'] ) ? $key['country_name'] : false;
					?>
						<div class="wk-element-block <?php echo ( 'on' == $featured ) ? 'featured-testimonial' : false; ?>" id="<?php echo esc_attr( $r_id ); ?>" data-id="<?php echo esc_attr( $r_id ); ?>">
							<span title="Remove" class="wk-review-remove-block dashicons dashicons-dismiss"></span>
							<p class="wk-display-none mk-review-toggle"><b >Client Testimonial</b></p>
							<div class="review-mini">
								<span class="dashicons dashicons-edit cr-review-icon more"></span>
								<div class="wk-review-mini-data">
									<img src="<?php echo esc_url( $img_url ); ?>" onerror="this.error=null; this.src='<?php echo esc_url( $place_holder ); ?>'"/>
									<span><strong><?php echo esc_attr( $key['name'] ); ?> <br>( <?php echo esc_attr( $country_name ); ?> )</strong></span>
									<span class="status <?php echo $mk_status; ?>" data-status="<?php echo $mk_status; ?>"></span>
								</div>
							</div>
						
							<div class="wk-display-none mk-review-toggle">

								
								<div>
									<div class="img-wrap">
										<img src="<?php echo esc_url( $img_url ); ?>" />
										<input type="hidden" class="img-url" value="<?php echo esc_url( isset( $key['imgUrl'] ) ? $path . $key['imgUrl'] : '' ); ?>"/>
									</div>
									<textarea class="bubble review" placeholder="Review"><?php echo esc_attr( $key['testimonial'] ); ?></textarea>
								</div>
								<!-- Unique Id For Data -->
								<input type="hidden" name="mk-id" class="mk-review-id" value="<?php echo  esc_attr( $r_id ) ?>">
								<input type="hidden" name="mk-order" class="mk-review-order" value="<?php echo esc_attr( $order ); ?>">

								<table class="form-body">
									<tbody>
										<tr>
											<th>Status</th>
											<td>
											<label class="mk-review-status">
												<input type="checkbox" class="status" name="status" value="enable" <?php echo esc_attr( $status ); ?>>
												<span class="slider enable"></span>
											</label>
											</td>
										</tr>
										<tr>
											<th>Name</th>
											<td><input type="text" class="name" value="<?php echo esc_attr( $key['name'] ); ?>" placeholder="Name of the client"/></td>
										</tr>
										<tr>
											<th>Ratings</th>
											<td class="mk-rating">
												<?php
												$rate = isset( $key['rating'] ) ? (int) $key['rating'] : 0;
												for ( $i = 5; $i >= 1; $i-- ) {
													$checked = '';
													if( $i == $rate ) {
														$checked = 'checked';
													}
													?>
													<input class="mk-rating-input" name="stars<?php echo $count;?>" id="stars<?php echo $count . $i;?>" type="radio"  value ='<?php echo $i;?>' <?php echo $checked; ?> ><label class="mk-rating-stars" for="stars<?php echo $count . $i;?>" ></label>
													<?php
												}?>
												<!-- <input type="checkbox" value =''> -->
											</td>
										</tr>
										<tr >
											<th>Designation</th>
											<td><input type="text" class="design" value="<?php echo isset( $key['design'] ) ? esc_attr( $key['design'] ) : false; ?>" placeholder="Client Designation and Company"/></td>
										</tr>
										
										<tr style="position: absolute; visibility: hidden;">
											<th>Website</th>
											<td><input type="text" class="work" value="<?php echo esc_attr( $key['website'] ); ?>" placeholder="website"/></td>
										</tr>
										<tr>
											<th>Country</th>
											<td>
												<select class="country mk_testinomial_country_list">
													<?php
													if( ! empty( $countries ) && is_array( $countries ) ) {
														foreach( $countries as $code => $name ) {
															?>
															<option <?php echo "value='$code' data-img='https://restcountries.eu/data/" . strtolower( $code ) . ".svg'"; selected( $code, $country_code ); ?> ><?php echo $name; ?></option>
															<?php
														}
													}
													?>
												</select>
											</td>
										</tr>
										<tr style="position: absolute; visibility: hidden;">
											<th>Video Link</th>
											<td>
												<hr>
												<input type="text" class="video" value="<?php echo esc_attr( $key['video'] ); ?>" placeholder="Video Link"/>
												<p><label>
													<input type="checkbox" class="video_status" value="on" <?php checked( 'on', $video_status ); ?>>&nbsp;
													Tick checkbox to show video on homepage.
												</label></p>
												<hr>
											</td>
										</tr>
										<tr>
											<th>Featured<br>&ensp;</th>
											<td>
											<label class="mk-review-status">
												<input type="checkbox" class="featured" name="featured" value="on" id="featured-testimonial" <?php checked( 'on', $featured ); ?>>
												<span class="slider enable"></span>
											</label>
											<p class="description">*Tick featured, to show on Homepage.</p>
											</td>
										</tr>
									</tbody>
								</table>
								<button class="mk-update-review button button-primary button-large" id="<?php echo esc_attr( $r_id ); ?>" >Update</button>
								<img style="display:none;" class="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>"/>
							</div>
						</div>

					<?php
				}
			}
		?>
		</div>
		</div>

	</div>
	<?php

	// save data in key pair term at first time.... since data-structure changed ...
	if ( isset( $first_set ) && $first_set ) {
		update_option( 'wkct-client-testimonial-data', maybe_serialize( $data_all ) );
	}

	/** Country Lists */
	$wk_country_data = get_option( 'wk_country_list' );
	if( ! empty( $wk_country_data ) ) {
		echo '<script id="wkCountryData" type="application/json">' . wp_json_encode( $wk_country_data ) . '</script>';
	}
}



add_action( 'wp_ajax_wkcr_save_client_reviews', 'wkcr_save_client_reviews_cb' );

function wkcr_save_client_reviews_cb() {

	check_ajax_referer( 'wkcr-admin-js-nonce', 'token' );

	if ( ! isset( $_POST['wkCRdata'] ) || empty( $_POST['wkCRdata'] ) ) {
		die;
	}

	$bag = isset( $_POST['wkCRdata'] ) ? stripslashes_deep( $_POST['wkCRdata'] ) : array();

	if ( isset( $_POST['command' ] ) ) {
		$data_all = maybe_unserialize( get_option( 'wkct-client-testimonial-data' ) );
		if ( 'edit' == $_POST['command'] ) {
			$data_all[ $bag['id'] ] = $bag;
		} elseif( 'order_update' == $_POST['command'] ) {
			foreach ( $bag as $key => $value ) {
				$data_all[ $key ] ['order']  =  $value['order'];
			}
		} elseif ('delete' ==  $_POST['command'] ) {
			if ( isset( $data_all[$bag] ) ) {
				unset( $data_all[$bag] );
			}
		} elseif( 'update_status' ==  $_POST['command'] ){
			$data_all[$bag['id']]['status'] = $bag['status'];
		}

		update_option( 'wkct-client-testimonial-data', maybe_serialize( $data_all ) );
	}
	exit;
}

add_action( 'init', function() {
	if ( isset( $_GET['page'] ) && isset( $_GET['country'] ) && 'wk_client_testimonial' === $_GET['page'] && 'saved' === $_GET['country'] ) {
		$response = json_decode( wk_get_api_data( 'https://restcountries.eu/rest/v2/all' ) );
		// $response = json_decode( wk_get_api_data( 'http://countryapi.gear.host/v1/Country/getCountries' ) );
		$coutry_list = array();
		foreach( $response as $key => $value ) {
			$coutry_list[ $value->alpha3Code ] = $value->name;
		}
		asort( $coutry_list );
		update_option( 'wk_country_list', $coutry_list );

	}
} );

function wk_get_api_data( $url ) {
	$ch = curl_init();

	//OPTIONS
	curl_setopt( $ch, CURLOPT_URL, $url );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

	//EXECUTE
	$results = curl_exec( $ch );
	curl_close( $ch );

	return $results;
}


// Just Change theme folder Name in 'themeFolder';
//Install 'gulp-clean-css' package

var themeFolder =  'hotel-reservation';
var themePath   =  './wp-content/themes/' + themeFolder + '/';
var gulp        =  require('gulp');
var less        =  require('gulp-less');
var cleanCSS    =  require('gulp-clean-css');
var rename      =  require( 'gulp-rename' );
var uglify      =  require( 'gulp-uglifyes' );



/* Task to compile less */
const compileLess = () => {
  return gulp.src( themePath + 'assets/less/*.less' )
    .pipe( less() )
    .pipe( gulp.dest( themePath + 'assets/build/css/' ) );
};


/*Minify CSS*/
throwPath = {}
throwPath.path = themePath + 'assets/dist/css/';
const minifyCss = () => {
	return gulp.src( themePath + 'assets/build/css/*.css' )
		.pipe( cleanCSS( { compatibility: 'ie8' } ) )
		.pipe( rename(function( path ) {
			path.basename += '.min';
		}))
		.pipe( gulp.dest( throwPath.path ) );
};


/*clone style.min from dist to root */
const copyMainCssToRoot = () => {
	return gulp.src( themePath + 'assets/dist/css/style.min.css' )
		.pipe( rename(function( path ) {
			path.basename = 'style';
		}))
		.pipe( gulp.dest( themePath ) );
};


const minifyJs = () => {
	return gulp.src( themePath + 'assets/build/js/*.js' )
		.pipe( uglify() )
		.pipe( rename({
			suffix: '.min'
		}))
		.pipe( gulp.dest( themePath + 'assets/dist/js/' ) );
};

/* Task to watch less changes */
const watchLess = () => {
	return gulp.watch( themePath + 'assets/less/**/*.less' , compileLess );
};


/*Watch CSS*/
watchCss = () => {
	return gulp.watch( themePath + 'assets/build/css/*.css' , minifyCss );
};

/*Watch CSS MAIN*/
watchCssMain = () => {
	return gulp.watch( themePath + 'assets/dist/css/style.min.css' , copyMainCssToRoot );
};

/* Task to watch js changes */
const watchJs = () => {
	return gulp.watch( themePath + 'assets/build/js/*.js', minifyJs );
};

const build = gulp.parallel( watchLess, watchCss, watchCssMain, watchJs );


/* Tasks when running `gulp` from terminal */
exports.compileLess = compileLess;
exports.minifyCss = minifyCss;
exports.copyMainCssToRoot = copyMainCssToRoot;
exports.minifyJs = minifyJs;
exports.watchLess = watchLess;
exports.watchCss = watchCss;
exports.watchCssMain = watchCssMain;
exports.watchJs = watchJs;

gulp.task( 'default', build );


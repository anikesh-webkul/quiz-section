<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php wp_title( '|', true, 'right' ); ?></title>
		<link rel="icon" type="image/x-icon" href="<?php echo esc_attr( get_bloginfo( 'template_url' ) ); ?>/images/favicon.ico"/>
		<link rel="apple-touch-icon" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-57.png' ); ?>" />
		<link rel="apple-touch-icon" sizes="72x72" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-72.png' ); ?>" />
		<link rel="apple-touch-icon" sizes="114x114" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-114.png' ); ?>" />
		<link rel="apple-touch-icon" sizes="144x144" href="<?php echo esc_url( get_template_directory_uri() . '/images/icon-144.png' ); ?>" />
		<link rel="preload" as="image" href="<?php echo esc_url( get_template_directory_uri() . '/images/webkul-main-sprite.svg' ); ?>">
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,600" rel="stylesheet">
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
		<link href="<?php echo esc_url( get_template_directory_uri() . '/assets/dist/css/wk-deloittepages.min.css?1.0' ); ?>" rel="stylesheet" type="text/css">
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		<script>
		$( function() {
			$( window ).load(function() {
				$( "#accordion" ).accordion();
			});
		} );
		</script>
	<?php wp_head(); ?>
	</head>

	<body>
		<div class="wk-container">
			<div class="header">
				<div class="wrapper">
					<a href="https://webkul.com/" title="Webkul Software"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/deloitte/webkul.svg' ); ?>"></a>
				</div>
			</div>
			<div class="page">
				<div id="scroller" style="width: 100%; height: 400px; margin: 0 auto;">
					<div class="innerScrollArea">
						<ul>
							<li style="left: 0px;"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/deloitte/deloitte-17/image-1.png' ); ?>"></li>
							<li style="left: 0px;"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/deloitte/deloitte-17/image-2.png' ); ?>"></li>
							<li style="left: 0px;"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/deloitte/deloitte-17/image-3.png' ); ?>"></li>
							<li style="left: 0px;"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/deloitte/deloitte-17/image-4.png' ); ?>"></li>
						</ul>
					</div>
				</div>
				<div class="wrapper">

					<div class="main">

						<div id="accordion" class="accodi">
							<section class="tab_title">India Ranking</section>
							<div class="tab_content">
							<img src="<?php echo esc_url( get_template_directory_uri() . '/images/deloitte/webkul-blue.svg?v=1' ); ?>">
							<p>Awarded as</p>
							<span class="shield">
								<h3>28</h3>
								<p>Winner</p>
							</span>
							<a href="https://www2.deloitte.com/content/dam/Deloitte/in/Documents/technology-media-telecommunications/in-tmt-tech-fast-50-winners-report-17-noexp.pdf" target="_blank"><p class="main-para">Technology <span>Fast 50</span><br>2017 INDIA</p></a>
							<img src="<?php echo esc_url( get_template_directory_uri() . '/images/deloitte/deloitte.svg' ); ?>">
						</div>
						<section class="tab_title">Asia Ranking</section>
						<div class="tab_content">
							<img src="<?php echo esc_url( get_template_directory_uri() . '/images/deloitte/webkul-blue.svg' ); ?>">
							<p>Awarded as</p>
							<span class="shield">
								<h3>341</h3>
								<p>Winner</p>
							</span>
							<a href="https://www2.deloitte.com/content/dam/Deloitte/au/Documents/technology-media-telecommunications/deloitte-au-tmt-tech-fast-500-apac-ranking-2017-121217.pdf" target="_blank"><p class="main-para">Technology <span>Fast 500</span><br>2017 ASIA PACIFIC</p></a>
							<img src="<?php echo esc_url( get_template_directory_uri() . '/images/deloitte/deloitte.svg' ); ?>">
						</div>
					</div>
				</div>
			</div>
			<div class="footer"></div>
		</div>
			<div class="footer">
				<div class="wrapper">
					<ul>
						<a href="<?php echo esc_url( site_url() . '/deloitte-award-winner-2015' ); ?>"><li>2015</li></a>
						<a href="<?php echo esc_url( site_url() . '/deloitte-award-winner-2016' ); ?>"><li>2016</li></a>
						<a href="<?php echo esc_url( site_url() . '/deloitte-award-winner-2017' ); ?>"><li class="active">2017</li></a>
						<a href="<?php echo esc_url( site_url() . '/deloitte-award-winner-2018' ); ?>"><li>2018</li></a>
						<a href="<?php echo esc_url( site_url() . '/deloitte-award-winner-2019' ); ?>"><li>2019</li></a>
					</ul>
				</div>
			</div>
		</div>

		<?php wp_footer(); ?>

<script type="text/javascript">
	$(function(){
		window.onload = function(){
			var scroller = $('#scroller div.innerScrollArea');
			var scrollerContent = scroller.children('ul');
			scrollerContent.children().clone().appendTo(scrollerContent);
			var curX = 0;
			scrollerContent.children().each(function(){
				var $this = $(this);
				$this.css('left', curX);
				curX += $this.width();
			});
			var fullW = curX / 2;
			var viewportW = scroller.width();

			// Scrolling speed management
			var controller = {curSpeed:0, fullSpeed:1};
			var $controller = $(controller);
			var tweenToNewSpeed = function(newSpeed, duration)
			{
				if (duration === undefined)
					duration = 0;
				$controller.stop(true).animate({curSpeed:newSpeed}, duration);
			};

			// Pause on hover
			scroller.hover(function(){
				tweenToNewSpeed(0);
			}, function(){
				tweenToNewSpeed(controller.fullSpeed);
			});

			// Scrolling management; start the automatical scrolling
			var doScroll = function()
			{
				var curX = scroller.scrollLeft();
				var newX = curX + controller.curSpeed;
				if (newX > fullW*2 - viewportW)
					newX -= fullW;
				scroller.scrollLeft(newX);
			};
			setInterval(doScroll, 20);
			tweenToNewSpeed(controller.fullSpeed);
		}
	});
</script>
	</body>
</html>

<?php
/**
 * @package webkul
 * @subpackage webkul theme 2K18
 * @since webkul theme 2.0
 */

get_header();

?>
<section class="wk-page-content jobs-page-section">
	<div class="wk-component component--page-header" _bgcolor="default">
		<div _wkgrid="wide">
			<div class="header-wrap">
				<div class="header-tagline">
					<h1>Open Positions</h1>
					<p>Here is the list of open positions that we are currently hiring. You can follow us on Linkedin to receive job updates.</p>
					<div class="wp-block-button"><a class="wp-block-button__link has-primary-background-color has-background" href="https://in.linkedin.com/company/webkul" style="border-radius:8px">Follow us on LinkedIn</a></div>
				</div>
			</div>
		</div>
	</div>
	<div class="wk-component component--jumbotron">
		<div _wkgrid="wide">
			<div _bgcolor="blue">
				<div class="block-jumbotron-wrap">
					<div class="jumbotron-image">
						<img alt="" src="<?php echo get_template_directory_uri() . '/images/career/job-card.png' ?>" />
					</div>
					<div class="jumbotron-content">
						<h2>Employee Referral Program</h2>
						<p>We do take applications through employee referrals skipping first-level profile screening.</p>
						<p>If you know someone at Webkul, reach out to them.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
global $wpdb;
$table         = $wpdb->prefix . 'open_positions';
$positions_bag = $wpdb->get_results( "SELECT * FROM $table WHERE visibility='show'", ARRAY_A );
$all_group_str = trim( get_option( 'open-position-groups' ), ',' );
$all_group_set = explode( ',', $all_group_str );

function filter_positions_in_groups( $positions_bag, $grp ) {

	$group = array_values( array_filter( $positions_bag, function ( $item ) use ( $grp ) {
		if ( $grp === $item['group_name'] ) {
			return $item;
		}
	} ) );
	return $group;
}

?>
<section class="wk-open-position section-padding-0B">
	<div class="wkgrid-squeezy">
		<?php
		$op_json = array();
		foreach ( $all_group_set as $name ) {

			$group_set = filter_positions_in_groups( $positions_bag, $name );

			if ( count( $group_set ) ) {
				?>
				<div id="<?php echo esc_attr( strtolower( str_replace( '.', '-', str_replace( ' ', '-', trim( $name ) ) ) ) ); ?>" class="op-group">
					<h3 class="op-group-title" data-link="<?php echo esc_url( get_the_permalink( get_the_ID() ) ) . '#' . esc_attr( strtolower( str_replace( ' ', '-', trim( $name ) ) ) ); ?>"><?php echo esc_html( $name ); ?></h3>
					<?php
					foreach ( $group_set as $op ) {

						$share_id      = strtolower( str_replace( '.', '-', str_replace( ' ', '-', trim($op['position_name'] ) ) ) );
						$url           = get_the_permalink() . $share_id;

						echo '<a href="' . $url . '" op-id="' . esc_attr( $share_id ) . '" class="op-block op-next"><h5 class="op-name">' . esc_html( trim( $op['position_name'] ) ) . '</h5><div class="op-info"><span>Experience: ' . $op['position_experience'] . '</span><span>Open Position: ' . $op['openings'] . '</span></div></a>';
					}
					?>
				</div>
				<?php
			}
		}
		?>
	</div>

</section>

<section class="wk-page-content jobs-page-section">
	<div class="wk-component " _bgcolor="default"><div _wkgrid="squeezy">
		<h2>Didn't find relevant opportunity?</h2>
		<p>We’re always looking forward to work with great ideas and top talent. You can send us your resume and cover letter at <a href="mailto:jobs@webkul.com" title="Send us your resume">jobs@webkul.com</a>.</p>
		<p>If we find your profile suitable, we’ll get back to you.</p>
		</div>
	</div>

	<div class="wk-component block-jumbotron"><div _wkgrid="wide"><div _bgcolor="dark">
		<div class="block-jumbotron-wrap full-grid"><div class="jumbotron-content center">
		<h2 class="has-text-align-center jumbotron-title">You can follow us on LinkedIn to never miss a job opening update</h2>
		<div class="wp-block-button aligncenter"><a class="wp-block-button__link has-gray-background-color has-background" href="https://in.linkedin.com/company/webkul" target="_blank" rel="nofollow noopener">Follow us on LinkedIn</a></div>
		</div></div>
		</div></div>
	</div>
</section>

<?php
get_footer();

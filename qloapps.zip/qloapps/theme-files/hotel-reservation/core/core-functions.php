<?php

/*--Custom Theme Menus.--*/
add_action( 'admin_menu', function() {
    add_menu_page( 'Theme Settings', 'Theme Settings', 'edit_posts', 'wk-theme-pages-config', '_wk_pages_config_template', 'dashicons-layout', 3 );
    
} );

function _wk_pages_config_template() {

    require_once( dirname( __FILE__ ) . '/wk-theme-pages-config.php' );
	?>
	<div class="webkul-theme-bar"></div>
	<div class="wrap">
		<div class="wkug-template">
			<h1>Content for various Pages</h1>
			<p class="description">Set the content for your pages.</p>
			<br /><br />
			<nav class="nav-tab-wrapper">
				<?php
				$wkug_setting_tabs = array(
                    'featured-on' => array(
                        'title'   => 'Homepage Featured-on',
                        'add-new' => true,
                    ),
				);
				$current_tab = empty( $_GET['tab'] ) ? 'featured-on' : sanitize_title( $_GET['tab'] );
                
                $add_new = $wkug_setting_tabs[ $current_tab ]['add-new'];

				foreach ( $wkug_setting_tabs as $name => $label ) {

					echo '<a href="' . esc_url( admin_url( 'admin.php?page=wk-theme-pages-config&tab=' . $name ) ) . '" class="nav-tab ' . ( $current_tab === $name ? 'nav-tab-active' : '' ) . '">' . esc_html( $label['title'] ) . '</a>';
				}
				?>
			</nav>
            <br />
            <div class="wktheme-action-panel">
                <?php
                if( $add_new ) {
                    ?>
                    <div class="add-block">Add New
                        <span class="dashicons dashicons-plus-alt"></span>
                    </div>
                    <?php
                }
                ?>
                <div class="save-widget-btn" <?php echo ( ! $add_new ) ? 'style="direction:rtl"' : false; ?>>
                    <img style="display:none;vertical-align: middle;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />
                    <button id="save-icons" class="button button-primary">UPDATE</button>
                </div>
            </div>
			<?php
			do_action( 'wktheme_' . $current_tab . '_page_setting_tab' );
			?>
        </div>
        <div style="display:none;" class="notice notice-success is-dismissible">
            <p><strong><?php echo $wkug_setting_tabs[ $current_tab ]['title']; ?> Data Successfully Updated.</strong></p>
        </div>
        <div style="display:none;" class="notice notice-error is-dismissible">
            <p><strong>Something Went Wrong! Please Try Again.</strong></p>
        </div>
	</div>
	<?php
}



/* Common Ajax Method to save all SETTINGS options */
add_action( 'wp_ajax_wktheme_shortcode_panels_save_data', 'wk_shortcode_panels_handler' );
function wk_shortcode_panels_handler() {

    $bag            = isset( $_POST['wkdata'] ) ? $_POST['wkdata'] : array();
    $bag            = json_decode( stripslashes( $bag ), true );
	$db_option_name = $_POST['option'];   //option name
	$all_panels     = get_option( $db_option_name );
	$curr_panel_ids = array_keys( $all_panels );
	$new_panel_ids  = array_keys( $bag );

	foreach ( $curr_panel_ids as $id_check ) {
		if ( ! in_array( $id_check, $new_panel_ids, true ) ) {
			unset( $all_panels[ $id_check ] );
		}
    }

	foreach ( $bag as $key => $data ) {
		/**
		 * Option settings for the Component
		 * Added after new version of widgets' layout
         *
		 * @param array $all_panels[ $key ]['options'] Array of extra options/settings
		 */
		$all_panels[ $key ]['meta'] = array();
		if ( isset( $data['meta'] ) ) {
			$meta_array = array();
			foreach ( array_keys( $data['meta'] ) as $meta_field ) {
				$meta_array[ $meta_field ] = $data['meta'][ $meta_field ];
			}
			$all_panels[ $key ]['meta'] = $meta_array;
		}
		/*//Option settings for the Component*/

		$all_panels[ $key ]['items'] = array();

        $items = ( isset( $data['items'] ) ) ? ( $data['items'] ) : $data;  // $data for old way.

		foreach ( $items as $item ) {

            $data_arr = array();

            if ( ! empty( $item ) ) {
                foreach ( array_keys( $item ) as $k ) {
                    $data_arr[ $k ] = wp_unslash( $item[ $k ] );
                }
                $all_panels[ $key ]['items'][] = $data_arr;
            }
		}
    }
	update_option( $db_option_name, $all_panels );   // Update to DB.
	exit;
}
/* //Common Ajax Method to save all SETTINGS options */
?>
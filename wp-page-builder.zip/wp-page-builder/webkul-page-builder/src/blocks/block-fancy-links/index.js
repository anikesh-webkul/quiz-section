registerBlockType( 'wk-blocks/fancy-links', {
    title : 'Fancy Links',
    icon : 'excerpt-view',
    category: 'webkul',
    keywords: ['Fancy Links'],
    parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    example:{},
    attributes: {
        content: {
            type:'string',
            selector: 'h4',
        },
        
        newWindow: {
            type:'boolean',
        },
        imgLink: {
            type:'string',
            source: 'attribute',
			attribute: 'href',
            selector: 'a',
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgSrc: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
        }
       
    },
    edit : function( props ) {
        var content = props.attributes.content,
        newWindow = props.attributes.newWindow,
        imgLink= props.attributes.imgLink,
        imgID = props.attributes.imgID,
        imgALT = props.attributes.imgALT,
        imgSrc = props.attributes.imgSrc;

        const onRemoveImage = () => {
			props.setAttributes( {
				imgSrc: null,
                imgID: null,
                imgALT:null,
			} );
        };

       
        return (
            el(
                Fragment,
                {},
                el(
                    InspectorControls,
                    {},
                    el(
                        Panel,
                        {},
                        el(
                            PanelBody,
                            {
                                title:'Fancy Link Setting',
                            },
                            el(
                                PanelRow,
                                {},
                                el(
                                    TextControl,
                                    {
                                        type:"string",
							            label:'ADD URL',
                                        value:imgLink,
                                        onChange:(newLink) => {
                                            props.setAttributes({imgLink:newLink});
                                        }
                                    }
                                ),
                            ),
                            el(
                                PanelRow,
                                {},
                                el(
                                    FormToggle,
                                    {
                                        checked:newWindow,
                                        onChange: ( event ) => {
                                            props.setAttributes( {
                                                newWindow: event.target.checked,
                                            } )
                                        },
                                    }
                                ),
                                el(
                                    'span',
                                    {},
                                    'Open in New Tab'
                                )
                            ),
                        )
                    )
                ),
                el(
                    'div',
                    {
                        className:'wk-image-uploader',
                    },
                    el(
                        MediaUpload,
                        {
                            buttonProps: {
                                className: 'change-image'
                            },
                            onSelect: img => props.setAttributes({
                                imgID: img.id,
                                imgSrc: img.url,
                                imgALT:img.alt ? img.alt : img.title 
                            }),
                            allowed: ALLOWED_MEDIA_TYPES,
                            type: "image",
                            value: imgID,
                            render: ({ open }) => el(
                                Fragment,
                                null,
                                el(
                                    Button,
                                    {
                                        className: imgSrc ? 'wk-change-image' : 'wk-add-image',
                                        onClick: open
                                    },
                                    ! imgSrc ? wkUploadIcon : el( "img",
                                        {
                                            src: imgSrc,
                                            alt: imgALT
                                        }
                                    )
                                ),
                                imgSrc && el(
                                    Button,
                                    {
                                        className: "wk-remove-image",
                                        onClick: onRemoveImage
                                    },
                                    el(
                                        Dashicon,
                                        {
                                            icon: 'dismiss'
                                        }
                                    )
                                )
                            )
                        }
    
                    ),
                ),
                el(
                    PlainText,
                    {
                        key: 'editable',
                        tag:'h4',
                        value:content,
                        placeholder:'Fancy Link Text....',
                        onChange:(newContent) => {
                            props.setAttributes({content:newContent});
                        },
                        style:{
                            marginTop:'5px'
                        }
                    },

                ),
                // el(
                //     Dashicon,
                //     {
                //         icon:'admin-links'
                //     }
                // )
            )
        
        );
    },
    save:function(props) {
        return el(
            Fragment,
            {},
            el(
                'a',
                {
                    href:props.attributes.imgLink,
                    className:'link-component',
                    title:props.attributes.content,
                    target:(props.attributes.newContent) ? '_blank' : false,
                    rel:(props.attributes.newContent) ? 'noopener noreferrer' : false,
                },
                el(
                    'img',
                    {
                        src:props.attributes.imgSrc,
                        alt:props.attributes.imgALT,
                        className:'fancy-img'
                    },
                    
                ),
                el(
                    'p',
                    {
                        className:'fancy-title',
                    },
                    props.attributes.content
                )
            )
        )
    }


} );
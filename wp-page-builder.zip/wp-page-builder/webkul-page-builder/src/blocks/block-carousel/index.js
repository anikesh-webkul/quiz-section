/**
 * Register Custom Carousel Block
 */

registerBlockType( 'wk-blocks/carousel', {
    title : 'Carousel',
    icon : 'images-alt2',
    category: 'webkul',
    keywords: ['Carousel'],
    example:{},
    attributes: {
        product: {
            type:'string',
            selector:'a'
        },
        desc:{
            type:'string',
            selector:'p',
        },
        
        newWindow: {
            type:'boolean',
        },
        link: {
            type:'string',
            source: 'attribute',
			attribute: 'href',
            selector: 'a',
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgSrc: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
        },
        clientName:{
            type:'string',
            // selector:
        },
        clientLoc: {
            type:'string'
        },
        workDetail: {
            type:'string'
        }
       
    },
    edit:function(props) {

        var product = props.attributes.product,
        newWindow = props.attributes.newWindow,
        link= props.attributes.link,
        imgID = props.attributes.imgID,
        imgALT = props.attributes.imgALT,
        desc = props.attributes.desc,
        workDetail = props.attributes.workDetail,
        clientLoc = props.attributes.clientLoc,
        clientName = props.attributes.clientName,
        imgSrc = props.attributes.imgSrc;

        const onRemoveImage = () => {
			props.setAttributes( {
				imgSrc: null,
                imgID: null,
                imgALT:null,
			} );
        };

        const [isOpen, setOpen] = useState(false);
        const openModal = () => setOpen(true);
        const closeModal = () => setOpen(false);

        return el(
            Fragment,
            {},

            /** //Sidebar setting */
            el(
                InspectorControls,
                {},
                el(
                    PanelBody,
                    {},
                    el(
                        PanelRow,
                        {},
                        el(
                            'div',
                            {
                                style:{
                                    visibility:'hidden',
                                },
                            },
                            el(
                                MediaUpload,
                                {
                                    buttonProps: {
                                        className: 'change-image'
                                    },
                                    onSelect: ( img ) => { props.setAttributes({
                                        imgID: img.id,
                                        imgSrc: img.url,
                                        imgALT:img.alt ? img.alt : img.title 
                                        });
                                        setOpen(true);
                                    },
                                    allowed: ALLOWED_MEDIA_TYPES,
                                    type: "image",
                                    value: imgID,
                                    render: ({ open }) => el(
                                        Fragment,
                                        null,
                                        el(
                                            Button,
                                            {
                                                className: imgSrc ? 'wk-change-image wk-add-alter-image' : 'wk-add-image wk-add-alter-image',
                                                onClick: open
                                            },
                                            ! imgSrc ? wkUploadIcon : el( "img",
                                                {
                                                    src: imgSrc,
                                                    alt: imgALT
                                                }
                                            )
                                        ),
                                        imgSrc && el(
                                            Button,
                                            {
                                                className: "wk-remove-image",
                                                onClick: onRemoveImage
                                            },
                                            el(
                                                Dashicon,
                                                {
                                                    icon: 'dismiss'
                                                }
                                            )
                                        )
                                    )
                                }
                            )
                        ),
                    )
                ),

            ),
            el(
                'div',
                {
                    className:'wk-carousel-panel-wrap'
                },
                el(
                    'div',
                    {},
                    ( product ) ? product : 'Add Carousel Data',
                ),
                el(
                    'span',
                    {
                        onClick: openModal,
                    },
                    el(
                        Dashicon,
                        {
                            icon:'edit',
                            
                        }
                    )
                ),

            ),
            isOpen && el (
                Modal,
                {
                    title:'ADD/EDIT Carousel Data',
                    onRequestClose:closeModal,
                    style:{
                        maxWidth: '100%',
                        width: '540px',
                    }
                },
                el(
                    'div',
                    {
                        style:{
                            display:'grid',
                            gridGap:'5px'
                        }
                    },
                    
                    /** Form Field */
                    el(
                        TextControl,
                        {
                            label:"Product/Service Name",
                            value:product,
                                onChange:(newProduct) => {
                                props.setAttributes({product:newProduct});
                            },
                            placeholder:'Ex. Woocommerce Marketplace'
                        }
                    ),

                    /** Form Field */
                    el(
                        TextControl,
                        {
                            label:"Product/Service Link",
                            value:link,
                                onChange:(link) => {
                                props.setAttributes({link:link});
                            },
                            placeholder:'https://example.com'
                        }
                    ),
                    
                    /** Form Field */
                    el(
                        'label',
                        {},
                        el(
                            FormToggle,
                            {
                                checked:newWindow,
                                onChange: ( event ) => {
                                    props.setAttributes( {
                                        newWindow: event.target.checked,
                                    } )
                                },
                            }
                        ),
                        el(
                            'span',
                            {
                                style:{
                                    float:'right'
                                }
                            },
                            'Open in New Tab'
                        )

                    ),

                    /** Form Field */
                    el(
                        'div',
                        {},
                        el(
                            'label',
                            {},
                            'Review/Descrition',
                            el(
                                PlainText,
                                {
                                    label:"Review/Description",
                                    value:desc,
                                        onChange:(newDesc) => {
                                        props.setAttributes({desc:newDesc});
                                    },
                                    placeholder:'Review....',
                                    style:{
                                        width:'100%',
                                        minHeight:'80px'
                                    }
                                }
                            ),
                        )

                    ),

                    el(
                        'div',
                        {
                            style:{
                                display:'grid',
                                gridTemplateColumns: '180px auto',
                                gridGap: '15px',
                                marginTop: '15px',
                            }
                        },
                        el(
                            'div',
                            {
                                className:'wk-image-uploader'
                            },
                            el(
                                Button,
                                {
                                    className: 'wk-change-image',
                                    onClick: () => {
                                        document.querySelector('.wk-add-alter-image').click();
                                    }
                                },
                                ! imgSrc ? wkUploadIcon : el( "img",
                                    {
                                        src: imgSrc,
                                        alt: imgALT
                                    }
                                )
                            ),
                            imgSrc && el(
                                Button,
                                {
                                    className: "wk-remove-image",
                                    onClick: onRemoveImage,
                                },
                                el(
                                    Dashicon,
                                    {
                                        icon: 'dismiss'
                                    }
                                )
                            )
                        ),

                        el(
                            'div',
                            {},
                            /** Sub Form Field */
                            el(
                                TextControl,
                                {
                                    label:"Client Name",
                                    value:clientName,
                                        onChange:(clientName) => {
                                        props.setAttributes({clientName:clientName});
                                    },
                                }
                            ),
                            
        
                            /** sub Form Field */
                            el(
                                TextControl,
                                {
                                    label:"Work Details",
                                    value:workDetail,
                                        onChange:(workDetail) => {
                                        props.setAttributes({workDetail:workDetail});
                                    },
                                }
                            ),
    
                            el(
                                'div',
                                {},
                                el(
                                    TextControl,
                                    {
                                        label:"Client Location",
                                        value:clientLoc,
                                            onChange:(clientLoc) => {
                                            props.setAttributes({clientLoc:clientLoc});
                                        },
                                    }
                                ),
                            ),
                        ),
                    ),


                    
                    /** Form Field */

                ),
            )
        );

    },
    save:function(props) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className:'data',
                },
                el(
                    'p',
                    {},
                    'Review for'
                ),
                el(
                    'p',
                    {},
                    el(
                        'a',
                        {
                            href:props.attributes.link,
                            target:(props.attributes.newWindow) ? '_blank' : false,
                            rel:(props.attributes.newWindow) ? 'noopener noreferrer' : false,
                            title:props.attributes.product,
                        },
                        props.attributes.product
                    ),
                ),
                el(
                    'p',
                    {
                        className:'larger speak',
                    },
                    props.attributes.desc
                ),
                el(
                    'div',
                    {
                        className:'customer-bio',
                    },
                    el(
                        'img',
                        {
                            src:props.attributes.imgSrc,
                            alt:props.attributes.imgALT,
                            className:'pic'
                        }
                    ),
                    el(
                        'div',
                        {
                            className:'info',
                        },
                        el(
                            'p',
                            {},
                            props.attributes.clientName
                        ),
                        el(
                            'p',
                            {},
                            props.attributes.workDetail
                        ),
                        el(
                            'p',
                            {},
                            props.attributes.clientLoc
                        ),
                    )
                ),
            )
        );
    }
} );
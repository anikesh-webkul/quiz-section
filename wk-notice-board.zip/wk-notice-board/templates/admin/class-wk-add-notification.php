<?php

	if  ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Wk_Add_Notification' ) ) {

	class Wk_Add_Notification {

		public function __construct() {
			global $wpdb;
			$table_name = $wpdb->prefix . 'banner_list';

			if ( ! empty( $_GET['id'] ) && intval( $_GET['id'] ) ) {
				$button_text = 'Update Notification';
			} else {
				$button_text = 'Save Notification';

			}
			date_default_timezone_set('Asia/Kolkata');

//alter table
						global $wpdb;
						$table_name = $wpdb->prefix . 'banner_list';
						
						$dbname= $wpdb->dbname;
						$row = $wpdb->get_results(  "SELECT NULL  FROM INFORMATION_SCHEMA.COLUMNS
						WHERE table_name = '$table_name' AND column_name = 'auto_disable'"  );

						if(empty($row))
						{
							$wpdb->query("ALTER TABLE 
								$table_name ADD 
								auto_disable      varchar(50)   NOT NULL
								 ");
						}

						$row2 = $wpdb->get_results(  "SELECT NULL FROM INFORMATION_SCHEMA.COLUMNS
						WHERE table_name = '$table_name' AND column_name = 'end_date '"  );

						if(empty($row2))
						{
							$wpdb->query("ALTER TABLE 
								$table_name ADD 
								end_date          varchar(50)   NOT NULL
								 ");
						}
	

			if ( isset( $_POST['wk_banner_submit'] ) ) {

				$table_name = $wpdb->prefix . 'banner_list';
				$default    = array(
					'id'                     => 0,
					'title'                  => null,
					'link_title'             => null,
					'link'                   => null,
					'label_title'            => null,
					'label_title_color'      => null,
					'label_background_color' => null,
					'auto_disable'           => null,
					'end_date'               => null,
					'priority'               => 0,
					'status'                 => 'enable',
				);
				
			
				$wk_current_user                = $_REQUEST['wk_current_user'];
				$banner_title                   = sanitize_text_field( $_POST['banner-title'] );
				$banner_titles                  = $banner_title;
				$item['title']                  = $banner_title;
				$item['link_title']             = sanitize_text_field( $_POST['banner-link-title'] );
				$item['banner_text']            = sanitize_text_field( $_POST['banner-text'] );
				$item['link']                   = $_POST['banner-link'];
				$item['label_title']            = sanitize_text_field( $_POST['banner-label-select'] );
				$item['label_title_color']      = sanitize_text_field( $_POST['banner-label-title-color'] );
				$item['label_background_color'] = sanitize_text_field( $_POST['banner-label-background-color'] );
				if(isset($_POST['auto-disable']))
				{
					$item['auto_disable'] = sanitize_text_field( $_POST['auto-disable'] );
					$item['end_date'] = sanitize_text_field( $_POST['notice-end-date'] );
				}
				else
				{
					$item['auto_disable'] = sanitize_text_field('');
				}
				if(! empty($item['auto_disable']))
				{
					date_default_timezone_set('Asia/Kolkata');
						$end_date1= $item['end_date'];
						$today=date('Y-m-d H:i') ;

						if(strtotime($end_date1) <= strtotime($today) )
						{	
							$item['status']   = 'disable';
						}
						else
						{
							$item['status']  = 'enable';
						}
			    }
				
			else
			{
				$item['status']  = 'enable';
			}
			
				
				if ( ! isset( $_GET['id'] ) && empty( $_GET['id'] ) ) {
					if ( ! empty( $item['title'] ) ) {
						$result      = $wpdb->insert( $table_name, $item );
						$item['id']  = $wpdb->insert_id;
						$set_priroty = array( 'priority' => $item['id'] );
						$result      = $wpdb->update( $table_name, $set_priroty, array( 'id' => $item['id'] ) );
					} else {
						$result='';
					}
					if ($result) {
						echo '<div class="notice notice-success">';
						echo '<p>Data has been added successfully.</p>';
						echo '</div>';
					} else {
						echo '<div class="notice notice-error">';
						echo '<p>There was an error while saving.</p>';
						echo '</div>';
					}
				} else {

					$result = $wpdb->update( $table_name, $item, array( 'id' => $_GET['id'] ) );
					if ( $result ) {
						echo '<div class="notice notice-success">';
						echo '<p>Data has been updated successfully.</p>';
						echo '</div>';
					} else {
						echo '<div class="notice notice-error">';
						echo '<p>There was an error while updating.</p>';
						echo '</div>';
					}
				}
			}

			if ( ! empty( $_GET['id'] ) && intval( $_GET['id'] ) )
			 {
				$cur_banner = $item['id'] = $_GET['id'];
				$banner_l = $wpdb->get_results( "SELECT * from $table_name WHERE id='$cur_banner'" );
				$banner_l                      = $banner_l[0];
				$banner_titles                 = _wk_remove_slashes( $banner_l->title );
				$banner_text                   = _wk_remove_slashes( $banner_l->banner_text );
				$banner_link_title             = _wk_remove_slashes( $banner_l->link_title );
				$banner_link                   = $banner_l->link;
				$banner_label_title            = _wk_remove_slashes( $banner_l->label_title );
				$banner_label_title_color      = $banner_l->label_title_color;
				$banner_label_background_color = $banner_l->label_background_color;
				$banner_status                 = $banner_l->status;
				$auto_disable				   =  $banner_l->auto_disable;
				$end_date1					   =  $banner_l->end_date;
				$id1= $banner_l->id;		
			}
console_log($banner_l );
			global $wpdb;
			$table_name = $wpdb->prefix . 'banner_list';
			$select_options = $wpdb->get_results( "SELECT label_title from $table_name WHERE label_title != ''", ARRAY_A );
			if ( isset( $select_options ) && ! empty( $select_options ) )
			{
				$select_options = json_decode( json_encode( $select_options ), true );
				$select_options = array_unique( $select_options, SORT_REGULAR );
			}
			
			if(! empty($auto_disable))
			{
				date_default_timezone_set('Asia/Kolkata');
				$end_date= $end_date1;
				$today=date('Y-m-d H:i');
			
				if(strtotime($end_date) <= strtotime($today) )
				{	
						$dataupdate = array( 
							'status' => 'disable',	
						  );
						  $where = [ 'id' => $id1 ];
						  
						  $updated = $wpdb->update( $table_name, $dataupdate, $where);
				}	
				
			}
			
		
			?>
			<div class="wk-form wk-banner-outerwrapper">
				<h1>Banner</h1>
				<form action="" method="post" id="banner_list">
					<input type="hidden" name="id" value="
					<?php
					if ( isset( $item['id'] ) ) {
						echo esc_html( $item['id'] );
					}
					?>
					"/>
					<input type="hidden" name="nonce" value="
					<?php
					echo wp_create_nonce( basename( __FILE__ ) );
					?>
					"/>
					<div class="inner-wrap">
						<label for="banner-title">Banner Title:   </label>
						<input type="text" id="banner-title" required name="banner-title"  placeholder="Banner Title" required value="<?php echo ( isset( $banner_titles ) && ! empty( $banner_titles ) ) ? esc_html( $banner_titles ) : false?>">
					</div>

					<div class="inner-wrap">
						<label for="banner-text">Banner Text: (MAX 130 Characters)  </label>
						<input type="text" id="banner-text" required name="banner-text"  placeholder="Banner Text" required value="<?php echo ( ! empty( $banner_text ) ) ? esc_html( $banner_text ) : false;?>">
					</div>

					<div class="inner-wrap banner-label-select-outer">
						<label for="banner-label-select">Banner Label Title:   </label>
						<select id="banner-label-select" class="<?php if ( ! isset( $select_options ) || empty( $select_options ) ) echo 'disable-select-dropdown'; ?>"  name="banner-label-select">
							<?php if ( isset( $select_options ) && ! empty( $select_options ) && is_array( $select_options ) ) {
								foreach ( $select_options as $key => $value ) :
									?>
									<option value="<?php echo  esc_html( $value['label_title'] ); ?>"
										<?php
										if ( isset( $banner_label_title ) && ! empty( $banner_label_title ) && $banner_label_title == $value['label_title'] ) echo 'selected'; ?>
										><?php
										echo  esc_html( $value['label_title'] );
										?>
									</option>
									<?php
								endforeach;
							}
							?>
							<option value="" <?php if ( isset( $banner_label_title ) && empty( $banner_label_title ) ) echo 'selected'; ?>>None</option>
						</select>

						<input type="text" name="banner-label-title"  value="<?php
							if ( isset( $banner_label_title ) && $banner_label_title !='' ) {
								echo esc_html( $banner_label_title );
							}
							?>"
							>
						<a href="javascript:void(0);" value="add label title" class="add-label-title-button button-primary">Add Label Title</a>
				 </div>
				 <div class="inner-wrap">
						<label for="banner-label-title-color">Label Title Color:   </label>
						<input type="text" class="color-picker" name="banner-label-title-color" id='banner-label-title-color' value="<?php
							if (isset($banner_label_title_color) && $banner_label_title_color!='') {
									echo $banner_label_title_color;
							}
							?>"
						 />
				 </div>
				 <div class="inner-wrap">
						<label for="banner-label-background-color">Label Background Color:   </label>
						<input type="text" class="color-picker" name="banner-label-background-color" id='banner-label-background-color' value="<?php
							if (isset($banner_label_background_color) && $banner_label_background_color!='') {
									echo $banner_label_background_color;
							}
							?>"
						 />
				 </div>
				 <div class="inner-wrap" id="banner-link-title">
					 <label for="banner-link-title">Banner Link Title: </label>
					 <input type="text" name="banner-link-title"  value="<?php
						 if (isset($banner_link_title) && $banner_link_title!='') {
									echo $banner_link_title;
						 }
						 ?>"
					 >
				</div>
					<div class="inner-wrap" id="banner-link">
						<label for="banner-link">Banner Link: </label>
						<input type="text" name="banner-link"  value="<?php
							if (isset($banner_link) && $banner_link!='') {
									 echo $banner_link;
							}
							?>"
						>
				 </div>

	<!-- Auto disable function code here -->

				 <label><strong>Mark as Auto Disable</strong></label>
           
		   <div class="inner-wrap">
			   <!-- <br> -->
			   <?php 
			   $enable_value  = ! empty( $auto_disable) ? $auto_disable : 'false'; 
			  
			   ?>
					
			   <label>
				   <span class="switcher">
					   <input id="enableoption" name="auto-disable" type="checkbox" value="true"
					   <?php checked( 'true', $enable_value ); ?>> 
					   <span class="slider round"></span>
					   
				   </span>
			   </label>
			  
		   </div>

		   
	   <div class="inner-wrap">
		   <div class="inline-grid" >

				   <label>
					   <strong>End Date & Time( 24Hrs )</strong>
					   <input id="time-end" type="datetime-local" name="notice-end-date" value="<?php echo ! empty( $end_date1) ? $end_date1 : 'false'; ?>" class="form-input">
				   </label>
			   </div>
		   </div>


					<div class="inner-wrap">
						<input type="hidden" name="wk_current_user" value="<?php echo get_current_user_id(); ?>">
					</div>
					<div class="button-section">
							<input type="submit" value="<?php echo esc_html( $button_text ); ?>" name="wk_banner_submit" class="button button-primary">
					</div>
				</form>
			</div>


			<?php

		}

	}

	return new Wk_Add_Notification();

}

<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Wk_Job_Templates' ) ) {

	class Wk_Job_Templates {

		public function __construct() {

		}

		public function form() {
			?>
			<section class="op-apply-form-section">
				<div id="uv_top_message" class="uv_load"></div>

				<script id="2665ad486ac4ffc35ad486ac50071" src="https://hr.uvdesk.com/apps/form-builder/en/form/2665ad486ac4ffc35ad486ac50071?removePlaceholders=1&info=1&ver=1.1" async="async"></script>

				<div class="form-wrapper">
					<div class="form-head">
						<span title="close" class="op-close"></span>
						<p class="application-form-title">Webkul Job Application Form</p>
					</div>

					<div class="form-body">

						<div class="field-group-controls">

							<div class="wkj-form-meta-wrapper">
								<p class="apply-for"><span class="txt-light">Applying for</span><br><span id="profile"></span>'s Post</p>
								<div id="wkFormCredibilityMeter" class="form-credibility" data-credibility="0">
									<svg class="meter" width="145" height="145" viewBox="0 0 120 120">
										<circle class="meter__bg" cx="60" cy="60" r="54" stroke-width="6" />
										<circle class="meter__score" cx="60" cy="60" r="54" stroke-width="6" />
									</svg>
								</div>
								<div class="text-center wkj-label">Credibility</div>
							</div>

							<div class="wkj-form-tabs-wrapper">
								<span class="active-tab-stick"></span>
								<div class="wkj-form-tabs tab-active" data-hook="info">
									<div class="wkj-label">Information</div>
									<div class="field-progress-markers"></div>
								</div>

								<div class="wkj-form-tabs" data-hook="resume">
									<div class="wkj-label">Resume</div>
									<div class="field-progress-markers"></div>
								</div>

								<div class="wkj-form-tabs" data-hook="other">
									<div class="wkj-label">Other Details</div>
									<div class="field-progress-markers"></div>
								</div>
							</div>
						</div>

						<div class="fields-group-wrapper">
							<div class="field-groups grp-active" data-index="info">
								<div class="field-group-title">General Info</div>
								<div class="field-wrap">
									<label for="name">Name*</label>
									<input required class="op-field" id="name" type="text" value="" />
									<div class="error"></div>
								</div>
								<div class="field-wrap">
									<label for="email">Email*</label>
									<input required class="op-field" id="email" type="email" value="" />
									<div class="error"></div>
								</div>
								<div class="field-wrap">
									<label for="contact">Contact*</label>
									<input required class="op-field" id="contact" type="text" value="" />
									<div class="error"></div>
								</div>
								<div class="field-wrap">
									<label for="linkdin-profile">LinkedIn Profile</label>
									<input class="op-field" id="linkdin-profile" type="text" value="" />
								</div>
								<div class="field-wrap wk-linkedin-followers">
									<div class="follower-count-label">For job updates at Webkul, follow us on LinkedIn</div>
									<div class="follower-count-close"></div>
									<script src="https://platform.linkedin.com/in.js" type="text/javascript"> lang: en_US</script>
									<script type="IN/FollowCompany" data-id="914889" data-counter="right"></script>
								</div>
								<div class="field-wrap">
									<label for="github-profile">Github / Behance / dribbble Profile</label>
									<input class="op-field" id="github-profile" type="text" value="" />
								</div>
								<button type="button" id="continue-tab" class="wk-button tab-next">Continue</button>
							</div>
							<div class="field-groups has-file-upload" data-index="resume">
								<div class="field-group-title">Upload Resume</div>
								<div class="field-wrap">
									<label for="resume-title">Resume Title</label>
									<input required class="op-field" id="resume-title" type="text" value="" />
									<div class="error"></div>
								</div>
								<div class="field-wrap file-upload">
									<div class="icon add"></div>
									<div class="upload-label">Upload Your CV / Resume</div>
									<label tabindex="0" for="uv_forFile-(Resume-Attachment)550" id="file-upload-label" class="op-field upload-btn">Upload File</label>
									<div class="error"></div>
									<div class="accept-file">PDF, DOC & DOCX Accepted <br> Max file size 2 MB</div>
								</div>
								<button type="button" id="continue-tab" class="wk-button tab-next">Continue</button>
							</div>
							<div class="field-groups" data-index="other">
								<div class="field-group-title">Other Details</div>
								<div class="field-wrap">
									<label for="location">Location</label>
									<input required class="op-field" id="location" type="text" value="" />
									<div class="error"></div>
								</div>
								<div class="field-wrap">
									<label class="top-20" for="experience">Total Experience - In Yrs.</label>
									<input required class="op-field" id="experience" type="text" value="" />
									<div class="error"></div>
								</div>
								<div class="field-wrap">
									<label class="top-20" for="current-ctc">Current CTC</label>
									<input required class="op-field" id="current-ctc" type="text" value="" />
									<div class="error"></div>
								</div>
								<div class="field-wrap">
									<label class="top-20" for="expected-ctc">Expected CTC</label>
									<input required class="op-field" id="expected-ctc" type="text" value="" />
									<div class="error"></div>
								</div>
								<div class="field-wrap">
									<label class="top-20" for="heard-from">How did you hear about this job?</label>
									<input required class="op-field" id="heard-from" type="text" value="" />
									<div class="error"></div>
								</div>
								<button type="button" id="wk-job-form-submit-btn" class="wk-button btn-submit-form">Apply</button>
							</div>
						</div>
					</div>
				</div>
				<div class="form-wrapper response display-none">
					<div class="response-content">
						<div class="icon-wrap"><span class="icon"></span></div>
						<p class="main">That's Bullseye!</p>
						<p>We have successfully recieved your request for the post of <span id="res-post"></span> and if you get shortlisted We will get back to you.<br />Good Luck!</p>
						<a class="wk-button" href="<?php echo esc_url( site_url() . '/careers' ); ?>" title="Back to Careers">Back to Careers</a>
					</div>
					<div class="social-btns">
						<a class="social-btn social-linkedin" target="_blank" rel="noopener" href="https://www.linkedin.com/company/webkul"><span></span>Follow us on LinkedIn</a>
						<a class="social-btn social-facebook" target="_blank" rel="noopener" href="https://www.facebook.com/webkul"><span></span>Like us on Facebook</a>
					</div>
				</div>
			</section>
			<?php
		}

		public function cf7form( $position = '', $nav = '' ) {
			?>
			<section class="op-apply-form-section">
				<div class="form-wrapper">
					<div class="form-head">
						<div class="form-container">
							<div class="back-link op-close">Back</div>
						</div>
					</div>
					<div class="form-body">
						<div class="form-container">
							<div class="apply-meta">
								<h3 id="profile"><?php echo $position; ?></h3>
								<?php echo $nav; ?>
							</div>
							<div class="form-group">
								<p class="form-title">JOB APPLICATION FORM</p>
								<?php echo do_shortcode( '[contact-form-7 id="22892" title="Job Application Form"]' ); ?>
							</div>

							<div class="form-response text-center display-none">
								<br>
								<img src="<?php echo get_template_directory_uri() . '/images/career/icon-success.jpg' ?>" alt="Job Application Submitted">
								<p>We appreciate your interest in joining us. We will be in touch if your skills and experience are a strong match for the role.</p>
								<br>
								<a href="https://webkul.com/jobs/" class="wk-button">Back to Jobs</a>
							</div>
						</div>
					</div>
				</div>
			</section>
			<?php
		}

		public function share_brick() {
			?>
			<script type="text/html" id="wk-jobShare-template">
			<div class="share-brick">
				<div class="close-share"></div>
				<div class="share-section">
					<h6>Share Job</h6>
					<div class="social-btns-sm">
						<a onclick="window.open( this.href, 'targetWindow', 'toolbar=0,status=0,width=620,height=500'); return false;" class="social-btn social-btn-fb" href="http://www.facebook.com/sharer.php?u=https%3A//webkul.com/jobs/{{wkJobId}}&title={{wkJobTitle}}&description=Apply for {{wkJobTitle}}">Facebook</a>
						<a onclick="window.open('https://twitter.com/share?url=https%3A//webkul.com/jobs/{{wkJobId}}&hashtags=WebkulCareers&related=webkul&text=Apply for post - {{wkJobTitle}} @webkul', 'sharer', 'toolbar=0,status=0,width=620,height=500')" class="social-btn social-btn-tw" href="javascript:void(0);">Twitter</a>
						<a onclick="window.open('https://www.linkedin.com/shareArticle?mini=true&url=https%3A//webkul.com/jobs/{{wkJobId}}&title={{wkJobTitle}}&summary=We are one, We are Webkul - We are always on to say “Hello” to both creative and expert craftsmen. If you want to help us to create and solve the real world problems. You’ll enjoy your road trip with us.&source=https%3A%2F%2Fwebkul.com/careers', 'sharer', 'toolbar=0,status=0,width=620,height=500')" class="social-btn social-btn-in" href="javascript:void(0);">LinkedIn</a>
						<a href="mailto:?subject=Job Opening at Webkul Software&body=Webkul Software is hiring for the post of {{wkJobTitle}}.%0A%0AJob Description - {{wkJobDesc}}%0A%0AApply for the post of {{wkJobTitle}} at - https%3A//webkul.com/jobs/{{wkJobId}}%0A%0A" class="social-btn social-btn-em">Send by Email</a>
					</div>
				</div>
				<div class="share-section">
					<h6>Copy Code to Embed Job on your Website</h6>
					<div class="copy-wrap">
						<span class="copy-code">&lt;iframe width="100%" height="315" src="<?php echo esc_url(site_url() . '/jobs/embed-job/'); ?>{{wkJobId}}"&gt;&lt;/iframe&gt;</span>
					</div>
				</div>
			</div>
			</script>
			<?php
		}
	}
}
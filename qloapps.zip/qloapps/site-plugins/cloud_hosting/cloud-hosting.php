<?php
/*
Plugin Name: Cloud Hosting 
Plugin URI: http://qloapps.com
Description: A plugin for Adding Cloud Hosting Plan to qloapps themes
Author: qloapps
Author URI: http://qloapps.com
Text Domain: Qloapps
*/

/*-------------------*/ /*---------->>> Menu Pages <<<----------*/ /*--------------------*/
add_action( 'admin_menu', 'cloud_hosting_plans' );
function cloud_hosting_plans(){

  add_menu_page( 'Cloud Plan', 'Cloud Plan', 'edit_posts', 'cloud_feature', 'cloud_plan_add_menu_page', 'dashicons-editor-ul', 15);

  $hook=add_submenu_page( 'cloud_feature', 'Cloud Plan List', 'Cloud Plan List', 'edit_posts', 'cloud_plan_list', 'cloud_plan_menu_page' );

  add_action( "load-".$hook, 'add_op' );

  if(get_query_var('page')=='cloud_plan_list'){

    add_action( "current_screen",'new_menu_page_screen_op');
  }

  // add_action( 'current_screen','my_admin_add_help_tab');
}

function add_op() { 

  $option = 'per_page';

  $args = array(

         'label' => 'Results',

         'default' => 10,

         'option' => 'reviews_per_page'

         );

  add_screen_option( $option, $args );

}

function new_menu_page_screen_op() {  

    $screen = get_current_screen();   

    // get out of here if we are not on our settings page

    if(!is_object($screen) || $screen->idate(format) != 'toplevel_page_mp_addons')

        return;

    $args = array(

        'label' => __('Members per page', $new_menu_page),

        'default' => 10,

        'option' => 'result_per_page'
    );

    add_screen_option( 'per_page', $args );
}


function cloud_plan_add_menu_page(){
    if(!empty($_GET['user']))
      $button_text='Update Plan';
    else
      $button_text='Save Plan';
    if(!empty($_GET['user'])){
       $cur_user=$_GET['user'];
      $current_post_data=get_post($cur_user);
      $cloud_feature=$current_post_data->post_title;
      $cur_userLess=$cur_user-1;
      $cloud_plan=get_post_meta($cur_user,'cloud-plan', true);
    }
?>
<div class="wk-form">
                  <h1>cloud Plan!</h1>
                  <form action="" method="post" id="cloud_plan">
                      <div class="inner-wrap">
                          <label for="plan-feature">Cloud Feature</label>
                          <input type="text" id="plan-feature"  name="plan-feature" value="<?php if(!empty($cloud_feature))echo $cloud_feature?>" placeholder="Cloud Feature" required>
                      </div>
                      <div class="inner-wrap">
                          <label for="cloud-plan">Cloud Plan</label>
                          <input type="text" id="cloud-plan"  name="cloud-plan" value="<?php if(!empty($cloud_plan))echo $cloud_plan?>" placeholder="Plan Name" required>
                      </div>
                      
                      <div class="inner-wrap">
                          <input type="hidden" name="wk_current_user" value="<?php echo get_current_user_id(); ?>"> 
                          <input type="hidden" value="not displayed" name="plan_on"> 
                      </div>
                      
                      <div class="button-section">
                       <input type="submit" value="<?php echo $button_text?>" name="wk_submit" class="button button-primary">
                      </div>
                  </form>
                  </div>

  <?php

  global $wpdb; 

  if(isset($_POST['wk_submit'])){ 

    $wk_current_user=$_REQUEST['wk_current_user'];
    
    $cloud_feature=$_POST['plan-feature'];

    $cloud_plan=$_POST['cloud-plan'];
    
    $plan_on=$_POST['plan_on'];

    if(isset($wk_current_user)){
     
      if($_POST['wk_submit']=='Update Plan'){
  
    $cur_user=$_GET['user'];

    $cur_userLess=$cur_user-1;

    $my_post = array(
      'ID'           => $cur_user,
      'post_title'   => $cloud_feature
    );
      wp_update_post($my_post);
      update_post_meta($cur_user, 'cloud-plan', $cloud_plan);
      echo "<script>";
      echo "alert('Plan has been Updated Successfully')";
      echo "</script>";
    }
    else
    {
       $defaults = array(
      'post_status'           => 'publish', 
      'post_type'             => 'cloud_feature',
      'post_author'           => $wk_current_user, 
      'post_title'            => $cloud_feature,
      'plan_on'             => $plan_on  
    );
    wp_insert_post($defaults); 
    $lastid = $wpdb->insert_id;
    update_post_meta($lastid,'plan_on',$plan_on);
    update_post_meta($lastid,'cloud-plan',$cloud_plan);
    echo "<script>";
    echo "alert('Plan has been added Successfully')";
    echo "</script>";
    }
  }
    

  }

}

add_filter('set-screen-option', 'test_table_set_op', 10, 3);

function test_table_set_op($status, $option, $value) {

  if ( 'reviews_per_page' == $option ) return $value;

  return $status;

}


function cloud_plan_menu_page(){

if(!class_exists('Plan_List_Table')){

   require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );

}

    class Plan_List_Table extends WP_List_Table {



   /**

    * Constructor, we override the parent to pass our own arguments

    * We usually focus on three parameters: singular and plural labels, as well as whether the class supports AJAX.

    */

    function __construct() {

       parent::__construct( array(

            'singular'  => 'cloud_feature_list',     //singular name of the listed records

            'plural'    => 'all_cloud_feature_list',    //plural name of the listed records

            'ajax'      => false 

      ) );

    }

     public function prepare_items()  
     {

        global $wpdb;  

            $columns = $this->get_columns();

            $sortable = $this->get_sortable_columns();

            $hidden=$this->get_hidden_columns();

            $this->process_bulk_action();

            $data = $this->table_data();

            $totalitems = count($data);

            $user = get_current_user_id();

            $screen = get_current_screen();

            $option = $screen->get_option('per_page', 'option'); 

            $perpage = get_user_meta($user, $option, true);

            $this->_column_headers = array($columns,$hidden,$sortable); 

            if ( empty ( $per_page) || $per_page < 1 ) {
            
              $per_page = $screen->get_option( 'per_page', 'default' ); 

            }


            function usort_reorder($a,$b){

            $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'id'; //If no sort, default to title

            $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'desc'; //If no order, default to asc

            $result = strcmp($a[$orderby], $b[$orderby]); //Determine sort order

            return ($order==='asc') ? $result : -$result; //Send final sort direction to usort

        }

        usort($data, 'usort_reorder');

                $totalpages = ceil($totalitems/$perpage); 

                $currentPage = $this->get_pagenum();
                
                $data = array_slice($data,(($currentPage-1)*$perpage),$perpage);

                $this->set_pagination_args( array(

                "total_items" => $totalitems,

                "total_pages" => $totalpages,

                "per_page" => $perpage,
            ) );
                
        $this->items =$data;
    }

      public function get_hidden_columns()

    {

        return array();

    }

    function column_cb($item){

          return sprintf('<input type="checkbox" id="user_%s"name="user[]" value="%s" />',$item['id'], $item['id']);
    }

    function get_columns() {

    $columns= array( 

      'cb'        => '<input type="checkbox" />', //Render a checkbox instead of text

      'cloud_feature'=>__('Cloud Feature'),

      'cloud_plan'=>__('Cloud Plan'),

      'publish_date'=>__('Publish Date'),

      'front_end'   =>_('Status'),

   );

   return $columns;

}

/**

 * Decide which columns to activate the sorting functionality on

 * @return array $sortable, the array of columns that can be sorted by the user

 */

public function get_sortable_columns() {

     $sortable_columns = array(

            'cloud_feature'     => array('cloud_feature',true),

            'publish_date'   => array('publish_date',true)

        );

        return $sortable_columns;

}



 private function table_data()

   {      

    $post_per_page = get_option('posts_per_page');

         global $wpdb;
        if(isset($_GET['s']))

          {

          $search=$_GET['s'];

         $search = trim($search);
          $wk_post = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_title LIKE '%$search%' and post_type='cloud_feature' and post_status='publish'");
          }

        else{

            $wk_post = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type='cloud_feature' and post_status='publish'");

        }

        $data = array();

        $cloud_feature = array();

        $cloud_plan = array();

        $publish = array();

        $review_post_id=array(); 

        $upData=array();

         $i=0;

        foreach ($wk_post as $wk_posts) {

            $publish[]=$wk_posts->post_date;

            $review_post_id[]=$wk_posts->ID;
            
            $cloud_feature[]=$wk_posts->post_title;

            $cloud_plan[]=get_post_meta($wk_posts->ID,'cloud-plan',true);

            $plan_on[]=get_post_meta($wk_posts->ID,'plan_on',true);

            $data[] = array(

                    'id'           => $review_post_id[$i],   

                    'cloud_feature'  => $cloud_feature[$i],

                    'cloud_plan'  => $cloud_plan[$i],

                    'publish_date' => $publish[$i],

                    'front_end'    =>$plan_on[$i]

                    );

        $i++;

        }

        return $data;

    }

      function get_bulk_actions()
      {

        $actions = array(

            'trash'    => 'Move To Trash',
            'frontEnd' => 'Display'
        );

        return $actions;
    }



      public function process_bulk_action()
        { 

        global $wpdb;
        
        if ('trash' === $this->current_action()) {

              if (isset($_GET['user'])) {

                  if (is_array($_GET['user'])){

                    foreach ($_GET['user'] as $id) {

                    if (!empty($id)) { 

                      wp_trash_post($id);  

                      }

                  } 

                }
            else{

                  if (!empty($_GET['user'])) { 
                        $id=$_GET['user'];
                        wp_trash_post($id);  

              }

              }

          }

      }
      if ('frontEnd' === $this->current_action()) {

              if (isset($_GET['user'])) {
                $post_id_array=array();
                  if (is_array($_GET['user'])){
                   $meta = $wpdb->get_results("SELECT * FROM `".$wpdb->postmeta."` WHERE meta_key='plan_on'"); 
                      foreach ($meta as $res) {
                            $post_id_array[]=$res->post_id;
                          }
            foreach ($_GET['user'] as $id) {

            if (!empty($id)) { 
              $pos=array_search($id,$post_id_array);
              unset($post_id_array[$pos]); 
              $post_id_array[]=array_values($post_id_array);

              update_post_meta($id,'plan_on','displayed'); 
              for ($i=0; $i < count($post_id_array); $i++) { 
                update_post_meta($post_id_array[$i],'plan_on','not displayed');  
                }
              }

              else{

                  if (!empty($_GET['user'])) { 
                    update_post_meta($id,'plan_on', 'true');
                    for ($i=0; $i < count($post_id_array); $i++) { 
                        update_post_meta($post_id_array[$i],'plan_on','false');  
                      }       
                  }

                }

              }
            }

          }

      }

    }



    public function column_default( $item, $column_name )

      {

        switch( $column_name ) {

            case 'cloud_feature':

            case 'cloud_plan':

            case 'publish_date':

            case 'front_end':

                return $item[$column_name];

                    

            default:

                return print_r( $item, true ) ;

        }

    }



      /**

     * [OPTIONAL] this is example, how to render column with actions,

     * when you hover row "Edit | Delete" links showed

     *

     * @param $item - row (key, value array)

     * @return HTML

     */



   function column_cloud_feature($item) {

   $actions = array(

            'edit'      => sprintf('<a href="?page=cloud_feature&user=%s">Edit</a>',$item['id']),

            'trash'    => sprintf('<a href="?page=cloud_plan_list&action=trash&user=%s">Trash</a>',$item['id']),

            );

  return sprintf('%1$s %2$s', $item['cloud_feature'], $this->row_actions($actions) );

}


} 

    $wp_list_table = new Plan_List_Table();  

                 if( isset($_GET['s']) ){

                $wp_list_table->prepare_items($_GET['s']);

        } else {

                $wp_list_table->prepare_items();

        }
 

?>

 <form method="GET">

    <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />

  <?php $wp_list_table->search_box('Search Cloud Hosting Plan', 'search-id');

    $wp_list_table->display();

 ?>

</form>

<?php 

}
<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * For example, it puts together the home page when no home.php file exists.
 *
 * @link http://webkul.com
 *
 * @package webkul Blog
 * @subpackage webkulBlog
 * @since webkulBlog 1.0
 */

get_header();


/* A Renderer class to get the panels from
the content and create navigation template */
$content_obj  = new WK_Blog_Content_Renderer();
$show_toggler = apply_filters( 'return_show_toggler', get_the_ID() );
/* end */

blog_navbar();

while ( have_posts() ) {

	the_post();

	$author_id       = get_the_author_meta( 'ID' );
	$post_id         = get_the_ID();
	$author_thumb    = get_the_author_meta( 'profile-image', $author_id );
	$author_thumb    = ( ! empty( $author_thumb ) ) ? $author_thumb : get_avatar_url( ( get_the_author_meta( 'user_email' ) ) );
	$gradient_filter = get_post_meta( get_the_ID(), 'tag_cl' );

	if ( ! empty( $gradient_filter ) ) {
		$gradient_filter = $gradient_filter[0];
	} else {
		$gradient_filter = 'articles';
	}

	$share_title = rawurlencode( get_the_title() );
	$share_url   = rawurlencode( get_permalink() );
	$twitter     = get_the_author_meta( 'twitter', $author_id );

	$sd = get_the_date( 'd' );

	if ( $sd > 0 && $sd <= 7 ) {
		$bg_gradient = 1;
	} elseif ( $sd > 7 && $sd <= 15 ) {
		$bg_gradient = 2;
	} elseif ( $sd > 15 && $sd <= 24 ) {
		$bg_gradient = 3;
	} else {
		$bg_gradient = 4;
	}

	if ( ! empty( $twitter ) ) {
		$twitter = substr( $twitter, strrpos( $twitter, '/' ) + 1 );
		$twitter = ( '@' === $twitter[0] ) ? $twitter : '@' . $twitter;
	} else {
		$twitter = strtoupper( get_the_author() );
	}

	$post_link = get_post_meta( $post_id, 'wkpl-post-link', true );
	$post_filter = get_post_meta( $post_id, 'qlo_filter', true );

?>
<div class="single-page-blog-uv">

	<!--Author-->
	<div class="wk-single-page-blog">
		<div class="wk-grid-md null">
			<div class="wk-grid-lt-5">
				<div class="wk-single-story">
					<div class="wk-story-author">
						<a href="<?php echo get_author_posts_url( $author_id ); ?>"><img src="<?php echo $author_thumb; ?>"></a>
						<div class="wk-story-author-block">
							<a href="<?php echo get_author_posts_url( $author_id ); ?>"><?php the_author(); ?></a>
							<span><?php echo get_the_date( 'j F Y' ); ?></span>
						</div>
					</div>
					<div class="qloblog-version-block">
						<?php do_action( 'wkp_version_tab' ); ?>
					</div>
					<div class="qlo-blog-title">
						<h1 data-story="<?php echo esc_attr( $post_filter ); ?>"><?php echo get_the_title(); ?></h1>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--//Author-->

	<!--Bar-->
	<div class="wk-bar">
		<div class="wk-grid-md null">
			<div class="qlo-blog-options">
			<?php
			if ( ( isset( $post_link['store_link'] ) && ! empty( $post_link['store_link'] ) ) || isset( $post_link['demo_link'] ) && ! empty( $post_link['store_link'] ) ) {

				?>
				<div class="wk-demo-link">
				<?php
				if ( isset( $post_link['demo_link'] ) ) {
					if ( count( array_filter( $post_link['demo_link'] ) ) === 1 ) {
						echo '<a class="wkpl-btn color-prime get-it-now-green-btn" id="wkpl-demo" href="' . esc_url( $post_link['demo_link'][0] ) . '" rel="noopener" target="_blank">View Demo</a>';
					} elseif ( count( array_filter( $post_link['demo_link'] ) ) > 1 ) {
						?>
						<span class="wkpl-btn color-prime get-it-now-green-btn wklp-dropdown-label" id="wkpl-demo">Demo</span>
						<ul>
						<?php
						foreach ( $post_link['demo_link'] as $key => $demo_link ) {
							echo '<li><a href="' . esc_url( $demo_link ) . '" rel="noopener" target="_blank">' . esc_html( $post_link['demo_label'][ $key ] ) . '</a></li>';
						}
						echo '</ul>';
					}
				}
				if ( isset( $post_link['store_link'] ) && ! empty( $post_link['store_link'] ) ) {
					echo '<a class="wkpl-btn color-sec get-it-now-green-btn" id="wkpl-buy-now" href="' . esc_url( $post_link['store_link'] ) . '" rel="noopener" target="_blank">' . esc_html( $post_link['store_label'] ) . '</a>';
				}
				?>
				</div>
				<?php
				}
				?>
				<div class="wk-bar-share">
					<?php
					if ( $show_toggler ) {
						?>
						<span class="wk-bar-icon wk-bar-icon-index">Index</span>
						<?php
					}
					?>
					<a href="javascript:void(0)" onClick="window.open('http://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode( the_permalink() ); ?>&amp;t=<?php echo strip_tags( get_the_title() );?>', 'sharer', 'toolbar=0,status=0,width=620,height=500');" class="wk-bar-icon wk-bar-share-icon-facebook">Share</a>

					<a href="javascript:void(0)" onClick="window.open('https://twitter.com/share?url=<?php echo urlencode( get_permalink() );?>&related=WebkulDesign&text=<?php echo get_the_title() . " by " . get_the_author() ;?>&hashtags=WebkulDesign', 'sharer ', 'toolbar=0,status=0,width=620,height=500')"  class="wk-bar-icon wk-bar-share-icon-twitter">Tweet</a>

					<span class="wk-bar-icon wk-bar-icon-save">Save</span>
					<span class="wk-bar-icon icon-action-theme"></span>
				</div>
			</div>
		</div>
	</div>
	<!--//Bar-->

	<div class="wk-grid-md" id="wk_single_post">

		<article>

			<div class="wk-editor">
			<?php

			setPostViews( get_the_ID() );   /* Mark view count for this post */
			?>
			<div class="wkp-post-version">

			<?php
			if ( isset( $_GET['version'] ) && $_GET['version'] ) {

				$version = strip_tags( trim( $_GET['version'] ) );

				if ( '/' === substr( $version, -1 ) ) {
					$version = substr( $version, 0, -1 );
				}
				$data = wp_get_post_revisions( get_the_ID() );
				foreach ( $data as $revision => $value ) {
					if ( $revision === (int) $version ) {
						$content = $value->post_content;
					}
				}
				echo apply_filters( 'the_content', $content );
			} else {
				the_content();
			}
			?>

			</div>

			<div class="version-info">
			<?php
			do_action( 'wkp_post_framework_detail' );
			?>
			</div>
			<?php
			/* Display Tags */
			$tags = get_the_tags( $post_id );

			if ( ! empty( $tags ) ) {
			?>
			<div class="wk-tags">
				<span>Tag(s)</span>
				<?php
				foreach ( $tags as $tag ) {
					?>
					<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>"><?php echo esc_html( $tag->name ); ?></a>
					<?php
				}
				?>
			</div>
			<?php
			}
			/* //Display Tags*/

			/* Display Category */
			$category = get_the_category( $post_id );

			if ( ! empty( $category ) ) {
			?>
			<div class="wk-tags">
				<span>Category(s)</span>
				<?php
				foreach ( $category as $category ) {
					?>
					<a href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>"><?php echo esc_html( $category->name ); ?></a>
					<?php
				}
				?>
			</div>
			<?php
			}
			/* //Display Category*/
			?>

			</div>
		</article>
				<!--//Article-->

		<!-- Seperator-->
		<div class="wk-sep">.&nbsp;.&nbsp;.</div>
		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
		?>
	</div>
</div>

<script>
var element;
var copy;
document.addEventListener("click", function(e){
	var element = document.querySelectorAll('#wk_single_post .wk-in-link');
	for(i=0;i<element.length;i++) {
		if( e.target == element[i] ) {
			copy = element[i].getAttribute('data-link');
			copyLink(copy);
			removeClass();
			element[i].firstChild.classList.add("wk-copied");
		}
	}
});
function removeClass() {
	var tooltip = document.getElementsByClassName('wk-tooltip');
	for (var i = 0; i < tooltip.length; i++) {
		tooltip[i].classList.remove('wk-copied');
	}
}
function timeout(){
	var ele = document.getElementsByClassName('wk-tooltip');
	for (var i = 0; i < ele.length; i++) {
		ele[i].setAttribute('data-tooltip','click to copy');
		ele[i].classList.remove('wk-copied');
	}
}
function copyLink(copy) {
	var temp = document.createElement("input");
	temp.setAttribute("value",copy)
	document.body.appendChild(temp);
	temp.select();
	document.execCommand("copy");
	temp.remove();
}

</script>

<?php
} /* End of post */


get_footer();
?>

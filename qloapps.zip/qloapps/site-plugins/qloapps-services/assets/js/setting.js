
jQuery(document).ready(function(){

   var value = jQuery("#type").attr('value');

   if(value == 'url'){
     jQuery(".url").css("display","table-row");
   }

  jQuery("#type").on("change", function(){
    var selectedtype = jQuery("#type option:selected").val();
      // console.log(selectedtype.tolowercase());
      if(selectedtype.toLowerCase() == 'url')
      {
      jQuery(".url").css("display","table-row");
    }
    else{
      jQuery(".url").css("display","none");
    }
  })
  jQuery(".img-wrap").on("click", function(){
    var imgPrev = jQuery('#image-preview');
    var url = jQuery('#image-path');

    open_media_uploader_gallary();

    function open_media_uploader_gallary()
    {
        var media_uploader;
        media_uploader = wp.media({
         title: 'Select or Upload Media Of Your Chosen Persuasion',
         button: {
            text: 'Use this media'
         },
         multiple: false  // Set to true to allow multiple files to be selected
       });

        media_uploader.on("select", function(){

          // Get media attachment details from the frame state
           var attachment = media_uploader.state().get('selection').first().toJSON();

           // Send the attachment URL to our custom image input field.
           imgPrev.attr('src', attachment.url );

           url.attr('value', attachment.url );
           // url.val( attachment.url );

        });
            media_uploader.open();

    }
      });
});

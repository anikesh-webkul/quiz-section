<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

if ( ! class_exists( 'WK_Tab_Meta_Box' ) ) {
	/**
	 * Main class
	 *
	 * @class WK_Tab_Meta_Box
	 */
	class WK_Tab_Meta_Box {

		/**
		 * Single instance of WK_Tab_Meta_Box in memory
		 *
		 * @var $instance
		 */
		private static $instance = null;


		/**
		 * Current post.
		 * @var $post
		 */
		public static $post = null;


		/**
		 * Constructor forbidden
		 */
		private function __construct() {
			if ( null !== self::$instance ) {
				_doing_it_wrong( __FUNCTION__, 'This is not allowed', '5.0' );
			}
		}


		/**
		 * Creates a single instance for WK_Tab_Meta_Box and makes sure only one instance is present in memory.
		 *
		 * @return WK_Tab_Meta_Box
		 */
		public static function instance() {

			if ( null === self::$instance ) {
				self::$instance = new self();
				self::$instance->init();
			}

			return self::$instance;
		}


		/**
		 * The Initiator, which is only be called once at the time of class creation
		 */
		private function init() {

			add_action( 'admin_enqueue_scripts', array( $this, 'print_styles' ) );
		}


		/**
		 * This will print required style and script in the body
		 * Content in this method gets print with an automated tool,
		 * Do not touch remove anything from here.
		 */
		public function print_styles() {
			?>
			<style>
			/* inject:css */
			.wktmb-container{display:grid;background:#fff;margin-top:-6px;margin-left:-12px}.wktmb-container .wktmb-sidebar{grid-area:sidebar;margin:0}.wktmb-container .wktmb-sidebar .wktmb-tab{display:block;position:relative;margin-bottom:0;padding:12px 10px;cursor:pointer;background:#d6d6d6;color:#444;font-weight:700;font-size:14px;border-bottom:2px solid #c5c5c5;text-transform:capitalize;transition:box-shadow .2s}.wktmb-container .wktmb-sidebar .wktmb-tab.wktmb-tab-on{background-color:#fff;box-shadow:inset 0 0 30px 0 rgba(0,0,0,.15);border-bottom:2px solid #0085ba}.wktmb-container .wktmb-sidebar .wktmb-tab:hover{box-shadow:inset 0 0 30px 0 rgba(0,0,0,.15)}.wktmb-container .wktmb-content-wrapper{grid-area:bodyContent;padding:20px 15px;min-height:200px;border-left:1px solid #ddd;max-height: 400px;overflow-y:auto;}.wktmb-container .wktmb-content-wrapper .wktmb-content{display:none}.wktmb-container .wktmb-content-wrapper .wktmb-content.wktmb-content-on{display:block}.wktmb-container[_layout="_as_sidebar"],.wktmb-container[_layout]{grid-template-areas:'sidebar bodyContent bodyContent bodyContent bodyContent bodyContent bodyContent bodyContent'}.wktmb-container[_layout="_as_topbar"]{grid-template-areas:'sidebar' 'bodyContent'}.wktmb-container[_layout="_as_topbar"] .wktmb-sidebar{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));border-bottom:2px solid #c5c5c5}.wktmb-container[_layout="_as_topbar"] .wktmb-sidebar .wktmb-tab{border:1px solid #c5c5c5;text-align:center}.wktmb-container[_layout="_as_topbar"] .wktmb-sidebar .wktmb-tab.wktmb-tab-on{border-bottom:2px solid #0085ba}
			/* endinject */
			</style>
			<script>
			/* inject:js */
			document.addEventListener("DOMContentLoaded",(function(){var t=document.querySelectorAll(".wktmb-container");if(null!=t&&null!=t){const e=".wktmb-tab",a="wktmb-tab-on",n="wktmb-content-on";t.forEach(t=>{t.activeTab=t.querySelector("."+a),t.activeContent=t.querySelector("."+n),t.addEventListener("click",(function(c){var o=c.target;o.matches(e)&&(t.activeTab.classList.remove(a),t.activeTab=o,t.activeTab.classList.add(a),t.activeContent.classList.remove(n),t.activeContent=t.querySelector("[wktmb_hook='"+o.id+"']"),t.activeContent.classList.add(n))}))})}}));
			/* endinject */
			</script>
			<?php
		}


		/**
		 * Add Metabox with tab system
		 *
		 * @param string                 $id            Meta box ID (used in the 'id' attribute for the meta box).
		 * @param string                 $title         Title of the meta box.
		 * @param callable               $callback      Function that returns an array of tab_ids and tab_content.
		 *                                              The function can echo its output or simply return html string.
		 * @param string|array|WP_Screen $screen        Optional. The screen or screens on which to show the box
		 *                                              (such as a post type, 'link', or 'comment').
		 * @param string                 $layout        '_as_sidebar' - for horizonal layout and '_as_topbar' for vertical
		 * @param string                 $context       Optional. The context within the screen where the boxes
		 *                                              should display. Default 'advance'
		 * @param string                 $priority      Optional. The priority within the context where the boxes
		 *                                              should show ('high', 'low'). Default 'default'.
		 * @param array                  $callback_args Optional.
		 *                                               layout. Default '_as_sidebar'
		 * @return hookId
		 */
		public static function add( $id, $title, $callback, $screen = null, $layout = '_as_sidebar', $context = 'advance', $priority = 'default', $callback_args = null ) {

			if ( ! is_callable( $callback ) ) {
				return null;
			}

			$_args = array(
				'id'            => sanitize_title( $id ),
				'callback'      => $callback,
				'title'         => $title,
				'screen'        => $screen,
				'context'       => $context,
				'priority'      => $priority,
				'callback_args' => $callback_args,
				'layout'        => $layout,
			);

			add_action( 'add_meta_boxes', function() use ( $_args ) {

				$metabox_html = '';
				$after_html   = '';
				$before_html  = '';

				$before_html = apply_filters( 'meta_tab_html_before', apply_filters( "meta_tab_html_before_{$_args['id']}", $before_html ) );
				$after_html  = apply_filters( 'meta_tab_html_after', apply_filters( "meta_tab_html_after_{$_args['id']}", $after_html ) );

				self::$post   = get_post();

				$tabs         = call_user_func( $_args['callback'], self::$post );

				$tabs         = apply_filters( "meta_tab_args_{$_args['id']}", $tabs, self::$post );

				$metabox_html = self::create_html( $tabs, $_args );

				$metabox_html = $before_html . $metabox_html . $after_html;

				add_meta_box( $_args['id'], $_args['title'], function() use ( $metabox_html, $_args ) {

					echo $metabox_html; // wpcs: xss ok.

				}, $_args['screen'], $_args['context'], $_args['priority'], $_args['callback_args'] );

			} );

			return $id;  //return hook name/id
		}


		/**
		 * Final content creator which will be used by 'add_meta_box'
		 *
		 * @param array $tabs              Array for tab data ( KV pairs of tabName accociated with tabContent )
		 * @param array $_args             Set of options for the current metabox
		 * @return      $final_html_output Final content of the metabox used by 'add_meta_box'
		 */
		public static function create_html( $tabs, $args ) {

			if ( ! is_array( $tabs ) ) {
				return '';
			}

			ob_start();

			$final_html_output  = '';
			$__tab_template     = '';
			$__content_template = '';
			$__count            = 0;
			?>

			<div class="wktmb-container wktmb-container--<?php echo esc_attr( $args['id'] ); ?>" _layout="<?php echo esc_attr( $args['layout'] ); ?>">
				<?php

				foreach ( $tabs as $tab_name => $tab_content ) {

					$if_active = ( ! $__count ) ? 'on' : 'off';
					$__count ++;

					$tab_id = 'wktmb-' . sanitize_title( $tab_name );

					$__tab_template     .= '<li class="wktmb-tab wktmb-tab-' . $if_active . '" id="' . esc_attr( $tab_id ) . '">' . esc_html( $tab_name ) . '</li>';

					$__content_template .= '<div class="wktmb-content wktmb-content-' . $if_active . '" wktmb_hook="' . esc_attr( $tab_id ) . '">';

					if ( is_callable( $tab_content ) ) {

						$final_html_output .= ob_get_contents();
						ob_clean();

						$return_string = call_user_func( $tab_content );

						if ( is_null( $return_string ) ) {

							$__content_template .= ob_get_contents();
							ob_clean();

						} else {

							$__content_template .= $return_string;
						}
					} else {
						$__content_template .= $tab_content;
					}

					$__content_template .= '</div>';
				}

				?>
				<ul class="wktmb-sidebar">
					<?php echo $__tab_template; // WPCS: XSS ok. ?>
				</ul>
				<div class="wktmb-content-wrapper">
					<?php echo $__content_template; // WPCS: XSS ok. ?>
				</div>
			</div>

			<?php
			$final_html_output .= ob_get_contents();
			ob_end_clean();

			return $final_html_output;
		}

	}       // END OF CLASS WK_Tab_Meta_Box.


	/*Initiate the class in admin area only*/
	add_action( 'admin_init', function () {
		WK_Tab_Meta_Box::instance();
	} );
}




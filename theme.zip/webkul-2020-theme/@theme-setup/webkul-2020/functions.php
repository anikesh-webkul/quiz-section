<?php
/**
 * The functions template for webkul theme 2k18
 * @package webkul
 * @subpackage webkul
 * @since webkul 1.0
 **/
! defined( 'WKTHEME_ROOT' ) && define( 'WKTHEME_ROOT', dirname( __FILE__ ) );

! defined( 'WKTHEME_CORE' ) && define( 'WKTHEME_CORE', WKTHEME_ROOT . '/core/' );

/*ADD a GLOBAL to store required options like, used in job-details template to hoist variable to header.php*/
$GLOBALS['WEBKUL_THEME_OPTIONS'] = array();
/*/ADD a GLOBAL to store required options like, used in job-details template to hoist variable to header.php*/

/*--New theme Funcitonalities--*/
require_once WKTHEME_CORE . 'core-functions.php';
/*--//New theme Funcitonalities--*/


add_action( 'template_redirect', function(){

	$post_mtime = false;

	if ( is_singular() ) {
		$post_id = get_queried_object_id();
		if ( $post_id ) {
			$post_mtime = strtotime( get_the_modified_time("D, d M Y H:i:s", $post_id ) );
		}
	} else if( is_home() ) {
		$post_mtime = filemtime( WKTHEME_ROOT . '/index.php' );
	}
	if ( $post_mtime ) {
		$header_last_modified_value = str_replace( '+0000', 'GMT', gmdate( 'r', $post_mtime ) );
		header( "Last-Modified: " . $header_last_modified_value );
	}
} );

/* OG & TwitterCard images Override */
add_filter('wpseo_opengraph_image', function ( $url ) {
	if (is_page('marketplace-guide')) {
		return esc_url(get_template_directory_uri() . '/images/mp-guide-og-image.png');
	} elseif (is_page('akeneo-pim-integration')) {
		return esc_url(get_template_directory_uri() . '/images/akeneo/akeneo-pim-og-image.png');
	} elseif (is_page('marketplace-mobile-app-guide')) {
		return esc_url(get_template_directory_uri() . '/images/mp-mobile-app-og.png');
	} else {
		return $url;
	}
});

add_filter('wpseo_twitter_image', function ($url) {
	if (is_page('marketplace-guide')) {
		return esc_url(get_template_directory_uri() . '/images/mp-guide-og-image.png');
	} elseif (is_page('akeneo-pim-integration')) {
		return esc_url(get_template_directory_uri() . '/images/akeneo/akeneo-pim-og-image.png');
	} elseif (is_page('marketplace-mobile-app-guide')) {
		return esc_url(get_template_directory_uri() . '/images/mp-mobile-app-og.png');
	} else {
		return $url;
	}
});
/* //OG & TwitterCard images Override */


global $script_suffix;
// $script_suffix = '.min';
$script_suffix = '.min';

/*-------Enqueue Asests---------*/
add_action('wp_enqueue_scripts', function () {

	global $script_suffix;

	/*
	Deregister wp jquery as it is outdated and vulnerable to prototype pollution.
	And register the updated jquery 3.4.0
	*/
	wp_deregister_script( 'jquery' );
	wp_register_script( 'jquery', 'https://code.jquery.com/jquery-3.5.1.min.js', array(), '', false );

	$styles = array(
		'global'               => get_stylesheet_uri(),
		'job_page'             => get_template_directory_uri() . "/assets/dist/css/wk-job$script_suffix.css",
		'job_single_page'      => get_template_directory_uri() . "/assets/dist/css/wk-jobsinglepage$script_suffix.css",
		'career_page'          => get_template_directory_uri() . "/assets/dist/css/wk-career$script_suffix.css",
		'magento_imagine_2019' => get_template_directory_uri() . "/assets/dist/css/wk-magentoaward2019$script_suffix.css",
		'technology_page'      => get_template_directory_uri() . "/assets/dist/css/wk-technologies$script_suffix.css",
		'countryflag_style'      => get_template_directory_uri() . "/assets/dist/css/wk-countryflags$script_suffix.css",
	);

	$scripts = array(
		'global'          => get_template_directory_uri() . "/assets/dist/js/wk-script$script_suffix.js",
		'job_page'        => get_template_directory_uri() . "/assets/dist/js/_modules/wk-jobs$script_suffix.js",
		'job_single_page' => get_template_directory_uri() . "/assets/dist/js/_modules/wk-job-details$script_suffix.js",
		'technology_page' => get_template_directory_uri() . "/assets/dist/js/_modules/wk-technologies$script_suffix.js",
		'location_page' => get_template_directory_uri() . "/assets/dist/js/_modules/wk-top-locations$script_suffix.js",
	);

	wp_enqueue_style( 'wk-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap', array(), 'v2.0.0' );

	wp_enqueue_style( 'wk-style', get_stylesheet_uri(), array(), 'v2.5.31' );

	wp_register_script( 'wk-script', $scripts['global'], array(), 'v2.1.05', true );
	wp_enqueue_script( 'wk-script' );

	if ( is_page( 'meetups' ) || is_page( 'awards' ) || is_page( 'careers' ) || is_page( 'jobs' ) ) {
		wp_enqueue_style( 'wk-carousel-css', get_template_directory_uri() . '/assets/plugins/meetup/owl.carousel.min.css' );
		wp_enqueue_script( 'wk-carousel-js', get_template_directory_uri() . '/assets/plugins/meetup/owl.carousel.min.js', array( 'jquery' ), '1.0.0', true );
	}

	if ( is_page( 'top-locations' ) ) {
		wp_enqueue_style( 'wk-country-flag', $styles['countryflag_style'], array(), '1.0.4' );
		wp_enqueue_script( 'wk-location-js', $scripts['location_page'], array( 'wk-script' ), '1.0.7', true );
	}

	if ( is_page( 'jobs' ) && ! empty( get_query_var( 'job' ) ) ) {
		wp_enqueue_style( 'wk-jobs-single-page', $styles['job_single_page'], array(), 'v2.0.2' );
		wp_enqueue_script( 'wk-jobs-single-page-js', $scripts['job_single_page'], array( 'wk-script' ), '2.0.2', true );
	}

	if ( is_page( 'magento-imagine-2019' ) ) {
		wp_enqueue_style( 'magento_imagine_2019', $styles['magento_imagine_2019'], array(), '1.0.0' );
	}

	if ( is_post_type_archive( 'technologies' ) || 'technologies' === get_post_type() ) {
		wp_enqueue_style( 'technology_page-css', $styles['technology_page'], array(), '1.0.0' );
		wp_enqueue_script( 'technology_page-js', $scripts['technology_page'], array( 'wk-script' ), '1.0.0', true );

		if ( is_archive() ) {
			$localized_obj    = array(
				'title'        => ucfirst( get_post_type() ),
				'slug'         => get_post_type(),
				'permalink'    => get_post_type_archive_link( get_post_type() ),
				'archiveTitle' => ucfirst( get_post_type() ),
				'archiveLink'  => get_post_type_archive_link( get_post_type() ),
				'archiveSlug'  => get_post_type(),
			);
		} else {
			$tech_queried_obj = get_post_type_object( get_post_type( get_queried_object() ) );
			$localized_obj    = array(
				'title'        => get_the_title(),
				'slug'         => get_queried_object()->post_name,
				'permalink'    => get_the_permalink(),
				'archiveTitle' => ucfirst( $tech_queried_obj->rewrite['slug'] ),
				'archiveSlug'  => $tech_queried_obj->rewrite['slug'],
				'archiveLink'  => get_post_type_archive_link( get_post_type() ),
			);
		}
		wp_localize_script( 'technology_page-js', 'wkTechLocalizedObj', $localized_obj );
	}

	wp_localize_script( 'wk-script', 'wkXhrObj', array(
		'url'        => admin_url( 'admin-ajax.php' ),
		'security'   => wp_create_nonce( 'wkXhr_handler_nonce' ),
		'assets_uri' => get_template_directory_uri() . '/assets/',
	) );

	if ( ! is_admin() ) {
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		// wp_dequeue_script( 'jquery' );

		if ( ! is_page( 'contacts' ) && ! is_page( 'gdpr' ) ) {
			wp_dequeue_script( 'google-recaptcha' );
		}
		if ( is_home() ) {

			wp_deregister_style( 'wp-block-library' );
		}
	}
});

add_action( 'wp', function () {
	if ( ! is_admin() && ! is_page( 'contacts' ) && ! is_page( 'gdpr' ) && ! is_page( 'jobs' ) && empty( get_query_var( 'job' ) ) ) {
		// add_filter( 'wpcf7_load_js', '__return_false' );
		add_filter( 'wpcf7_load_css', '__return_false' );
	}
});

add_action( 'admin_enqueue_scripts', function() {

	global $script_suffix;
	if ( 'page' === get_current_screen()->post_type && isset( $_GET['page'] ) && 'wk-theme-page-setting' === $_GET['page'] ) {
		wp_enqueue_script( 'jquery-ui-sortable' );
	}

	if ( isset( $_GET['page'] ) && ( 'wk-theme-shortcodes-config' === $_GET['page'] || 'wkjob_post_new' === $_GET['page'] ) ) {
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_script( 'tinymce_js', includes_url( 'js/tinymce/' ) . 'wp-tinymce.php', array( 'jquery' ), false, true );
	}

	wp_enqueue_script( 'wk-backend-js', get_template_directory_uri() . "/assets/dist/js/wk-backend$script_suffix.js", array( 'jquery', 'jquery-ui-sortable' ), filemtime( get_template_directory() . "/assets/dist/js/wk-backend$script_suffix.js" ) );
	wp_enqueue_style( 'wk-backend-css', get_template_directory_uri() . "/assets/dist/css/wk-backend$script_suffix.css", array(), 'v1.0.5' );

	// enqueue Select2.
	if ( isset( $_GET['page'] ) && 'wkjob_post_new' === $_GET['page'] ) {

		wp_enqueue_style( 'wk_feature', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css' );
		wp_enqueue_script( 'wk_feature_js', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js' );

		// jQuery UI date picker file.
		wp_enqueue_script( 'jquery-ui-datepicker' );
		// jQuery UI theme css file.
		wp_enqueue_style( 'e2b-admin-ui-css', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.0/themes/base/jquery-ui.css', false, '1.9.0', false );
	}

	wp_localize_script('wk-backend-js', 'wkthemeAjaxObj', array(
		'url'           => admin_url( 'admin-ajax.php' ),
		'nonce'         => wp_create_nonce( 'wktheme-admin-js-nonce' ),
		'wp_upload_dir' => wp_upload_dir()['baseurl'],
	));

	if ( isset( $_GET['page'] ) && 'wk-theme-pages-config' === $_GET['page'] ) {
		wp_register_style( 'jquery-ui', 'https://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css' );
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_style( 'jquery-ui' );
	}

}, 10 );
/*-------//Enqueue Assets---------*/

/* Add page editor style */
add_action( 'admin_init', function() {

	global $script_suffix;
	add_editor_style( "/assets/dist/css/wk-editor$script_suffix.css" );
} );
/* //Add page editor style */

/*-------Register Menus---------*/
add_action( 'init', function() {
	register_nav_menu( 'webkul_mega_menu', __( 'Webkul Megu Menu' ) );
	register_nav_menu( 'wk_our_expertise', __( 'Footer - Our Expertise' ) );
	register_nav_menu( 'wk_industries', __( 'Footer - Industies' ) );
	register_nav_menu( 'wk_explore', __( 'Footer - Explore' ) );
	register_nav_menu( 'wk_quick_link', __( 'Footer - Quick Links' ) );
} );
/*-------//Register Menus---------*/

/*technology post typ handlers*/
/*Register post types*/
add_action( 'init', function() {

	register_post_type( 'technologies',
		array(
			'labels' => array(
				'name'               => __( 'Technologies' ),
				'singular_name'      => __( 'Technology' ),
				'all_items'          => __( 'Technology' ),
				'add_new'            => __( 'New Technology' ),
				'add_new_item'       => __( 'Add New Technology' ),
				'edit_item'          => __( 'Edit Technology' ),
				'new_item'           => __( 'New Technology' ),
				'view_item'          => __( 'View Technology' ),
				'search_items'       => __( 'Search Technology' ),
				'not_found'          => __( 'Nothnig found' ),
				'not_found_in_trash' => __( 'Nothing found in Trash' ),
			),
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'exerpt'              => true,
			'menu_icon'           => 'dashicons-edit',
			'hierarchical'        => false,
			'supports'            => array( 'title', 'editor', 'thumbnail', 'tags', 'excerpt' ),
			'capability_type'     => 'post',
			'rewrite'             => array( 'slug' => 'archive-technologies' ),
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => true,
		)
	);
	register_taxonomy( 'technology-category', array( 'technologies' ),
		array(
			'labels' => array(
				'name'              => __( 'Technology Categories' ),
				'singular_name'     => __( 'Category' ),
				'search_items'      => __( 'Search Category' ),
				'all_items'         => __( 'All Category' ),
				'parent_item'       => __( 'Parent Category' ),
				'parent_item_colon' => __( 'Parent Category:' ),
				'edit_item'         => __( 'Edit Category' ),
				'update_item'       => __( 'Update Category' ),
				'add_new_item'      => __( 'Add New Category' ),
				'new_item_name'     => __( 'New Category Name' ),
				'menu_name'         => __( 'Category' ),
			),
			'hierarchical'      => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'public'            => false,
			'rewrite'           => array( 'slug' => 'technology-category' ),
		)
	);
} );
/*//Register post types*/

/* ----------Add Meta Boxes---------- */
add_action( 'add_meta_boxes', function() {

	add_meta_box( 'wk-technology-post-stats', 'Related Stats', function() {

		wp_nonce_field( 'wktech_nonce_value', 'wktech_nonce_fieldname' );

		$post_id   = get_the_ID();
		$stats     = maybe_unserialize( get_post_meta( $post_id, 'technology_data', true ) );
		$team_size = isset( $stats['teamsize'] ) ? $stats['teamsize'] : '';
		$projects  = isset( $stats['projects'] ) ? $stats['projects'] : '';
		$exp       = isset( $stats['exp'] ) ? $stats['exp'] : '';
		?>
		<label><p class="description">Team Size</p><input type="number" name="tech_data[teamsize]" value="<?php echo $team_size; ?>"/></label><br><br>
		<label><p class="description">Total Live Projects</p><input type="number" name="tech_data[projects]" value="<?php echo $projects; ?>"/></label><br><br>
		<label><p class="description">Years of Experience</p><input type="number" name="tech_data[exp]" value="<?php echo $exp; ?>"/></label><br><br>
		<?php
	}, 'technologies', 'side', 'high' );
} );
/* ----------//Add Meta Boxes---------- */

/*The save post action hook*/
add_action( 'save_post', function( $post_id ) {
	// POST - Technologies
	if ( 'technologies' === get_post_type( $post_id ) ) {

		wp_verify_nonce( 'wktech_nonce_fieldname', 'wktech_nonce_value' );

		$tech_data = isset( $_POST['tech_data'] ) ? wp_unslash( $_POST['tech_data'] ) : '';
		$tech_data = maybe_serialize( $tech_data );

		update_post_meta( $post_id, 'technology_data', $tech_data );
	}
} );
/*//technology post typ handlers*/


// Add Tinymce plugin.
add_action( 'admin_head', function() {
	global $post;
	if ( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	// check if WYSIWYG is enabled.
	if ( 'true' === get_user_option( 'rich_editing' ) ) {
		if ( isset( $post->post_type ) ) {
			if ( ! is_null( $post ) && 'page' === $post->post_type ) {
				add_filter( 'mce_external_plugins', 'add_wk_plugin_script' );
				add_filter( 'mce_buttons_3', 'register_wk_button' );
			}
		}
	}
});

// Register TMce buttons.
function register_wk_button( $buttons ) {

	array_push( $buttons, 'wk_highlight_col_prime', 'wk_highlight_col_alter' );
	return $buttons;
}

// Declare script for TMce Buttons.
function add_wk_plugin_script( $plugin_array ) {

	global $script_suffix;
	$plugin_array['wk_mce_button'] = get_template_directory_uri() . "/assets/dist/js/wk-tinymce-plugin$script_suffix.js";
	return $plugin_array;
}
//  /Add Tinymce plugin.


// Add title for each page
add_filter('wp_title', function( $title, $sep ) {

	global $paged, $page;
	if ( is_feed() ) {
		return $title;
	}
	$title .= get_bloginfo( 'name', 'display' );

	$site_description = get_bloginfo( 'description', 'display' );

	if ( $site_description && ( is_home() || is_front_page() ) ) {
		$title = "$title $sep $site_description";
	}

	if ( ( $paged >= 2 || $page >= 2) && ! is_404() ) {
		$title = "$title $sep " . sprintf( __( 'Page %s', 'webkul' ), max( $paged, $page ) );
	}
	return $title;

}, 10, 2 );


add_action('after_setup_theme', function() {

	add_theme_support( 'automatic-feed-links' );
	add_editor_style();

	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

	add_theme_support( 'post-formats', array( 'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video' ) );

	add_theme_support( 'post-thumbnails' );

	add_filter( 'use_default_gallery_style', '__return_false' );
});


add_action( 'admin_head', function() {
	wp_enqueue_media();
} );

// Custom admin Menu pages for Webkul theme
add_action( 'admin_menu', 'register_wk_backend_menu_pages' );
function register_wk_backend_menu_pages() {

	global $new_menu_page;

	// add_menu_page( 'Client Reviews', 'Client Reviews', 'edit_posts', 'client_review', 'client_add_review_menu_page', get_template_directory_uri() . '/images/backend-client.png', 10 );

	/* Job post menus*/
	add_menu_page( 'Job Postings', 'Job Postings', 'edit_posts', 'wkjob_post', 'wkjob_posts_listing', get_template_directory_uri() . '/images/backend-career.png', 8 );

	$jobpost_list_hook = add_submenu_page( 'wkjob_post', 'Job Postings', 'Job Postings', 'edit_posts', 'wkjob_post', 'wkjob_posts_listing' );

	add_submenu_page( 'wkjob_post', 'Add New', 'Add New', 'edit_posts', 'wkjob_post_new', 'wkjob_post_detail' );

	add_action( 'load-' . $jobpost_list_hook, 'wk_add_options' );
	/*//Job post menus*/

	add_menu_page( 'Team', 'Team', 'edit_posts', 'team', 'team_list_page', get_template_directory_uri() . '/images/backend-group.png', 6 );

	$team_list_hook = add_submenu_page('team', 'Team List', 'Team List', 'edit_posts', 'team', 'team_list_page' );

	add_submenu_page( 'team', 'Add New', 'Add New', 'edit_posts', 'team_add_new', 'team_add_new' );

	add_action( 'load-' . $team_list_hook, 'wk_add_options' );

	/*Technology Menu*/
	$tech_list_hook = add_menu_page( 'Technology', 'Technology', 'edit_posts', 'wk-tech', 'tech_list_page', 'dashicons-laptop' );

	add_submenu_page( 'wk-tech', 'Add New Technology', 'Add New Technology', 'edit_posts', 'tech-add-new', 'tech_add_new' );

	add_action( 'load-' . $tech_list_hook, 'add_technology_options' );
}


function wk_add_options() {
	$option = 'per_page';
	$args   = array(
		'label' => 'Results',
		'default' => 10,
		'option' => 'reviews_per_page'
	);
	add_screen_option($option, $args);
}


function new_menu_page_screen_options() {

	$screen = get_current_screen();
	// get out of here if we are not on our settings page.
	if ( ! is_object( $screen ) || $screen->idate( format ) !== 'toplevel_page_mp_addons' ) {
		return;
	}

	add_screen_option( 'per_page', array(
		'label'   => __( 'Members per page', $new_menu_page ),
		'default' => 10,
		'option'  => 'result_per_page',
	) );
}

//--------Team list --------//
function team_list_page() {

	if ( ! class_exists( 'Team_List_Table' ) ) {
		require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	}

	class Team_List_Table extends WP_List_Table {

		function __construct() {
			parent::__construct( array(

				'singular' => 'team_list',     //singular name of the listed records.
				'plural'   => 'all_team_list',    //plural name of the listed records.
				'ajax'     => false,
			));
		}

		public function prepare_items()	{

			global $wpdb;
			$columns  = $this->get_columns();
			$sortable = $this->get_sortable_columns();
			$hidden   = $this->get_hidden_columns();

			$this->process_bulk_action();
			$data       = $this->fetch_team_data();
			$totalitems = count( $data );
			$user       = get_current_user_id();
			$screen     = get_current_screen();
			$option     = $screen->get_option( 'per_page', 'option' );
			$per_page   = get_user_meta( $user, $option, true );

			$this->_column_headers = array( $columns, $hidden, $sortable );

			if ( empty( $per_page ) || $per_page < 1 ) {
				$per_page = $screen->get_option( 'per_page', 'default' );
			}

			function usort_reorder( $a, $b ) {

				$orderby = ( ! empty( $_REQUEST['orderby'] ) ) ? $_REQUEST['orderby'] : 'emp_name';
				$order   = ( ! empty( $_REQUEST['order'] ) ) ? $_REQUEST['order'] : 'asc';
				$result  = strcmp( $a[ $orderby ], $b[ $orderby ] );
				return ('asc' === $order) ? $result : -$result;
			}

			usort( $data, 'usort_reorder' );

			$totalpages   = ceil( $totalitems / $per_page );
			$current_page = $this->get_pagenum();
			$data         = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );

			$this->set_pagination_args( array(
				'total_items' => $totalitems,
				'total_pages' => $totalpages,
				'per_page'    => $per_page,
			) );

			$this->items = $data;
		}

		public function get_hidden_columns()
		{
			return array();
		}

		function column_cb($item)
		{

			return sprintf('<input type="checkbox" id="user_%s"name="user[]" value="%s" />', $item['id'], $item['id']);
		}

		function get_columns()
		{

			$columns = array(
				'cb'              => '<input type="checkbox" />',
				'emp_name'        => __('Employee Name'),
				'emp_team'        => __('Employee Group'),
				'emp_designation' => __('Employee Designation'),
				'emp_image'       => __('Employee Image'),
			);
			return $columns;
		}

		public function get_sortable_columns()
		{

			$sortable_columns = array(
				'emp_name' => array('emp_name', true),
			);

			return $sortable_columns;
		}

		private function fetch_team_data()
		{

			global $wpdb;
			$table_name = $wpdb->prefix . 'team';
			$data = array();

			if (isset($_GET['s'])) {

				$search    = $_GET['s'];
				$search    = trim($search);
				$team_data = $wpdb->get_results("SELECT * FROM $table_name WHERE emp_name LIKE '%$search%' and post_status='publish'", ARRAY_A);
			} else {
				$team_data = $wpdb->get_results("SELECT * FROM $table_name WHERE post_status='publish'", ARRAY_A);
			}

			return $team_data;
		}

		function get_bulk_actions()
		{

			$actions = array(
				'trash'    => 'Move To Trash',
			);
			return $actions;
		}

		public function process_bulk_action()
		{

			global $wpdb;
			$table_name = $wpdb->prefix . 'team';

			if ('trash' === $this->current_action()) {
				if (isset($_GET['user'])) {
					if (is_array($_GET['user'])) {
						foreach ($_GET['user'] as $id) {

							if (!empty($id)) {
								$wpdb->query("DELETE FROM $table_name WHERE id IN ($id)");
							}
						}
					} else {
						if (!empty($_GET['user'])) {
							$id = $_GET['user'];
							$wpdb->query("DELETE FROM $table_name WHERE id = $id");
						}
					}
				}
			}
		}

		public function column_default($item, $column_name)
		{

			switch ($column_name) {

				case 'emp_name':
				case 'emp_designation':
				case 'emp_team':
				case 'emp_image':
					// case 'emp_words':
					return $item[$column_name];
				default:
					return print_r($item, true);
			}
		}

		function column_emp_name($item)
		{

			$actions = array(
				'edit'  => sprintf('<a href="?page=team_add_new&action=edit&user=%s">Edit</a>', $item['id']),
				'trash' => sprintf('<a href="?page=team&action=trash&user=%s">Delete</a>', $item['id']),
			);
			return sprintf('%1$s %2$s', $item['emp_name'], $this->row_actions($actions));
		}
		function column_emp_image($item)
		{

			$img_url = wp_upload_dir()['baseurl'] . '/' . $item['emp_image'];
			return '<a href="' . $img_url . '"><div class="list-emp-img" style="background-image: url(' . $img_url . ');"/></div></a>';
		}
	}

	$wp_list_table = new Team_List_Table();

	if (isset($_GET['s'])) {
		$wp_list_table->prepare_items($_GET['s']);
	} else {
		$wp_list_table->prepare_items();
	}
	?>
	<style>
		.list-emp-img {
			height: 142px;
			width: 210px;
			background-repeat: no-repeat;
		}

		.list-emp-img:hover {
			background-position: center bottom;
		}
	</style>
	<form method="GET">
		<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
		<?php
		$wp_list_table->search_box('Search Employee', 'search-id');
		$wp_list_table->display();
		?>
	</form>
<?php
}
//--------/Team list END --------//


function team_add_new()
{

	?>
	<h1>Employee Details</h1>
	<style>
		.emp_img_upload {
			border: 3px dotted #ddd;
			cursor: pointer;
		}

		.emp_img_upload:hover {
			border: 3px dotted #0085ba;
		}
	</style>
	<hr />
	<?php

	global $wpdb;
	$table_name = $wpdb->prefix . 'team';

	if (isset($_POST['wk_submit_employee'])) {
		$emp_name   = $_POST['emp-name'];
		$emp_desig  = $_POST['emp-desig'];
		$emp_words  = stripslashes($_POST['emp-words']);
		$emp_team   = $_POST['emp-team'];
		$emp_image  = $_POST['emp-image'];
		$emp_image  = explode(wp_upload_dir()['baseurl'], $emp_image)[1];

		if ($wpdb->get_var("show tables like '$table_name'") != $table_name) {
			$sql = "CREATE TABLE $table_name (
				id int(11) NOT NULL auto_increment,
				emp_name varchar(255) NOT NULL,
				emp_designation varchar(255) NOT NULL,
				post_type varchar(255) NOT NULL,
				emp_words varchar(255) NOT NULL,
				emp_team varchar(255) NOT NULL,
				emp_image varchar(255) NOT NULL,
				post_status varchar(255) NOT NULL,
				PRIMARY KEY (`id`)
			);";

			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($sql);
		}
		if (isset($_GET['action']) && 'edit' === $_GET['action']) {

			$data = array(
				'emp_name'        => $emp_name,
				'emp_designation' => $emp_desig,
				'emp_words'       => $emp_words,
				'emp_team'        => $emp_team,
				'emp_image'       => $emp_image,
			);

			$cur_user     = $_GET['user'];
			$where        = array('id' => $cur_user);
			$format       = array('%s', '%s', '%s', '%s');
			$where_format = array('%d');
			$res = $wpdb->update($table_name, $data, $where, $format, $where_format);
			if ($res) {
				echo '<br /><br /><div class="notice notice-success is-dismissible">
				<p><strong>Employee Details Updated.</strong></p>
				</div>';
			} else {
				echo '<br /><br /><div class="notice notice-error is-dismissible">
				<p><strong>An error occurred! Please try again.</strong></p>
				</div>';
			}
		} else {

			$res = $wpdb->insert(
				$table_name,
				array(
					'emp_name'        => $emp_name,
					'emp_designation' => $emp_desig,
					'post_type'       => 'team',
					'emp_words'       => $emp_words,
					'emp_team'        => $emp_team,
					'emp_image'       => $emp_image,
					'post_status'     => 'publish',
				),
				array(
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
				)
			);
			if ($res) {
				echo '<br /><br /><div class="notice notice-success is-dismissible">
				<p><strong>New Employee Added.</strong></p>
				</div>';
			} else {
				echo '<br /><br /><div class="notice notice-error is-dismissible">
				<p><strong>An error occurred! Please try again.</strong></p>
				</div>';
			}
		}
	}

	if (!empty($_GET['user'])) {
		$button_text = 'Update Employee Profile';
		$cur_user  = $_GET['user'];
		$data      = $wpdb->get_results("SELECT * FROM $table_name WHERE id = '$cur_user'", ARRAY_A);
		$data      = $data[0];
		$emp_name  = $data['emp_name'];
		$emp_desig = $data['emp_designation'];
		$emp_team  = $data['emp_team'];
		$emp_words = $data['emp_words'];
		$emp_image = $data['emp_image'];
		$emp_image = wp_upload_dir()['baseurl'] . '/' . $emp_image;
	} else {
		$button_text = 'Create Employee Profile';
		$emp_name    = '';
		$emp_desig   = '';
		$emp_team    = '';
		$emp_words   = '';
		$emp_image   = '';
	}

	?>

	<form action="" method="post" id="wk_form_employee">
		<table class="form-table">
			<tbody>
				<tr>
					<th><label for="employee-name">Employee Name </label></th>
					<td><input type="text" id="employee-name" name="emp-name" placeholder="Employee Name" value="<?php echo $emp_name; ?>" required></td>
				</tr>
				<tr>
					<th>
						<label for="emp-desig">Employee Designation</label>
					</th>
					<td>
						<input type="text" id="emp-desig" name="emp-desig" placeholder="Employee Designation" value="<?php echo $emp_desig; ?>" required>
					</td>
				</tr>
				<tr>
					<th><label for="emp-team">Employee Group</label></th>
					<td>
						<input type="text" id="emp-team" name="emp-team" placeholder="Employee Team" value="<?php echo $emp_team; ?>">
						<p class="description">*Leave the field blank for Italy office employees</p>
					</td>
				</tr>
				<tr>
					<th>
						<label for="emp-image">Employee Profile Image</label>
					</th>
					<td>
						<img class="emp_img_upload" src="<?php echo $emp_image; ?>" alt="Please Update Your Profile" id='prof_img'>
						<input type="hidden" id="emp-image" name="emp-image" value="<?php echo $emp_image; ?>" class="profile_image_url" required>
					</td>
				</tr>
				<tr>
					<th><label for="emp-words">Employee Words</label></th>
					<td>
						<textarea id="emp-words" name="emp-words" maxlength="200" placeholder="Employee Words"><?php echo $emp_words; ?></textarea>
						<p class="description">*Optional</p>
					</td>
				</tr>
			</tbody>
		</table>

		<button type="submit" class="button button-primary" name="wk_submit_employee"><?php echo $button_text; ?></button>
	</form>
<?php
}
//-----/Team Section End-------//

//--- /Technology section ---/
function tech_list_page()
{
	include('core/wk-manage-technology.php');
	echo '<div class="wrap"><h1 class="wp-heading-inline">Technology List</h1>';
	wk_tech_list();

	$wp_list_table = new Technology_List_Table();

	if (isset($_GET['s'])) {
		$wp_list_table->prepare_items($_GET['s']);
	} else {
		$wp_list_table->prepare_items();
	}
	?>
	<a href="?page=tech-add-new" class="page-title-action">Add New</a>
	<form method="GET">
		<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
		<?php
		$wp_list_table->search_box('Technology', 'search-id');
		$wp_list_table->display();
		?>
	</form>
	</div>
<?php
}
function tech_add_new()
{
	include('core/wk-manage-technology.php');
	add_new_technology();
}

function add_technology_options()
{
	$option = 'per_page';
	$args = array(
		'label'   => 'Technology Per Page',
		'default' => 5,
		'options' => 'technology_per_page',
	);
	add_screen_option($option, $args);
}

/*To add Screen Options */
add_filter( 'set-screen-option', function( $status, $option, $value ) {
	if ( 'toplevel_page_wk_tech_per_page' == $option ) {
		return $value;
	}
	return $value;
}, 10, 3 );
//--- /Technology section End---/

/**
 * Check if a column exists in a table
 *
 * @param string $table_name
 * @param string $column_name
 * @return boolean
 */
function wk_table_column_exists( $table_name, $column_name ) {
	global $wpdb;

	$existing_columns = $wpdb->get_col( "DESC {$table_name}", 0 );
	if ( in_array( $column_name, $existing_columns ) ) {
		return true;
	} else {
		return false;
	}
}
// Open Position Page


/*Job post details- ADD/EDIT*/
function wkjob_post_detail( $current = 'position_details' ) {

	$upload = wp_upload_dir();

	if ( isset( $_POST['wk_submit_position'] ) ) {

		// Submision Start.
		global $wpdb;
		$table_name = $wpdb->prefix . 'open_positions';

		if ( $wpdb->get_var( "show tables like '$table_name'" ) != $table_name ) {
			$sql = "CREATE TABLE $table_name (
				id int(10) NOT NULL auto_increment,
				position_name varchar(255) NOT NULL,
				group_name varchar(255) NOT NULL,
				position_detail text NOT NULL,
				position_experience varchar(255) NOT NULL,
				openings int(255) NOT NULL,
				expected_salary varchar(50) NOT NULL,
				visibility varchar(255) NOT NULL,
				interview_process varchar(255) NOT NULL,
				extra_details Longtext NOT NULL,
				seo Longtext NOT NULL,
				status varchar(255) NOT NULL,
				PRIMARY KEY (`id`)
			);";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
		}

		//Set DEFAULT TAB
		$_GET['tab'] = ( ! isset( $_GET['tab'] ) ) ? 'position_details' : wp_unslash( $_GET['tab'] );

		if ( isset( $_GET['tab'] ) ) {

			$position_name        = $_POST['position-name'];
			$position_detail      = stripslashes($_POST['position-detail']);
			$position_experience  = $_POST['position-experience'];
			$openings             = $_POST['openings'];
			$expected_salary      = $_POST['expected-salary'];
			$interview_process    = $_POST['interview-process'];
			$group_name           = $_POST['group-name'];
			$visibility           = $_POST['visibility'];
			$open_date            = empty( $_POST['open_date'] ) ? date( 'd-m-Y' ) : $_POST['open_date'];
			$slug                 = $_POST['slug'];
			$new_group_names      = $_POST['new-groups-list'];

			if ( empty( $position_name ) 
			|| empty( $position_detail )
			|| empty( $position_experience )
			|| empty( $group_name )
			|| empty( $openings )
			) {
				echo '<br><br><div class="notice notice-error is-dismissible">
				<p><strong>Kindly provide the every required detail.</strong></p>
				</div>';

			// Data missing dont save, but report.
			} else {

				update_option('open-position-groups', $new_group_names);
	
				$extra_details['about_job']    = $_POST['about_job'];
				$extra_details['meet_ups']     = isset( $_POST['meetup_list'] ) ? json_encode( $_POST['meetup_list'] ) : '';
				$extra_details['banner_image'] = isset( $_POST['banner_image' ]) ? str_replace( $upload['baseurl'],'', $_POST['banner_image'] ): '';
				$extra_details['wk_next']      = isset( $_POST['wk_next'] ) ?  $_POST['wk_next'] : '';
	
				$speaker_list = array();
				$tweets_list  = array();
				$platfrom_img = array();
	
				if ( isset($_POST['platfrom_img'] ) && ! empty( $_POST['platfrom_img'] ) ) {
					
					foreach ($_POST['platfrom_img'] as $key => $value) {
						if ( ! empty( $value ) ) {
							$platfrom_img[] = !empty($value) ? str_replace( $upload['baseurl'],'', $value):'';
						}
					}
				}
	
				if ( isset( $_POST['wk_speak'] ) && isset( $_POST['wk_speak']['speaker'] ) && ! empty( $_POST['wk_speak']['speaker'] ) ){
					foreach ($_POST['wk_speak']['speaker'] as $key => $value) {
						$speaker_list[] = array(
							'name' => $value,
							'desg' => isset( $_POST['wk_speak']['desg'][ $key ] ) ? $_POST['wk_speak']['desg'][$key] : '',
							'image' => isset( $_POST['wk_speak']['image'][$key] )? str_replace( $upload['baseurl'], '', $_POST['wk_speak']['image'][$key]):'',
							'url' => isset( $_POST['wk_speak']['link'][$key] ) ? $_POST['wk_speak']['link'][$key] : '',
						);
					}
				}
	
				if ( isset( $_POST['tweet_links'] ) ) {
	
					foreach ( $_POST['tweet_links'] as $key => $value ) {
						if ( ! empty( $value ) ) {
							$value = str_replace( '<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>', '', $value);
							$tweets_list[] = json_encode( stripcslashes( $value ) );
						}
					}
				}
	
				$extra_details['platfrom_img'] = $platfrom_img;
				$extra_details['tweet_links']  = $tweets_list;
				$extra_details['speaker_list'] = $speaker_list;
				$extra_details['job_widget']   = array(
					'widget_label'       => ( isset( $_POST['widget_label'] ) ) ? $_POST['widget_label'] : '',
					'widget_description' => ( isset( $_POST['widget_description'] ) ) ? $_POST['widget_description'] : '',
					'widget_link'        => ( isset( $_POST['widget_link'] ) ) ? $_POST['widget_link'] : '',
				);
	
				$extra_details = maybe_serialize( $extra_details );
	
				$seo_details = isset( $_POST['seo'] ) ? maybe_serialize( $_POST['seo'] ) : array( 'meta_title' => '', 'meta_description' => '', 'og_image' => '' );
	
				if ( isset( $_GET['action'] ) && 'edit' === $_GET['action'] ) {
	
					$data = array(
						'position_name'       => $position_name,
						'position_detail'     => $position_detail,
						'position_experience' => $position_experience,
						'openings'            => $openings,
						'group_name'          => $group_name,
						'interview_process'   => $interview_process,
						'expected_salary'     => $expected_salary,
						'visibility'          => $visibility,
						'open_date'           => $open_date,
						'slug'                => $slug,
						'extra_details'       => $extra_details,
						'seo'                 => $seo_details,
					);
	
					$format       = array( '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' );
					$pos_id       = trim( $_GET['op_id'] );
					$where        = array( 'id' => $pos_id );
					$where_format = array( '%d' );
		
					$r = $wpdb->update( $table_name, $data, $where, $format, $where_format );
		
					if ( $r ) {
	
						echo '<br><br><div class="notice notice-success is-dismissible">
							<p><strong>Job post updated :)</strong></p>
						</div>';
					} else {
						echo '<br><br><div class="notice notice-error is-dismissible">
							<p><strong>Something Went Wrong! Please Try Again.</strong></p>
							</div>';
					}
	
				} else {
	
					$check = $wpdb->insert(
						$table_name,
						array(
							'position_name'       => $position_name,
							'position_detail'     => $position_detail,
							'group_name'          => $group_name,
							'position_experience' => $position_experience,
							'openings'            => $openings,
							'expected_salary'     => $expected_salary,
							'interview_process'   => $interview_process,
							'group_name'          => $group_name,
							'visibility'          => $visibility,
							'status'              => 'publish',
							'open_date'           => $open_date,
							'slug'                => $slug,
							'extra_details'       => $extra_details,
							'seo'                 => $seo_details,
						),
						array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
					);
					if ( $check ) {
						echo '<br><br><div class="notice notice-success is-dismissible">
							<p><strong>New Job post has been created.</strong></p>
						</div>';
	
					} else {
						echo '<br><br><div class="notice notice-error is-dismissible">
							<p><strong>Something Went Wrong! Please Try Again.</strong></p>
							</div>';
					}
				}
			}
		}
	}
	// SUbmision END

	global $wpdb;
	$table_name = $wpdb->prefix . 'open_positions';

	if ( ! wk_table_column_exists( $table_name, 'extra_details' ) ) {
		$wpdb->query( "ALTER TABLE $table_name ADD extra_details Longtext NULL" );
	}
	
	if ( ! wk_table_column_exists( $table_name, 'open_date' ) ) {
		$wpdb->query( "ALTER TABLE $table_name ADD open_date varchar(80) NULL" );
	}

	if ( ! wk_table_column_exists( $table_name, 'slug' ) ) {
		$wpdb->query( "ALTER TABLE $table_name ADD slug varchar(80) NOT NULL" );
	}

	if ( ! wk_table_column_exists( $table_name, 'seo' ) ) {
		$wpdb->query( "ALTER TABLE $table_name ADD seo Longtext NULL" );
	}

	if ( isset($_GET['action'] ) && 'edit' === $_GET['action'] ) {

		$pos_id              = $_GET['op_id'];
		$op_data             = $wpdb->get_results("SELECT * FROM $table_name WHERE id = '$pos_id'", ARRAY_A);
		$op_data             = $op_data[0];
		$position_name       = $op_data['position_name'];
		$position_detail     = $op_data['position_detail'];
		$position_experience = $op_data['position_experience'];
		$openings            = $op_data['openings'];
		$expected_salary     = $op_data['expected_salary'];
		$visibility          = $op_data['visibility'];
		$interview_process   = $op_data['interview_process'];
		$group_name          = $op_data['group_name'];
		$extra_details       = $op_data['extra_details'];
		$seo                 = $op_data['seo'];
		$open_date           = ( ! empty( $op_data['open_date'] ) ) ? $op_data['open_date'] : date( 'd-m-Y' );
		$slug                = ( ! empty( $op_data['slug'] ) ) ? $op_data['slug'] : get_jobpost_slug_from_name( $op_data['position_name'] );
		
		$page_heading = '<h1 class="setting-heading">Job Post - <span id="wkop-job-header-title">' . $position_name .  '</span></h1>';
	    $url_slug     = ( ! empty( $slug ) ) ? $slug : get_jobpost_slug_from_name( $position_name );
		$url          = home_url( 'jobs' ) . '/' . $url_slug;
		$url          = '<a href="' . $url . '" target="_blank" rel="nofollow noopener" >' . $url . '</a>';

	} else {
		$position_name        = '';
		$position_detail      = '';
		$position_experience  = '';
		$openings             = '';
		$expected_salary      = '';
		$visibility           = 'show';
		$interview_process    = '';
		$group_name           = '';
		$extra_details        = '';
		$seo                  = '';
		$open_date            = date( 'd-m-Y' ); //current date
		$slug                 = '';
		$page_heading         = '<h1 class="setting-heading">Job Post <span id="wkop-job-header-title"></span></h1>';
		$url                  = '';
	}

	$all_group_str   = trim( get_option( 'open-position-groups' ), ',' );
	$all_group_set   = explode( ',', $all_group_str );
	
	//Setting Data for new fields
	if ( ! empty( $extra_details ) ) {
		$extra_details = maybe_unserialize( $extra_details, true );
		$meetup        = isset( $extra_details['meet_ups'] ) && ! empty( $extra_details['meet_ups'] ) ? json_decode( $extra_details['meet_ups'], true ) : array();
		$about_job     = isset( $extra_details['about_job'] ) ? stripslashes( $extra_details['about_job'] ) : '';
		$banner_image  = isset( $extra_details['banner_image'] ) && ! empty( $extra_details['banner_image'] ) ? $upload['baseurl'] . $extra_details['banner_image'] : '';
		$wk_next       = isset( $extra_details['wk_next'] ) ? stripslashes( $extra_details['wk_next'] ) : '';
		$platfrom_img  = isset( $extra_details['platfrom_img'] ) && ! empty( $extra_details['platfrom_img'] ) ? $extra_details['platfrom_img'] : array();
		$speaker_list  = isset( $extra_details['speaker_list'] ) && ! empty( $extra_details['speaker_list'] ) ? $extra_details['speaker_list'] : array();
		$tweets_list   = isset( $extra_details['tweet_links'] ) && ! empty( $extra_details['tweet_links'] ) ? $extra_details['tweet_links'] : array();
		$widget        = isset( $extra_details['job_widget'] ) && ! empty( $extra_details['job_widget'] ) ? $extra_details['job_widget'] : array();

	} else {
		$meetup         = array();
		$about_job      = '';
		$banner_image   = '';
		$wk_next        = '';
		$platfrom_img   = array();
		$speaker_list   = array();
		$tweets_list    = array();
		$widget         = array();
	}

	if ( ! empty( $seo ) ) {

		$seo             = maybe_unserialize( $seo, true );
		$seo_title       = isset( $seo['meta_title'] ) ? $seo['meta_title'] : '';
		$seo_description = isset( $seo['meta_description'] ) ? $seo['meta_description'] : '';
		$seo_image       = isset( $seo['og_image'] ) && ! empty( $seo['og_image'] ) ? ( substr_count( $seo['og_image'], $upload['baseurl'] ) ? $seo['og_image'] : $upload['baseurl'] . $seo['og_image'] ) : '';
		$ogimg_template  = isset( $seo['ogimg_template'] ) ? $seo['ogimg_template'] : '';
		$ogtemplate_name = isset( $seo['ogimg_template_name'] ) ? $seo['ogimg_template_name'] : '';
	} else {
		$seo             = '';
		$seo_title       = '';
		$seo_description = '';
		$seo_image       = '';
		$ogimg_template  = '';
		$ogtemplate_name = '';
	}
	
	?>
	<script>
	wkopObj = { jobPageUrl : "<?php echo home_url( 'jobs' ); ?>" };
	</script>
	<div class="" id="wk-openposition-settings">

		<?php
		echo $page_heading;
		echo '<div class="wkop-page-preview-url">' . $url . '</div>';
		
		$current_tab = empty( $_GET['tab'] ) ? 'position_details' : sanitize_title( $_GET['tab'] );
		$tabs        = array(
			'position_details' => 'Position Details',
			'page_content'     => 'Page Content',
			'page_seo'         => 'SEO',
		);

		?>
		<div class="wkop-setting-actions">
			<nav class="wkop-item nav-tab-wrapper">
				<?php
				foreach ( $tabs as $tab => $name ) {
					$class = ( $tab === $current_tab ) ? 'nav-tab-active' : '';
					echo '<div class="nav-tab ' . $class . ' wkop-tab" data-route="' . $tab . '">' . $name . '</div>';
				}
				?>
			</nav>
			<div class="wkop-item wkop-actions">
				<button type="submit" id="wkop-save-btn" class="button button-primary">Save Position</button>
			</div>
		</div>
		<form action="" method="post" id="wkop-main-form">
			<div class="wkop-body">
	
				<div class="wkop-body-box">
					
					<!-- POSITION DETAILS SECTION -->
					<table id="wkop-tab-position_details" class="form-table wkop-tab-content <?php echo ( 'position_details' === $current_tab ) ? 'wkop-tab-active' : '' ;  ?>">
						<tr>
							<th><label for="p-name">Position Name*</label></th>
							<td><input required type="text" id="p-name" name="position-name" placeholder="Job Post Name" value="<?php echo $position_name; ?>" required></td>
						</tr>
						<tr>
							<th><label for="p-group">Group Name*</label></th>
							<td>
								<select required id="op-group-select" name="group-name">
									<?php
									foreach ($all_group_set as $grp) {
										echo $grp . $group_name;
		
										?><option value="<?php echo esc_html( $grp ); ?>" <?php selected( $grp, $group_name ); ?>><?php echo esc_html( $grp ); ?></option>
									<?php
								}
								?>
								</select>
								<a id="add-op-group" class="button button-secaondary" style="transition: all 0.5s ease;">Add New</a>
								<input type="text" id="new-group-field" style="display:none;" />
								<input name="new-groups-list" type="hidden" id="new-group-set" value="<?php echo $all_group_str; ?>" />
							</td>
						</tr>
						<tr>
							<th><label for="p-detail">Position Detail*</label></th>
							<td><textarea required id="p-detail" rows="6" name="position-detail" placeholder="Position Details..." required><?php echo $position_detail; ?></textarea>
								<p class="description">Length should not exceed 500 characters.</p>
							</td>
						</tr>
						<tr>
							<th><label for="p-experience">Required Experience*</label></th>
							<td><input required type="text" id="p-experience" name="position-experience" placeholder="Required Experience..." value="<?php echo $position_experience; ?>" required></td>
						</tr>
						<tr>
							<th><label for="openings">No. Of Openings*</label></th>
							<td><input required type="number" id="openings" name="openings" placeholder="No. of Openings..." value="<?php echo $openings; ?>"></td>
						</tr>
						<tr>
							<th><label for="expected_salary">Expected Salary</label></th>
							<td><input type="text" id="expected_salary" name="expected-salary" placeholder="Expected Salary" value="<?php echo $expected_salary; ?>"><p class="description">Follow this format : 2.34LPA - 3LPA, 4LPA+ <br>( *Enter expected salary in terms of LPA only. )</p></td>
						</tr>
						<tr>
							<th><label for="interview_process">Interview Process</label></th>
							<td><textarea rows="6" id="interview_process" name="interview-process" placeholder="Interview Process"><?php echo $interview_process; ?></textarea>
								<p class="description">Add comma seperated names of the rounds in an order.</p>
							</td>
						</tr>
					</table>
					<?php
	
					?>
					<!-- PAGE CONTENT SECTION -->
					<table id="wkop-tab-page_content" class="form-table wkop-tab-content <?php echo ( 'page_content' === $current_tab ) ? 'wkop-tab-active' : '' ;  ?>">
						<tr>
							<th><label for="wk-bannerimage">Banner Image</label></th>
							<td>
								<div class="wk-image-wrapper">
									<div class="wk-img-wrap" id="wk-bannerimage">
										<img src="<?php echo esc_url( $banner_image ); ?>">
										<input type="hidden" value="<?php echo esc_url( $banner_image ); ?>" name="banner_image" id="banner_image" class="banner_image">
									</div>
								</div>
							</td>
						</tr>
						<!-- Banner Image -->
		
						<!-- MeetUps Lists -->
						<tr>
							<th><label for="meetups">Meetups</label></th>
							<td>
								<?php
								$all_events = get_option( 'wktheme-page-events' );
								$all_events = ( '' === $all_events ) ? array() : $all_events;
								?>
								<select id="meet-up-select" name="meetup_list[]" multiple="multiple">
									<?php
								if ( isset( $all_events['events'] ) ) {
									foreach ( $all_events['events']['items'] as $key => $item ) {
										?>
										<option value="<?php echo esc_attr( trim( $item['name'] ) ); ?>" <?php echo in_array( trim( $item['name'] ), $meetup ) ? 'selected' : ''; ?>><?php echo $item['name']; ?></option>
										<?php
									}
								}
								?>
								</select>
							</td>
						</tr>
						<!-- MeetUps Lists -->
		
						<!-- MeetUps Speakers -->
						<tr>
							<th>
								<label for="">MeetUps Guest Speakers</label>
								<p></p>
							</th>
							<td>
								<wk-add-block class="wk-add-new-speaker">Add New<span class="dashicons dashicons-plus-alt"></span></wk-add-block>
								<div class="meet-up-speaker-wrap">
									<?php
									foreach ( $speaker_list as $key => $value ) {
										?>
										<div class="wk-meetup-speaker-container wk-image-wrapper">
											<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
											<div class="wk-img-wrap wk-platfromimage">
												<img src="<?php echo esc_url( $upload['baseurl'] . $value['image'] ); ?>">
												<input type="hidden" value="<?php echo esc_url( $upload['baseurl'] . $value['image'] ); ?>" name="wk_speak[image][]" class="banner_image">
											</div>
											<div>
												<label><strong>Name:</strong><input type="text" value="<?php echo esc_attr( $value['name'] ); ?>" name="wk_speak[speaker][]"></label><br>
												<label><strong>Desg:</strong><input type="text" value="<?php echo esc_attr( $value['desg'] ); ?>" name="wk_speak[desg][]"></label><br>
												<label><strong>Url:</strong><input type="text" value="<?php echo esc_attr( $value['url'] ); ?>" name="wk_speak[link][]"></label><br>
											</div>
										</div>
										<?php
									}
									?>
								</div>
							</td>
						</tr>
						<!-- MeetUps Speakers -->
		
						<!-- Tweets -->
						<tr>
							<th>
								<label for="">Tweet Embeded code</label>
							</th>
							<td>
								<wk-add-block class="wk-add-tweet-link">Add New<span class="dashicons dashicons-plus-alt"></span></wk-add-block>
								<div class="wk-tweets-links">
									<?php
										foreach ($tweets_list as $key => $value) {
											?>
											<div class="wk-tweet-wrapper">
												<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
												<textarea type="text" rows="5" name="tweet_links[]"><?php echo stripcslashes( json_decode( $value ) ); ?></textarea>
											</div>
										<?php
										}
										?>
								</div>
		
							</td>
						</tr>
						<!-- Tweets -->
		
						<!-- Description About Job -->
						<tr>
							<th><label for="wk_about_job">About</label>
								<p class="description">A short Description related to job</p>
							</th>
							<td>
								<textarea name="about_job" class="wktheme_tinyeditor" id="wk_about_job"><?php echo $about_job; ?></textarea>
							</td>
						</tr>
						<!-- Description About Job -->
		
						<!-- Add Frame work -->
						<tr>
							<th><label>Add Platforms</label>
								<p class="description">Add related Platform images</p>
							</th>
							<td>
								<wk-add-block class="wk-add-new-platfrom">Add New<span class="dashicons dashicons-plus-alt"></span></wk-add-block>
								<div class="wk-image-wrapper wk-platfrom-wrapper">
									<?php
		
									foreach ($platfrom_img as $key => $value) {
										if (!empty($value)) {
											?>
											<div class="wk-img-wrap wk-platfromimage">
												<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
												<img src="<?php echo esc_url( $upload['baseurl'].$value ); ?>">
												<input type="hidden" value="<?php echo esc_url( $upload['baseurl'].$value ); ?>" name="platfrom_img[]" class="banner_image">
											</div>
										<?php
									}
								}
								?>
								</div>
							</td>
						</tr>
						<!-- Add Frame work -->
		
						<!-- Upcomming  -->
						<tr>
							<th><label for="wk_next">Upcomming</label>
								<p class="description">New ideas and works related to job.</p>
							</th>
							<td>
								<textarea name="wk_next" class="wktheme_tinyeditor" id="wk_next"><?php echo $wk_next; ?></textarea>
							</td>
						</tr>
						<!-- Upcomming -->
		
						<!-- Widget -->
						<tr>
							<th><label for="wid-label">Widget Settings</label><p class="description">( Ex. - How to apply for Job at Webkul? ) </p></th>
							<td>
								<table>
									<tr>
										<th><label for="wid-label">Label</label></th>
										<td>
											<input type="text" value="<?php echo isset( $widget['widget_label'] ) ? $widget['widget_label'] : ''; ?>" placeholder="Add label" name="widget_label" id="wid-label">
										</td>
									</tr>
									<tr>
										<th><label for="wid-desc">Short Description</label></th>
										<td>
											<textarea placeholder="Some description" name="widget_description" id="wid-desc"><?php echo isset( $widget['widget_description'] ) ? $widget['widget_description'] : ''; ?></textarea>
										</td>
									</tr>
									<tr>
										<th><label for="wid-link">Add Link</label></th>
										<td>
											<input placeholder="Optional link" type="text" value="<?php echo isset( $widget['widget_link'] ) ? $widget['widget_link'] : ''; ?>" name="widget_link" id="wid-link">Perma
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<!-- //Widget -->
					</table>
	
					<!-- PAGE SEO SECTION -->
					<table id="wkop-tab-page_seo" class="form-table wkop-tab-content <?php echo ( 'page_seo' === $current_tab ) ? 'wkop-tab-active' : '' ;  ?>">
						<tr>
							<th><label for="seo-title">Meta Title</label></th>
							<td><input type="text" id="seo-title" name="seo[meta_title]" placeholder="" value="<?php echo $seo_title; ?>"></td>
						</tr>
						<tr>
							<th><label for="seo-description">Meta Description</label></th>
							<td><textarea rows="6" id="seo-description" name="seo[meta_description]"><?php echo $seo_description; ?></textarea>
							</td>
						</tr>
						<tr>
							<th><label for="seo-image">Social / OG / Facebook / Twitter Image</label><p class="description">*This image is used, when page share on social site.</p></th>
							<td><wk-i-upload style="line-height:0px;width:300px;min-height:100px;">
								<img class="thumb" src="<?php echo $seo_image; ?>"/>
								<input class="thumb-url" type="hidden" id="seo-image" name="seo[og_image]" placeholder="" value="<?php echo $seo_image; ?>"></td>
							</wk-i-upload>
							</td>
						</tr>
						<tr>
							<th></th>
							<td>
								<hr><br><strong style="display:block;margin-bottom:10px;"><label for="seo-image-temp">Create Image</label></strong>
								<div id="wk-page-meta-boxes">
									<label>
										<span class="switch" style="margin-left:0px">
											<input name="seo[ogimg_template]" type="checkbox" value="true" id="seo-image-temp" <?php checked( 'true', $ogimg_template ) ?>>
											<span class="slider round"></span>
										</span>
									</label>
									<br>
									<input type="text" rows="6" id="seo-image-temp-name" name="seo[ogimg_template_name]" value="<?php echo esc_html( $ogtemplate_name ); ?>" placeholder="<?php echo esc_html( $position_name ); ?>">
								</div>
								<p class="description">*This Image created with position name and webkul logo.</p>
							</td>
						</tr>
					</table>
					<input type="hidden" id="wkog-submit-mirror"/>
				</div>

				<div class="wkop-sidebar-box">
					<div class="box-setting-component">
						<h2 class="box-setting-title"><button type="button" aria-expanded="true" class="box-panel-toggle-btn wk-collapse-toggle" data-target="wkop-setting-status"><span aria-hidden="true"><svg class="box-setting-arrow" width="24px" height="24px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true" focusable="false"><g><path fill="none" d="M0,0h24v24H0V0z"></path></g><g><path d="M12,8l-6,6l1.41,1.41L12,10.83l4.59,4.58L18,14L12,8z"></path></g></svg></span>Status &amp; Visibility</button></h2>
								
						<div class="box-setting-body" id="wkop-setting-status">
							<div class="box-setting-row">
								<label class="box-setting-label" for="wkop--status">Status</label>
								<select class="box-setting-select" name="visibility" id="wkop--status">
									<option <?php echo ( 'show' == $visibility ) ? 'selected' : ''; ?> value="show">Open</option>
									<option <?php echo ( 'hide' == $visibility ) ? 'selected' : ''; ?>value="hide">Closed</option>
								</select>
							</div>
							<div class="box-setting-row">
								<label class="box-setting-label" for="wkop--published">Published on</label>
								<?php
								?>
								<input id="wkop--published" type="text" class="wkop-datepicker" name="open_date" value="<?php echo esc_attr( $open_date ); ?>"/>
							</div>
							<div class="box-setting-row">
								<?php
								if ( isset( $_GET['action'] ) && 'edit' === $_GET['action'] ) {
									?>
									<a href="<?php echo '?page=wkjob_post&action=trash&op_id='. trim( $pos_id ); ?>" type="button" class="button button-secondary wkop-delete-job-post-btn">Permanent Delete</a>
									<?php
								}
								?>
							</div>
						</div>
					</div>
					<div class="box-setting-component">
						<h2 class="box-setting-title"><button type="button" aria-expanded="true" class="box-panel-toggle-btn wk-collapse-toggle" data-target="wkop-setting-permalink"><span aria-hidden="true"><svg class="box-setting-arrow" width="24px" height="24px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true" focusable="false"><g><path fill="none" d="M0,0h24v24H0V0z"></path></g><g><path d="M12,8l-6,6l1.41,1.41L12,10.83l4.59,4.58L18,14L12,8z"></path></g></svg></span>Permalink</button></h2>
	
						<div class="box-setting-body" id="wkop-setting-permalink">
							<div class="box-setting-row display-blockwise">
								<label class="box-setting-label" for="slug">Slug</label>
								<input id="slug" class="box-setting-input" type="text" value="<?php echo esc_attr( $slug ); ?>" name="slug">
							</div>
							<div class="box-setting-row display-blockwise">
								<span>Preview</span>
								<?php
								echo '<div class="wkop-page-preview-url">' . $url . '</div>';
								?>
							</div>
						</div>
						
					</div>
				</div>

			</div>
		</form>

	</div>
<?php
}
/*Job post details- ADD/EDIT*/


// /* OPEN POSITION BACKEND TABLE*/
function wkjob_posts_listing() {

	if ( ! class_exists( 'Open_Position_List_Table' ) ) {
		require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	}

	class Open_Position_List_Table extends WP_List_Table {

		private $credibility_scores = array();

		public $table_name = '';

		function __construct()	{
			parent::__construct( array(
				'singular' => 'wk_job_post',
				'plural'   => 'wk_job_posts',
				'ajax'     => false
			) );

			global $wpdb;
			$this->table_name = $wpdb->prefix . 'open_positions';
		}

		private function get_liability_score( $data ) {

			$unwrapped_items  = array();
			$exception_fields = array( 'id', 'slug', 'visibility', 'status' );
			
			foreach( $data as $key => $field ) {

				if ( in_array( $key, $exception_fields ) ) {
					continue;
				}

				$field = maybe_unserialize( $field );

				if ( is_array( $field ) ) {
					
					foreach ( $field as $sub_key => $sub_field ) {
						
						if ( in_array( $sub_key, $exception_fields ) ) {
							continue;
						}

						$unwrapped_items[ $sub_key ] = $sub_field;
						
					}

				} else {
					$unwrapped_items[ $key ] = $field;
				}
			}
			
			$total_min_count   = 19; //present total field count, needed for old posts where all data fields not present.
			$unwrapped_count   = count ( $unwrapped_items );
			$total_items       = ( 19 > $unwrapped_count ) ? 19 : $unwrapped_count;
			$filled_fields     = array_filter( $unwrapped_items, function( $column ) {
				try {
					return (
						(
							! empty( $column )
							&&
							! is_array( $column )
						)
						||
						(
							is_array( $column )
							&&
							count( $column )
							&&(
								(
									is_string( array_values( $column )[0] )
									&&
									! empty( implode( '', $column ) )
								)
								||
								(
									is_array( array_values( $column )[0] )
									// &&
									// ! empty( implode( '', $column ) )
								)
							)
						)
					);

				} catch( Exception $e ) {
					die;
				}
			} );

			return ceil( ( count( $filled_fields ) / $total_items ) * 100 );
		}

		private function calculate_liability_score( $data_set ) {

			foreach( $data_set as $single_set ) {
				$this->credibility_scores[ $single_set['id'] ] = (int) $this->get_liability_score( $single_set );
			}
		}

		public function get_op_data() {

			global $wpdb;
			$table_name = $wpdb->prefix . 'open_positions';

			if ( isset( $_REQUEST['s'] ) ) {
				$search  = trim( $_REQUEST['s'] );
				$op_data = $wpdb->get_results( "SELECT * FROM $table_name WHERE position_name LIKE '%$search%'", ARRAY_A );
			} else {
				$op_data = $wpdb->get_results( "SELECT * FROM $table_name", ARRAY_A );
			}
			return $op_data;
		}

		public function prepare_items() {

			global $wpdb;
			$columns  = $this->get_columns();
			$sortable = $this->get_sortable_columns();
			$hidden   = $this->get_hidden_columns();

			$this->process_bulk_action();

			$data       = $this->get_op_data();
			$totalitems = count( $data );
			$user       = get_current_user_id();
			$screen     = get_current_screen();
			$option     = $screen->get_option( 'per_page', 'option' );
			$per_page   = get_user_meta( $user, $option, true );
			
			$this->_column_headers = array( $columns, $hidden, $sortable );
			
			if ( empty( $per_page ) || $per_page < 1 ) {
				$per_page = $screen->get_option( 'per_page', 'default' );
			}

			$this->calculate_liability_score( $data );
			
			usort( $data, function( $a, $b ) {

				$orderby = ( ! empty( $_REQUEST['orderby'] ) ) ? $_REQUEST['orderby'] : 'position_name';
				$order   = ( ! empty( $_REQUEST['order'] ) ) ? $_REQUEST['order'] : 'asc';
				
				( 'completion_score' === $orderby )
				&& (
					( $this->credibility_scores[ $a['id'] ] == $this->credibility_scores[ $b['id'] ] )
					&&
					( $result = 0 )
					||
					( $result = ( $this->credibility_scores[ $a['id'] ] < $this->credibility_scores[ $b['id'] ] ) ? -1 : 1 )
				)
				|| 
				( 'openings' === $orderby )
				&& (
					( $a[ $orderby ] == $b[ $orderby ] )
					&&
					( $result = 0 )
					||
					( $result = ( $a[ $orderby ] < $b[ $orderby ] ) ? -1 : 1 )
				)
				||
				( $result = strcmp( $a[ $orderby ], $b[ $orderby ] ) );

				return ( $order === 'asc' ) ? $result : -$result;

			} );

			$totalpages  = ceil( $totalitems / $per_page );
			$currentPage = $this->get_pagenum();
			$data        = array_slice( $data, ( ( $currentPage - 1 ) * $per_page ), $per_page );

			$this->set_pagination_args( array(
				'total_items' => $totalitems,
				'total_pages' => $totalpages,
				'per_page'    => $per_page,
			) );
			$this->items = $data;
		}

		public function get_hidden_columns() {
			return array();
		}

		function column_cb( $item ) {
			return sprintf( '<input type="checkbox" id="op_id_%s" name="op_id[]" value="%s" />', $item['id'], $item['id'] );
		}

		function get_columns() {

			$columns = array(
				'cb'                  => '<input type="checkbox" />',
				'position_name'       => __( 'Post Name' ),
				'position_experience' => __( 'Experience Required' ),
				'openings'            => __( 'No. of Openings' ),
				'expected_salary'     => __( 'Expected Salary' ),
				'group_name'          => __( 'Group' ),
				'visibility'          => __( 'Status' ),
				'completion_score'    => __( 'Credibility Score (%)' ),
			);
			return $columns;
		}

		public function get_sortable_columns() {

			$sortable_columns = array(
				'position_name'    => array( 'position_name', true ),
				'openings'         => array( 'openings', true ),
				'group_name'       => array( 'group_name', true ),
				'visibility'       => array( 'visibility', true ),
				'completion_score' => array( 'completion_score', true ),
			);
			return $sortable_columns;
		}

		function get_bulk_actions() {

			$actions = array(
				'trash'      => 'Permanent Delete',
				'visibility' => 'Toggle Status'
			);
			return $actions;
		}

		public function process_bulk_action() {

			global $wpdb;
			$table_name = $wpdb->prefix . 'open_positions';

			if ( 'trash' === $this->current_action() ) {
				if ( isset( $_REQUEST['op_id'] ) ) {
					if ( is_array( $_REQUEST['op_id'] ) ) {
						$ids = implode( ',', $_REQUEST['op_id'] );
						$wpdb->query( "DELETE FROM $table_name WHERE id IN ( $ids )" );
					} else {
						if ( ! empty( $_REQUEST['op_id'] ) ) {
							$id = $_REQUEST['op_id'];
							$wpdb->query( "DELETE FROM $table_name WHERE id = $id" );
						}
					}
				}
				echo '<script>window.location.href=" ' . admin_url( '/admin.php?page=wkjob_post') . ' ";</script>';
			}

			if ( 'visibility' === $this->current_action() ) {
				if ( isset( $_POST['op_id'] ) ) {
					$post_id_array = array();
					if ( is_array( $_POST['op_id'] ) ) {
						foreach ( $_POST['op_id'] as $id ) {
							if ( ! empty( $id ) ) {
								$curr_status = $wpdb->get_row( "SELECT visibility FROM $table_name WHERE id=$id", ARRAY_A );
								$new_status  = ( 'show' === $curr_status['visibility'] ) ? 'hide' : 'show';
								$wpdb->query( "UPDATE $table_name SET visibility = '$new_status' WHERE id = $id" );
							}
						}
					}
				}
			}
		}

		public function column_default( $item, $column_name ) {

			switch ( $column_name ) {

				case 'position_name':
				case 'position_experience':
				case 'openings':
				case 'visibility':
				case 'position_detail':
				case 'expected_salary':
				case 'interview_process':
				case 'completion_score':
				case 'group_name':
					return $item[ $column_name ];
				default:
					return print_r( $item, true );
			}
		}

		public function column_position_name( $item ) {

			$slug = ( isset( $item['slug'] ) && ! empty( $item['slug'] ) ) ? $item['slug'] : get_jobpost_slug_from_name( $item['position_name'] );
			$url  = home_url( 'jobs' ) . '/' . $slug;

			$actions = array(
				'edit'  => sprintf( '<a href="?page=wkjob_post_new&action=edit&op_id=%s">Edit</a>', $item['id'] ),
				// 'trash' => sprintf( '<a href="?page=wkjob_post_new&action=trash&op_id=%s">Delete</a>', $item['id'] ),
				'view'  => sprintf( '<a target="_blank" rel="nofollow noopener" href="%s">View</a>', $url ),
			);

			return sprintf( '<a href="?page=wkjob_post_new&action=edit&op_id=%1$s"><b>%2$s</b></a></a> %3$s', $item['id'], $item['position_name'], $this->row_actions( $actions ) );
		}
		
		public function column_visibility( $item ) {

			$status = ( 'show' === $item['visibility'] ) ? '<span class="wkop-list-status open">Open</span>' : '<span class="wkop-list-status closed">Closed</span>';
			return $status;
		}

		public function column_completion_score( $item ) {

			$score_html = '<div class="wkop-listing-meter-wrapper" data-score="' . $this->credibility_scores[ $item['id'] ] . '">
				<svg class="wkop-listing-meter" width="60" height="60" viewBox="0 0 50 50">
					<circle class="meter__bg" cx="25" cy="25" r="20" stroke-width="3"></circle>
					<circle class="meter__score" cx="25" cy="25" r="20" stroke-width="3" style=""></circle>
				</svg>
			</div>';
			return $score_html;
		}
	}
	//End of class

	
	$open_post_table_obj = new Open_Position_List_Table();

	if ( isset( $_REQUEST['s'] ) ) {
		$open_post_table_obj->prepare_items( $_REQUEST['s'] );
	} else {
		$open_post_table_obj->prepare_items();
	}

	// if ( isset( $_GET['wk_action'] ) && 'create_slug' === $_GET['wk_action'] ) {

	// 	$open_post_table_obj->get_op_data();

	// 	echo '<pre>';
	// 	$items = $open_post_table_obj->items;

	// 	global $wpdb;

	// 	foreach( $items as $itm ) {
	// 		if ( empty( $itm['slug'] ) ) {
	// 			$slug = get_jobpost_slug_from_name( $itm['position_name'] );
	// 			var_dump( $slug );
			
	// 			$data = array(
	// 				'slug' => $slug,
	// 			);
	// 			$format       = array( '%s' );
	// 			$pos_id       = trim(  $itm['id'] );
	// 			$where        = array( 'id' => $pos_id );
	// 			$where_format = array( '%d' );
	// 			$r = $wpdb->update( $open_post_table_obj->table_name, $data, $where, $format, $where_format );
	// 			var_dump($r);
	// 		}
	// 	}
	// 	die;
	// }
	?>
	<div class="wrap wkop-job-listing-table">
		<h1 class="wp-heading-inline">Job Posts</h1>
		<a href="<?php echo menu_page_url( 'wkjob_post_new', false ); ?>" class="page-title-action">Add New</a>
		<form method="POST">
			<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
			<?php
			$open_post_table_obj->search_box( 'Search', 'position-id' );
			$open_post_table_obj->display();
			?>
		</form>
	</div>
	<?php
}
// /* //OPEN POSITION BACKEND TABLE*/


/* //ENd Client reviews handling */
function client_add_review_menu_page() {

	$all_reviews = get_option('wktheme-client-reviews');
	$all_reviews = ('' === $all_reviews) ? array() : $all_reviews;
	$path        = wp_upload_dir()['baseurl'];

	?>
	<div class="wrap">
		<h1>Our Client Reviews</h1>
		<hr /><br />
		<button id="save-reviews" class="button button-primary">UPDATE REVIEWS</button>
		<img style="display:none;" id="loader" src="<?php echo esc_url(site_url() . '/wp-includes/images/spinner.gif'); ?>" />
		<br><br>
		<p class="description">*Hold & Drag items to order the reviews.</p>
		<template id="wk-review-template">
			<div class="wk-element-block">
				<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
				<p><b>Review For ?</b></p>
				<input type="text" class="link-label" placeholder="Name of Product/Service" />
				<input type="text" class="link-url" placeholder="Link" />
				<div>
					<div class="img-wrap">
						<img src="" />
						<input type="hidden" class="img-url" value="" />
					</div>
					<textarea class="bubble review" placeholder="Review"></textarea>
				</div>
				<table class="form-body">
					<tbody>
						<tr>
							<th>Name</th>
							<td><input type="text" class="name" value="" placeholder="Name of the client" /></td>
						</tr>
						<tr>
							<th>Work details</th>
							<td><input type="text" class="work" value="" placeholder="Work details" /></td>
						</tr>
						<tr>
							<th>Location</th>
							<td><input type="text" class="location" value="" placeholder="Location" /></td>
						</tr>
					</tbody>
				</table>
			</div>
		</template>
		<div id="wk-handle-client-reviews" class="wk-is-sortable">
			<?php
			if (isset($all_reviews['reviews'])) {
				foreach ($all_reviews['reviews']['items'] as $key) {

					?>
					<div class="wk-element-block">
						<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
						<p><b>Review For ?</b></p>
						<input type="text" value="<?php echo esc_attr($key['linkLabel']); ?>" class="link-label" placeholder="Name of Product/Service" />
						<input type="text" value="<?php echo esc_attr($key['linkUrl']); ?>" class="link-url" placeholder="Link" />
						<div>
							<div class="img-wrap">
								<img src="<?php echo esc_url($path . $key['imgUrl']); ?>" />
								<input type="hidden" class="img-url" value="<?php echo esc_attr($path . $key['imgUrl']); ?>" />
							</div>
							<textarea class="bubble review" placeholder="Review"><?php echo esc_attr($key['cReview']); ?></textarea>
						</div>
						<table class="form-body">
							<tbody>
								<tr>
									<th>Name</th>
									<td><input type="text" class="name" value="<?php echo esc_attr($key['cName']); ?>" placeholder="Name of the client" /></td>
								</tr>
								<tr>
									<th>Work details</th>
									<td><input type="text" class="work" value="<?php echo esc_attr($key['cWork']); ?>" placeholder="Work details" /></td>
								</tr>
								<tr>
									<th>Location</th>
									<td><input type="text" class="location" value="<?php echo esc_attr($key['cLocation']); ?>" placeholder="Location" /></td>
								</tr>
							</tbody>
						</table>
					</div>
				<?php
			}
		}
		?>
		</div>
		<div class="blocks-container">
			<div class="add-block">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
		</div>
	</div>
<?php
}
/* //ENd Client reviews handling */


/* Notification Bubble for Add menu pages */
add_action('admin_menu', function() {
	global $menu;
	$team        = get_number_of_new_post_by_type_team( 'team' );
	$menu[6][0] .= ' <span class="update-plugins count-' . $team . '"><span class="plugin-count">' . $team . '</span></span>';
});
/* //Notification Bubble for Add menu pages */

function get_number_of_new_post_by_type_team($type) {
	global  $wpdb;
	$table_name = $wpdb->prefix . $type;
	if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name) {
		$teamData =  $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}$type WHERE post_status='publish'");
		return $teamData;
	}
}

//custom console function//
function console_log() {
	$data = func_get_args();
	for ($i = 0; $i < count($data); $i++) {
		$log  = "<script>console.log( 'PHP debugger: ";
		$log .= '\n\n';
		$log .= json_encode(print_r($data[$i], true));
		$log .= '\n';
	}
	$log .= "' );</script>";
	echo $log;
}


/* // Alter Header section */
add_action('wk_altered_header', 'wk_altered_header_section', 10, 4);

function wk_altered_header_section( $imageurl, $content, $videoimage, $videourl ) {
	?>
	<section class="wk-altered-header">
		<div class="wkgrid-wide">
			<div class="wk-altered-header-info">

				<?php if (!empty($imageurl)) { ?>

					<div class="page-banner">
						<img src="<?php echo $imageurl; ?>" />
					</div>

				<?php	}

			if (!empty($content)) { ?>

					<div class="page-tagline">

						<?php echo $content; ?>

					</div>

				<?php } ?>

			</div>
			<?php if (!empty($videoimage) || !empty($videourl)) { ?>
				<div class="altered-video-cover">
					<img src="<?php echo esc_url($videoimage); ?>" title="<?php echo get_the_title(); ?>" alt="<?php echo get_the_title(); ?>" />
					<div class="video-icon">
						<img src="<?php echo get_template_directory_uri() . '/images/akeneo/video.png'; ?>" title="<?php echo get_the_title(); ?>" alt="<?php echo get_the_title(); ?>" />
						<p>1 Minute Intro</p>
					</div>
				</div>
			<?php } ?>
		</div>

		<div class="altered_video_popup">
			<div class="altered_popup_wrapper">
				<span class="altered_popup_close"></span>
				<div class="altered_popup_content">
					<video id="altered_video_player" controls poster="<?php echo get_template_directory_uri() . '/images/akeneo/akeneo-pim-og-image.png'; ?>" preload="1">

						<source src="<?php echo $videourl; ?>" type="video/mp4">

					</video>
				</div>
			</div>
		</div>

	</section>
<?php
}

<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();
?>

<section class=" wk-innov-section">
  <img src="<?php echo esc_url(get_template_directory_uri() . '/images/innovations-lab-winner-cover.png?v=1.0'); ?>" alt="Innovation Lab" title="Innovation Lab" />
</section>

<section class="wk-page-content section-padding">
  <div class="wkgrid-squeezy">
    <?php
    while( have_posts() ) {
      the_post();
      the_content();
    }
    ?>
  </div>
</section>

<?php

get_footer();

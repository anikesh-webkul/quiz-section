<?php

get_header();

blog_navbar();

$tag_id    = get_query_var( 'tag_id' );
$the_query = new WP_Query( array(

	'post_type'      => 'post',
	'posts_per_page' => get_option( 'posts_per_page' ),
	'paged'          => get_pagenumber_args(),
	'tag_id'         => $tag_id,
	'post_status'    => 'publish',
) );

$text = ( $the_query->found_posts > 1 ) ? 'results' : 'result';

?>

<section class="qloblog-taxonomy-wrapper taxonomy-tag">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="qloblog-taxonomy-head">
					<h1>#<?php echo esc_html( single_tag_title() ); ?></h1>
					<p class="alter-text-style"><?php echo esc_html( $the_query->found_posts . ' ' . $text . ' found' ); ?></p>
				</div>
			</div>
		</div>
	</div>

	<div class="wk-page-blog-sec ">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="qblog-archives text-left">
					<?php
					if ( $the_query->have_posts() ) {

						while ( $the_query->have_posts() ) {

							$the_query->the_post();

							get_template_part( 'content', 'blog' );
						}
					}
					?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<div class="wk-pagination-wrapper">
					<?php hotelreservation_pagination( $the_query->found_posts ); ?>
				</div>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>

</section>
<?php
get_footer();


<?php
get_header();

$wn_tagline      = get_option( 'qa-webinar-tagline' );
$wn_booking_link = get_option( 'qa-webinar-booking-link' );

$banner_data = array(
  'title' => 'Webinar',
  'content' => $wn_tagline,
  'link_url' => $wn_booking_link,
  'link_label' => 'Book Now',
  'new_tab' => 'true',
);

apply_filters( 'qa_moon_section', $banner_data );

?>
<nav class="webinar-nav-menu">
  <div class="wk-grid-lg">
    <?php
    $qa_active = ( !empty( $_GET['p'] ) ) ? $_GET['p']  : 'all';
    ?>
    <a class="<?php echo ( 'all' === $qa_active ) ? 'qa-active' : false; ?>" href="<?php echo site_url() . '/webinar/'; ?>">All</a>
    <a class="<?php echo ( 'upcoming' === $qa_active ) ? 'qa-active' : false; ?>" href="<?php echo site_url() . '/webinar/?p=upcoming'; ?>">Upcoming</a>
    <a class="<?php echo ( 'previous' === $qa_active ) ? 'qa-active' : false; ?>" href="<?php echo site_url() . '/webinar/?p=previous'; ?>">Previous</a>
  </div>
</nav>

<?php
date_default_timezone_set('Asia/Kolkata');
$current_dt = date('Y-m-d H:i');
$args = array(
  'post_type' => 'webinar',
  'meta_key'  => 'webinar-date',
  'orderby'   => 'meta_value',
  'order'     => 'DESC',
);
if( 'all' !== $qa_active  ) {
  $args['meta_query'] = array(
    'key' => 'webinar-date',
    'value' => $current_dt,
    'type' => 'DATETIME',
  );
  $args['meta_query']['compare'] = ( 'upcoming' === $qa_active ) ? '>=' : '<=';
}

$the_query = new WP_Query($args);
?>
<section class="webinar-listing-section">
  <div class="wk-grid-lg">
    <div class="webinar-list-wrap">
      <?php
      // The Loop
      if ( $the_query->have_posts() ) {
        while ( $the_query->have_posts() ) {
          $the_query->the_post();
          $webinar_date = get_post_meta( get_the_ID(), 'webinar-date', true );
          $flag = ( strtotime( $current_dt ) <  strtotime( $webinar_date ) ) ? 'upcoming' : 'previous';
          $book_link = get_post_meta( get_the_ID(), 'webinar-book-link', true );
          $booking_date = date( 'd-M-Y | h:iA', strtotime( $webinar_date ) );
          $booking_flag = ( 'upcoming' === $flag ) ? '1' : '0';
          ?>
          <div class="webinar-brick" data-id="<?php echo get_the_ID(); ?>">
            <div class="webinar-brick-title <?php echo $flag; ?>">
              <h2><?php echo esc_html( get_the_title() ); ?></h2>
              <?php
              if( 'upcoming' === $flag ) {
                echo '<span>Upcoming</span>';
              }
              ?>
            </div>
            <div class="webinar-brick-content">
              <?php
              foreach (explode("\n", get_the_excerpt()) as $line) {
                if (trim($line)) {
                  echo '<p>' . $line . '</p>';
                }
              }
              ?>
              <span class="wn-read-more">Read More</span>
            </div>
          </div>
          <?php
          $content = apply_filters( 'the_content', get_the_content() );
          $web_data[get_the_ID()] = array(
            'title'   => get_the_title(),
            'content' => $content,
            'link'    => esc_url( $book_link ),
            'date'    => $booking_date . ' (IST)',
            'flag'    => $booking_flag,
          );
          ?>
          <?php
        }
        echo '<script id="qaWebinarData" type="application/json">' . wp_json_encode( $web_data ) . '</script>';
        wp_reset_postdata();
      } else {
        echo "<p class='no-record-found'>Sorry! No Webinar Available.</p>";
      }
      ?>
    </div>

  </div>
</section>

<div class="webinar-popup">
  <div class="wk-grid-md">
    <div class="webinar-title">
      <h1></h1>
      <span class="wn-close-popup"></span>
    </div>
    <div class="webinar-editor">
      <article id="wn-content"></article>
      <div class="webinar-live-date">
        <h6>TIME & DATE</h6>
        <ul>
          <li id="wn-date"></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php

get_footer();

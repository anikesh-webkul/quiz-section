/**
 * JS code traverse followed blocks.js then deprecated.js and last index.js
 * blocks.js > deprecated,js > index.js
 */

var el = wp.element.createElement;

const {
    Fragment,
    useState
} = wp.element;

const {
    rawHandler,
    registerBlockType

} = wp.blocks;

const {
    AlignmentToolbar,
    BlockControls,
    ColorPalette,
    InnerBlocks,
    InspectorControls,
    InspectorAdvancedControls,
    MediaUpload, 
    PanelColorSettings,
    PlainText,
    RichText,
    URLInput,
    URLInputButton,
    URLPopover 
} = wp.blockEditor;

const {
    Button,
    ButtonGroup,
    CheckboxControl,
    ColorIndicator,
    ColorPicker,
    Dashicon,
    FormToggle,
    FormFileUpload,
    Modal,
    PanelBody,
    Panel,
    PanelHeader,
    PanelRow,
    Placeholder,
    RangeControl,
    RadioControl,
    SelectControl,
    TextControl,
    ToggleControl,
    Tooltip,
    TabPanel
} = wp.components;

const { withSelect, withDispatch } = wp.data;
const { compose } = wp.compose;

const ALLOWED_MEDIA_TYPES = [ 'image' ];

const wkColorPallete = [
    { name: 'primary', color: '#2149f3' },
    { name: 'secondary', color: '#0cf0cf' },
    { name: 'dark', color: '#0e1b51' },
    { name: 'gray', color: '#efefef' },
    { name: 'default', color: '#ffffff' },
];

/** Gloabl Upload Icon */
const wkUploadIcon = el(
    'svg',
    {
        width:"32px",
		height:"32px",
		viewBox:"0 0 100 100",
		xmlns:"http://www.w3.org/2000/svg",
    },
    el(
        'path',
        {
            d:'m77.945 91.453h-72.371c-3.3711 0-5.5742-2.3633-5.5742-5.2422v-55.719c0-3.457 2.1172-6.0703 5.5742-6.0703h44.453v11.051l-38.98-0.003906v45.008h60.977v-17.133l11.988-0.007812v22.875c0 2.8789-2.7812 5.2422-6.0664 5.2422z'
        }
    ),
    el(
        'path',
        {
            d:'m16.543 75.48l23.25-22.324 10.441 9.7773 11.234-14.766 5.5039 10.539 0.039063 16.773z'
        }
    ),
    el(
        'path',
        {
            d:'m28.047 52.992c-3.168 0-5.7422-2.5742-5.7422-5.7461 0-3.1758 2.5742-5.75 5.7422-5.75 3.1797 0 5.7539 2.5742 5.7539 5.75 0 3.1719-2.5742 5.7461-5.7539 5.7461z'
        }
    ),
    el(
        'path',
        {
            d:'m84.043 30.492v22.02h-12.059l-0.015625-22.02h-15.852l21.941-21.945 21.941 21.945z'
        }
    )
);


/**
 * Add a Wk Layout button to the toolbar.
 */

// (function (window, wp) {
	
// 	document.addEventListener('DOMContentLoaded', () => {
		
// 		/**
// 		* Add the wk Layout block on click.
// 		*/
// 		function wkInsertLayout() {
// 			const block = wp.blocks.createBlock( 'wk-blocks/layout-selector' );
// 			wp.data.dispatch( 'core/block-editor' ).insertBlocks( block );

// 			var wkSBIds = wp.data.select('core/block-editor').getSelectedBlockClientId();
// 			wkModalOpen = document.querySelector( '#block-' + wkSBIds + ' .wk-open-modal-library');
// 			( undefined != wkModalOpen ) && wkModalOpen.click();
// 		}
	
// 		// just to keep it cleaner - we refer to our link by id for speed of lookup on DOM.
// 		var _id = 'wkLayoutInsertButton';

// 		// prepare our custom link's html.
// 		var _html = '<div class="wk-toolbar-insert-layout"><button id="' + _id + '" class="components-button components-icon-button" aria-label="Insert Layout"><i class="dashicons dashicons-layout wk-toolbar-insert-layout-button"></i>Page Components</button>';
// 		console.log('ded');

// 		// check if gutenberg's editor root element is present.
// 		var editorEl = document.getElementById('editor');
// 		if (!editorEl) { // do nothing if there's no gutenberg root element on page.
// 			return;
// 		}

// 		console.log('d')
// 		var unsubscribe = wp.data.subscribe(function () {
// 			setTimeout(function () {
// 				if (!document.getElementById(_id)) {
// 					var toolbalEl = editorEl.querySelector('.edit-post-header__toolbar');
// 					if (toolbalEl instanceof HTMLElement) {
// 						toolbalEl.insertAdjacentHTML('beforeend', _html);
// 					}
// 				}
// 			}, 1)
// 		});
// 		// unsubscribe();
// 		// but in case you'll need to stop this link from being reappeared at any point you can just call unsubscribe();
// 		// unsubscribe is a function - it's not used right now
// 	});

// })(window, wp);

	// document.getElementById( 'wkLayoutInsertButton' ).addEventListener( 'click', wkInsertLayout );
		
// 		/**
// 		* Add the wk Layout block on click.
// 		*/
		function wkInsertLayout() {
			const block = wp.blocks.createBlock( 'wk-blocks/layout-selector' );
			wp.data.dispatch( 'core/block-editor' ).insertBlocks( block );

			var wkSBIds = wp.data.select('core/block-editor').getSelectedBlockClientId();
			wkModalOpen = document.querySelector( '#block-' + wkSBIds + ' .wk-open-modal-library');
			( undefined != wkModalOpen ) && wkModalOpen.click();
		}
document.addEventListener( 'DOMContentLoaded', appendImportButton );

/**
 * Build the layout inserter button.
 */
function appendImportButton() {
	setTimeout(() => {
		// console.log('dd')
		const toolbar = document.querySelector('.edit-post-header-toolbar');
		
		if (!toolbar) {
			return;
		}
		const buttonDiv = document.createElement('div');
		let html = '<div class="wk-toolbar-insert-layout">';
		html += `<button id="wkLayoutInsertButton" class="components-button components-icon-button" aria-label="${'Insert Layout'}"><i class="dashicons dashicons-layout wk-toolbar-insert-layout-button"></i> ${'Wk Layouts'}</button>`;
		html += '</div>';
		buttonDiv.innerHTML = html;
		toolbar.appendChild(buttonDiv);
		document.getElementById('wkLayoutInsertButton').addEventListener('click', wkInsertLayout);
            
	}, 100);

}


/**
 * Setting Icons
 */
var wkSettingIcon = el(
    Dashicon,
    {
        icon:'admin-generic',
        style:{
            position:'absolute',
            right:'-10px',
            top:'-10px',
            cursor:'pointer'
        }
    }
);
/** SVG Icons Foer Block */
var wkBlockIcons = {};

/* Two columns - 50/50. */
wkBlockIcons.twoEqual = el( 'svg',
    {
        viewBox:"0 0 60 30",
		height:"26",
		xmlns:"http://www.w3.org/2000/svg",
		fillRule:"evenodd",
		clipRule:"evenodd",
		strokeLinejoin:"round",
		strokeMiterlimit:"1.414",
    },
    el(
        'rect',
        {
            x:'33',
            y:'0',
            width:'29',
            height:'30',
            fill:'#6d6a6f'
        }
    ),
    el(
        'rect',
        {
            x:'0',
            y:'0',
            width:'29',
            height:'30',
            fill:'#6d6a6f'
        }
    )
);

wkBlockIcons.twoLeftSqueezy = el( 'svg',
    {
        viewBox:"0 0 60 30",
        height:"26",
        xmlns:"http://www.w3.org/2000/svg",
        fillRule:"evenodd",
        clipRule:"evenodd",
        strokeLinejoin:"round",
        strokeMiterlimit:"1.414",
    },
    el(
        'rect',
        {
            x:'36',
            y:'0',
            width:'22',
            height:'30',
            fill:'#6d6a6f'
        }
    ),
    el(
        'rect',
        {
            x:'0',
            y:'0',
            width:'32',
            height:'30',
            fill:'#6d6a6f'
        }
    )
);


wkBlockIcons.twoRightSqueezy = el( 'svg',
    {
        viewBox:"0 0 60 30",
        height:"26",
        xmlns:"http://www.w3.org/2000/svg",
        fillRule:"evenodd",
        clipRule:"evenodd",
        strokeLinejoin:"round",
        strokeMiterlimit:"1.414",
    },
    el(
        'rect',
        {
            x:'28',
            y:'0',
            width:'32',
            height:'30',
            fill:'#6d6a6f'
        }
    ),
    el(
        'rect',
        {
            x:'0',
            y:'0',
            width:'24',
            height:'30',
            fill:'#6d6a6f'
        }
    )
);

wkBlockIcons.twoLeftWide = el( 'svg',
    {
        viewBox:"0 0 60 30",
        height:"26",
        xmlns:"http://www.w3.org/2000/svg",
        fillRule:"evenodd",
        clipRule:"evenodd",
        strokeLinejoin:"round",
        strokeMiterlimit:"1.414",
    },
    el(
        'rect',
        {
            x:'43',
            y:'0',
            width:'16',
            height:'30',
            fill:'#6d6a6f'
        }
    ),
    el(
        'rect',
        {
            x:'0',
            y:'0',
            width:'39',
            height:'30',
            fill:'#6d6a6f'
        }
    )
);


wkBlockIcons.twoRightWide = el( 'svg',
    {
        viewBox:"0 0 60 30",
        height:"26",
        xmlns:"http://www.w3.org/2000/svg",
        fillRule:"evenodd",
        clipRule:"evenodd",
        strokeLinejoin:"round",
        strokeMiterlimit:"1.414",
    },
    el(
        'rect',
        {
            x:'20',
            y:'0',
            width:'39',
            height:'30',
            fill:'#6d6a6f'
        }
    ),
    el(
        'rect',
        {
            x:'0',
            y:'0',
            width:'16',
            height:'30',
            fill:'#6d6a6f'
        }
    )
);

wkBlockIcons.columnResponsive = el( 'svg',
    {
        viewBox:"0 0 60 40",
        height:"40",
        xmlns:"http://www.w3.org/2000/svg",
        fillRule:"evenodd",
        clipRule:"evenodd",
        strokeLinejoin:"round",
        strokeMiterlimit:"1.414",
    },
    el(
        'rect',
        {
            x:'0',
            y:'0',
            width:'60',
            height:'15',
            fill:'#6d6a6f'
        }
    ),
    el(
        'rect',
        {
            x:'0',
            y:'20',
            width:'60',
            height:'15',
            fill:'#6d6a6f'
        }
    )
);


/**
 * Hide Blocks From Inserter
 */
wp.domReady( function() {
    // var wkHideBlocks = [
    //     'wk-blocks/review-slider',
    //     'wk-blocks/column-inner-block',
    //     'wk-blocks/caption-icons',
    //     'wk-blocks/fancy-links',
    //     'wk-blocks/fancy-links',
    //     'wk-blocks/jumbotron',
    //     'wk-blocks/special-links',
    //     'wk-blocks/success-story',
    //     'wk-blocks/testimonial',
    //     'wk-blocks/image-gallery',
    // ];
    var wkHideBlocks = [
        'wk-blocks/image-gallery',
    ];
    wp.data.dispatch( 'core/edit-post' ).hideBlockTypes( wkHideBlocks );

} );
/** //Hide Blocks From Inserter */
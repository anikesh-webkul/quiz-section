<?php
add_action( 'wktheme_backup_recovery_tab', '_template_backup_recovery_tab' );
add_action( 'wktheme_users_tab', '_template_users_tab' );


function _template_backup_recovery_tab() {

	// $all_options = get_option( 'wk_theme_backup_option' );
	// $backup_keys = get_option( 'wk_backup_option_keys' );
    //
	// $new_options = array();
    //
	// foreach ( $backup_keys as $opt_key ) {
    //
	// 	$real_option             = get_option( $opt_key );
	// 	$new_options[ $opt_key ] = $real_option;
	// }
	// update_option( 'wk_theme_backup_option', $new_options );
	?>
	<div id="wktheme-backup-recovery-area">
		<div style="display:none;" class="notice notice-success is-dismissible">
			<p><strong>Yay! BackUp Created Successfuly :)</strong></p>
		</div>
		<div style="display:none;" class="notice notice-error is-dismissible">
			<p><strong>Something Went Wrong! Please Try Again :(</strong></p>
		</div>
		<div id="wk-backup-recovery-section">
			<h4>Create Backup of Theme Elements used in Webkul Theme</h4>
			<div class="strip">
				<p class="description">Ohh! No Backup Created Yet.</p>
			</div>
			<input type="text" id="bk-label" placeholder="Backup Label ( < 50 characters )"/>
			<button id="create-backup" class="button button-primary">Create Backup</button>
			<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />
			<p class="error"></p>
		</div>
		<style>
		.strip{
			padding: 20px 15px;
			margin: 20px 0px;
			border-left: 5px solid #2149f3;
			position: relative;
			background-color: #e6e6e6;
		}
		.strip p{
			font-size: 16px;
			margin: 0px;
		}
		.strip::before{
			content: "";
			width: 3px;
			height: 48px;
			background: #fe97e7;
			display: inline-block;
			position: absolute;
			top: 8px;
			left: 0;
		}
		.error{
			margin: 0;
			color: #d60a0a;
		}
		</style>
	</div>
	<?php
}

function _template_users_tab() {
	echo '<h2>Working On it too !</h2>';
}

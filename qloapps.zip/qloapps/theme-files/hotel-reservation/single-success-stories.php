
<?php
/**
 * The template for displaying Features
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();

$customer_name 	  = get_post_meta( get_the_ID(), 'customer-name', true);
$customer_url 		= get_post_meta( get_the_ID(), 'partner-url', true);
$customer_logo 		= get_post_meta( get_the_ID(), 'partner-logo', true);
$customer_country = get_post_meta( get_the_ID(), 'partner-country', true);
$customer_image 	= get_post_meta( get_the_ID(), 'customer-image', true);
$customer_image   = ( !empty( $customer_image ) ) ? wp_upload_dir()['baseurl'] . $customer_image : '';
$customer_review 	= get_post_meta( get_the_ID(), 'customer-review', true);

?>
<section class="single-success-story wrapper">
    <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="customer-header">
                      <div class="info-box-one">
                        <?php
                        if( ! empty( $customer_logo ) ){
                          ?>
                          <img src="<?php echo esc_url( $customer_logo ); ?>">
                          <?php
                        }
                        ?>
                        <h2><?php echo get_the_title(); ?></h2>
                        <?php
                        if( ! empty( $customer_url ) ){
                          ?>
                          <p> Source Link :- <a href="<?php echo esc_url( $customer_url ); ?>" rel="noopener" target="_blank"><?php echo esc_url( $customer_url ); ?></a></p>
                          <?php
                        }
                        ?>
                      </div>
                      <div class="info-box-two">
                        <?php
                        if( ! empty( $customer_image ) ){
                          ?>
                          <img src="<?php echo esc_url( $customer_image ); ?>">
                          <?php
                        }
                        ?>
                        <div class="customer-data">
                          <?php
                          if( ! empty( $customer_name ) ){
                            ?>
                            <h4><?php echo esc_attr( $customer_name ); ?></h4>
                            <?php
                          }
                          if( ! empty( $customer_country ) ){
                            ?>
                            <p><?php echo esc_attr( $customer_country ); ?></p>
                            <?php
                          }
                          ?>
                        </div>
                      </div>
                    </div>
                    <div class="customer-sub-header">
                      <h3 class="review-title"><?php echo __('QloApps Review','hotelreservation'); ?></h3>
                      <?php
                      if( ! empty( $customer_review ) ){
                        ?>
                        <p><?php echo esc_attr( $customer_review ); ?></p>
                        <?php
                      }
                      if( ! empty( $customer_name ) ){
                        ?>
                        <h5><?php echo __('By :- ','hotelreservation'); echo esc_attr( $customer_name ); ?></h5>
                        <?php
                      }
                      ?>

                    </div>
                    <div class="customer-content">
                      <?php

                     if ( have_posts() ) :
                         while( have_posts() ) :
                           the_post();
                           echo get_the_post_thumbnail( get_the_ID(), 'full');
                           the_content();

                         endwhile;
                     endif;
                     ?>
                    </div>
                </div>
            </div>
    </div>
</section>
<section class="qlo-add-story wk-common-padding text-center">
  <div class="container">
    <div class="row">
        <div class="col-md-12">
          <h1>Add Your Success Story With Us</h1>
          <p>You’ve read about the importance of being courageous, rebellious and imaginative. These are all vital ingredients in an effective advertising campaign. However, they must be tempered with the most important ingredient of all.</p>
          <a href="<?php echo home_url('/register-success-story'); ?>" class="white-button">Send Message</a>
        </div>
    </div>
  </div>
</section>
<?php get_footer();?>

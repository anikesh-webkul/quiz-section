<?php 

header("Location: https://qloapps.com/download");
die;

?>
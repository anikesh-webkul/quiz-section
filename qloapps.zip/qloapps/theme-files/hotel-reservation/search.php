<?php

/**
 * The template for displaying Search Results pages
 *
 * @package HotelReservation
 * @subpackage HotelReservation theme
 * @since HotelReservation theme 1.0
 */

get_header();

blog_navbar();

if ( get_query_var( 'paged' ) ) {

	$paged = get_query_var( 'paged' );
} elseif ( get_query_var( 'page' ) ) {

	$paged = get_query_var( 'page' );
} else {
	$paged = 1;
}

$the_query = new WP_Query( array(

	'post_type'      => 'post',
	'posts_per_page' => get_option( 'posts_per_page' ),
	's'              => get_search_query(),
	'paged'          => $paged,
	'post_status'    => 'publish',
) );

$text = ( $the_query->found_posts > 1 ) ? 'results' : 'result';

?>
<div class="wk-page-blog-sec">
	<div class="main-wrapper">
		<div class="search-results">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="qloblog-taxonomy-head">
							<h1>Search Results</h1>
							<p class="alter-text-style"><?php echo esc_html( $the_query->found_posts . ' ' . $text . ' found' ); ?> with keyword - "<strong><?php echo esc_html( get_search_query() ); ?></strong>"</p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12 text-center">
						<div class="qblog-archives text-left">
							<?php
							while ( $the_query->have_posts() ) {
								$the_query->the_post();
								get_template_part( 'content', 'blog' );
							}
							?>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-3"></div>
					<div class="col-md-6">
						<div class="wk-pagination-wrapper">
						<?php hotelreservation_pagination( $the_query->found_posts ); ?>
						</div>
					</div>
					<div class="col-md-3"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php

get_footer();


<?php
/*
Plugin Name: Popular Post Widget
Plugin URI: http://hotelreservation.com/blog
Description: A plugin for adding Popular Post link
Version: 0.1
Author: webkul
Author URI: http://hotelreservation.com/blog
Text Domain: Hotel Reservation
*/


class popularPosts_Widget extends WP_Widget {

    public function __construct() {

        parent::__construct(
            'pp_id',
            __( 'Hotel Reservation Popular Post Widget', 'ppwidget' ),
            array(
                'classname'   => 'popular_posts',
                'description' => __('Hotel Reservation Popular Post Widget.', 'ppwidget' )
                )
        );

    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
  public function widget( $args, $instance ) {
        extract( $args );
        ?>
  <div class="row">
      <div class="col-md-2"></div>
        <div class="col-md-8">
          <h2 class="popular_post_h2">Popular Articles</h2>
              <?php
                query_posts(array( 'posts_per_page'=>'4'),'meta_key=post_views_count&orderby=meta_value_num&order=DESC');
                if(have_posts()) : while (have_posts()) : the_post();
                    if( get_post_meta( get_the_ID(), 'meta-featured-post')[0]=='yes'){
                      $dir = wp_upload_dir()['baseurl'];
                			$feat_img = $dir.get_post_meta( get_the_ID(), 'blog_banner_image', true );
                			global $wpdb;
                			$attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $feat_img ));
                		  $img_id = $attachment[0];
                			$feat_img = wp_get_attachment_image_src($img_id, 'post-thumbnail','true');
                      $url=$feat_img[0];
                    }
                    else{
                      $url = get_the_post_thumbnail_url( get_the_ID() );
                    }


              ?>
              <div class="popular_posts">
                    <a href="<?php the_permalink();?>" title="<?php the_title();?>"><img src="<?php echo $url;?>" alt="<?php the_title();?>"></a>
                    <div><a href="<?php the_permalink();?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></div>

              </div>
                <?php
                endwhile; endif;

                wp_reset_query();?>
      </div>
      <div class="col-md-2"></div>
  </div>

<?php
}



    /**
      * Sanitize widget form values as they are saved.
      *
      * @see WP_Widget::update()
      *
      * @param array $new_instance Values just sent to be saved.
      * @param array $old_instance Previously saved values from database.
      *
      * @return array Updated safe values to be saved.
      */
    public function update( $new_instance, $old_instance ) {

        $instance = $old_instance;

        return $instance;

    }

    /**
      * Back-end widget form.
      *
      * @see WP_Widget::form()
      *
      * @param array $instance Previously saved values from database.
      */
    public function form( $instance ) {



    }

}

/* Register the widget */
add_action( 'widgets_init', function(){
     register_widget( 'popularPosts_Widget' );
});

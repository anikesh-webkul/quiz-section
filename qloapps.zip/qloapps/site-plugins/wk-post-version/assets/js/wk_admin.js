var $wkp = jQuery.noConflict();
(function( $wkp ){

    $wkp( ".wkp-dropdown-label" ).on( 'click', function(){

      if( $wkp(this).hasClass('active') ){
        $wkp(this).removeClass("active").next().removeClass("active");
      } else {
        $wkp(this).addClass("active").next().addClass("active");
      }

    });

    $wkp( ".wkp-post-versions li" ).on( 'click', function(){

        $wkp(this).addClass('disabled');
        $wkp('.wkp-dropdown-label').html($(this).html());
        $wkp(this).siblings().removeClass('disabled');
        versionName = $wkp(this).data( "name" );
        versionValue = $wkp(this).data("value");
        post_id = $wkp(this).data("post-id");

        $wkp.ajax({

            type: "post",
            url: wkpPostvar.url,
            data: {
              action:'wkp_post_data',
              nonce:wkpPostvar.nonce,
              wkp_version_name:versionName,
              wkp_version_data:versionValue,
              post_id: post_id,
            },
            beforeSend: function () {
                $wkp('.wkp-dropdown-label').addClass('animation');
            },
            success: function(html){
              $wkp('.wkp-dropdown-label').removeClass("active").next().removeClass("active");
              $wkp('.wkp-dropdown-label').removeClass('animation');
              $wkp('.wkp-post-version').empty();
              $wkp('.wkp-post-version').append(html);
              $wkp('.wk-editor .wkp-current-version rev').html($wkp('.wkp-demos li.disabled').attr('data-version'));
              $wkp('.wk-editor .wkp-current-framework rev').html($wkp('.wkp-demos li.disabled').attr('data-frameversion'));
              zoomermanInt();

            }

        });

    });

})($wkp);

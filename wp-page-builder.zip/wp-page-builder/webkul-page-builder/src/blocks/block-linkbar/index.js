registerBlockType( 'wk-blocks/linkbar', {
    title : 'Link Bar',
    icon : 'excerpt-view',
    category: 'webkul',
    keywords: ['Link Bar'],
    parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    example:{},
    attributes: {
        content: {
            type:'string',
            selector: 'h4',
        },
        
        newWindow: {
            type:'boolean',
        },
        imgLink: {
            type:'string',
            source: 'attribute',
			attribute: 'href',
            selector: 'a',
        },
        description:
        {
            type:'string',
            selector:'p'
        }
       
    },
    edit : function( props ) {
        var content = props.attributes.content,
        description=props.attributes.description,
        newWindow = props.attributes.newWindow,
        imgLink= props.attributes.imgLink;
        
        

       
       
        return (
            el(
                Fragment,
                {},
                el(
                    InspectorControls,
                    {},
                    el(
                        Panel,
                        {},
                        el(
                            PanelBody,
                            {
                                title:'Link Bar URL Setting',
                            },
                            el(
                                PanelRow,
                                {},
                                el(
                                    TextControl,
                                    {
                                        type:"string",
							            label:'ADD URL',
                                        value:imgLink,
                                        onChange:(newLink) => {
                                            props.setAttributes({imgLink:newLink});
                                        }
                                    }
                                ),
                            ),
                            el(
                                PanelRow,
                                {},
                                el(
                                    FormToggle,
                                    {
                                        checked:newWindow,
                                        onChange: ( event ) => {
                                            props.setAttributes( {
                                                newWindow: event.target.checked,
                                            } )
                                        },
                                    }
                                ),
                                el(
                                    'span',
                                    {},
                                    'Open in New Tab'
                                )
                            ),
                        )
                    )
                ),
                el(
                    'div',
                    {
                        className:'wk-link-block wk-image-uploader',
                    },
                    el(
                        PlainText,
                        {
                            key: 'editable',
                            tag:'h4',
                            value:content,
                            placeholder:'Title...',
                            onChange:(newContent) => {
                                props.setAttributes({content:newContent});
                            },
                            style:{
                                marginTop:'5px',
                              'text-align':'center'
                            },
                            className:'wk-link-title',
                        },
    
                    ),
                    el(
                        PlainText,
                        {
                            key: 'editable',
                            tag:'p',
                            value:description,
                            placeholder:'Description...',
                            onChange:(newDes) => {
                                props.setAttributes({description:newDes});
                            },
                            style:{
                                marginTop:'5px',
                              'text-align':'center'
                            },
                            className:'wk-link-info'
                        },
    
                    ),
                ),
                
                // el(
                //     Dashicon,
                //     {
                //         icon:'admin-links'
                //     }
                // )
            )
        
        );
    },
    save:function(props) {
        let wrapperEl = (props.attributes.imgLink) ? 'a' : 'div';
		let wrapperElProps = (props.attributes.imgLink) ? {
			href: props.attributes.imgLink,
			className: 'wk-link-block',
			title: props.attributes.content,
			target: (props.attributes.newContent) ? '_blank' : false,
			rel: (props.attributes.newContent) ? 'noopener noreferrer' : false,
          
		} : {
				className: 'wk-link-block no-link',
				title: props.attributes.content,
				
			};
        
        return el(
            Fragment,
            {},
            el(
                wrapperEl,
                wrapperElProps,
                el(
                    'h4',
                    {
                        className:'wk-link-title',
                        
                    },
                    props.attributes.content
                    
                ),
                el(
                    'p',
                    {
                        className:'wk-link-info',
                        
                    },
                    props.attributes.description
                )
            )
        )
    }


} );
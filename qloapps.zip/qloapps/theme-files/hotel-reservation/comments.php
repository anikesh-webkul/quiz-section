<?php
/**
 * The template for displaying Comments
 *
 * The area of the page that contains comments and the comment form.
 *
   * @package Hotel&Reservation
 * @subpackage Hotel&Reservation
 * @since Hotel&Reservation 1.0
 */

/*
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */
if ( post_password_required() )
	return;
?>

<?php  $count= get_comments_number(); ?>
	<section class="comment-section">
		<div class="container">
			<div class="row">
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<?php	if($count>0){	?>

							<div class="commnet-form-section margin-20" id="comment-response">


										<!--Response Wrapper Begins-->

										<?php if ( have_comments() ) : ?>

										<div class="response-wrapper">

											<!--Heading-->

											<h5 class="comment-head"><?php echo $count?> Response(s)</h5>

											<!--Heading-->

											<div class="comment-body">

												<?php

												wp_list_comments('type=comment&callback=hotelReservation_comment');

												?>

											</div>

										</div>

										<?php endif; // have_comments() ?>

										<!--Response Wrapper Ends-->

							</div>

						<!-- Responses -->
						<?php }?>

						<!-- Comment -->

							<div class="comment-form-fields margin-20" id="leave-response">

								<div class="crunchify-text"> <h5 class="white">Leave A Comment</h5></div>
										<!--Comment Wrapper Begins-->

										<!-- <div class="comment-wrapper"> -->

										<?php //comment_form();
												$args = array(
													'fields' => apply_filters(
													'comment_form_default_fields', array(
														'author' =>'<div class="comment-form-author">' . '<input id="author" placeholder="Name" name="author" type="text" value="' .
															esc_attr( $commenter['comment_author'] ) . '" size="30"' . @$aria_req . ' />'.'</div>'
															,
														'email'  => '<div class="comment-form-email">' . '<input id="email" placeholder="Email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
															'" size="30"' . @$aria_req . ' />'.'</div>',
													)
												),
												'comment_field' => '<div class="comment-form-comment">' .
													'<textarea id="comment" class="mdl-textfield__input" name="comment" placeholder="Comment" cols="45" rows="8" aria-required="true"></textarea>' .
													'</div>',
													'comment_notes_after' => ''
											);

										comment_form( $args );

											//comment_form();
									?>
										<!-- </div> -->

										<!--Comment Wrapper Ends-->


							</div>
				</div>
				<div class="col-md-2"></div>
			</div>
		</div>
	</section>

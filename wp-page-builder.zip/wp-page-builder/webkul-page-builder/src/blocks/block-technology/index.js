registerBlockType( 'wk-blocks/technology', {
    title : 'Technology',
    icon : 'excerpt-view',
    category: 'webkul',
    keywords: ['Technology'],
    parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],
    example:{},
    attributes: {
        content: {
            type:'string',
            selector: 'h4',
        },
        
        newWindow: {
            type:'boolean',
        },
        imgLink: {
            type:'string',
            source: 'attribute',
			attribute: 'href',
            selector: 'a',
        },
        imgID: {
            type: 'number',
        },
        imgALT: {
            type:'string',
            source: 'attribute',
			attribute: 'alt',
			selector: 'img',
        },
        imgSrc: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
        }
       
    },
    edit : function( props ) {
        var content = props.attributes.content,
        newWindow = props.attributes.newWindow,
        imgLink= props.attributes.imgLink,
        imgID = props.attributes.imgID,
        imgALT = props.attributes.imgALT,
        imgSrc = props.attributes.imgSrc;

        const onRemoveImage = () => {
			props.setAttributes( {
				imgSrc: null,
                imgID: null,
                imgALT:null,
			} );
        };

       
        return (
            el(
                Fragment,
                {},
                el(
                    InspectorControls,
                    {},
                    el(
                        Panel,
                        {},
                        el(
                            PanelBody,
                            {
                                title:'Technology Link Setting',
                            },
                            el(
                                PanelRow,
                                {},
                                el(
                                    TextControl,
                                    {
                                        type:"string",
							            label:'ADD URL',
                                        value:imgLink,
                                        onChange:(newLink) => {
                                            props.setAttributes({imgLink:newLink});
                                        }
                                    }
                                ),
                            ),
                            el(
                                PanelRow,
                                {},
                                el(
                                    FormToggle,
                                    {
                                        checked:newWindow,
                                        onChange: ( event ) => {
                                            props.setAttributes( {
                                                newWindow: event.target.checked,
                                            } )
                                        },
                                    }
                                ),
                                el(
                                    'span',
                                    {},
                                    'Open in New Tab'
                                )
                            ),
                        )
                    )
                ),
                el(
                    'div',
                    {
                        className:'wk-tech-brick wk-image-uploader',
                    },
                    el(
                        MediaUpload,
                        {
                            buttonProps: {
                                className: 'change-image'
                            },
                            onSelect: img => props.setAttributes({
                                imgID: img.id,
                                imgSrc: img.url,
                                imgALT:img.alt ? img.alt : img.title 
                            }),
                            allowed: ALLOWED_MEDIA_TYPES,
                            type: "image",
                            value: imgID,
                            render: ({ open }) => el(
                                Fragment,
                                null,
                                el(
                                    Button,
                                    {
                                        className: imgSrc ? 'wk-change-image' : 'wk-add-image',
                                        onClick: open
                                    },
                                    ! imgSrc ? wkUploadIcon : el( "img",
                                        {
                                            src: imgSrc,
                                            alt: imgALT
                                        }
                                    )
                                ),
                                imgSrc && el(
                                    Button,
                                    {
                                        className: "wk-remove-image",
                                        onClick: onRemoveImage
                                    },
                                    el(
                                        Dashicon,
                                        {
                                            icon: 'dismiss'
                                        }
                                    )
                                )
                            )
                        }
    
                    ),
                ),
                el(
                    PlainText,
                    {
                        key: 'editable',
                        tag:'h4',
                        value:content,
                        placeholder:'Your text...',
                        onChange:(newContent) => {
                            props.setAttributes({content:newContent});
                        },
                        style:{
                            marginTop:'5px',
                          'text-align':'center'
                        }
                    },

                ),
                // el(
                //     Dashicon,
                //     {
                //         icon:'admin-links'
                //     }
                // )
            )
        
        );
    },
    save:function(props) {
        let wrapperEl = (props.attributes.imgLink) ? 'a' : 'div';
		let wrapperElProps = (props.attributes.imgLink) ? {
			href: props.attributes.imgLink,
			className: 'p-x3 wk-tech-brick',
			title: props.attributes.content,
			target: (props.attributes.newContent) ? '_blank' : false,
			rel: (props.attributes.newContent) ? 'noopener noreferrer' : false,
          
		} : {
				className: 'p-x3 wk-tech-brick no-link',
				title: props.attributes.title,
				
			};
        
        return el(
            Fragment,
            {},
            el(
                wrapperEl,
                wrapperElProps,
                el(
                    'img',
                    {
                        src:props.attributes.imgSrc,
                        alt:props.attributes.imgALT,
                        className:'technology-img'
                    },
                    
                ),
                el(
                    'p',
                    {
                        className:'p-x3',
                        
                    },
                    props.attributes.content
                )
            )
        )
    }


} );
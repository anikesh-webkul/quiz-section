<?php

add_action( 'wktheme_clients_page_setting_tab', '_template_clients_tab' );
add_action( 'wktheme_customer_page_setting_tab', '_template_customer_tab' );
add_action( 'wktheme_press_page_setting_tab', '_template_press_tab' );
add_action( 'wktheme_certification_page_setting_tab', '_template_certification_tab' );
add_action( 'wktheme_infrastructure_page_setting_tab', '_template_infrastructure_tab' );
add_action( 'wktheme_events_page_setting_tab', '_template_events_tab' );
add_action( 'wktheme_awards_page_setting_tab', '_template_awards_tab' );
add_action( 'wktheme_innovations_page_setting_tab', '_template_innovations_tab');

function _wk_get_notification_stip( $title ) {

	?>
	<div style="display:none;" class="notice notice-success is-dismissible">
		<p><strong><?php echo esc_html( $title ); ?> Elements Updated.</strong></p>
	</div>
	<div style="display:none;" class="notice notice-error is-dismissible">
		<p><strong>Something Went Wrong! Please Try Again.</strong></p>
	</div>
	<?php
}

function _template_clients_tab() {

	$all_clients = get_option( 'wktheme-page-clients' );
	$all_clients = ( '' === $all_clients ) ? array() : $all_clients;
	$path      = wp_upload_dir()['baseurl'];
	_wk_get_notification_stip( 'Clients' );
	?>

	<p><a target="_blank" href="<?php echo esc_url(  get_permalink( get_page_by_path( 'press' ) ) ); ?>">Go To Press Page</a></p>
	<button id="save-icons" class="button button-primary">UPDATE</button>
	<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />

	<template id="wk-client-template">
		<div class="wk-element-block block-compact">
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<div class="thumbnail client-logo">
				<span style="position:absolute;z-index:-1; top:17%; left:33%;">Add Logo</span>
				<img class="thumb-img" src="" />
				<input class="thumb-url" type="hidden" value=""/>
			</div>
			<div>
				<label>
					<p class="description">Client Name</p>
					<input type="text" class="client-name" value=""/>
				</label>
				<label>
					<p class="description">Client Designation</p>
					<input type="text" class="client-designation" value=""/>
				</label>
				<label>
					<p class="description">Saying Title</p>
					<input type="text" class="client-saying-title" value=""/>
				</label>
				<label>
					<p class="description">Short Description</p>
					<textarea class="desc" ></textarea>
				</label>
				<label>
					<p class="description">Link title</p>
					<input type="text" class="link-title" value=""/>
				</label>
				<label>
					<p class="description">Link</p>
					<input type="text" class="link" value=""/>
				</label>
				<label>
					<p><span class="description">Enable</span>
					<input type="checkbox" class="enable" value=""/></p>
				</label>
			</div>
		</div>
	</template>

	<br /><br /><hr /><br />

	<div id="wktheme-clients-wrapper">
		<div class="wk-is-sortable">
			<?php
			if ( isset( $all_clients['client'] ) ) {
				foreach ( $all_clients['client']['items'] as $key ) {

					?>
					<div class="wk-element-block block-compact">
						<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
						<div class="thumbnail client-logo">
							<span style="position:absolute;z-index:-1; top:17%; left:33%;">Add Logo</span>
							<img class="thumb-img" src="<?php echo esc_url( $path . $key['image'] ); ?>" />
							<input class="thumb-url" type="hidden" value="<?php echo esc_url( $path . $key['image'] ); ?>"/>
						</div>
						<div>
							<label>
								<p class="description">Client Name</p>
								<input type="text" class="client-name" value="<?php echo esc_attr( $key['name'] ); ?>"/>
							</label>
							<label>
								<p class="description">Client Designation</p>
								<input type="text" class="client-designation" value="<?php echo esc_attr( $key['designation'] ); ?>"/>
							</label>
							<label>
								<p class="description">Saying Title</p>
								<input type="text" class="client-saying-title" value="<?php echo esc_attr( $key['saying_title'] ); ?>"/>
							</label>
							<label>
								<p class="description">Short Description</p>
								<textarea class="desc"><?php echo esc_attr( $key['desc'] ); ?></textarea>
							</label>
							<label>
								<p class="description">Link Title</p>
								<input type="text" class="link-title" value="<?php echo esc_attr( $key['link_title'] ); ?>"/>
							</label>
							<label>
								<p class="description">Link</p>
								<input type="text" class="link" value="<?php echo esc_url( $key['link'] ); ?>"/>
							</label>
							<label>
								<p><span class="description">Enable</span>
								<input type="checkbox" class="enable" value="1" <?php echo ( 'true' === $key['enable'] ) ? ' checked' : ''; ?>/></p>
							</label>
						</div>
					</div>
					<?php
				}
			}
			?>
		</div>
		<div class="blocks-container">
			<div class="add-block">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
		</div>
	</div>
	<?php
}

function _template_customer_tab() {

	$all_customers = get_option( 'wktheme-page-customer' );
	$all_customers = ( '' === $all_customers ) ? array() : $all_customers;
	$path          = wp_upload_dir()['baseurl'];

	_wk_get_notification_stip( 'Customers' );
	?>

	<p><a target="_blank" href="<?php echo esc_url( get_permalink( get_page_by_path( 'our-customers' ) ) ); ?>">Go To Customer Page</a></p>
	<button id="save-icons" class="button button-primary">UPDATE</button>
	<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />

	<template id="template-type-1">
		<div class="wk-element-block">
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<div class="wk-customer-logo">
				<span style="position:absolute;z-index:-1">Add Logo</span>
				<img id="thumb-img" src="" />
				<input id="thumb-url" type="hidden" value="" />
			</div>
			<div>
				<ul class="wk-customer-textbox" id="wk-customer-data" contenteditable="true"></ul>
			</div>
		</div>
	</template>
	<template id="template-type-2">
		<div class="wk-element-block">
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<div class="icon">
				<img class="thumb" src="{{img_url}}" />
				<input type="hidden" class="thumb-url" value="{{img_url}}" />
			</div>
		</div>
	</template>
	<br /><br /><hr />
	<div id="wktheme-customer-page-wrapper">
		<p>Customer Logos with List of products they use</p>
		<div id="type-1-container" class="wk-is-sortable">
			<?php
			if ( isset( $all_customers['logoWithList'] ) ) {
				foreach ( $all_customers['logoWithList']['items'] as $key ) {
					if ( ! empty( $key['url'] ) && ! empty( $key['content'] ) ) {

						?>
						<div class="wk-element-block">
							<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
							<div class="wk-customer-logo">
								<span style="position:absolute;z-index:-1">Add Logo</span>
								<img id="thumb-img" src="<?php echo esc_url( $path . $key['url'] ); ?>" />
								<input id="thumb-url" type="hidden" value="<?php echo esc_url( $path . $key['url'] ); ?>" />
							</div>
							<div>
								<ul class="wk-customer-textbox" id="wk-customer-data" contenteditable="true"><?php echo $key['content']; ?></ul>
							</div>
						</div>
						<?php
					}
				}
			}
			?>
		</div>
		<div class="blocks-container">
			<div class="add-block" id="type-1">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
		</div>
		<br /><hr /><br />
		<p>Customer Logos gallery</p>
		<div id="type-2-container">
			<?php
			if ( isset( $all_customers['logoGallery'] ) ) {
				foreach ( $all_customers['logoGallery']['items'] as $key ) {

					if ( ! empty( $key['url'] ) ) {
						?>
						<div class="wk-element-block">
							<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
							<div class="icon">
								<img class="thumb" src="<?php echo esc_url( $path . $key['url'] ); ?>" />
								<input type="hidden" class="thumb-url" value="<?php echo esc_url( $path . $key['url'] ); ?>" />
							</div>
						</div>
						<?php
					}
				}
			}
			?>
		</div>
		<div class="blocks-container">
			<div class="add-block" id="type-2">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
		</div>
	</div>
	<?php
}

function _template_press_tab() {

	$all_press = get_option( 'wktheme-page-press' );
	$all_press = ( '' === $all_press ) ? array() : $all_press;
	$path      = wp_upload_dir()['baseurl'];
	_wk_get_notification_stip( 'Press' );
	?>

	<p><a target="_blank" href="<?php echo esc_url(  get_permalink( get_page_by_path( 'press' ) ) ); ?>">Go To Press Page</a></p>
	<button id="save-icons" class="button button-primary">UPDATE</button>
	<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />

	<template id="wk-press-template">
		<div class="wk-element-block block-compact">
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<div class="thumbnail press-logo">
				<span style="position:absolute;z-index:-1; top:17%; left:33%;">Add Logo</span>
				<img class="thumb-img" src="" />
				<input class="thumb-url" type="hidden" value=""/>
			</div>
			<div>
				<label>
					<p class="description">Name</p>
					<input type="text" class="name" value=""/>
				</label>
				<label>
					<p class="description">Desctiption / Published Date</p>
					<input type="text" class="desc" value=""/>
				</label>
				<label>
					<p class="description">Press Link Title</p>
					<input type="text" class="title" value=""/>
				</label>
				<label>
					<p class="description">Press URL</p>
					<input type="text" class="url" value=""/>
				</label>
			</div>
		</div>
	</template>

	<br /><br /><hr /><br />

	<div id="wktheme-press-page-wrapper">
		<div class="wk-is-sortable">
			<?php
			if ( isset( $all_press['press'] ) ) {
				foreach ( $all_press['press']['items'] as $key ) {

					?>
					<div class="wk-element-block block-compact">
						<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
						<div class="thumbnail press-logo">
							<span style="position:absolute;z-index:-1; top:17%; left:33%;">Add Logo</span>
							<img class="thumb-img" src="<?php echo esc_url( $path . $key['logo'] ); ?>" />
							<input class="thumb-url" type="hidden" value="<?php echo esc_url( $path . $key['logo'] ); ?>"/>
						</div>
						<div>
							<label>
								<p class="description">Name</p>
								<input type="text" class="name" value="<?php echo esc_attr( $key['name'] ); ?>"/>
							</label>
							<label>
								<p class="description">Name & Date / Description</p>
								<input type="text" class="desc" value="<?php echo esc_attr( $key['desc'] ); ?>"/>
							</label>
							<label>
								<p class="description">Press Link Title</p>
								<input type="text" class="title" value="<?php echo esc_attr( $key['title'] ); ?>"/>
							</label>
							<label>
								<p class="description">Press URL</p>
								<input type="text" class="url" value="<?php echo esc_url( $key['url'] ); ?>"/>
							</label>
						</div>
					</div>
					<?php
				}
			}
			?>
		</div>
		<div class="blocks-container">
			<div class="add-block">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
		</div>
	</div>
	<?php
}

function _template_certification_tab() {

	$all_certi = get_option( 'wktheme-page-certification' );
	$all_certi = ( '' === $all_certi ) ? array() : $all_certi;
	$path      = wp_upload_dir()['baseurl'];
	_wk_get_notification_stip( 'Certification & Partners' );

	?>
	<p>
		<a target="_blank" href="<?php echo esc_url( get_permalink( get_page_by_path( 'certification' ) ) ); ?>">Go To Certification Page</a><br>
		<a target="_blank" href="<?php echo esc_url( get_permalink( get_page_by_path( 'partners' ) ) ); ?>">Go To Partners Page</a>
	</p>
	<button id="save-icons" class="button button-primary">UPDATE</button>
	<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />

	<template id="wk-certification-template">
		<div class="wk-element-block">
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<div class="certi-logo">
				<span style="position:absolute;z-index:-1; top:40%; left:36%;">Add Logo</span>
				<img class="thumb-img" src="" />
				<input class="thumb-url" type="hidden" value=""/>
			</div>
			<div class="certi-content">
				<label>
					<p class="description">Name</p>
					<input type="text" class="name" value=""/>
				</label>
				<label>
					<p class="description">Link (Optional)</p>
					<input type="text" class="link" value=""/>
				</label>
				<label class="filter-val">
					<p class="description">Mark it as-</p>
					<label><input type="radio" name="{{rand}}" data-name="filter" value="certificate" checked />Certificate</label><br>
					<label><input type="radio" name="{{rand}}" data-name="filter" value="partner" />Partner</label>
				</label>
				<label class="block">
					<p class="description">Description</p>
					<textarea cols="51" class="desc"></textarea>
				</label>
			</div>
		</div>
	</template>

	<br /><br /><hr /><br />

	<div id="wktheme-certification-page-wrapper">
		<div class="wk-is-sortable">
			<?php
			if ( isset( $all_certi['certification'] ) ) {
				foreach ( $all_certi['certification']['items'] as $idx => $key ) {

					?>
					<div class="wk-element-block">
						<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
						<div class="certi-logo">
							<span style="position:absolute;z-index:-1; top:40%; left:36%;">Add Logo</span>
							<img class="thumb-img" src="<?php echo esc_url( $path . $key['logo'] ); ?>" />
							<input class="thumb-url" type="hidden" value="<?php echo esc_url( $path . $key['logo'] ); ?>"/>
						</div>
						<div class="certi-content">
							<label>
								<p class="description">Name</p>
								<input type="text" class="name" value="<?php echo esc_attr( $key['name'] ); ?>"/>
							</label>
							<label>
								<p class="description">Link (Optional)</p>
								<input type="text" class="link" value="<?php echo esc_url( $key['link'] ); ?>"/>
							</label>
							<label class="filter-val">
								<p class="description">Mark it as-</p>
								<label><input type="radio" name="filter-<?php echo esc_attr( $idx ); ?>" data-name="filter" value="certificate" <?php checked( 'certificate', $key['filter'] ); ?> />Certificate</label><br>
								<label><input type="radio" name="filter-<?php echo esc_attr( $idx ); ?>" data-name="filter" value="partner" <?php checked( 'partner', $key['filter'] ); ?> />Partner</label>
							</label>
							<label class="block">
								<p class="description">Description</p>
								<textarea cols="51" class="desc"><?php echo esc_attr( $key['desc'] ); ?></textarea>
							</label>
						</div>
					</div>
					<?php
				}
			}
			?>
		</div>
		<div class="blocks-container">
			<div class="add-block">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
		</div>
	</div>
	<?php
}
function wk_get_all_infra_template( $all_infra, $content ) {
	$path    = wp_upload_dir()['baseurl'];
	$id      = isset( $content['id'] ) ? $content['id'] : '';
	$heading = isset( $content['heading'] ) ? $content['heading'] : '';
	?>
	<div class="half-part">
		<h2><span class="dashicons dashicons-plus-alt wk-infra-handle"></span><?php echo esc_attr( $heading ); ?></h2>
		<div class="wk-infra-block-wrap display-none">
			<div class="wk-is-sortable">
			<?php
			if ( isset( $all_infra['infrastructure'] ) ) {
				foreach ( $all_infra['infrastructure']['items'] as $idx => $key ) {
					if ( ! $key['logo'] || $id !== $key['region'] ) {
						continue;
					}
					?>
					<div class="wk-element-block" data-region='<?php echo $id; ?>'>
						<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
						<div class="icon">
							<img class="thumb" src="<?php echo esc_url( $path . $key['logo'] ); ?>" />
							<input type="hidden" class="thumb-url" value="<?php echo esc_url( $path . $key['logo'] ); ?>" />
						</div>
					</div>
					<?php
				}
			}
			?>
		</div>
		<div class="blocks-container">
			<div class="add-block" id="<?php echo esc_attr( $id ); ?>">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
		</div>
	</div>
</div>
	<?php
}
function _template_infrastructure_tab() {

	$all_infra = get_option( 'wktheme-page-infrastructure' );
	// $all_infra = update_option( 'wktheme-page-infrastructure', '' );
	$all_infra = ( '' === $all_infra ) ? array() : $all_infra;
	$path      = wp_upload_dir()['baseurl'];
	_wk_get_notification_stip( 'Infrastructure' );
	?>

	<p><a target="_blank" href="<?php echo esc_url(  get_permalink( get_page_by_path( 'infrastructure' ) ) ); ?>">Go To Infrastructure Page</a></p>
	<button id="save-icons" class="button button-primary">UPDATE</button>
	<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />

	<template id="wk-infrastructure-template">
		<div class="wk-element-block" data-region={{region}}>
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<div class="icon">
				<img class="thumb" src="{{img_url}}" />
				<input type="hidden" class="thumb-url" value="{{img_url}}" />
			</div>
		</div>
	</template>

	<br /><br /><hr /><br />

	<div id="wktheme-infrastructure-page-wrapper">
		<h2>Drag to Sort</h2>
		<div class="wk-is-sortable">
			<?php
			$path    = wp_upload_dir()['baseurl'];
			$heading = '';
			$region  = '';
			$id      = '';
			$i       = 0;
			$region  = array();
			$region_all = array(
				'italy'     => 'italy',
				'india'     => 'india',
				'india-new' => 'india-new',
			);
			if ( isset( $all_infra['infrastructure'] ) ) {
				foreach ( $all_infra['infrastructure']['items'] as $idx => $key ) {
					$region[ $key['region'] ] = $key['region'];
				}
			}
			$result = array_diff( $region_all, $region );
			if ( ! empty( $result ) ) {
				foreach ( $result as $key => $value ) {
					$region[ $key ] = $key;
				}
			}
			foreach ( $region as $key => $value ) {
				switch ( $key ) {
					case 'italy':
						wk_get_all_infra_template(
							$all_infra,
							array(
								'id'      => 'italy',
								'heading' => 'Corbetta, Branch Office Italy',
							)
						);
						break;
					case 'india':
						wk_get_all_infra_template(
							$all_infra,
							array(
								'id'      => 'india',
								'heading' => 'Noida, Head Office India',
							)
						);
						break;
					case 'india-new':
						wk_get_all_infra_template(
							$all_infra,
							array(
								'id'      => 'india-new',
								'heading' => 'Noida, Branch Office India',
							)
						);
						break;
					default:
						break;
				}
			}
		?>
		</div>
	</div>
	<?php
}

function _template_events_tab() {

	$all_certi = get_option( 'wktheme-page-events' );
	$all_certi = ( '' === $all_certi ) ? array() : $all_certi;
	$path      = wp_upload_dir()['baseurl'];
	( 'Events' );

	?>
	<p>
		<a target="_blank" href="<?php echo esc_url( get_permalink( get_page_by_path( 'events' ) ) ); ?>">Go To Events Page</a><br>
	</p>
	<button id="save-icons" class="button button-primary">UPDATE</button>
	<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />

	<template id="wk-events-template">
		<div class="wk-element-block">
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<div class="events-logo">
				<span style="position:absolute;z-index:-1; top:40%; left:36%;">Add Logo</span>
				<img class="thumb-img" src="" />
				<input class="thumb-url" type="hidden" value=""/>
			</div>
			<div class="events-content">
				<label class="event-select">
					<p class="description">Type</p>
					<select class="events-type" style="width: 108px;">
						<option value="event">Event</option>
						<option value="meetup">Meetup</option>
					</select>
				</label>
				<label>
					<p class="description">Webkul As</p>
					<select class="events-as" style="width: 108px;">
						<option value="attendee">Attendee</option>
						<option value="organiser">Organiser</option>
					</select>
				</label>
				<label class="events-label">
					<p class="description">Extra Label</p>
					<input type="text" name="event-extra-label" class="event-extra-label" value="" />
				</label>
				<br />
				<label>
					<p class="description">Name</p>
					<input type="text" class="name" value=""/>
				</label>
				<label>
					<p class="description">Link (Optional)</p>
					<input type="text" class="link" value=""/>
				</label>
				<br />
				<label>
					<p class="description">Address</p>
					<input type="text" class="add" value=""/>
				</label>
				<label>
					<p class="description">Date</p>
					<input type="text" class="date" value="" placeholder="eg. november 28, 2018"/>
				</label>
			</div>
		</div>
	</template>

	<br /><br /><hr /><br />

	<div id="wktheme-events-page-wrapper">
		<div class="wk-is-sortable">
			<?php
			if ( isset( $all_certi['events'] ) ) {
				foreach ( $all_certi['events']['items'] as $idx => $key ) {
					if ( ! $key['logo'] || ! $key['name'] ) {
						continue;
					}
					?>
					<div class="wk-element-block">
						<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
						<div class="events-logo">
							<span style="position:absolute;z-index:-1; top:40%; left:36%;">Add Logo</span>
							<img class="thumb-img" src="<?php echo esc_url( $path . $key['logo'] ); ?>" />
							<input class="thumb-url" type="hidden" value="<?php echo esc_url( $path . $key['logo'] ); ?>"/>
						</div>
						<div class="events-content">
							<label>
								<p class="description">Type</p>
								<select class="events-type" style="width: 108px;">
									<option value="event" <?php echo ( isset( $key['type'] ) && $key['type'] === 'event') ? 'selected="selected"' : ''; ?>>Event</option>
									<option value="meetup" <?php echo ( isset( $key['type'] ) && $key['type'] === 'meetup') ? 'selected="selected"' : ''; ?>>Meetup</option>
									<option value="conference" <?php echo ( isset( $key['type'] ) && $key['type'] === 'conference') ? 'selected="selected"' : ''; ?>>Conference</option>
								</select>
							</label>
							<label>
								<p class="description">Webkul As</p>
								<select class="events-as" style="width: 108px;">
									<option value="attendee" <?php echo ( isset( $key['as'] ) && $key['as'] === 'attendee') ? 'selected="selected"' : ''; ?>>Attendee</option>
									<option value="organiser" <?php echo ( isset( $key['as'] ) && $key['as'] === 'organiser') ? 'selected="selected"' : ''; ?>>Organiser</option>
								</select>
							</label>
							<label class="events-label">
								<p class="description">Extra Label</p>
								<input type="text" name="event-extra-label" class="event-extra-label" value="<?php echo ( isset( $key['extra-label'] ) ) ? $key['extra-label'] : false; ?>" />
							</label>
							<!-- <label class="events-filter">
								<p class="description">Upcoming</p>
								<label><input type="checkbox" name="filter-<?php echo esc_attr( $idx ); ?>" data-name="status" value="upcoming" <?php checked( 'upcoming', $key['filter'] ); ?> />Upcoming</label>
							</label> -->
							<br />
							<label>
								<p class="description">Name</p>
								<input type="text" class="name" value="<?php echo esc_attr( $key['name'] ); ?>"/>
							</label>
							<label>
								<p class="description">Link (Optional)</p>
								<input type="text" class="link" value="<?php echo esc_url( $key['link'] ); ?>"/>
							</label>
							<br />
							<label>
								<p class="description">Address</p>
								<input type="text" class="add" value="<?php echo esc_attr( $key['add'] ); ?>"/>
							</label>
							<label>
								<p class="description">Date</p>
								<input type="text" class="date" placeholder="eg. november 28, 2018" value="<?php echo esc_attr( $key['date'] ); ?>"/>
							</label>
						</div>
					</div>
					<?php
				}
			}
			?>
		</div>
		<div class="blocks-container">
			<div class="add-block">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
		</div>
	</div>
	<?php
}
function _template_awards_tab() {
	$all_awards = get_option( 'wktheme-page-awards' );
	?>
	<p>
		<a target="_blank" href="<?php echo esc_url( get_permalink( get_page_by_path( 'awards' ) ) ); ?>">Go To Awards Page</a><br>
	</p>
	<button id="save-icons" class="button button-primary">UPDATE</button>
	<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />

	<br /><br /><hr /><br />
	
	<div id="wktheme-awards-page-wrapper">
		<div class="blocks-container">
			<div class="add-block">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
			<br /><br />
		</div>
		<?php
		if ( isset( $all_awards['awards'] ) ) {
			foreach ( $all_awards['awards']['items'] as $award ) {
				?>
				<div class="wk-element-block" style="display:block">
					<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
					<div class="awards-container" style="display: grid; grid-gap: 20px; grid-template-columns: 150px auto;">
						<div class="awards-row">
							<p class="description">Upload Image</p>
							<div class="_wk_image_uploader_" style="width:150px;height:180px;position: relative;">
								<img src="<?php echo ( ! empty( $award['image'] ) ) ? esc_url( wp_upload_dir()['baseurl'] . $award['image'] ) : false; ?>" class="wk_image_src" onerror="this.onerror=null;this.src = '<?php echo esc_url( get_template_directory_uri() . '/images/upload.png' ); ?>'" style="position: absolute; top: 0; bottom: 0; left: 0; right: 0; margin: auto; max-width: 90%;">
								<input type="hidden" class="wk_image_url" value="<?php echo ( ! empty( $award['image'] ) ) ? esc_url( wp_upload_dir()['baseurl'] . $award['image'] ) : false; ?>">
							</div>
						</div>
						<!-- <br/> -->
						<div class="award-row">
							<p class="description">Title</p>
							<input type="text" name="award-title" class="award-title" value="<?php echo ( ! empty( $award['title'] ) ) ? esc_html( $award['title'] ) : false; ?>">
							<p></p>
							<div style="display: grid; grid-template-columns: auto 155px 120px 80px;">
								<label >
									Link<br>
									<input type="text" name="award-link" class="award-link" value="<?php echo ( ! empty( $award['link'] ) ) ? esc_url( $award['link'] ) : false; ?>">
								</label>
								<label style="margin-right:50px">
									Open in New Tab<br>
									<select name="award-link" class="award-link-window" style="width: 104px; height: 30px;">
										<option <?php selected( 'no', $award['new-tab'] ); ?> value="no">No</option>
										<option value="yes" <?php selected( 'yes', $award['new-tab'] ); ?>>Yes</option>
									</select>
								</label>
								<label>
									Day & Months<br>
									<input type="text" placeholder="Eg. 31-12" class="award-date wk-day-month-picker" value="<?php echo ( ! empty( $award['date'] ) ) ? esc_html( $award['date'] ) : false; ?>">
								</label>
								<label>
									Year<br>
									<input type="text" pattern="\d*" maxlength="4" class="award-year" min="2000" max="2099" name="award-year" value="<?php echo ( ! empty( $award['year'] ) ) ? esc_html( $award['year'] ) : false; ?>">
								</label>
							</div>
							<p class="description">Content</p>
							<textarea style="resize:none;" class="award-content"><?php echo ( ! empty( $award['content'] ) ) ? esc_html( $award['content'] ) : false; ?></textarea>
						</div>
					</div>
				</div>
				<?php
			}
		}
		?>

	</div>
		
	<template id="wktheme-awards-page-tmpl">
		<div class="wk-element-block" style="display:block">
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<div class="awards-container" style="display: grid; grid-gap: 20px; grid-template-columns: 150px auto;">
				<div class="awards-row">
					<p class="description">Upload Image</p>
					<div class="_wk_image_uploader_" style="width:150px;height:180px;position: relative;">
						<img src="" class="wk_image_src" onerror="this.onerror=null;this.src = '<?php echo esc_url( get_template_directory_uri() . '/images/upload.png' ); ?>'" style="position: absolute; top: 0; bottom: 0; left: 0; right: 0; margin: auto; max-width: 90%;">
						<input type="hidden" class="wk_image_url">
					</div>
				</div>
				<!-- <br/> -->
				<div class="award-row">
					<p class="description">Title</p>
					<input type="text" name="award-title" class="award-title">
					<p></p>
					<div style="display: grid; grid-template-columns: auto 155px 120px 80px;">
						<label>
							Link<br>
							<input type="text" name="award-link" class="award-link">
						</label>
						<label style="margin-right:50px">
							Open in New Tab<br>
							<select name="award-link" class="award-link-window" style="width: 104px; height: 30px;">
								<option value="no">No</option>
								<option value="yes">Yes</option>
							</select>
						</label>


						<label>
							Day & Months<br>
							<input type="text" placeholder="Eg. 31-12" class="award-date wk-day-month-picker">
						</label>
						<label>
							Year<br>
							<input type="text" pattern="\d*" maxlength="4" class="award-year" min="2000" max="2099" name="award-year" value="<?php echo date("Y"); ?>">
						</label>
					</div>
					<p class="description">Content</p>
					<textarea style="resize:none;" class="award-content"></textarea>
				</div>
			</div>
		</div>
	</template>
	<?php
}

function _template_innovations_tab() {

	$all_press = get_option( 'wktheme-page-innovations' );
	$all_press = ( '' === $all_press ) ? array() : $all_press;
	$path      = wp_upload_dir()['baseurl'];
	
	var_dump($all_press);
	_wk_get_notification_stip( 'Innovations' );
	?>

	<p><a target="_blank" href="<?php echo esc_url( get_permalink( get_page_by_path( 'innovations' ) ) ); ?>">Go To Innovations Page</a></p>
	<button id="save-icons" class="button button-primary">UPDATE</button>
	<img style="display:none;" id="loader" src="<?php echo esc_url( site_url() . '/wp-includes/images/spinner.gif' ); ?>" />

	<template id="wk-innovation-template">
		<div class="wk-element-block">
			<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
			<wk-i-upload size="full">
				<img class="thumb" src="" />
				<input type="hidden" name="image" data-name="image" data-type="img" class="thumb-url" value="" />
			</wk-i-upload>
			<div>
				<br>
				<label>
					<p class="description">Name</p>
					<input type="text" class="name" value=""/>
				</label>
				<br>
				<label>
					<p class="description">Short description</p>
					<textarea class="desc"></textarea>
				</label>
				<br>
				<label>
					<p class="description">Youtube video link</p>
					<input type="text" class="link" value=""/>
				</label>
				<br>
				<label>
					<p></p>
					<span class="description">Show on homepage</span>
					&nbsp;&nbsp;<input type="checkbox" class="show-on-home" value="no"/>
				</label>
			</div>
		</div>
	</template>

	<br /><br /><hr /><br />

	<div id="wktheme-innovation-page-wrapper">
		<div class="blocks-container">
			<div class="add-block">
				<span class="dashicons dashicons-plus-alt"></span>
			</div>
			<br><Br>
		</div>
		<div class="wk-is-sortable">
			<?php
			if ( isset( $all_press['innovation'] ) ) {

				foreach ( $all_press['innovation']['items'] as $key ) {

					$poster = ! empty( $key['poster'] ) ? $path . $key['poster'] : '';
					?>
					<div class="wk-element-block">
						<span title="Remove" class="wk-remove-block dashicons dashicons-dismiss"></span>
						<wk-i-upload size="full">
							<img class="thumb" src="<?php echo $poster; ?>" />
							<input type="hidden" name="image" data-name="image" data-type="img" class="thumb-url" value="<?php echo $poster; ?>" />
						</wk-i-upload>
						<div>
							<label>
								<p class="description">Name</p>
								<input type="text" class="name" value="<?php echo esc_attr( $key['name'] ); ?>"/>
							</label>
							<label>
								<p class="description">Short description</p>
								<textarea class="desc"><?php echo esc_attr( $key['desc'] ); ?></textarea>
							</label>
							<label>
								<p class="description">Youtube video link</p>
								<input type="text" class="link" value="<?php echo esc_attr( $key['link'] ); ?>"/>
							</label>
							<label>
								<p></p>
								<span class="description">Show on homepage</span>
								&nbsp;&nbsp;
								<input type="checkbox" class="show-on-home" value="<?php echo $key['onhome']; ?>" <?php echo 'yes' === $key['onhome'] ? ' checked=checked' : ''; ?> />
							</label>
						</div>
					</div>
					<?php
				}
			}
			?>
		</div>
	</div>
	<?php
}




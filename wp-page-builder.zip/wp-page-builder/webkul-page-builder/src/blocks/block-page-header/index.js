/**
 * Register Custom Success Story Block
 */

registerBlockType( 'wk-blocks/header', {
    title : 'Header',
    icon : 'id',
    category: 'webkul',
    keywords: [ 'Header' ],
    parent: [ ['wk-blocks/layout-container'], ['wk-blocks/block-wrapper'] ],

    example: {},

    attributes: {
        title:{
            type:'array',
            source:'children',
            selector:'.page-title',
        },
        content:{
            type:'array',
            source:'children',
            selector:'.page-desc',
        },
        imgID:{
            type:'boolean'
        },
        imgALT:{
            type:'string'
        },
        imgURL:{
            type:'string'
        },
        layoutOption: {
            type:'string',
            default:'1'
        },
    },
    edit : function( props ) {
        var layoutOption = props.attributes.layoutOption;

        var layoutStruc = [
            [ 'core/heading', {"placeholder":"Page Heading","level":1} ],
            [ 'core/heading', {"placeholder":"Page Sub Heading","level":4} ],
            [ 'core/paragraph', {"placeholder":"Page Description"} ],
            [ 'core/button', {"backgroundColor":"primary", "borderRadius":8} ]
        ]
        if( '1' == layoutOption ) {
            var headerTemplate = [
				['wk-blocks/inline-inner-column', { "innerTemplate": JSON.stringify(layoutStruc), "className": "header-tagline" }],
				[ 'wk-blocks/inline-inner-column', {placeholder:'core/image',"className":"header-img"} ]
            ];
        } else {
            var headerTemplate = [
                [ 'wk-blocks/inline-inner-column', {"innerTemplate" : JSON.stringify(layoutStruc),"className":"header-tagline"} ],
                [ 'wk-blocks/inline-inner-column', {placeholder:'core/image',"className":"header-img"} ]
            ];
        }
        
        return el(
            Fragment,
            {},

            /**Sidebar Setting */
            el(
                InspectorControls,
                {},
                el(
                    PanelBody,
                    {
                        title:'Header Setting',
                        initial:true,
                    },
                    el(
                        PanelRow,
                        {},
                        el(
                            SelectControl,
                            {
                                label:'Layout Type',
                                value:layoutOption,
                                options:[
                                    { label:'Default', value:'1' },
                                    { label:'Lateral', value:'2' },
                                ],
                                onChange:( option ) => { props.setAttributes({layoutOption:option}) }
                            }
                        )
                    )
                )
            ),
            /** //Sidebar Setting */

            el(
                'div',
                {},
                el(
                    Dashicon,
                    {
                        icon:'admin-generic',
                        style:{
                            position:'absolute',
                            right:'-10px',
                            top:'-10px',
                            cursor:'pointer'
                        }
                    }
                ),
                el(
                    'div',
                    {
                        className: ( '1' == layoutOption ) ? 'component--page-header wkFlexGrid text-center' : 'component--page-header wkFlexGrid',
                    },
                    el(
                        InnerBlocks,
                        {
                            template:headerTemplate,
                            templateLock:'all',
                        }
                    ),
                ),
            )
        );
        /** //WP Fragment End */
    },

    save:function(props) {
        layoutOption = props.attributes.layoutOption
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className: ( '1' == layoutOption ) ? 'header-wrap header--view-default' :  'header-wrap header--view-alter',
                },
                el(InnerBlocks.Content),
            )
        );
    }


} );
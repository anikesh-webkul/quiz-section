registerBlockType( 'wk-blocks/inline-inner-column', {
    title : 'Inline inner Column',
    icon : 'controls-pause',
    category: 'webkul',
    parent: [ ['wk-blocks/inline-column'] ],
    example: {},

    attributes:{
        placeholder:{
            type:'string',
        },
        innerTemplate:{
            type:'string',
        },
        wkInserter:{
            type:'boolean',
            default:false
        }
    },

    edit : function( props ) {
        var innerTemplate = props.attributes.innerTemplate,
        wkInserter = props.attributes.wkInserter;
        if( props.attributes.placeholder && 'core/image' == props.attributes.placeholder ) {
            template = [ ['core/image'] ];
        } else {
            template = [
                ['core/heading'],
				['core/paragraph'],
				['wk-blocks/block-wrapper'],
                ['core/button'],
            ];
        }
        if( props.attributes.innerTemplate ) {
            template = JSON.parse(innerTemplate);
        }
        return (
           el(
               Fragment,
               {},
                el(
                    InspectorControls,
                    {},
                    el(
                        PanelBody,
                        {
                            title:'Block Setting',
                            initial:true,
                        },
                        el(
                            PanelRow,
                            {},
                            el(
                                ToggleControl,
                                {
                                    label:'Add/Prevent new block',
                                    checked:props.attributes.wkInserter,
                                    onChange:(changeInserter) => {
                                        props.setAttributes({wkInserter:changeInserter});
                                    },
                                },
                            ),
                        ),
                    )
               ),
               el(
                   'div',
                   {
                       style:{ border:'1px dotted #d3d3d3',position:'relative' }
                   },
                   
                   el(
                       InnerBlocks,
                       {
                           template:template,
                           templateLock:false,
                           allowedBlocks:wkInserter,
                           templateInsertUpdatesSelection:false
                       },
                   )
               ),
           )
        );
    },
    save:function(props) {
        return el(
            Fragment,
            {},
            el(
                'div',
                {
                    className:props.attributes.className,
                },
                el(
                    InnerBlocks.Content
                )
            )
        )
    }


} );
<?php


$groups = get_terms( array(
	'taxonomy' => 'technology-category',
) );

$tech_posts = get_posts( array(
	'post_type'   => 'technologies',
	'post_status' => 'publish',
) );

$tech_json_data = array();

foreach ( $tech_posts as $tech_post ) {

	$stats = maybe_unserialize( get_post_meta( $tech_post->ID, 'technology_data', true ) );
	$team_size = isset( $stats['teamsize'] ) ? $stats['teamsize'] : '';
	$projects  = isset( $stats['projects'] ) ? $stats['projects'] : '';
	$exp       = isset( $stats['exp'] ) ? $stats['exp'] : '';
	$tech_json_data[] = array(
		'id'            => $tech_post->ID,
		'slug'          => $tech_post->post_name,
		'name'          => $tech_post->post_title,
		'brief'         => $tech_post->description,
		'group'         => array(
			'name' => get_the_terms( $tech_post->ID, 'technology-category' )[0]->name,
			'slug' => get_the_terms( $tech_post->ID, 'technology-category' )[0]->slug,
		),
		'stat_exp'      => $exp,
		'stat_teamsize' => $team_size,
		'stat_projects' => $projects,
	);
}
?>
<section class="wktech-technology-page">
	<div class="wktech-page-header section-padding">
		<div class="wkgrid-wide">
			<h1>Technologies</h1>
			<p class="larger">We have expertise in an extensive range of astound technologies to build world class apps and extensions for enterprises and ventures.</p>
		</div>
	</div>
	<div class="wktech-page-content section-padding">
		<div class="wkgrid-wide">
		<?php
		foreach ( $groups as $group ) {
		?>
			<div class="wktech-group" id="tech-group-<?php echo esc_attr( $group->slug ); ?>">
				<div class="group-name">
					<h2><?php echo esc_html( $group->name ); ?></h2>
					<div class="desc"><?php echo esc_html( $group->description ); ?></div>
				</div>
				<div class="group-tech-list">
					<?php
					$techs_in_groups = array_filter( $tech_json_data, function( $data ) use ( $group ) {

						return $data['group']['slug'] === $group->slug;
					} );

					foreach ( $techs_in_groups as $idx => $tech_post ) {
						?>
						<a class="tech-info-block" route="<?php echo esc_html( $tech_post['slug'] ); ?>" id="wktech-route-<?php echo esc_html( $tech_post['slug'] ); ?>">
							<div class="inner-content">
								<div class="name"><?php echo esc_html( $tech_post['name'] ); ?></div>
								<div class="info"><?php echo esc_html( $tech_post['stat_exp'] ); ?> years experience</div>
								<div class="info"><?php echo esc_html( $tech_post['stat_projects'] ); ?> Projects</div>
							</div>
						</a>
						<?php
					}
					?>
				</div>
			</div>
			<?php
		}
		?>
		</div>
	</div>
</section>

<div class="wktech-single-overlay" id="__techOverlayScreenHolder" _overlay="false"></div>

<script type="text/template" id="__techOverlayScreenTMPL">

	<!-- <tmpl-vars>
		<var n="stat_exp" paint="if_exists"><span _stats_num="{{stat_exp}}" class="stats-round"><span class="txt">Years of Experience</span></span></var>

		<var n="stat_teamsize" paint="if_exists"><span _stats_num="{{stat_teamsize}}" class="stats-round"><span class="txt">Total Team Size</span></span></var>

		<var n="stat_projects" paint="if_exists"><span _stats_num="{{stat_projects}}" class="stats-round"><span class="txt">Live Projects</span></span></var>
	</tmpl-vars> -->

	<!-- <tmpl-vars>
	{
		stat_exp : `<span _stats_num="{{stat_exp}}" class="stats-round"><span class="txt">Years of Experience</span></span>`,

		stat_teamsize : `<span _stats_num="{{stat_teamsize}}" class="stats-round"><span class="txt">Total Team Size</span></span>`,

		stat_projects : `<span _stats_num="{{stat_projects}}" class="stats-round"><span class="txt">Live Projects</span></span>`
	}
	</tmpl-vars> -->

	<div class="wktech-single-wrapper">
		<div class="_controls-wrapper">
			<span class="wktech--controls --close" id="wktech-controls-close"></span>
			<span class="wktech--controls --prev" id="wktech-controls-prev"></span>
			<span class="wktech--controls --next" id="wktech-controls-next"></span>
		</div>
		<div class="wktech-single-content">
			<div class="wkgrid-squeezy text-center">
				<h2 class="name">{{name}}</h2>
				<p class="group">{{group_name}}</p>
				<div class="wktech-stats-block">
					<!-- @var(stat_exp) @var(stat_teamsize) @var(stat_projects) -->
					<span _stats_num="{{stat_exp}}" class="stats-round"><span class="txt">Years of Experience</span></span>
					<span _stats_num="{{stat_teamsize}}" class="stats-round"><span class="txt">Total Team Size</span></span>
					<span _stats_num="{{stat_projects}}" class="stats-round"><span class="txt">Live Projects</span></span>
				</div>
				<p class="wktech-brief">{{brief}}</p>
			</div>
		</div>
	</div>
</script>

<?php
echo '<script type="application/json" id="__wktechJsonDataStats">' . wp_json_encode( $tech_json_data ) . '</script>';
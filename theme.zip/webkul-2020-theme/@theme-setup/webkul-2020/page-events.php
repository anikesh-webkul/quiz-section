<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();

$all_certi = get_option( 'wktheme-page-events' );
$all_certi = ( '' === $all_certi ) ? array() : $all_certi;
$path      = wp_upload_dir()['baseurl'];

?>

<section class="wk-events-listing">
	<div class="wkgrid-squeezy">
		<div class="section-padding-0B">
			<img class="img-responsive" alt="Event Cover" src="<?php echo esc_url( get_template_directory_uri() . '/images/events/thumbs/event-cover.png' ); ?>" />
		</div>
		<div class="section-padding-0B">
			<h1>Events, MeetUps and<br />Conferences</h1>
			<p>We are hungry to meet like-minded people around the globe. We attend most of the international tech talks, conferences and seminars. We also organize a set of events for the local dev, design and marketing communities to share our thought process with them.</p>
			<p>We are quite social about learning and sharing our ideas with the community. You can see the glimpses of our presence below.</p>
		</div>
		<hr>
	</div>

	<div class="wkgrid-squeezy">
		<div class="section-padding-0B">
			<h2 class="text-center">Event Log</h2>
			<?php
			if ( isset( $all_certi['events'] ) ) {

				foreach ($all_certi['events']['items'] as $key => $value) {
					if ( $value['date'] ) {
						$past_date       = explode( ' ', $value['date'] );
						$month           = $past_date[0];
						$p_date          = explode( '-', $past_date[1] );
						$year            = $past_date[2];
						@$past_date_args = strtotime( $month . ' ' . $p_date[0] . ' ' . $year );
						$all_certi['events']['items'][$key]['sort'] = $past_date_args;
					} else {
						$all_certi['events']['items'][$key]['sort'] = '';
					}
				}

				usort( $all_certi['events']['items'], function( $a, $b ) {
					return $b['sort'] - $a['sort'];
				});

				foreach ( $all_certi['events']['items']  as $idx => $key ) {
					if ( ! $key['logo'] || ! $key['name'] ) {
						continue;
					}
			?>
				<div class="event-blocks">
					<?php
					if ( empty( $key['link'] ) ) {
						?>
						<img class="evt-thumbs" alt="<?php echo ( ! empty( $key['name'] ) ) ? $key['name'] : ''; ?>" title="<?php echo ( ! empty( $key['name'] ) ) ? $key['name'] : ''; ?>" src="<?php echo esc_url( $path . $key['logo'] ); ?>" />
						<?php
					} else {
						?>
						<a href="<?php echo esc_url( $key['link'] ); ?>" target="_blank" rel="noopener"><img class="evt-thumbs" alt="<?php echo ( ! empty( $key['name'] ) ) ? $key['name'] : ''; ?>" title="<?php echo ( ! empty( $key['name'] ) ) ? $key['name'] : ''; ?>" src="<?php echo esc_url( $path . $key['logo'] ); ?>" /></a>
						<?php
					}
					?>
					<div class="evt-info">
						<div class="labels">
							<span class="evt-type"><?php echo ( ! empty( $key['type'] ) ) ? $key['type'] : ''; ?></span>
							<span class="evt-part <?php echo ( ! empty( $key['as'] ) && $key['as'] === 'attendee') ? 'attn' : 'org'; ?>"><?php echo ( ! empty( $key['as'] ) ) ? $key['as'] : ''; ?></span>
							<?php
							if( ! empty( $key['extra-label'] ) ) {
								?>
								<span class="evt-part <?php echo ( ! empty( $key['as'] ) && $key['as'] === 'attendee') ? 'org' : 'attn'; ?>"><?php echo $key['extra-label']; ?></span>
								<?php
							}
							?>
						</div>
						<?php
						if ( empty( $key['link'] ) ) {
							?>
							<p class="evt-link"><?php echo $key['name']; ?></p>
							<?php
						} else {
							?>
							<a class="evt-link" href="<?php echo esc_url( $key['link'] ); ?>" target="_blank" rel="noopener"><?php echo ( ! empty( $key['name'] ) ) ? $key['name'] : ''; ?></a>
							<?php
						}
						?>
						<div class="evt-meta">
							<span class="place"><?php echo ( ! empty( $key['add'] ) ) ? $key['add'] : ''; ?></span>
							<?php
							$date         = $key['sort'];
							$today        = strtotime( 'now' );
							$event_status = ( $today < $date ) ? 'true' : 'false';
							?>
							<span event-status="<?php echo esc_attr( $event_status ); ?>" class="date"><?php echo ( ! empty( $key['date'] ) ) ? $key['date'] : ''; ?></span>

							<!-- <span event-status="<?php echo ( ! empty( $key['filter'] ) ) ? 'true' : 'false'; ?>" class="date"><?php echo ( ! empty( $key['date'] ) ) ? $key['date'] : ''; ?></span> -->
						</div>
					</div>
				</div>
			<?php
				}
			}
			?>
		</div>
	</div>

</section>

<?php
get_footer();

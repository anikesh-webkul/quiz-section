<?php
if (!defined('ABSPATH')) {
	exit;
}
global $wpdb;
$table_name = $wpdb->prefix . 'technology';
if ( $wpdb->get_var("show tables like '$table_name'") != $table_name) {
	$sql = "CREATE TABLE $table_name (
			id int(11) NOT NULL auto_increment,
			tech_name varchar(255) NOT NULL,
			tech_type varchar(255) NOT NULL,
			tech_team varchar(255),
			PRIMARY KEY (`id`)
		);";

	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($sql);
}
function wk_tech_list()
{
	if (!class_exists('Team_List_Table')) {
		require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
	}

	if (!class_exists('Technology_List_Table')) {
		class Technology_List_Table extends WP_List_Table
		{

			function __construct()
			{

				parent::__construct(array(

					'singular'  => 'tech_list',     //singular name of the tech records
					'plural'    => 'all_tech_list',    //plural name of the tech records
					'ajax'      => false,
				));

				/* Repair action - converting data to POST_TYPE*/
				if ( isset( $_GET['repair_action'] ) && 'tech' == $_GET['repair_action'] ) {

					$data = $this->fetch_team_data();

					echo '<pre>';
					foreach ( $data as $tech ) {
						$cat_slug       = sanitize_title( $tech['tech_type'] );
						$term           = get_term_by( 'slug', $cat_slug, 'technology-category' );
						if ( $term ) {
							$cat_id = get_term_by( 'slug', $cat_slug, 'technology-category' )->term_id;
						} else {
							$newly_cat_ids = wp_insert_term( $tech['tech_type'], 'technology-category', array( 'slug' => $cat_slug ) );
							$cat_id        = $newly_cat_ids['term_id'];

							echo 'New Category created : ' . $tech['tech_type'] . '<br/>';
						}
						$post_slug_tobe = sanitize_title( $tech['tech_name'] );
						$posts_exists   = get_page_by_path( $post_slug_tobe, OBJECT, 'technologies' );

						if ( is_null( $posts_exists ) ) {
							$post_id = wp_insert_post( array(
								'post_type'   => 'technologies',
								'post_status' => 'publish',
								'post_title'  => $tech['tech_name'],
							) );
							echo 'New technology post created : ' . $tech['tech_name'] . '<br/>';
							wp_set_post_terms( $post_id, array( $cat_id ), 'technology-category', true );
							echo 'Category : ' . $tech['tech_type'] .' assigned to : ' . $tech['tech_name'] . '<br/><br/>';
						}
					}
					echo '</pre>';
					// die;
				}
				/* Repair action*/
			}

			public function prepare_items()
			{

				global $wpdb;
				$columns  = $this->get_columns();
				$sortable = $this->get_sortable_columns();
				$hidden   = $this->get_hidden_columns();

				$this->process_bulk_action();
				$data       = $this->fetch_team_data();
				$totalitems = count($data);
				$screen     = get_current_screen();
				$option     = $screen->get_option('per_page', 'option');
				$per_page   = $this->get_items_per_page('toplevel_page_wk_tech_per_page');

				$this->_column_headers = array($columns, $hidden, $sortable);

				if (empty($per_page) || $per_page < 1) {
					$per_page = $screen->get_option('per_page', 'default');
				}


				function usort_reorder($a, $b)
				{

					$orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'tech_name';
					$order   = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc';
					$result  = strcmp($a[$orderby], $b[$orderby]);
					return ('asc' === $order) ? $result : -$result;
				}

				usort($data, 'usort_reorder');

				$totalpages  = ceil($totalitems / $per_page);
				$currentpage = $this->get_pagenum();
				$data        = array_slice($data, (($currentpage - 1) * $per_page), $per_page);

				$this->set_pagination_args(array(
					'total_items' => $totalitems,
					'total_pages' => $totalpages,
					'per_page'    => $per_page,
				));

				$this->items = $data;
			}

			public function get_hidden_columns()
			{
				return array();
			}

			function column_cb($item)
			{

				return sprintf('<input type="checkbox" id="id_%s"name="id[]" value="%s" />', $item['id'], $item['id']);
			}

			function get_columns()
			{

				$columns = array(
					'cb'        => '<input type="checkbox" />',
					'tech_name' => __('Technology'),
					'tech_type' => __('Type'),
				);
				return $columns;
			}

			public function get_sortable_columns()
			{

				$sortable_columns = array(
					'tech_name' => array('tech_name', true),
					'tech_type' => array('tech_type', true),
				);

				return $sortable_columns;
			}

			private function fetch_team_data()
			{

				global $wpdb;
				$table_name = $wpdb->prefix . 'technology';
				$data = array();

				if (isset($_GET['s'])) {

					$search    = $_GET['s'];
					$search    = trim($search);
					$team_data = $wpdb->get_results("SELECT * FROM $table_name WHERE tech_name LIKE '%$search%' ", ARRAY_A);
				} else {
					$team_data = $wpdb->get_results("SELECT * FROM $table_name ", ARRAY_A);
				}

				return $team_data;
			}

			function get_bulk_actions()
			{

				$actions = array(
					'trash'    => 'Move To Trash',
				);
				return $actions;
			}

			public function process_bulk_action()
			{

				global $wpdb;
				$table_name = $wpdb->prefix . 'technology';

				if ('trash' === $this->current_action()) {
					if (isset($_GET['id'])) {
						if (is_array($_GET['id'])) {
							foreach ($_GET['id'] as $id) {

								if (!empty($id)) {
									$wpdb->query("DELETE FROM $table_name WHERE id IN ($id)");
								}
							}
						} else {
							if (!empty($_GET['id'])) {
								$id = $_GET['id'];
								$wpdb->query("DELETE FROM $table_name WHERE id = $id");
							}
						}
					}
				}
			}

			public function column_default($item, $column_name)
			{

				switch ($column_name) {

					case 'tech_name':
					case 'tech_type':
						return $item[$column_name];
					default:
						return print_r($item, true);
				}
			}

			function column_tech_name($item)
			{

				$actions = array(
					'edit'  => sprintf('<a href="?page=tech-add-new&action=edit&id=%s">Edit</a>', $item['id']),
					'trash' => sprintf('<a href="?page=wk-tech&action=trash&id=%s">Delete</a>', $item['id']),
				);
				return sprintf('%1$s %2$s', $item['tech_name'], $this->row_actions($actions));
			}
		}
	}
}

function get_tech_type_list()
{
	global $wpdb;
	$table_name = $wpdb->prefix . 'technology';
	$tech_type_list = array();
	if ($wpdb->get_var("show tables like '$table_name'") == $table_name) {
		$team_data = $wpdb->get_results("SELECT DISTINCT tech_type FROM $table_name ");
		foreach ($team_data as $key => $value) {
			$tech_type_list[] = $value->tech_type;
			// code...
		}
	}
	return $tech_type_list;
}

function add_new_technology()
{
	$tech_type_list = get_tech_type_list();
	$tech_page      = site_url() . '/technology';
	?>
<h1>Add New Technology</h1>

<hr />
<?php

global $wpdb;
$table_name = $wpdb->prefix . 'technology';
$team_data = $wpdb->get_results("SELECT tech_type FROM $table_name ");

if (isset($_POST['wk_submit_technology'])) {
	$tech_name = sanitize_text_field($_POST['tech-name']);
	$tech_type = sanitize_text_field($_POST['tech-type']);
	$tech_team = 0;

	if (isset($_GET['action']) && 'edit' === $_GET['action']) {

		$data = array(
			'tech_name' => $tech_name,
			'tech_type' => $tech_type,
			'tech_team' => 0,
		);

		$cur_user     = $_GET['id'];
		$where        = array('id' => $cur_user);
		$format       = array('%s', '%s', '%s');
		$where_format = array('%d');
		$res = $wpdb->update($table_name, $data, $where, $format, $where_format);
		if ($res) {
			echo '<br /><br /><div class="notice notice-success is-dismissible">
				<p><strong>Technology Details Updated. </strong> <a href="' . esc_url($tech_page) . '" target="_blank"> view<a/></p>
				</div>';
		} else {
			echo '<br /><br /><div class="notice notice-error is-dismissible">
				<p><strong>An error occurred! Please try again.</strong></p>
				</div>';
		}
	} else {

		$res = $wpdb->insert(
			$table_name,
			array(
				'tech_name' => $tech_name,
				'tech_type' => $tech_type,
				'tech_team' => $tech_team,
			),
			array(
				'%s',
				'%s',
				'%s',
			)
		);
		if ($res) {
			echo '<br /><br /><div class="notice notice-success is-dismissible">
				<p><strong>New Technology Added. <a href="' . esc_url($tech_page) . '" target="_blank">view<a/></strong></p>
				</div>';
		} else {
			echo '<br /><br /><div class="notice notice-error is-dismissible">
				<p><strong>An error occurred! Please try again.</strong></p>
				</div>';
		}
	}
}
	if (!empty($_GET['id'])) {
		$button_text = 'Update Technology Data';
		$id          = $_GET['id'];
		$data        = $wpdb->get_results("SELECT * FROM $table_name WHERE id = '$id'", ARRAY_A);
		$data        = $data[0];
		$tech_name   = $data['tech_name'];
		$tech_type   = $data['tech_type'];
	} else {
		$button_text = 'Add Technology';
		$tech_name   = '';
		$tech_type   = '';
	}

?>


<form action="" method="post" id="wk_form_technology">
	<table class="form-table">
		<tbody>
			<tr>
				<th><label for="tech-name">Technology Name </label></th>
				<td><input type="text" id="tech-name" name="tech-name" placeholder="Technology Name" value="<?php echo wp_kses_post( $tech_name ); ?>" required></td>
			</tr>
			<tr>
				<th>
					<label for="tech-type">Technology Type </label>
				</th>
				<td>
					<select id="tech-type" name="tech-type">
						<?php foreach ( $tech_type_list as $key => $value ) {
							$selected = '';
							if ( ! empty( $tech_type ) && $tech_type == $value ) {
								$selected = "selected";
							}
							?>
						<option value="<?php echo wp_kses_post($value); ?>" <?php echo $selected; ?>><?php echo wp_kses_post( $value ); ?></option>
						<?php
					}
					?>
					</select>
					<a class="button button-secaondary" name="wk_add_technology" id="add-tech-btn">Add New </a>
					<input type="text" id="add-tech-type" style="display: none;" placeholder="Add New Technology Type" value="">
				</td>
			</tr>
		</tbody>
	</table>

	<button type="submit" class="button button-primary" name="wk_submit_technology"><?php echo wp_kses_post($button_text); ?></button>
</form>

<?php

}
function edit_technology_type() {
	$tech_type_list = get_tech_type_list();
	if ( isset( $_POST['wk_submit_technology'] ) ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'technology';
		unset( $_POST['wk_submit_technology'] );
		$result = 0;
		foreach ( $_POST as $key => $value ) {
			if ( $tech_type_list[ $key ] !== $_POST[ $key ] ) {
				$result = $wpdb->update( $table_name,
					array(
						'tech_type' => $_POST[ $key ],
					),
					array('tech_type' => $tech_type_list[ $key ] ),
					array('%s'),
					array(
					'%s'
					)
				);
			}
		}
		if ( $result ) {
			$tech_type_list = get_tech_type_list();
			echo '<br /><br /><div class="notice notice-success is-dismissible">
			<p><strong>Updated Technology Types </strong></p>
			</div>';
		} else {
			echo '<br /><br /><div class="notice notice-error is-dismissible">
			<p><strong>An error occurred! Please try again.</strong></p>
			</div>';
		}
	}
	if ( count( $tech_type_list ) ) {
		?>
		<h1>Click to edit Technology Type</h1>

		<hr />
		<form action="" method="post" id="wk_form_technology_type">
		<?php
		foreach ( $tech_type_list as $key => $value ) {
			echo '<br><input type="text" name="' . $key . '" value="' . $value . '">
			<br>';
		}
		?>
		<br>
		<button type="submit" class="button button-primary" name="wk_submit_technology">Update</button>
		</form>
		<?php
	}
}
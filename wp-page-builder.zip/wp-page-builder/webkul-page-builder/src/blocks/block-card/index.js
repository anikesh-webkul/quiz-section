registerBlockType('wk-blocks/card', {
	title: 'Cards',
	icon: 'excerpt-view',
	category: 'webkul',
	keywords: ['Cards'],
	parent: [['wk-blocks/layout-container'], ['wk-blocks/block-wrapper']],
	example: {},
	attributes: {
		cardLabel: {
			type: 'string',
			selector: 'p',
		},
		caption: {
			type: 'string',
			selector: 'p',
		},
		borderRadius: {
			type: 'number',
		},
		newWindow: {
			type: 'boolean',
		},
		cardLink: {
			type: 'string',
			source: 'attribute',
			attribute: 'href',
			selector: 'a',
		},
		imgID: {
			type: 'number',
		},
		imgALT: {
			type: 'string',
			source: 'attribute',
			attribute: 'alt',
			selector: 'img',
		},
		imgSrc: {
			type: 'string',
			source: 'attribute',
			attribute: 'src',
			selector: 'img',
		}
	},
	edit: function (props) {
		var cardLabel = props.attributes.cardLabel,
			caption = props.attributes.caption,
			newWindow = props.attributes.newWindow,
			cardLink = props.attributes.cardLink,
			imgID = props.attributes.imgID,
			imgALT = props.attributes.imgALT,
			imgSrc = props.attributes.imgSrc;
			borderRadius = props.attributes.borderRadius;

		const onRemoveImage = () => {
			props.setAttributes({
				imgSrc: null,
				imgID: null,
				imgALT: null,
			});
		};
		return (
			el(
				Fragment,
				{},
				el(
					InspectorControls,
					{},
					el(
						Panel,
						{},
						el(
							PanelBody,
							{
								title: 'Card Link',
							},
							el(
								PanelRow,
								{},
								el(
									TextControl,
									{
										type: "string",
										label: 'ADD URL',
										value: cardLink,
										onChange: (newLink) => {
											props.setAttributes({ cardLink: newLink });
										}
									}
								),
							),
							el(
								PanelRow,
								{},
								el(
									FormToggle,
									{
										checked: newWindow,
										onChange: (event) => {
											props.setAttributes({
												newWindow: event.target.checked,
											})
										},
									}
								),
								el(
									'span',
									{},
									'Open in New Tab'
								)
							),
						),
						el(
							PanelBody,
							{
								title: 'Styling',
								initialOpen: true,
							},
							el(
								RangeControl,
								{
									label: 'Border Radius',
									value: props.attributes.borderRadius,
									onChange: (data) => {
										props.setAttributes({ borderRadius: data })
									},
									min: 0,
									max: 20,
									help: 'Border value in pixel(px)',
									allowReset: true,
									initialPosition: 8,
								}
							),
						)
					)
				),
				el(
					'div',
					{
						className: 'wk-image-uploader',
					},
					el(
						MediaUpload,
						{
							buttonProps: {
								className: 'change-image'
							},
							onSelect: img => props.setAttributes({
								imgID: img.id,
								imgSrc: img.url,
								imgALT: img.alt ? img.alt : img.title
							}),
							allowed: ALLOWED_MEDIA_TYPES,
							type: "image",
							value: imgID,
							render: ({ open }) => el(
								Fragment,
								null,
								el(
									Button,
									{
										className: imgSrc ? 'wk-change-image' : 'wk-add-image',
										onClick: open
									},
									!imgSrc ? wkUploadIcon : el("img",
										{
											src: imgSrc,
											alt: imgALT,
										}
									)
								),
								imgSrc && el(
									Button,
									{
										className: "wk-remove-image",
										onClick: onRemoveImage
									},
									el(
										Dashicon,
										{
											icon: 'dismiss'
										}
									)
								)
							)
						}
					),
				),
				el(
					PlainText,
					{
						key: 'editable',
						tag: 'p',
						value: caption,
						placeholder: 'Caption...',
						onChange: (caption) => {
							props.setAttributes({ caption: caption });
						},
						style: {
							marginTop: '5px'
						}
					},
				),
				el(
					'span',
					{
						className: 'card-label'
					},
					el(
						PlainText,
						{
							key: 'editable',
							tag: 'p',
							value: cardLabel,
							placeholder: 'Card Label....',
							onChange: (cardLabel) => {
								props.setAttributes({ cardLabel: cardLabel });
							},
							style: {
								marginTop: '5px'
							}
						}
					)
				),
			)
		);
	},
	save: function (props) {

		let widgetStyle = {};
		widgetStyle['borderRadius'] = 8;
		(props.attributes.borderRadius) && (widgetStyle['borderRadius'] = props.attributes.borderRadius);

		let wrapperEl = (props.attributes.cardLink) ? 'a' : 'div';
		let wrapperElProps = (props.attributes.cardLink) ? {
			href: props.attributes.cardLink,
			className: 'block-card',
			title: props.attributes.cardLabel,
			target: (props.attributes.newContent) ? '_blank' : false,
			rel: (props.attributes.newContent) ? 'noopener noreferrer' : false,
			style: widgetStyle,
		} : {
				className: 'block-card no-link',
				title: props.attributes.cardLabel,
				style: widgetStyle,
			};
        
		return el(
			Fragment,
			{},
			el(
				wrapperEl,
				wrapperElProps,
				el(
					'img',
					{
						src: props.attributes.imgSrc,
						alt: props.attributes.imgALT,
						className: 'card-img',
						style: widgetStyle,
					},
				),
				el(
					'span',
					{
						className: 'link-title',
						'data-label': props.attributes.caption
					},
					el(
						'span', {
							className: 'card-label'
						},
						(props.attributes.cardLabel) ? (props.attributes.cardLabel).replace(/\r?\n/g, '&#10;') : (props.attributes.cardLabel)
					)
				)
            )
        )
    }
});

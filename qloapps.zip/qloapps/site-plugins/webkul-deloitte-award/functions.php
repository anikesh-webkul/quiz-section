<?php
/**
*   Plugin name: Webkul Deloitte Award Plugin
*   Description: Webkul Deloitte Award Plugin
*   Plugin URI: https://webkul.com/
*   Author: Webkul
*   Version: 1.0
*   Author URI: https://webkul.com/
*/

define( 'WDA_DIR', plugin_dir_url( __FILE__ ) );

add_action( 'wp_footer', 'add_award_content' );

function add_award_content() {

    if ( ! is_page( 'deloitte-award-winner-2017' ) ) {
        ?>
        <a style="background-image: url(<?php echo WDA_DIR . 'images/award-ribbon.png'; ?>); background-repeat: no-repeat; width:130px; height: 62px; display: block; position: fixed; left: 0px; top: 200px; z-index: 999999;"href="//webkul.com/deloitte-award-winner-2017/" target="_blank" class="deloitte"></a>

        <style>
        @media screen and (max-width: 841px){
            .deloitte{
                display: none !important;
            }
        }
        </style>
        <?php
    }

}

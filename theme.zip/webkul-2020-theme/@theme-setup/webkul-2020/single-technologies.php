<?php
/*
* @package webkul
* @subpackage webkul theme 2K18
* @since webkul theme 2.0
*/

get_header();

get_template_part( 'content', 'technology-template' );

get_footer();

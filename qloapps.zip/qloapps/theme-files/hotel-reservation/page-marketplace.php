<?php
get_header();
?>
	<!-- Banner Section -->
	<section class="banner-wrapper full-height">
	   <div class="banner-full-image marketplacepage full-height"></div>
		 <div class="banner-content">
				<div class="homepage-head banner-head-wrapper">
					<div class="content-align">
						<img src="<?php echo get_template_directory_uri().'/images/cover-logo.svg'?>" title="QLO" alt="QLO">
						<h2 class="new-h2">Marketplace</h2>
						<p class="white">Convert Your Hotel Booking Site into Multi Hoteliers Marketplace/OTA (Online Travel Agency)</p>
						<a class="get-it-now-btn-white" target="_blank" href="https://store.webkul.com/Qloapps-Marketplace.html" title="Download Qlo Marketplace">Get It Now<span class="glyphicon glyphicon-arrow-right"></span></a>
						<div><a href="https://prestashop.webkul.com/hotelcommerce-marketplace/en/module/marketplace/dashboard" target="_blank" rel="noopener" class="demo-link white">View Demo</a></div>
					</div>
				</div>
		 </div>
	</section>
	<!-- //Banner Section -->


	<!--banner image should be outside of "outer-wrapper" for full-height// -->
	<div class="outer-wrapper">

	<!-- About Section -->
	<section class="wk-about-section wk-common-padding" id="about">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-5 col-sm-6">
						<img class="img-responsive" src="<?php echo get_template_directory_uri().'/images/marketplace/marketplace.png';?>" alt="Qlo Marketplace" title="Qlo Marketplace">
        </div>
        <div class="col-md-5 col-sm-6">
          <div class="section-margin">
            <h1 class="new-h1">About Marketplace</h1>
            <p class="head-detail">Convert your hotel website into a marketplace of hotels. Add multiple hotel partners to your marketplace and let them the list and sell their hotel rooms at your hotel booking website.</p>
            <p class="head-detail">Through the marketplace, customers can select any number of rooms from not just one or two hotels, but several hotels at the same time.</p>
          </div>
        </div>
        <div class="col-md-1"></div>
      </div>
    </div>
  </section>
  <section class="divider">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8"><hr></div>
        <div class="col-md-2"></div>
      </div>
    </div>
  </section>
	<!-- //About Section -->


	<!-- Feature Section -->
	<section class="wk-feature-section wk-common-padding">
  <div class="container">

    <div class="row">
      <div class="col-md-12">
        <h1 class="text-center new-h1">Features</h1>
      </div>
      <div class="col-md-3"></div>
      <div class="col-md-6">
        <p class="text-center head-detail">QloApps marketplace is loaded with incredible features which will turn your website into the ultimate platform for online hotel booking.</p>
      </div>
      <div class="col-md-3"></div>
    </div>

    <div class="row text-center">
      <div class="col-md-4 col-sm-6 text-center">
        <div class="feature-box">
          <span class="img-responsive homepage marketplace" title="Launch Marketplace"></span>
          <h3 class="new-h3">Launch Marketplace</h3>
          <p class="head-detail">Launch your own marketplace of hotels and let hoteliers add an unlimited number of rooms.</p>
        </div>
			</div>
			<div class="col-md-4 col-sm-6 text-center">
        <div class="feature-box">
          <span class="img-responsive homepage hoteliers" title="Get More Hoteliers"></span>
          <h3 class="new-h3">Get More Hoteliers</h3>
          <p class="head-detail">Let other hoteliers join your marketplace and allow them to host their hotels.</p>
        </div>
			</div>
			<div class="col-md-4 col-sm-6 text-center">
        <div class="feature-box">
          <span class="img-responsive homepage commission" title="Earn Commission"></span>
          <h3 class="new-h3">Earn Commission</h3>
          <p class="head-detail">Earn commissions for successful bookings.</p>
        </div>
			</div>
  </div>
</div>

</section>
  <section class="divider">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8"><hr></div>
        <div class="col-md-2"></div>
      </div>
    </div>
  </section>
<!-- //Feature Section -->


<!--List Of Features -->
	<section class="wk-list-of_features-section wk-common-padding">
    <div class="container-fluid">

      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-4">
          <div class="margin-to-left">
            <h2 class="new-h2">Multiple Hoteliers</h3>
            <p class="head-detail">The marketplace allows you to add multiple hoteliers from around the world.
</p>
          </div>
        </div>
        <div class="col-md-6">
	         <img class="img-responsive" src="<?php echo get_template_directory_uri().'/images/marketplace/feature-1.png';?>" alt="Multi Hoteliers" title="Multi Hoteliers">
        </div>
      </div>

      <div class="row">
        <div class="col-md-2 col-md-push-10"></div>
        <div class="col-md-4 col-md-push-4">
          <div class="margin-to-right">
            <h2 class="new-h2">Earn Commision</h3>
            <p class="head-detail">Now sit back and relax while you earn commission from bookings made through your website.</p>
          </div>
        </div>
        <div class="col-md-6 col-md-pull-6">
         <img class="img-responsive" src="<?php echo get_template_directory_uri().'/images/marketplace/feature-2.png';?>" alt="Multi Hoteliers" title="Multi Hoteliers">
        </div>
      </div>

      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-4">
          <div class="margin-to-left">
            <h2 class="new-h2">Extra Hotels/Rooms Options</h3>
            <p class="head-detail">Customers can enjoy the hassle free and time saving option to add multiple hotel rooms to a single order.</p>
          </div>
        </div>
        <div class="col-md-6">
         <img class="img-responsive" src="<?php echo get_template_directory_uri().'/images/marketplace/feature-3.png';?>" alt="Multi Hoteliers" title="Multi Hoteliers">
        </div>
      </div>

      <div class="row">
        <div class="col-md-2 col-md-push-10"></div>
        <div class="col-md-4 col-md-push-4">
          <div class="margin-to-right">
            <h2 class="new-h2">More Guests/Customers Traffic</h3>
            <p class="head-detail">A large number of hotels and rooms in your marketplace will surely bring a considerable number of customers to your website.</p>
          </div>
        </div>
        <div class="col-md-6 col-md-pull-6">
         <img class="img-responsive" src="<?php echo get_template_directory_uri().'/images/marketplace/feature-4.png';?>" alt="Multi Hoteliers" title="Multi Hoteliers">
        </div>
      </div>

      <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6 text-center">
          <p class="get-it-now-p">What are you waiting for? Get started with your own hotel marketplace here!</p>
          <a href="https://store.webkul.com/Qloapps-Marketplace.html" class="get-it-now-btn white btn-bgcolor btn-download-ext">Get It Now <span class="glyphicon glyphicon-arrow-right"></span></a>
        </div>
        <div class="col-md-3"></div>
      </div>

    </div>
  </section>
    <section class="divider">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8"><hr></div>
        <div class="col-md-2"></div>
      </div>
    </div>
  </section>
<!--//List Of Features -->


	<!-- Video Section -->
	<section class="wk-teaser-video-section wk-common-padding" id="how-it-works">
	  <div class="container">
	    <div class="row">
	      <div class="col-md-2"></div>
	      <div class="col-md-8 text-center">
	        <h1 class="new-h1">How It Works</h1>
	        <p class="head-detail">Watch how the hotel marketplace system works</p>
	      </div>
	      <div class="col-md-2"></div>
	    </div>

	    <div class="row">
	      <div class="col-md-3"></div>
	      <div class="col-md-6 text-center">
	          <div class="video-wrapper">
	              <a href="#" class="open-video" data-toggle="modal" data-target="#videoModal" data-theVideo="https://www.youtube.com/embed/LyVmg-NhEX0" title="video teaser"><img src="<?php echo get_template_directory_uri().'/images/icon-play.png'?>" class="icon-play img-responsive"></a>
	          </div>
	      </div>
	      <div class="col-md-3"></div>
	    </div>

	    <div class="row">
	      <div class="col-md-12 text-center">
	        <div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModal" aria-hidden="true">
	            <div class="modal-dialog">
	                <div class="modal-content">
	                    <div class="modal-body">
	                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	                        <div>
	                            <iframe width="100%" height="350" src=""></iframe>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	      </div>
	    </div>

	  </div>
	</section>
	<!-- //Video Section -->


	<!-- Contact Section -->
	<?php display_contact_section('For further inquiry please contact us and we will happy to assist you.') ?>
	<!-- /Contact Section -->

<?php get_footer(); ?>
